/*
 *	Class:			AdminSelection
 *	Supports class:	AdminItem
 *	Purpose:		To process selections
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "AdminItem.h"
#include "SelectionList.h"

class AdminSelection
	{
	// Private constructible variables

	SelectionItem *firstSelectionItem_;

	CommonVariables *commonVariables_;
	AdminItem *admin_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	ResultType removeDuplicateSelection()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "removeDuplicateSelection";
		if( admin_->conditionList != NULL )
			{
			if( admin_->actionList != NULL )
				{
				if( admin_->conditionList->deleteActiveItemsWithCurrentSentenceNr() == RESULT_OK )
					{
					if( admin_->actionList->deleteActiveItemsWithCurrentSentenceNr() == RESULT_OK )
						{
						if( admin_->alternativeList != NULL )
							{
							if( admin_->alternativeList->deleteActiveItemsWithCurrentSentenceNr() != RESULT_OK )
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to remove the alternative of a selection" );
							}
						}
					else
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to remove the action of a selection" );
					}
				else
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to remove the condition of a selection" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The action list isn't created yet" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The condition list isn't created yet" );

		return commonVariables_->result;
		}

	SelectionItem *firstCondition()
		{
		if( admin_->conditionList != NULL )
			return admin_->conditionList->firstActiveSelectionItem();

		return NULL;
		}


	public:
	// Constructor

	AdminSelection( AdminItem *admin, WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		firstSelectionItem_ = NULL;

		admin_ = admin;
		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "AdminSelection" );

		if( commonVariables_ != NULL )
			{
		if( admin_ != NULL )
			{
			if( myWord_ == NULL )
				strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given admin is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	ResultType checkForDuplicateSelection()
		{
		SelectionResultType selectionResult;
		bool hasFoundDuplicateSelection = false;
		unsigned int duplicateConditionSentenceNr;
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkForDuplicateSelection";

		if( admin_->conditionList != NULL )
			{
			if( admin_->actionList != NULL )
				{
				if( ( selectionResult = admin_->conditionList->checkDuplicateCondition() ).result == RESULT_OK )
					{
					if( ( duplicateConditionSentenceNr = selectionResult.duplicateConditionSentenceNr ) > NO_SENTENCE_NR )
						{
						if( ( selectionResult = admin_->actionList->checkDuplicateSelectionPart( duplicateConditionSentenceNr ) ).result == RESULT_OK )
							{
							if( selectionResult.hasFoundDuplicateSelection )
								{
								if( admin_->alternativeList == NULL )
									hasFoundDuplicateSelection = true;
								else
									{
									if( ( selectionResult = admin_->alternativeList->checkDuplicateSelectionPart( duplicateConditionSentenceNr ) ).result == RESULT_OK )
										{
										if( selectionResult.hasFoundDuplicateSelection )
											hasFoundDuplicateSelection = true;
										}
									else
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check if the alternative selection part is duplicate" );
									}
								}

							if( hasFoundDuplicateSelection )
								{
								if( removeDuplicateSelection() != RESULT_OK )
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to remove a duplicate selection" );
								}
							}
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check if the action selection part is duplicate" );
						}
					}
				else
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check if the condition selection part is duplicate" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The action list isn't created yet" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The condition list isn't created yet" );

		return commonVariables_->result;
		}

	ResultType createSelectionPart( bool isAction, bool isAssignedOrClear, bool isDeactive, bool isArchived, bool isFirstComparisonPart, bool isNewStart, bool isNegative, bool isPossessive, bool isValueSpecification, unsigned short selectionLevel, unsigned short selectionListNr, unsigned short imperativeParameter, unsigned short prepositionParameter, unsigned short specificationWordParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int nContextRelations, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString )
		{
		SelectionResultType selectionResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "createSelectionPart";

		if( generalizationWordItem != NULL ||
		specificationString != NULL )
			{
			switch( selectionListNr )
				{
				case ADMIN_CONDITION_LIST:
					if( admin_->conditionList == NULL )
						{
						// Create list
						if( ( admin_->conditionList = new SelectionList( ADMIN_CONDITION_LIST_SYMBOL, myWord_, commonVariables_ ) ) != NULL )
							{
							commonVariables_->adminConditionList = admin_->conditionList;
							admin_->adminList[ADMIN_CONDITION_LIST] = admin_->conditionList;
							}
						else
							return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I failed to create an admin condition list" );
						}

					if( ( selectionResult = admin_->conditionList->createSelectionItem( isAction, isAssignedOrClear, isDeactive, isArchived, isFirstComparisonPart, isNewStart, isNegative, isPossessive, isValueSpecification, selectionLevel, imperativeParameter, prepositionParameter, specificationWordParameter, generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, generalizationContextNr, specificationContextNr, relationContextNr, nContextRelations, generalizationWordItem, specificationWordItem, relationWordItem, specificationString ) ).result == RESULT_OK )
						{
						if( firstSelectionItem_ == NULL )
							firstSelectionItem_ = selectionResult.lastCreatedSelectionItem;
						}
					else
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create a copy of a temporary generalization noun selection item in the admin condition list" );

					break;

				case ADMIN_ACTION_LIST:
					if( admin_->actionList == NULL )
						{
						// Create list
						if( ( admin_->actionList = new SelectionList( ADMIN_ACTION_LIST_SYMBOL, myWord_, commonVariables_ ) ) != NULL )
							{
							commonVariables_->adminActionList = admin_->actionList;
							admin_->adminList[ADMIN_ACTION_LIST] = admin_->actionList;
							}
						else
							return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I failed to create an admin action list" );
						}

					if( ( selectionResult = admin_->actionList->createSelectionItem( false, isAssignedOrClear, isDeactive, isArchived, isFirstComparisonPart, isNewStart, isNegative, isPossessive, isValueSpecification, selectionLevel, imperativeParameter, prepositionParameter, specificationWordParameter, generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, generalizationContextNr, specificationContextNr, relationContextNr, nContextRelations, generalizationWordItem, specificationWordItem, relationWordItem, specificationString ) ).result == RESULT_OK )
						{
						if( firstSelectionItem_ == NULL )
							firstSelectionItem_ = selectionResult.lastCreatedSelectionItem;
						}
					else
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create a copy of a temporary generalization noun selection item in the admin action list" );

					break;

				case ADMIN_ALTERNATIVE_LIST:
					if( admin_->alternativeList == NULL )
						{
						// Create list
						if( ( admin_->alternativeList = new SelectionList( ADMIN_ALTERNATIVE_LIST_SYMBOL, myWord_, commonVariables_ ) ) != NULL )
							{
							commonVariables_->adminAlternativeList = admin_->alternativeList;
							admin_->adminList[ADMIN_ALTERNATIVE_LIST] = admin_->alternativeList;
							}
						else
							return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I failed to create an admin alternative list" );
						}

					if( ( selectionResult = admin_->alternativeList->createSelectionItem( false, isAssignedOrClear, isDeactive, isArchived, isFirstComparisonPart, isNewStart, isNegative, isPossessive, isValueSpecification, selectionLevel, imperativeParameter, prepositionParameter, specificationWordParameter, generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, generalizationContextNr, specificationContextNr, relationContextNr, nContextRelations, generalizationWordItem, specificationWordItem, relationWordItem, specificationString ) ).result == RESULT_OK )
						{
						if( firstSelectionItem_ == NULL )
							firstSelectionItem_ = selectionResult.lastCreatedSelectionItem;
						}
					else
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create a copy of a temporary generalization noun selection item in the admin alternative list" );

					break;

				default:
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given list number is invalid: ", selectionListNr );
				}
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word or specification string is undefined" );

		return commonVariables_->result;
		}

	ResultType executeSelection( unsigned long endSolveProgress, SelectionItem *actionSelectionItem )
		{
		SelectionResultType selectionResult;
		bool isNewStart;
		bool isSatisfied;
		bool isWaitingForNewStart;
		bool isWaitingForNewLevel;
		bool waitForExecution;
		bool doneLastExecution;
		bool initializeVariables;
		unsigned short executionLevel;
		unsigned short executionListNr;
		unsigned short selectionLevel;
		unsigned short nSelectionExecutions = 0;
		unsigned int executionSentenceNr;
		WordItem *conditionWordItem;
		SelectionItem *conditionSelectionItem;
		SelectionItem *executionSelectionItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "executeSelection";

		do	{
			doneLastExecution = false;
			commonVariables_->isAssignmentChanged = false;

			if( ( conditionSelectionItem = firstCondition() ) != NULL )
				{
				isSatisfied = false;
				isWaitingForNewStart = false;
				isWaitingForNewLevel = false;
				waitForExecution = false;
				executionLevel = conditionSelectionItem->selectionLevel();
				executionSentenceNr = conditionSelectionItem->activeSentenceNr();

				do	{
					if( conditionSelectionItem == NULL ||
					executionSentenceNr != conditionSelectionItem->activeSentenceNr() )
						{
						executionListNr = ( isSatisfied ? ADMIN_ACTION_LIST : ADMIN_ALTERNATIVE_LIST );
						executionSelectionItem = NULL;

						if( isSatisfied )
							{
							if( admin_->actionList != NULL )
								executionSelectionItem = admin_->actionList->executionStartEntry( executionLevel, executionSentenceNr );
							}
						else
							{
							if( admin_->alternativeList != NULL )
								executionSelectionItem = admin_->alternativeList->executionStartEntry( executionLevel, executionSentenceNr );
							}

						if( executionSelectionItem != NULL )
							{
							initializeVariables = true;

							do	{
								if( admin_->executeImperative( initializeVariables, executionListNr, executionSelectionItem->imperativeParameter(), executionSelectionItem->specificationWordParameter(), executionSelectionItem->specificationWordTypeNr(), endSolveProgress, executionSelectionItem->specificationString(), executionSelectionItem->generalizationWordItem(), executionSelectionItem->specificationWordItem(), NULL, NULL, executionSelectionItem, actionSelectionItem ) == RESULT_OK )
									initializeVariables = false;
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to execute an imperative" );
								}
							while( !admin_->hasRequestedRestart() &&
							!commonVariables_->hasShownWarning &&
							( executionSelectionItem = executionSelectionItem->nextExecutionItem( executionLevel, executionSentenceNr ) ) != NULL );
							}

						if( conditionSelectionItem != NULL )	// Found new condition
							{
							isSatisfied = false;
							isWaitingForNewStart = false;
							isWaitingForNewLevel = false;
							waitForExecution = false;
							executionLevel = conditionSelectionItem->selectionLevel();
							}
						}

					if( conditionSelectionItem == NULL )
						doneLastExecution = true;
					else
						{
						isNewStart = conditionSelectionItem->isNewStart();
						selectionLevel = conditionSelectionItem->selectionLevel();

						if( isNewStart &&
						isWaitingForNewStart &&
						executionLevel == selectionLevel )	// Found new start
							isWaitingForNewStart = false;

						if( isWaitingForNewLevel &&
						executionLevel != selectionLevel )	// Found new level
							isWaitingForNewLevel = false;

						if( !isWaitingForNewStart &&
						!isWaitingForNewLevel &&
						!waitForExecution )
							{
							if( !isNewStart &&
							!isSatisfied &&
							executionLevel == selectionLevel )
								isWaitingForNewStart = true;	// Skip checking of this condition part and wait for a new start to come on this level
							else
								{
								if( isNewStart &&
								isSatisfied &&
								executionLevel == selectionLevel )
									isWaitingForNewLevel = true;		// Skip checking of this condition part and wait for a new level to come
								else
									{
									if( executionLevel != selectionLevel &&
									isSatisfied != conditionSelectionItem->isAction() )
										waitForExecution = true;	// Skip checking of this condition and wait for the next condition sentence number to come
									else
										{
										conditionWordItem = conditionSelectionItem->generalizationWordItem();

										if( conditionWordItem != NULL )
											{
											if( ( selectionResult = admin_->checkCondition( conditionSelectionItem ) ).result == RESULT_OK )
												{
												isSatisfied = selectionResult.isConditionSatisfied;
												executionLevel = selectionLevel;
												executionSentenceNr = conditionSelectionItem->activeSentenceNr();
												}
											else
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check the condition of word \"", conditionWordItem->anyWordTypeString(), "\"" );
											}
										else
											return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found an undefined condition word" );
										}
									}
								}
							}

						conditionSelectionItem = conditionSelectionItem->nextSelectionItem();
						}
					}
				while( !doneLastExecution &&
				!admin_->hasRequestedRestart() &&
				!commonVariables_->hasShownWarning );
				}
			}
		while( !admin_->hasRequestedRestart() &&
		!commonVariables_->hasShownWarning &&
		commonVariables_->isAssignmentChanged &&
		++nSelectionExecutions < MAX_SELECTION_EXECUTIONS );

		if( commonVariables_->isAssignmentChanged &&
		nSelectionExecutions == MAX_SELECTION_EXECUTIONS )
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I think there is an endless loop in the selections" );

		return commonVariables_->result;
		}
	};

/*************************************************************************
 *
 *	"Praise his name with dancing,
 *	accompanied by tambourine and harp.
 *	For the Lord delights in his people;
 *	he crowns the humble with victory." (Psalm 149:3-4)
 *
 *************************************************************************/
