/*
 *	Class:			AdminAssumption
 *	Supports class:	AdminItem
 *	Purpose:		To create assumptions autonomously
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "AdminItem.h"
#include "GeneralizationItem.cpp"
#include "SpecificationItem.cpp"

class AdminAssumption
	{
	// Private constructible variables

	SpecificationItem *foundAssumptionSpecificationItem_;
	SpecificationItem *foundOppositePossessiveSpecificationItem_;
	SpecificationItem *foundPossessiveSpecificationItem_;
	SpecificationItem *possessiveSpecificationItem_;
	SpecificationItem *anotherDefinitionSpecificationItem_;
	SpecificationItem *specificSpecificationItem_;

	WordItem *oppositePossessiveSpecificationWordItem_;
	WordItem *possessiveSpecificationWordItem_;

	CommonVariables *commonVariables_;
	AdminItem *admin_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	bool isAssumption( unsigned short justificationTypeNr )
		{
		return ( justificationTypeNr == JUSTIFICATION_TYPE_GENERALIZATION_ASSUMPTION_BY_GENERALIZATION ||
				justificationTypeNr == JUSTIFICATION_TYPE_GENERALIZATION_ASSUMPTION_BY_SPECIFICATION ||
				justificationTypeNr == JUSTIFICATION_TYPE_OPPOSITE_POSSESSIVE_CONDITIONAL_SPECIFICATION_ASSUMPTION ||
				justificationTypeNr == JUSTIFICATION_TYPE_BACK_FIRED_POSSESSIVE_CONDITIONAL_SPECIFICATION_ASSUMPTION ||
				justificationTypeNr == JUSTIFICATION_TYPE_SPECIFICATION_SUBSTITUTION_ASSUMPTION ||
				justificationTypeNr == JUSTIFICATION_TYPE_EXCLUSIVE_SPECIFICATION_SUBSTITUTION_ASSUMPTION ||
				justificationTypeNr == JUSTIFICATION_TYPE_SUGGESTIVE_QUESTION_ASSUMPTION );
		}

	ResultType findPossessiveSpecifications( unsigned int generalizationContextNr, unsigned int specificationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem )
		{
		SpecificationItem *possessiveSpecificationItem;
		SpecificationItem *previousPossessiveSpecificationItem = NULL;
		WordItem *possessiveSpecificationWordItem;
		WordItem *higherLevelPossessiveSpecificationWordItem = NULL;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findPossessiveSpecifications";

		foundPossessiveSpecificationItem_ = NULL;
		foundOppositePossessiveSpecificationItem_ = NULL;

		if( generalizationWordItem != NULL )
			{
			if( specificationWordItem != NULL )
				{
				// First try to find a possessive specification on a higher level
				if( ( possessiveSpecificationItem = generalizationWordItem->firstSpecificationButNotAQuestion() ) != NULL )
					{
					do	{
						if( possessiveSpecificationItem->isPossessive() &&
						!possessiveSpecificationItem->isExclusive() &&
						possessiveSpecificationItem->isSpecificationNoun() &&
						( possessiveSpecificationWordItem = possessiveSpecificationItem->specificationWordItem() ) != NULL )
							{
							if( possessiveSpecificationWordItem != higherLevelPossessiveSpecificationWordItem )
								{
								if( possessiveSpecificationWordItem->firstAssignmentOrSpecification( false, false, false, NO_QUESTION_PARAMETER, generalizationContextNr, specificationContextNr, NO_CONTEXT_NR, specificationWordItem ) != NULL )
									{
									if( higherLevelPossessiveSpecificationWordItem == NULL )
										higherLevelPossessiveSpecificationWordItem = possessiveSpecificationWordItem;
									else
										return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found at least two fitting higher level specification words for generalization word \"", specificationWordItem->anyWordTypeString(), "\": \"", higherLevelPossessiveSpecificationWordItem->anyWordTypeString(), "\" and \"", possessiveSpecificationWordItem->anyWordTypeString(), "\"" );
									}
								}
							}
						}
					while( ( possessiveSpecificationItem = possessiveSpecificationItem->nextSpecificationItemButNotAQuestion() ) != NULL );

					if( ( possessiveSpecificationItem = generalizationWordItem->firstSpecificationButNotAQuestion() ) != NULL )
						{
						if( possessiveSpecificationItem->hasSpecificationCollection() )
							{
							previousPossessiveSpecificationItem = NULL;

							if( higherLevelPossessiveSpecificationWordItem != NULL )
								specificationWordItem = higherLevelPossessiveSpecificationWordItem;

							// Try to find the opposite of the possessive specification
							do	{
								if( possessiveSpecificationItem->isPossessive() &&
								!possessiveSpecificationItem->isExclusive() &&
								possessiveSpecificationItem->specificationWordItem() != NULL &&
								possessiveSpecificationItem->specificationWordItem()->isSingularNoun() &&

								( foundOppositePossessiveSpecificationItem_ == NULL ||
								possessiveSpecificationItem->specificationWordItem() != foundOppositePossessiveSpecificationItem_->specificationWordItem() ) )
									{
									if( previousPossessiveSpecificationItem != NULL &&
									previousPossessiveSpecificationItem->specificationWordItem() != possessiveSpecificationItem->specificationWordItem() &&

									( possessiveSpecificationItem->specificationWordItem() == specificationWordItem ||
									previousPossessiveSpecificationItem->specificationWordItem() == specificationWordItem ) &&
									previousPossessiveSpecificationItem->specificationCollectionNr() == possessiveSpecificationItem->specificationCollectionNr() )
										{
										if( foundOppositePossessiveSpecificationItem_ == NULL )
											{
											foundPossessiveSpecificationItem_ = ( specificationWordItem == possessiveSpecificationItem->specificationWordItem() ? possessiveSpecificationItem : previousPossessiveSpecificationItem );
											foundOppositePossessiveSpecificationItem_ = ( specificationWordItem == possessiveSpecificationItem->specificationWordItem() ? previousPossessiveSpecificationItem : possessiveSpecificationItem );
											}
										else
											return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found at least two fitting opposite possessive specification words for generalization word \"", specificationWordItem->anyWordTypeString(), "\": \"", higherLevelPossessiveSpecificationWordItem->anyWordTypeString(), "\" and \"", previousPossessiveSpecificationItem->specificationWordItem()->anyWordTypeString(), "\"" );
										}

									previousPossessiveSpecificationItem = possessiveSpecificationItem;
									}
								}
							while( ( possessiveSpecificationItem = possessiveSpecificationItem->nextSpecificationItemButNotAQuestion() ) != NULL );
							}
						}
					}
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		return commonVariables_->result;
		}

	ResultType findPossessiveConditionalSpecificationAssumption( bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "findPossessiveConditionalSpecificationAssumption";
		if( myWord_->isNounWordType( specificationWordTypeNr ) )
			{
			if( generalizationWordItem != NULL )
				{
				if( specificationWordItem != NULL )
					{
					if( relationWordItem != NULL )
						{
						if( specificSpecificationItem_ != NULL )
							{
							if( admin_->isGeneralizationReasoningWordType( false, generalizationWordTypeNr ) )
								{
								if( possessiveSpecificationWordItem_ != NULL &&
								possessiveSpecificationWordItem_ != specificationWordItem )
									{
									if( possessiveSpecificationWordItem_->isSingularNoun() )
										{
										if( addAssumption( isDeactive, isArchived, isExclusive, isNegative, !isPossessive, JUSTIFICATION_TYPE_BACK_FIRED_POSSESSIVE_CONDITIONAL_SPECIFICATION_ASSUMPTION, NO_PREPOSITION_PARAMETER, relationWordTypeNr, WORD_TYPE_NOUN_SINGULAR, generalizationWordTypeNr, NO_COLLECTION_NR, NO_COLLECTION_NR, NO_COLLECTION_NR, generalizationContextNr, specificationContextNr, NULL, NULL, specificSpecificationItem_, relationWordItem, possessiveSpecificationWordItem_, generalizationWordItem ) != RESULT_OK )
											return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a possessive conditional specification assumption in relation word \"", relationWordItem->anyWordTypeString(), "\" to specification word \"", possessiveSpecificationWordItem_->anyWordTypeString(), "\"" );
										}
									else
										return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The back-fire opposite possessive specification word should be a singular noun" );
									}

								if( !commonVariables_->hasShownWarning &&
								oppositePossessiveSpecificationWordItem_ != NULL )
									{
									if( oppositePossessiveSpecificationWordItem_->isSingularNoun() )
										{
										if( possessiveSpecificationItem_ != NULL )
											{
											if( addAssumption( isDeactive, isArchived, isExclusive, isNegative, isPossessive, JUSTIFICATION_TYPE_OPPOSITE_POSSESSIVE_CONDITIONAL_SPECIFICATION_ASSUMPTION, NO_PREPOSITION_PARAMETER, relationWordTypeNr, WORD_TYPE_NOUN_SINGULAR, ( isPossessive ? WORD_TYPE_UNDEFINED : generalizationWordTypeNr ), NO_COLLECTION_NR, NO_COLLECTION_NR, NO_COLLECTION_NR, generalizationContextNr, specificationContextNr, possessiveSpecificationItem_, NULL, specificSpecificationItem_, relationWordItem, oppositePossessiveSpecificationWordItem_, ( isPossessive ? NULL : generalizationWordItem ) ) != RESULT_OK )
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a possessive conditional specification assumption from relation word \"", relationWordItem->anyWordTypeString(), "\" to specification word \"", oppositePossessiveSpecificationWordItem_->anyWordTypeString(), "\"" );
											}
										else
											return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The possessive specification item is undefined" );
										}
									else
										return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The opposite possessive specification word should be a singular noun" );
									}
								}
							}
						else
							return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The specific specification item is undefined" );
						}
					else
						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given relation word item is undefined" );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specfication word item is undefined" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word type isn't a noun" );

		return commonVariables_->result;
		}


	public:
	// Constructor

	AdminAssumption( AdminItem *admin, WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		foundAssumptionSpecificationItem_ = NULL;
		foundOppositePossessiveSpecificationItem_ = NULL;
		foundPossessiveSpecificationItem_ = NULL;
		possessiveSpecificationItem_ = NULL;
		anotherDefinitionSpecificationItem_ = NULL;
		specificSpecificationItem_ = NULL;

		oppositePossessiveSpecificationWordItem_ = NULL;
		possessiveSpecificationWordItem_ = NULL;

		admin_ = admin;
		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "AdminAssumption" );

		if( commonVariables_ != NULL )
			{
		if( admin_ != NULL )
			{
			if( myWord_ == NULL )
				strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given admin is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	void initializeAdminAssumptionVariables()
		{
		anotherDefinitionSpecificationItem_ = NULL;
		specificSpecificationItem_ = NULL;
		}

	ResultType addSuggestiveQuestionAssumption( bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, SpecificationItem *specificSpecificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addSuggestiveQuestionAssumption";

		if( specificSpecificationItem != NULL )
			{
			if( generalizationWordItem != NULL )
				{
				if( relationWordItem != NULL )
					{
					if( ( specificationResult = generalizationWordItem->findRelatedSpecification( false, false, isExclusive, isPossessive, NO_QUESTION_PARAMETER, specificSpecificationItem->specificationCollectionNr(), specificSpecificationItem->relationCollectionNr(), generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, relationWordItem, NULL ) ).result == RESULT_OK )
						{
						if( specificationResult.relatedSpecificationItem == NULL )
							{
							if( addAssumption( isDeactive, isArchived, isExclusive, isNegative, isPossessive, JUSTIFICATION_TYPE_SUGGESTIVE_QUESTION_ASSUMPTION, NO_PREPOSITION_PARAMETER, generalizationWordTypeNr, specificationWordTypeNr, WORD_TYPE_UNDEFINED, NO_COLLECTION_NR, NO_COLLECTION_NR, NO_COLLECTION_NR, generalizationContextNr, specificationContextNr, NULL, NULL, specificSpecificationItem, generalizationWordItem, specificationWordItem, NULL ) != RESULT_OK )
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create a suggestive question assumption in generalization word \"", generalizationWordItem->anyWordTypeString(), "\"" );
							}
						}
					else
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find out if generalization word \"", generalizationWordItem->anyWordTypeString(), "\" is related to the found specification" );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given relation word item is undefined" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specific specification item is undefined" );

		return commonVariables_->result;
		}

	ResultType findGeneralizationAssumptionBySpecification( bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int generalizationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem )
		{
		GeneralizationItem *currentGeneralizationItem;
		SpecificationItem *definitionSpecificationItem;
		SpecificationItem *specificSpecificationItem;
		WordItem *currentGeneralizationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findGeneralizationAssumptionBySpecification";

		if( myWord_->isNounWordType( specificationWordTypeNr ) )
			{
			if( generalizationWordItem != NULL )
				{
				if( specificationWordItem != NULL )
					{
					if( ( currentGeneralizationItem = specificationWordItem->firstActiveGeneralizationItemOfSpecification() ) != NULL )
						{
						do	{
							if( ( currentGeneralizationWordItem = currentGeneralizationItem->generalizationWordItem() ) != NULL )
								{
								if( currentGeneralizationWordItem->isNoun() &&
								!currentGeneralizationWordItem->hasCollection( NULL ) &&
								!currentGeneralizationWordItem->hasPossessiveSpecificationButNotAQuestion() &&
								currentGeneralizationWordItem != generalizationWordItem )
									{
									// Get definition specification for justification
									if( ( definitionSpecificationItem = currentGeneralizationWordItem->firstAssignmentOrSpecificationButNotAQuestion( false, true, true, true, true, isNegative, isPossessive, NO_COLLECTION_NR, generalizationContextNr, NO_CONTEXT_NR, NO_CONTEXT_NR, specificationWordItem ) ) != NULL )
										{
										if( !definitionSpecificationItem->isSpecificationGeneralization() )
											{
											// Get specific specification for justification
											if( ( specificSpecificationItem = generalizationWordItem->firstAssignmentOrSpecification( true, true, true, true, true, isNegative, isPossessive, NO_QUESTION_PARAMETER, definitionSpecificationItem->specificationCollectionNr(), definitionSpecificationItem->generalizationContextNr(), definitionSpecificationItem->specificationContextNr(), definitionSpecificationItem->relationContextNr(), definitionSpecificationItem->specificationWordItem(), definitionSpecificationItem->specificationString() ) ) != NULL )
												{
												if( addAssumption( isDeactive, isArchived, false, isNegative, isPossessive, JUSTIFICATION_TYPE_GENERALIZATION_ASSUMPTION_BY_SPECIFICATION, NO_PREPOSITION_PARAMETER, generalizationWordTypeNr, specificationWordTypeNr, WORD_TYPE_UNDEFINED, NO_COLLECTION_NR, NO_COLLECTION_NR, NO_COLLECTION_NR, generalizationContextNr, NO_CONTEXT_NR, definitionSpecificationItem, NULL, specificSpecificationItem, generalizationWordItem, currentGeneralizationWordItem, NULL ) != RESULT_OK )
													return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a generalization assumption in generalization word \"", generalizationWordItem->anyWordTypeString(), "\" to specification word \"", currentGeneralizationWordItem->anyWordTypeString(), "\"" );
												}
											}
										}
									}
								}
							else
								return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found an undefined generalization word" );
							}
						while( !commonVariables_->hasShownWarning &&
						( currentGeneralizationItem = currentGeneralizationItem->nextGeneralizationItemOfSpecification() ) != NULL );
						}
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word item is undefined" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word type isn't a noun" );

		return commonVariables_->result;
		}

	ResultType findGeneralizationAssumptionByGeneralization( bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, unsigned short specificQuestionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int generalizationContextNr, unsigned int relationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem )
		{
		GeneralizationItem *currentGeneralizationItem;
		SpecificationItem *definitionSpecificationItem;
		SpecificationItem *specificSpecificationItem;
		WordItem *currentGeneralizationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findGeneralizationAssumptionByGeneralization";

		if( admin_->isGeneralizationReasoningWordType( true, generalizationWordTypeNr ) )
			{
			if( myWord_->isNounWordType( specificationWordTypeNr ) )
				{
				if( generalizationWordItem != NULL )
					{
					if( specificationWordItem != NULL )
						{
						if( ( currentGeneralizationItem = specificationWordItem->firstActiveGeneralizationItemOfSpecification() ) != NULL )
							{
							do	{
								if( ( currentGeneralizationWordItem = currentGeneralizationItem->generalizationWordItem() ) != NULL )
									{
									if( currentGeneralizationWordItem != generalizationWordItem &&
									currentGeneralizationWordItem->isNoun() &&
									!currentGeneralizationWordItem->hasCollection( NULL ) &&
									!currentGeneralizationWordItem->hasPossessiveSpecificationButNotAQuestion() )
										{
										// Check for related specification
										// Get definition specification for justification
										if( ( definitionSpecificationItem = currentGeneralizationWordItem->firstAssignmentOrSpecificationButNotAQuestion( false, true, true, true, true, isNegative, isPossessive, NO_COLLECTION_NR, generalizationContextNr, NO_CONTEXT_NR, relationContextNr, specificationWordItem ) ) != NULL )
											{
											// Get specific specification for justification
											if( ( specificSpecificationItem = generalizationWordItem->firstAssignmentOrSpecification( true, true, true, true, true, isNegative, isPossessive, specificQuestionParameter, definitionSpecificationItem->generalizationContextNr(), definitionSpecificationItem->specificationContextNr(), definitionSpecificationItem->relationContextNr(), definitionSpecificationItem->specificationWordItem(), definitionSpecificationItem->specificationString() ) ) != NULL )
												{
												if( addAssumption( isDeactive, isArchived, false, isNegative, isPossessive, JUSTIFICATION_TYPE_GENERALIZATION_ASSUMPTION_BY_GENERALIZATION, NO_PREPOSITION_PARAMETER, generalizationWordTypeNr, specificationWordTypeNr, WORD_TYPE_UNDEFINED, NO_COLLECTION_NR, NO_COLLECTION_NR, NO_COLLECTION_NR, generalizationContextNr, NO_CONTEXT_NR, definitionSpecificationItem, NULL, specificSpecificationItem, generalizationWordItem, currentGeneralizationWordItem, NULL ) != RESULT_OK )
													return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a generalization assumption in generalization word \"", generalizationWordItem->anyWordTypeString(), "\" to specification word \"", currentGeneralizationWordItem->anyWordTypeString(), "\"" );
												}
											}
										}
									}
								else
									return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found an undefined generalization word" );
								}
							while( !commonVariables_->hasShownWarning &&
							( currentGeneralizationItem = currentGeneralizationItem->nextGeneralizationItemOfSpecification() ) != NULL );
							}
						}
					else
						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word is undefined" );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word type isn't a noun" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word type isn't a reasoning word type" );

		return commonVariables_->result;
		}

	ResultType findExclusiveSpecificationSubstitutionAssumption( bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem )
		{
		SpecificationResultType specificationResult;
		SpecificationItem *definitionSpecificationItem;
		SpecificationItem *foundSpecificationItem;
		WordItem *currentWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findExclusiveSpecificationSubstitutionAssumption";

		possessiveSpecificationItem_ = NULL;

		possessiveSpecificationWordItem_ = NULL;
		oppositePossessiveSpecificationWordItem_ = NULL;

		if( myWord_->isNounWordType( specificationWordTypeNr ) )
			{
			if( generalizationWordItem != NULL )
				{
				if( specificationWordItem != NULL )
					{
					if( relationWordItem != NULL )
						{
						if( ( specificationResult = generalizationWordItem->findSpecification( true, true, isNegative, isPossessive, NO_QUESTION_PARAMETER, generalizationContextNr, specificationContextNr, specificationWordItem, relationWordItem ) ).result == RESULT_OK )
							{
							if( ( foundSpecificationItem = specificationResult.foundSpecificationItem ) != NULL )
								{
								// Initially some wanted words are not linked. So, search in all words.
								if( ( currentWordItem = commonVariables_->firstWordItem ) != NULL )
									{
									do	{
										if( currentWordItem->isNoun() )
											{
											if( findPossessiveSpecifications( generalizationContextNr, specificationContextNr, currentWordItem, specificationWordItem ) == RESULT_OK )
												{
												if( foundPossessiveSpecificationItem_ != NULL )
													{
													possessiveSpecificationItem_ = foundPossessiveSpecificationItem_;

													if( ( possessiveSpecificationWordItem_ = possessiveSpecificationItem_->specificationWordItem() ) != NULL )
														{
														if( ( definitionSpecificationItem = possessiveSpecificationWordItem_->firstAssignmentOrSpecification( false, isNegative, isPossessive, NO_QUESTION_PARAMETER, generalizationContextNr, specificationContextNr, NO_CONTEXT_NR, specificationWordItem ) ) != NULL )
															{
															if( addAssumption( isDeactive, isArchived, false, isNegative, isPossessive, JUSTIFICATION_TYPE_EXCLUSIVE_SPECIFICATION_SUBSTITUTION_ASSUMPTION, NO_PREPOSITION_PARAMETER, generalizationWordTypeNr, WORD_TYPE_NOUN_SINGULAR, relationWordTypeNr, NO_COLLECTION_NR, NO_COLLECTION_NR, NO_COLLECTION_NR, generalizationContextNr, specificationContextNr, definitionSpecificationItem, NULL, foundSpecificationItem, generalizationWordItem, possessiveSpecificationWordItem_, relationWordItem ) == RESULT_OK )
																{
																if( specificSpecificationItem_ == NULL )
																	specificSpecificationItem_ = foundAssumptionSpecificationItem_;
																}
															else
																return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add an exclusive specification substitution assumption about generalization word \"", generalizationWordItem->anyWordTypeString(), "\" and possessive specification word \"", possessiveSpecificationWordItem_->anyWordTypeString(), "\"" );
															}
														}
													}

												if( !commonVariables_->hasShownWarning &&
												foundOppositePossessiveSpecificationItem_ != NULL &&
												( oppositePossessiveSpecificationWordItem_ = foundOppositePossessiveSpecificationItem_->specificationWordItem() ) != NULL )
													{
													if( specificSpecificationItem_ == NULL )
														{
														specificSpecificationItem_ = foundSpecificationItem;

														if( isPossessive )		// Find another definition
															anotherDefinitionSpecificationItem_ = possessiveSpecificationWordItem_->firstAssignmentOrSpecification( false, NO_QUESTION_PARAMETER, NO_CONTEXT_NR, specificationWordItem );
														}

													if( addAssumption( isDeactive, isArchived, false, isNegative, !isPossessive, JUSTIFICATION_TYPE_EXCLUSIVE_SPECIFICATION_SUBSTITUTION_ASSUMPTION, NO_PREPOSITION_PARAMETER, generalizationWordTypeNr, WORD_TYPE_NOUN_SINGULAR, relationWordTypeNr, NO_COLLECTION_NR, NO_COLLECTION_NR, NO_COLLECTION_NR, generalizationContextNr, specificationContextNr, foundOppositePossessiveSpecificationItem_, anotherDefinitionSpecificationItem_, specificSpecificationItem_, generalizationWordItem, oppositePossessiveSpecificationWordItem_, relationWordItem ) != RESULT_OK )
														return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add an exclusive specification substitution assumption about generalization word \"", generalizationWordItem->anyWordTypeString(), "\" and opposite possessive specification word \"", oppositePossessiveSpecificationWordItem_->anyWordTypeString(), "\"" );
													}
												}
											else
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find possessive specifications in word \"", currentWordItem->anyWordTypeString(), "\"" );
											}
										}
									while( !commonVariables_->hasShownWarning &&
									( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
									}
								else
									return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The first word item is undefined" );
								}

							if( !commonVariables_->hasShownWarning &&
							specificSpecificationItem_ != NULL )
								{
								if( findPossessiveConditionalSpecificationAssumption( isDeactive, isArchived, isExclusive, isNegative, isPossessive, generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, generalizationContextNr, specificationContextNr, generalizationWordItem, specificationWordItem, relationWordItem ) != RESULT_OK )
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find an exclusive specification substitution assumption with generalization word \"", generalizationWordItem->anyWordTypeString(), "\" and specification word \"", specificationWordItem->anyWordTypeString(), "\"" );
								}
							}
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find an assignment from generalization word \"", generalizationWordItem->anyWordTypeString(), "\" to specification word \"", specificationWordItem->anyWordTypeString(), "\"" );
						}
					else
						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given relation word item is undefined" );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word item is undefined" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word type isn't a noun" );

		return commonVariables_->result;
		}

	ResultType addAssumption( bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, unsigned short justificationTypeNr, unsigned short prepositionParamater, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, SpecificationItem *definitionSpecificationItem, SpecificationItem *anotherDefinitionSpecificationItem, SpecificationItem *specificSpecificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem )
		{
		JustificationResultType justificationResult;
		SpecificationResultType specificationResult;
		bool hasCreatedJustification = false;
		bool isAssignment = ( isDeactive || isArchived );
		bool isExclusiveSpecificationSubstitutionAssumption = false;
		unsigned int relationContextNr;
		JustificationItem *archiveJustificationItem;
		JustificationItem *specificationJustificationItem = NULL;
		SpecificationItem *createdSpecificationItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addAssumption";

		foundAssumptionSpecificationItem_ = NULL;

		if( generalizationWordItem != NULL )
			{
			if( specificationWordItem != NULL )
				{
				if( isAssumption( justificationTypeNr ) )
					{
					if( ( justificationResult = generalizationWordItem->addJustification( false, justificationTypeNr, 1, commonVariables_->currentSentenceNr, NULL, definitionSpecificationItem, anotherDefinitionSpecificationItem, specificSpecificationItem ) ).result == RESULT_OK )
						{
						if( ( specificationJustificationItem = justificationResult.foundJustificationItem ) == NULL )
							{
							hasCreatedJustification = true;
							specificationJustificationItem = justificationResult.createdJustificationItem;
							}

						if( specificationJustificationItem != NULL )
							{
							if( ( specificationResult = admin_->addSpecification( isAssignment, isDeactive, isArchived, isExclusive, isNegative, isPossessive, true, false, false, prepositionParamater, NO_QUESTION_PARAMETER, generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, generalizationCollectionNr, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, NO_CONTEXT_NR, 0, specificationJustificationItem, generalizationWordItem, specificationWordItem, relationWordItem, NULL ) ).result == RESULT_OK )
								{
								if( !commonVariables_->hasShownWarning )
									{
									createdSpecificationItem = specificationResult.createdSpecificationItem;
									foundAssumptionSpecificationItem_ = specificationResult.foundSpecificationItem;

									if( !isPossessive &&
									justificationTypeNr == JUSTIFICATION_TYPE_EXCLUSIVE_SPECIFICATION_SUBSTITUTION_ASSUMPTION )
										{
										isExclusiveSpecificationSubstitutionAssumption = true;
										specificSpecificationItem_ = createdSpecificationItem;
										}

									if( createdSpecificationItem == NULL )
										{
										if( isExclusiveSpecificationSubstitutionAssumption &&
										generalizationWordItem->isConfirmedAssumption() &&
										foundAssumptionSpecificationItem_ != NULL &&
										( archiveJustificationItem = foundAssumptionSpecificationItem_->foundSpecificSpecificationJustificationItem( relationWordItem ) ) != NULL )
											{
											if( generalizationWordItem->archiveJustification( foundAssumptionSpecificationItem_->hasExclusiveGeneralizationCollection(), archiveJustificationItem, specificationJustificationItem ) != RESULT_OK )
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to archive a justification item" );
											}
										else
											{
											// A justification has been created, but the assumption specification already exists.
											// So, the justification needs to be added separately
											if( hasCreatedJustification )
												{
												if( foundAssumptionSpecificationItem_ != NULL )
													{
													if( ( justificationResult = generalizationWordItem->checkForConfirmedJustifications( foundAssumptionSpecificationItem_->hasExclusiveGeneralizationCollection(), justificationTypeNr, specificationJustificationItem, definitionSpecificationItem, specificSpecificationItem, specificationWordItem ) ).result == RESULT_OK )
														{
														if( !justificationResult.hasFoundConfirmation )
															{
															// Add (attach) new created justification to the found specification
															if( generalizationWordItem->attachJustification( specificationJustificationItem, foundAssumptionSpecificationItem_ ) != RESULT_OK )
																return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to attach a justification to an assumption in generalization word \"", generalizationWordItem->anyWordTypeString(), "\"" );
															}
														}
													else
														return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check for confirmations in generalization word \"", generalizationWordItem->anyWordTypeString(), "\"" );
													}
												else
													// Check assumption for existence before calling this function - rather than deleting the just created justification
													return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I have created a justification, but it isn't used. Please check if the assumption already exists, before calling this function" );
												}
											}
										}
									else
										{
										// Check assumption for integrity
										if( generalizationWordItem->writeSelectedSpecification( true, true, false, false, NO_ANSWER_PARAMETER, createdSpecificationItem ) == RESULT_OK )
											{
											if( strlen( commonVariables_->writeSentenceString ) > 0 )
												{
												if( ( relationContextNr = createdSpecificationItem->relationContextNr() ) > NO_CONTEXT_NR )
													{
													if( admin_->collectGeneralizationWordWithPreviousOne( isExclusive, createdSpecificationItem->hasExclusiveGeneralizationCollection(), isPossessive, generalizationWordTypeNr, specificationWordTypeNr, NO_QUESTION_PARAMETER, relationContextNr, generalizationWordItem, specificationWordItem ) != RESULT_OK )
														return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to collect a generalization word with a previous one" );
													}
												}
											else
												return myWord_->startErrorInItem( functionNameString, moduleNameString_, "Integrity error! I couldn't write the created assumption with generalization word \"", generalizationWordItem->anyWordTypeString(), "\" and specification word \"", specificationWordItem->anyWordTypeString(), "\". I guess, the implementation of my writing modules is insufficient to write this particular sentence structure" );
											}
										else
											return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write the created assumption in generalization word \"", generalizationWordItem->anyWordTypeString(), "\" to check the writing integrity" );
										}

									if( myWord_->isNounWordType( specificationWordTypeNr ) &&

									( hasCreatedJustification ||
									createdSpecificationItem != NULL ) )
										{
										if( admin_->findSpecificationSubstitutionConclusionOrQuestion( true, isDeactive, isArchived, isExclusive, isNegative, isPossessive, false, NO_QUESTION_PARAMETER, generalizationWordTypeNr, specificationWordTypeNr, generalizationContextNr, specificationContextNr, generalizationWordItem, specificationWordItem ) != RESULT_OK )
											return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a specification substitution conclusion or question for generalization word \"", generalizationWordItem->anyWordTypeString(), "\"" );
										}
									}
								}
							else
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add an assumpted specification" );
							}
						else
							return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I couldn't find or create a specification justification" );
						}
					else
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a justification" );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given justification type number isn't an assumption" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		return commonVariables_->result;
		}
	};

/*************************************************************************
 *
 *	"He is my loving ally and my fortress,
 *	my tower of safety, my rescuer.
 *	He is my shield, and I take refuge in him.
 *	He makes the nations submit to me." (Psalm 144:2)
 *
 *************************************************************************/
