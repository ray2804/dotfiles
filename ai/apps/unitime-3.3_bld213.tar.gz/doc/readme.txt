Installation instructions are available at http://help.unitime.org/Timetabling_Installation.
For more information, please visit http://www.unitime.org/.