<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<?php
	
	
	/* Load the functions file */
	include_once 'objects.php';
	
	/* Switch determining what to show on this page,
	either the search box or the summary document. 
	*/
	if (isset($_GET["topic"])) {
		$mode = "sum";
	} else {
		if(isset($_GET["page"])){
			$mode = "page";
			$place = $_GET["page"];
		} else {
			$mode = "search";
		}
	}
	
?>
<html>
<?php 
	$page = "main";
	include_once 'head.php'; 
	echo $header_html;
	
	$cmdGen = new CommandGenerator();
	$linkGen = new LinkGenerator($main_page);
	$cmdExe = new CommandExecuter();
	$pgGen = new PageGenerator($main_page);
?>
<body>
	<?php
		if($mode == "search"){
		/* we want the search form to appear */
			/* show the links in the top right corner */
			echo "<div id=\"links\">";
			echo $linkGen->t_link().' | <a href="." onclick="showPage(\'add\');return false;">add file</a>'; //$linkGen->a_link();
			echo "</div>";
			/* show the logo */
			echo "<center>$logo_html</center>";
			echo "<div id=\"page\">";
			/* show the search form */
			echo $pgGen->summaryForm("$main_page");
			echo "</div>";
			/* determine to show files or not */
		} elseif($mode == "page"){
			echo "<div id=\"links\">";
			if($place == "add"){
				echo $linkGen->t_link().' | <a href="." onclick="showPage(\'main\');return false;">main</a>'; //$linkGen->a_link();
			} else {
				echo $linkGen->t_link().' | <a href="." onclick="showPage(\'add\');return false;">add file</a>'; //$linkGen->a_link();			
			}
			echo "</div>";
			/* show the logo */
			echo "<center>$logo_html</center>";
			echo "<div id=\"page\">";
			
			/* show the search form */
			if($place == "add"){ 
				echo $pgGen->addFilePage(); 
			} else { 
				echo $pgGen->summaryForm("index.php"); 
			}
			
			echo "</div>";
			/* determine to show files or not */
			
		} else {
			/* if we aren't searching, we are summarizing */
			$pgGen->summaryPage($cmdGen,$cmdExe);
		}
		
		/* Show add file results, if any */
		//if($mode == "search"){
		if(isset($_GET['userfile'])){
			echo '<h3 class="indented">file upload results</h3>';
			echo '<p class="indented">';
			echo "file: ".$_GET['userfile']."<br />";
			
			//$headers = get_headers($_GET['userfile'],1);
			//echo $headers;
			
			//if($headers["Content-Type"] == 'text/plain' ){
				//echo "file is okay!<br>";
			$fileAdder = new FileAdder();
			$cmd = $cmdGen->a_file($_GET['userfile']);
			//echo $cmd."<br>";
			$output = $fileAdder->storeFile($cmd,$cmdExe);
			foreach($output as $line)  echo "$line<br>";
			/*} else {
				echo '<font color="red">unacceptable file type, will not upload \''.$_GET['userfile'].'\'!</font><br>';
				if($header["Content-Type"] == ''){
					echo 'no content-type detected for this file!<br>';
				} else {
					echo 'file type for upload is \''.$headers["Content-Type"].'\'!<br>';
				}
				echo 'acceptable file types are: \'text/plain\'!<br>';
			}*/	
			echo '</p>';
		} 
		//}
		echo $foot_html;
		
		exit();
?>
