/* License/copyright: At the end of this file or read copyright.txt */

/*---------- Declarations --------------*/
long int weightresult(char *file,char *result,long int size_result,int nbkey,int width,int lvst,int k_cst);
int analyze_result(char *class_probable,char *result,char *best_result,int nb,int width,int method);
long int classfreqevol(char *file,char *text,long int *pos_sentence,int nbl,int histogram,int rec);
