package mysql_getdoc::h2;
use base qw(mysql_getdoc);
use strict;


1;
