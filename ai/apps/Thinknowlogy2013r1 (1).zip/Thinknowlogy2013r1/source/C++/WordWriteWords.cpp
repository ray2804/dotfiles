/*
 *	Class:			WordWriteWords
 *	Supports class:	WordItem
 *	Purpose:		To write the words of the sentences
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "GrammarItem.cpp"
#include "SpecificationItem.cpp"

class WordWriteWords
	{
	// Private constructible variables

	bool hasFoundAllSpecificationWords_;
	bool hasFoundAllSpecificationWordsBeforeConjunction_;
	bool hasFoundGeneralizationWord_;
	bool hasFoundSpecificationWord_;
	bool hasFoundQuestionVerb_;
	bool hasFoundSingleSpecificationWord_;
	bool hasFoundSpecificationGeneralizationVerb_;

	bool isUnknownPluralOfNoun_;
	bool isSkipClearWriteLevel_;
	bool relationNeedsToWaitForConjunction_;
	bool specificationNeedsToWaitForConjunction_;

	size_t generalizationStartWordPosition_;
	size_t specificationStartWordPosition_;

	SpecificationItem *lastFoundSpecificationItem_;

	WordItem *lastFoundRelationWordItem_;

	char *writeWordString_;

	char lastSpecificationString_[MAX_READ_WRITE_STRING_LENGTH];
	char previousSpecificationString_[MAX_READ_WRITE_STRING_LENGTH];

	CommonVariables *commonVariables_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	bool isSpecificationReasoningWordType( unsigned short specificationWordTypeNr )
		{
		return ( specificationWordTypeNr == WORD_TYPE_SYMBOL ||
				specificationWordTypeNr == WORD_TYPE_NUMERAL ||
				specificationWordTypeNr == WORD_TYPE_LETTER_SMALL ||
				specificationWordTypeNr == WORD_TYPE_LETTER_CAPITAL ||
				specificationWordTypeNr == WORD_TYPE_NOUN_SINGULAR ||
				specificationWordTypeNr == WORD_TYPE_NOUN_PLURAL );
		}

	ResultType writeGeneralizationWordToSentence( bool isPluralSpecificationGeneralization, unsigned short grammarWordTypeNr )
		{
		WordResultType wordResult;
		unsigned short generalizationWordTypeNr = grammarWordTypeNr;
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeGeneralizationWordToSentence";

		hasFoundGeneralizationWord_ = false;
		isUnknownPluralOfNoun_ = false;

		if( ( writeWordString_ = myWord_->activeWordTypeString( isPluralSpecificationGeneralization ? WORD_TYPE_NOUN_PLURAL : grammarWordTypeNr ) ) == NULL )
			{
			if( isPluralSpecificationGeneralization &&
			grammarWordTypeNr == WORD_TYPE_NOUN_PLURAL &&
			( writeWordString_ = myWord_->activeSingularNounString() ) != NULL )
				{
				isUnknownPluralOfNoun_ = true;
				generalizationWordTypeNr = WORD_TYPE_NOUN_SINGULAR;
				}
			}

		if( writeWordString_ != NULL )
			{
			if( ( wordResult = myWord_->checkWordTypeForBeenWritten( generalizationWordTypeNr ) ).result == RESULT_OK )
				{
				if( wordResult.isWordAlreadyWritten )
					writeWordString_ = NULL;
				else
					{
					if( myWord_->markWordTypeAsWritten( generalizationWordTypeNr ) == RESULT_OK )
						hasFoundGeneralizationWord_ = true;
					else
						return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to mark a word type of a generalization word as written" );
					}
				}
			else
				return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to check if a word type of a generalization word has already been written" );
			}

		return commonVariables_->result;
		}

	ResultType writeSpecificationWordToSentence( bool isSpecificationGeneralization, bool isWordTypeNumeral, bool isWordTypePluralNoun, bool isWordTypeSingularNoun, bool isWriteGivenSpecificationWordOnly, unsigned short grammarWordTypeNr, SpecificationItem *writeSpecificationItem )
		{
		WordResultType wordResult;
		bool isAnsweredQuestion;
		bool isExclusive;
		bool isPossessive;
		bool hasFoundUnwrittenWordType = false;
		bool isNumberOfRelations = false;
		unsigned short specificationWordTypeNr;
		unsigned short writeWordTypeNr = grammarWordTypeNr;
		unsigned int nContextRelations;
		unsigned int generalizationCollectionNr;
		unsigned int specificationCollectionNr;
		unsigned int generalizationContextNr;
		unsigned int specificationContextNr;
		unsigned int relationContextNr;
		SpecificationItem *currentSpecificationItem;
		WordItem *currentSpecificationWordItem;
		WordItem *lastFoundSpecificationWordItem;
		char tempString[MAX_READ_WRITE_STRING_LENGTH];
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeSpecificationWordToSentence";

		hasFoundSpecificationWord_ = false;
		hasFoundSingleSpecificationWord_ = false;
		writeWordString_ = NULL;

		if( writeSpecificationItem != NULL )
			{
			isAnsweredQuestion = writeSpecificationItem->isAnsweredQuestion();

			if( ( currentSpecificationItem = myWord_->firstSelectedSpecification( isAnsweredQuestion, writeSpecificationItem->isAssignment(), writeSpecificationItem->isDeactiveAssignment(), writeSpecificationItem->isArchivedAssignment(), writeSpecificationItem->questionParameter() ) ) != NULL )
				{
				isExclusive = writeSpecificationItem->isExclusive();
				isPossessive = writeSpecificationItem->isPossessive();
				specificationWordTypeNr = writeSpecificationItem->specificationWordTypeNr();
				generalizationCollectionNr = writeSpecificationItem->generalizationCollectionNr();
				specificationCollectionNr = writeSpecificationItem->specificationCollectionNr();
				generalizationContextNr = writeSpecificationItem->generalizationContextNr();
				specificationContextNr = writeSpecificationItem->specificationContextNr();
				relationContextNr = writeSpecificationItem->relationContextNr();

				do	{
					if( currentSpecificationItem == writeSpecificationItem ||

					( !isWriteGivenSpecificationWordOnly &&
					currentSpecificationItem->isRelatedSpecification( isExclusive, isPossessive, generalizationCollectionNr, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr ) ) )
						{
						if( currentSpecificationItem != writeSpecificationItem )
							hasFoundUnwrittenWordType = true;

						if( ( currentSpecificationWordItem = currentSpecificationItem->specificationWordItem() ) == NULL )		// Specification string
							{
							if( !currentSpecificationItem->isSpecificationStringAlreadyWritten() )
								{
								if( currentSpecificationItem->markSpecificationStringAsWritten() == RESULT_OK )
									{
									hasFoundSpecificationWord_ = true;
									lastFoundSpecificationItem_ = currentSpecificationItem;
									writeWordString_ = currentSpecificationItem->specificationString();

									if( hasFoundAllSpecificationWordsBeforeConjunction_ )
										{
										isSkipClearWriteLevel_ = false;
										hasFoundAllSpecificationWords_ = true;
										hasFoundAllSpecificationWordsBeforeConjunction_ = false;
										}
									}
								else
									return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to mark specification string \"", currentSpecificationItem->specificationString(), "\" as written" );
								}
							}
						else
							{
							if( ( nContextRelations = currentSpecificationItem->nContextRelations() ) == 0 )
								{
								if( isPossessive &&
								currentSpecificationItem->hasRelationContext() &&
								isSpecificationReasoningWordType( grammarWordTypeNr ) &&
								specificationStartWordPosition_ == 0 )		// To avoid looping in numbers
									nContextRelations = myWord_->nContextWords( isPossessive, currentSpecificationItem->relationContextNr(), currentSpecificationWordItem );
								}

							if( ( nContextRelations == 0 &&
							specificationWordTypeNr == grammarWordTypeNr ) ||

							( nContextRelations == 1 &&
							isWordTypeSingularNoun ) ||

							( nContextRelations > 1 &&

							( isWordTypeNumeral ||
							isWordTypePluralNoun ) ) )
								{
								if( ( writeWordString_ = currentSpecificationWordItem->activeWordTypeString( grammarWordTypeNr ) ) == NULL )
									{
									if( isWordTypeNumeral )
										{
										if( specificationStartWordPosition_ == 0 )		// To avoid looping in numbers
											{
											// The word 'number' needs to be converted to the number of relations
											isNumberOfRelations = true;
											sprintf( tempString, "%u", nContextRelations );
											writeWordString_ = tempString;
											}
										}
									else
										{
										if( isWordTypePluralNoun &&
										( writeWordString_ = currentSpecificationWordItem->activeSingularNounString() ) != NULL )
											// The plural noun is unknown, but the singular is known. So, force a singular noun, but with a remark
											isUnknownPluralOfNoun_ = true;		// Force as singular noun
										else	// Must be hidden word type
											writeWordString_ = currentSpecificationWordItem->anyWordTypeString();
										}
									}

								if( !isNumberOfRelations &&
								writeWordString_ != NULL )
									{
									if( isUnknownPluralOfNoun_ )
										writeWordTypeNr = WORD_TYPE_NOUN_SINGULAR;

									if( ( wordResult = currentSpecificationWordItem->checkWordTypeForBeenWritten( writeWordTypeNr ) ).result == RESULT_OK )
										{
										if( wordResult.isWordAlreadyWritten )
											writeWordString_ = NULL;
										else
											{
											if( currentSpecificationWordItem->markWordTypeAsWritten( writeWordTypeNr ) == RESULT_OK )
												{
												hasFoundSpecificationWord_ = true;
												lastFoundSpecificationItem_ = currentSpecificationItem;

												if( hasFoundAllSpecificationWordsBeforeConjunction_ )
													{
													isSkipClearWriteLevel_ = false;
													hasFoundAllSpecificationWords_ = true;
													}
												}
											else
												return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to mark specification word \"", currentSpecificationWordItem->anyWordTypeString(), "\" as written" );
											}
										}
									else
										return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to check specification word \"", currentSpecificationWordItem->anyWordTypeString(), "\" for being written" );
									}
								}
							}
						}
					}
				while( writeWordString_ == NULL &&
				( currentSpecificationItem = currentSpecificationItem->nextSpecificationItemWithSameQuestionParameter( isAnsweredQuestion ) ) != NULL );
				}

			if( !hasFoundSpecificationWord_ &&
			!hasFoundAllSpecificationWords_ &&
			!hasFoundAllSpecificationWordsBeforeConjunction_ &&
			lastFoundSpecificationItem_ != NULL &&
			lastFoundSpecificationItem_->specificationWordTypeNr() == grammarWordTypeNr )
				{
				if( hasFoundUnwrittenWordType )
					{
					if( strlen( previousSpecificationString_ ) > 0 )
						{
						hasFoundAllSpecificationWordsBeforeConjunction_ = true;
						specificationNeedsToWaitForConjunction_ = true;

						if( !isSpecificationGeneralization )
							isSkipClearWriteLevel_ = true;

						strcpy( commonVariables_->writeSentenceString, previousSpecificationString_ );

						if( ( lastFoundSpecificationWordItem = lastFoundSpecificationItem_->specificationWordItem() ) == NULL )		// Specification string
							lastFoundSpecificationItem_->clearSpecificationStringWriteLevel( NO_WRITE_LEVEL );
						else
							lastFoundSpecificationWordItem->clearWriteLevel( NO_WRITE_LEVEL );
						}
					}
				else
					{
					if( isSpecificationGeneralization )
						{
						hasFoundAllSpecificationWords_ = true;
						hasFoundSingleSpecificationWord_ = true;
						}
					}
				}
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given write specification item is undefined" );

		return commonVariables_->result;
		}

	ResultType writeRelationContextWordToSentence( unsigned short relationWordTypeNr, SpecificationItem *writeSpecificationItem )
		{
		WordResultType wordResult;
		WordItem *currentRelationWordItem = NULL;		// Start to search first word in function contextWordInAllWords
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeRelationContextWordToSentence";

		writeWordString_ = NULL;

		if( writeSpecificationItem != NULL )
			{
			do	{
				if( ( currentRelationWordItem = writeSpecificationItem->relationWordItem( currentRelationWordItem ) ) != NULL )
					{
					if( ( writeWordString_ = currentRelationWordItem->activeWordTypeString( relationWordTypeNr ) ) != NULL )
						{
						if( ( wordResult = currentRelationWordItem->checkWordTypeForBeenWritten( relationWordTypeNr ) ).result == RESULT_OK )
							{
							if( wordResult.isWordAlreadyWritten )
								writeWordString_ = NULL;
							else
								{
								if( currentRelationWordItem->markWordTypeAsWritten( relationWordTypeNr ) != RESULT_OK )
									return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to mark relation context word \"", currentRelationWordItem->anyWordTypeString(), "\" as written" );
								}
							}
						else
							return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to check relation context word \"", currentRelationWordItem->anyWordTypeString(), "\" for being written" );
						}
					else
						return myWord_->startErrorInWord( functionNameString, moduleNameString_, "Relation context word \"", currentRelationWordItem->anyWordTypeString(), "\" doesn't have the requested word type" );
					}
				}
			while( writeWordString_ == NULL &&
			currentRelationWordItem != NULL );

			if( currentRelationWordItem != NULL &&
			lastFoundRelationWordItem_ != NULL &&
			lastFoundRelationWordItem_ != currentRelationWordItem &&
			writeSpecificationItem->relationWordItem( currentRelationWordItem ) == NULL )	// Look ahead: This is the last relation word of the relation context
				{
				relationNeedsToWaitForConjunction_ = true;
				writeWordString_ = NULL;
				currentRelationWordItem->clearWriteLevel( NO_WRITE_LEVEL );
				}

			lastFoundRelationWordItem_ = currentRelationWordItem;
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given write specification item is undefined" );

		return commonVariables_->result;
		}


	public:
	// Constructor

	WordWriteWords( WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		hasFoundAllSpecificationWords_ = false;
		hasFoundAllSpecificationWordsBeforeConjunction_ = false;
		hasFoundGeneralizationWord_ = false;
		hasFoundSpecificationWord_ = false;
		hasFoundQuestionVerb_ = false;
		hasFoundSingleSpecificationWord_ = false;
		hasFoundSpecificationGeneralizationVerb_ = false;

		isUnknownPluralOfNoun_ = false;
		isSkipClearWriteLevel_ = false;
		relationNeedsToWaitForConjunction_ = false;
		specificationNeedsToWaitForConjunction_ = false;

		generalizationStartWordPosition_ = 0;
		specificationStartWordPosition_ = 0;

		lastFoundSpecificationItem_ = NULL;
		lastFoundRelationWordItem_ = NULL;
		writeWordString_ = NULL;

		strcpy( lastSpecificationString_, EMPTY_STRING );
		strcpy( previousSpecificationString_, EMPTY_STRING );

		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "WordWriteWords" );

		if( commonVariables_ != NULL )
			{
		if( myWord_ == NULL )
			strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInWord( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	void initializeWordWriteWordsVariables()
		{
		hasFoundAllSpecificationWords_ = false;
		hasFoundAllSpecificationWordsBeforeConjunction_ = false;
		hasFoundGeneralizationWord_ = false;
		hasFoundSpecificationWord_ = false;
		hasFoundQuestionVerb_ = false;
		hasFoundSingleSpecificationWord_ = false;
		hasFoundSpecificationGeneralizationVerb_ = false;

		isSkipClearWriteLevel_ = false;
		relationNeedsToWaitForConjunction_ = false;
		specificationNeedsToWaitForConjunction_ = false;

		generalizationStartWordPosition_ = 0;
		specificationStartWordPosition_ = 0;

		lastFoundSpecificationItem_ = NULL;
		lastFoundRelationWordItem_ = NULL;
		writeWordString_ = NULL;

		strcpy( lastSpecificationString_, EMPTY_STRING );
		strcpy( previousSpecificationString_, EMPTY_STRING );
		}

	void initializeWordWriteWordsSpecificationVariables( size_t startWordPosition )
		{
		if( generalizationStartWordPosition_ > startWordPosition )
			generalizationStartWordPosition_ = 0;

		if( specificationStartWordPosition_ > startWordPosition )
			{
			hasFoundAllSpecificationWordsBeforeConjunction_ = false;
			hasFoundSpecificationGeneralizationVerb_ = false;
			specificationNeedsToWaitForConjunction_ = false;

			specificationStartWordPosition_ = 0;
			}
		}

	WriteResultType writeWordsToSentence( bool isWriteGivenSpecificationWordOnly, unsigned short answerParameter, GrammarItem *definitionGrammarItem, SpecificationItem *writeSpecificationItem )
		{
		SpecificationResultType specificationResult;
		SpecificationResultType relationSpecificationResult;
		WriteResultType writeResult;
		bool isAssignment;
		bool isActiveAssignment;
		bool isDeactiveAssignment;
		bool isArchivedAssignment;
		bool isConditional;
		bool isExclusive;
		bool isNegative;
		bool isPossessive;
		bool isQuestion;
		bool isGeneralization;
		bool isSpecification;
		bool isRelation;
		bool isDefiniteAssignment;
		bool isDefiniteArticleFollowedByPropername;
		bool isSpecificationGeneralization;
		bool isWordTypeNumeral;
		bool isWordTypeSingularNoun;
		bool isWordTypePluralNoun;
		bool isInsertSeparator = true;
		unsigned short definitionGrammarParameter;
		unsigned short definitionGrammarWordTypeNr;
		unsigned int pronounContextNr = NO_CONTEXT_NR;
		WordItem *predefinedWordItem;
		WordItem *pronounWordItem;
		WordItem *specificationWordItem;
		char *specificationString;
		char *predefinedWordString = NULL;
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeWordsToSentence";

		hasFoundGeneralizationWord_ = false;
		hasFoundSpecificationWord_ = false;
		isUnknownPluralOfNoun_ = false;

		writeWordString_ = NULL;

		if( definitionGrammarItem != NULL )
			{
			if( definitionGrammarItem->hasWordType() )
				{
				if( writeSpecificationItem != NULL )
					{
					isAssignment = writeSpecificationItem->isAssignment();
					isActiveAssignment = writeSpecificationItem->isActiveAssignment();
					isDeactiveAssignment = writeSpecificationItem->isDeactiveAssignment();
					isArchivedAssignment = writeSpecificationItem->isArchivedAssignment();

					isConditional = writeSpecificationItem->isConditional();
					isExclusive = writeSpecificationItem->isExclusive();
					isNegative = writeSpecificationItem->isNegative();
					isPossessive = writeSpecificationItem->isPossessive();
					isQuestion = writeSpecificationItem->isQuestion();
					isSpecificationGeneralization = writeSpecificationItem->isSpecificationGeneralization();

					isGeneralization = ( generalizationStartWordPosition_ == 0 &&

										( !isSpecificationGeneralization ||

										( hasFoundAllSpecificationWords_ &&
										hasFoundSpecificationGeneralizationVerb_ ) ) );

					isRelation = ( !isGeneralization &&
									specificationStartWordPosition_ > 0 &&
									writeSpecificationItem->hasRelationContext() );

					isSpecification = ( !isGeneralization &&
										!isRelation &&

										( !hasFoundAllSpecificationWords_ ||

										( isSpecificationGeneralization &&
										!hasFoundSpecificationGeneralizationVerb_ ) ) );

					definitionGrammarParameter = definitionGrammarItem->grammarParameter();
					definitionGrammarWordTypeNr = definitionGrammarItem->grammarWordTypeNr();

					if( definitionGrammarParameter > NO_GRAMMAR_PARAMETER &&
					( predefinedWordItem = myWord_->predefinedWordItem( definitionGrammarParameter ) ) != NULL )
						predefinedWordString = predefinedWordItem->wordTypeString( true, NO_ORDER_NR, definitionGrammarWordTypeNr );

					specificationWordItem = writeSpecificationItem->specificationWordItem();
					specificationString = writeSpecificationItem->specificationString();

					switch( definitionGrammarParameter )
						{
						case WORD_PARAMETER_SYMBOL_COMMA:
						case WORD_PARAMETER_SYMBOL_COLON:
						case WORD_PARAMETER_SYMBOL_EXCLAMATION_MARK:
						case WORD_PARAMETER_SYMBOL_QUESTION_MARK:
							isInsertSeparator = false;
							writeWordString_ = predefinedWordString;
							break;

						case WORD_PARAMETER_CONJUNCTION_DUTCH_ALS:		// Typically for Dutch: in zowel ... als ...
							relationNeedsToWaitForConjunction_ = false;
							specificationNeedsToWaitForConjunction_ = false;

							// Don't insert a break statement here

						case WORD_PARAMETER_NUMERAL_BOTH:				// Typically for English: in both ... and ...
						case WORD_PARAMETER_CONJUNCTION_DUTCH_ZOWEL:	// Typically for Dutch: in zowel ... als ...
							if( writeSpecificationItem->hasExclusiveRelationCollection() )
								writeWordString_ = predefinedWordString;

							break;

						case WORD_PARAMETER_ADJECTIVE_CALLED_OR_NAMED:
							writeWordString_ = predefinedWordString;
							break;

						case WORD_PARAMETER_ADJECTIVE_NEW_1:
						case WORD_PARAMETER_ADJECTIVE_NEW_2:
							if( isActiveAssignment &&
							writeSpecificationItem->hasCurrentActiveSentenceNr() )		// Only show the word "new" during the current sentence
								writeWordString_ = predefinedWordString;

							break;

						case WORD_PARAMETER_ADJECTIVE_PREVIOUS_1:
						case WORD_PARAMETER_ADJECTIVE_PREVIOUS_2:
							if( isDeactiveAssignment )
								writeWordString_ = predefinedWordString;

							break;

						case WORD_PARAMETER_ADJECTIVE_CURRENT_1:
						case WORD_PARAMETER_ADJECTIVE_CURRENT_2:
							if( isActiveAssignment &&
							writeSpecificationItem->hasExclusiveGeneralizationCollection() )
								writeWordString_ = predefinedWordString;

							break;

//						case WORD_PARAMETER_ADJECTIVE_NEXT_1:
//						case WORD_PARAMETER_ADJECTIVE_NEXT_2:

						case WORD_PARAMETER_ADVERB_AS:
						case WORD_PARAMETER_ADVERB_INFO:

//						case WORD_PARAMETER_ADVERB_PREVIOUSLY:
//						case WORD_PARAMETER_ADVERB_CURRENTLY:
							break;	// Skip these words

						case WORD_PARAMETER_ADJECTIVE_NO:
//						case WORD_PARAMETER_ADVERB_DO_NOT:
						case WORD_PARAMETER_ADVERB_NOT:
							if( isNegative )
								writeWordString_ = predefinedWordString;

							break;

						case WORD_PARAMETER_ADVERB_ASSUMPTION_MAY_BE:
							if( ( specificationResult = writeSpecificationItem->getAssumptionLevel() ).result == RESULT_OK )
								{
								if( specificationResult.assumptionLevel > 2 )
									writeWordString_ = predefinedWordString;
								}
							else
								myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to recalculate the assumption level" );

							break;

						case WORD_PARAMETER_ADVERB_ASSUMPTION_POSSIBLY:
							if( ( specificationResult = writeSpecificationItem->getAssumptionLevel() ).result == RESULT_OK )
								{
								if( specificationResult.assumptionLevel == 2 )
									writeWordString_ = predefinedWordString;
								}
							else
								myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to recalculate the assumption level" );

							break;

						case WORD_PARAMETER_ADVERB_ASSUMPTION_PROBABLY:
							if( ( specificationResult = writeSpecificationItem->getAssumptionLevel() ).result == RESULT_OK )
								{
								if( specificationResult.assumptionLevel == 1 )
									writeWordString_ = predefinedWordString;
								}
							else
								myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to recalculate the assumption level" );

							break;

						case WORD_PARAMETER_ARTICLE_INDEFINITE_1:
						case WORD_PARAMETER_ARTICLE_INDEFINITE_2:
							if( ( specificationResult = writeSpecificationItem->checkArticleForNextUnwrittenSpecificationNounWord( false, definitionGrammarParameter ) ).result == RESULT_OK )
								{
								if( ( !isAssignment ||

								( isAssignment &&
								!isArchivedAssignment ) ||

								( isArchivedAssignment &&
								writeSpecificationItem->hasRelationContext() ) ) &&

								// Generalization noun
								( ( isGeneralization &&
								writeSpecificationItem->isGeneralizationNoun() &&
								myWord_->isCorrectIndefiniteArticle( definitionGrammarParameter, writeSpecificationItem->generalizationWordTypeNr() ) ) ||

								// Specification nouns
								( isSpecification &&
								specificationResult.isCorrectArticle ) ) )
									writeWordString_ = predefinedWordString;
								}
							else
								myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to check the indefinite article of the next unwritten specification noun word" );

							break;

						case WORD_PARAMETER_ARTICLE_DEFINITE_1:
						case WORD_PARAMETER_ARTICLE_DEFINITE_2:
							if( ( specificationResult = writeSpecificationItem->checkArticleForNextUnwrittenSpecificationNounWord( true, definitionGrammarParameter ) ).result == RESULT_OK )
								{
								if( ( relationSpecificationResult = writeSpecificationItem->checkArticleForNextUnwrittenRelationPropernamePrecededByDefiniteArticle( definitionGrammarParameter ) ).result == RESULT_OK )
									{
									isDefiniteAssignment = ( isAssignment &&
															!isArchivedAssignment &&

															// Generalization noun
															( ( isGeneralization &&
															writeSpecificationItem->isGeneralizationNoun() &&
															myWord_->isCorrectDefiniteArticle( definitionGrammarParameter, writeSpecificationItem->generalizationWordTypeNr() ) ) ||

															// Specification nouns
															( isSpecification &&
															specificationResult.isCorrectArticle ) ) );

									isDefiniteArticleFollowedByPropername = ( ( isGeneralization &&		// Generalization propername preceded-by-defined-article
																			writeSpecificationItem->isGeneralizationPropername() &&
																			myWord_->isPropernamePrecededByDefiniteArticle( definitionGrammarParameter ) ) ||

																			( isRelation &&				// Relation propernames preceded-by-defined-article
																			relationSpecificationResult.isCorrectArticle ) );

									if( isDefiniteAssignment ||
									isDefiniteArticleFollowedByPropername )
									writeWordString_ = predefinedWordString;
									}
								else
									myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to check the definite article of the next unwritten relation propername word preceded-by-defined-article" );
								}
							else
								myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to check the definite article of the next unwritten specification noun word" );

							break;

						case WORD_PARAMETER_CONJUNCTION_AND:
							if( !isExclusive ||
							isDeactiveAssignment ||
							writeSpecificationItem->hasExclusiveRelationCollection() )	// Typically for English: ... in both ... and ...
								{
								relationNeedsToWaitForConjunction_ = false;
								specificationNeedsToWaitForConjunction_ = false;
								writeWordString_ = predefinedWordString;
								}

							break;

						case WORD_PARAMETER_CONJUNCTION_OR:
							if( isExclusive &&
							!isDeactiveAssignment )
								{
								relationNeedsToWaitForConjunction_ = false;
								specificationNeedsToWaitForConjunction_ = false;
								writeWordString_ = predefinedWordString;
								}

							break;

						case WORD_PARAMETER_ANSWER_YES:
						case WORD_PARAMETER_ANSWER_NO:
							if( definitionGrammarParameter == answerParameter )
								writeWordString_ = predefinedWordString;

							break;

						// Singular pronouns
						case WORD_PARAMETER_SINGULAR_PRONOUN_I_ME_MY_MINE:
						case WORD_PARAMETER_SINGULAR_PRONOUN_YOU_YOUR_YOURS_FORMAL:
						case WORD_PARAMETER_SINGULAR_PRONOUN_YOU_YOUR_YOURS_INFORMAL:
						case WORD_PARAMETER_SINGULAR_PRONOUN_HE_HIM_HIS_HIS:
						case WORD_PARAMETER_SINGULAR_PRONOUN_SHE_HER_HER_HERS:
						case WORD_PARAMETER_SINGULAR_PRONOUN_IT_ITS_ITS_ITS:

						// Plural pronouns
						case WORD_PARAMETER_PLURAL_PRONOUN_WE_US_OUR_OURS:
						case WORD_PARAMETER_PLURAL_PRONOUN_YOU_YOUR_YOURS:
						case WORD_PARAMETER_PLURAL_PRONOUN_THEY_THEM_THEIR_THEIRS:
							if( !isArchivedAssignment )
								{
								if( isGeneralization )
									pronounContextNr = writeSpecificationItem->generalizationContextNr();
								else
									{
									if( isSpecification )
										pronounContextNr = writeSpecificationItem->specificationContextNr();
									else
										{
										if( isRelation )
											pronounContextNr = writeSpecificationItem->relationContextNr();
										}
									}

								if( pronounContextNr > NO_CONTEXT_NR )
									{
									if( ( pronounWordItem = myWord_->predefinedWordItem( definitionGrammarParameter ) ) != NULL )
										{
										if( pronounWordItem->contextWordTypeNrInWord( pronounContextNr ) == definitionGrammarWordTypeNr )
											writeWordString_ = predefinedWordString;
										}
									else
										myWord_->startErrorInWord( functionNameString, moduleNameString_, "I couldn't find the pronoun word with the definition grammar parameter" );
									}
								}

							break;

						case WORD_PARAMETER_PREPOSITION_ABOUT:
							break;

						case WORD_PARAMETER_PREPOSITION_FOR:
							if( writeSpecificationItem->isPrepositionFor() )
								writeWordString_ = predefinedWordString;

							break;

						case WORD_PARAMETER_PREPOSITION_FROM:
							if( writeSpecificationItem->isPrepositionFrom() )
								writeWordString_ = predefinedWordString;

							break;

						case WORD_PARAMETER_PREPOSITION_IN:
							if( writeSpecificationItem->isPrepositionIn() )
								writeWordString_ = predefinedWordString;

							break;

						case WORD_PARAMETER_PREPOSITION_OF:
							if( writeSpecificationItem->isPrepositionOf() ||
							writeSpecificationItem->prepositionParameter() == NO_PREPOSITION_PARAMETER )
								writeWordString_ = predefinedWordString;

							break;

						case WORD_PARAMETER_PREPOSITION_TO:
							if( writeSpecificationItem->isPrepositionTo() )
								writeWordString_ = predefinedWordString;

							break;

						case WORD_PARAMETER_SINGULAR_VERB_IS:
						case WORD_PARAMETER_PLURAL_VERB_ARE:
							if( !isConditional &&
							!isPossessive &&

							( !isAssignment ||		// Definition specification
							isActiveAssignment ) &&

							( isQuestion ||
							hasFoundAllSpecificationWords_ ||
							!isSpecificationGeneralization ) )
								{
								writeWordString_ = predefinedWordString;

								if( isQuestion )
									hasFoundQuestionVerb_ = true;

								if( isSpecificationGeneralization )
									hasFoundSpecificationGeneralizationVerb_ = true;
								}

							break;

						case WORD_PARAMETER_SINGULAR_VERB_CAN_BE:
						case WORD_PARAMETER_PLURAL_VERB_CAN_BE:
							if( isConditional &&
							!isPossessive &&

							( !isAssignment ||
							isActiveAssignment ) )
								writeWordString_ = predefinedWordString;

							break;

						case WORD_PARAMETER_SINGULAR_VERB_WAS:
						case WORD_PARAMETER_PLURAL_VERB_WERE:
							if( !isConditional &&
							!isPossessive &&

							( isDeactiveAssignment ||
							isArchivedAssignment ) &&

							( hasFoundAllSpecificationWords_ ||
							!isSpecificationGeneralization ) )
								{
								if( isQuestion )
									hasFoundQuestionVerb_ = true;

								if( isSpecificationGeneralization )
									hasFoundSpecificationGeneralizationVerb_ = true;

								if( isArchivedAssignment ||
								!writeSpecificationItem->hasGeneralizationCollection() )
									writeWordString_ = predefinedWordString;
								else
									{
									if( myWord_->firstAssignment( false, true, true, isNegative, isPossessive, writeSpecificationItem->questionParameter(), writeSpecificationItem->generalizationContextNr(), writeSpecificationItem->specificationContextNr(), writeSpecificationItem->relationContextNr(), specificationWordItem, specificationString ) == NULL )
										writeWordString_ = predefinedWordString;
									else
										{
										// Force current tense, because the word 'previous' is used
										if( ( predefinedWordItem = myWord_->predefinedWordItem( definitionGrammarParameter == WORD_PARAMETER_SINGULAR_VERB_WAS ? WORD_PARAMETER_SINGULAR_VERB_IS : WORD_PARAMETER_PLURAL_VERB_ARE ) ) != NULL )
											{
											if( ( writeWordString_ = predefinedWordItem->wordTypeString( true, NO_ORDER_NR, definitionGrammarWordTypeNr ) ) == NULL )
												myWord_->startErrorInWord( functionNameString, moduleNameString_, "I couldn't get the word type string from the predefined word with word parameter ", definitionGrammarParameter );
											}
										else
											myWord_->startErrorInWord( functionNameString, moduleNameString_, "I couldn't find the predefined word with word parameter ", definitionGrammarParameter );
										}
									}
								}

							break;

						case WORD_PARAMETER_SINGULAR_VERB_HAS:
						case WORD_PARAMETER_PLURAL_VERB_HAVE:
							if( !isConditional &&
							isPossessive &&

							( !isAssignment ||
							isActiveAssignment ||
							isDeactiveAssignment ) &&

							( hasFoundAllSpecificationWords_ ||
							!isSpecificationGeneralization ) )
								{
								writeWordString_ = predefinedWordString;

								if( isQuestion )
									hasFoundQuestionVerb_ = true;

								if( isSpecificationGeneralization )
									hasFoundSpecificationGeneralizationVerb_ = true;
								}

							break;

						case WORD_PARAMETER_SINGULAR_VERB_CAN_HAVE:
						case WORD_PARAMETER_PLURAL_VERB_CAN_HAVE:
							if( isConditional &&
							isPossessive &&

							( !isAssignment ||
							isActiveAssignment ) )
								writeWordString_ = predefinedWordString;

							break;

						case WORD_PARAMETER_SINGULAR_VERB_HAD:
						case WORD_PARAMETER_PLURAL_VERB_HAD:
							if( !isConditional &&
							isPossessive &&

							( isDeactiveAssignment ||
							isArchivedAssignment ) &&

							( hasFoundAllSpecificationWords_ ||
							!isSpecificationGeneralization ) )
								{
								writeWordString_ = predefinedWordString;

								if( isQuestion )
									hasFoundQuestionVerb_ = true;

								if( isSpecificationGeneralization )
									hasFoundSpecificationGeneralizationVerb_ = true;
								}

							break;

						// Verbs
						case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_ADD:
						case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_MOVE:
						case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_REMOVE:
						case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_CLEAR:
						case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_HELP:
						case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_LOGIN:
						case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_READ:
						case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_REDO:
						case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_RESTART:
						case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_SHOW:
						case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_SOLVE:
						case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_UNDO:

						// Selection words
						case WORD_PARAMETER_SELECTION_IF:
						case WORD_PARAMETER_SELECTION_THEN:
						case WORD_PARAMETER_SELECTION_ELSE:
							break;	// Skip these words

						// Noun words
						case WORD_PARAMETER_NOUN_VALUE:
							break;	// Skip this words

						case NO_GRAMMAR_PARAMETER:

						// Adjectives
						case WORD_PARAMETER_ADJECTIVE_ASSIGNED:
						case WORD_PARAMETER_ADJECTIVE_BUSY:
						case WORD_PARAMETER_ADJECTIVE_CLEAR:
						case WORD_PARAMETER_ADJECTIVE_DONE:
						case WORD_PARAMETER_ADJECTIVE_DEFENSIVE:
						case WORD_PARAMETER_ADJECTIVE_EXCLUSIVE:
						case WORD_PARAMETER_ADJECTIVE_INVERTED:

						// Nouns
						case WORD_PARAMETER_NOUN_DEVELOPER:
						case WORD_PARAMETER_NOUN_FILE:
						case WORD_PARAMETER_NOUN_GRAMMAR_LANGUAGE:
						case WORD_PARAMETER_NOUN_INTERFACE_LANGUAGE:
						case WORD_PARAMETER_NOUN_JUSTIFICATION_REPORT:
						case WORD_PARAMETER_NOUN_HEAD:
						case WORD_PARAMETER_NOUN_TAIL:
						case WORD_PARAMETER_NOUN_MIND:
						case WORD_PARAMETER_NOUN_NUMBER:
						case WORD_PARAMETER_NOUN_PASSWORD:
						case WORD_PARAMETER_NOUN_SOLVE_LEVEL:
						case WORD_PARAMETER_NOUN_SOLVE_METHOD:
						case WORD_PARAMETER_NOUN_SOLVE_STRATEGY:
						case WORD_PARAMETER_NOUN_TEST_FILE:
						case WORD_PARAMETER_NOUN_USER:
							if( ( !isQuestion ||
							hasFoundQuestionVerb_ ) &&

							( !relationNeedsToWaitForConjunction_ &&
							!specificationNeedsToWaitForConjunction_ ) )
								{
								if( isGeneralization )
									{
									if( writeSpecificationItem->generalizationWordTypeNr() == definitionGrammarWordTypeNr )		// Matching word type
										{
										// Generalization
										if( writeGeneralizationWordToSentence( ( isSpecificationGeneralization && !hasFoundSingleSpecificationWord_ ), definitionGrammarWordTypeNr ) != RESULT_OK )
											myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write the generalization word to the sentence" );
										}
									}
								else
									{
									if( isSpecification )
										{
										isWordTypeNumeral = definitionGrammarItem->isWordTypeNumeral();
										isWordTypePluralNoun = definitionGrammarItem->isWordTypePluralNoun();
										isWordTypeSingularNoun = definitionGrammarItem->isWordTypeSingularNoun();

										if( isWordTypeNumeral ||
										isWordTypePluralNoun ||
										writeSpecificationItem->specificationWordTypeNr() == definitionGrammarWordTypeNr )		// Matching word type
											{
											// Specification
											if( writeSpecificationWordToSentence( isSpecificationGeneralization, isWordTypeNumeral, isWordTypePluralNoun, isWordTypeSingularNoun, isWriteGivenSpecificationWordOnly, definitionGrammarWordTypeNr, writeSpecificationItem ) != RESULT_OK )
												myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a specification word to the sentence" );
											}
										}
									else
										{
										if( isRelation &&
										writeSpecificationItem->relationWordTypeNr() == definitionGrammarWordTypeNr )			// Matching word type
											{
											// Relation context
											if( writeRelationContextWordToSentence( definitionGrammarWordTypeNr, writeSpecificationItem ) != RESULT_OK )
												myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a relation context word to the sentence" );
											}
										}
									}
								}

							break;

						default:
							myWord_->startErrorInWord( functionNameString, moduleNameString_, "I don't know how to handle the grammar definition with grammar parameter ", definitionGrammarParameter );
						}

					if( commonVariables_->result == RESULT_OK &&
					writeWordString_ != NULL )
						{
						if( strlen( commonVariables_->writeSentenceString ) == 0 )
							strcpy( commonVariables_->writeSentenceString, writeWordString_ );
						else
							{
							isSkipClearWriteLevel_ = false;

							if( isInsertSeparator )
								strcat( commonVariables_->writeSentenceString, SPACE_STRING );

							strcat( commonVariables_->writeSentenceString, writeWordString_ );
							}

						if( isUnknownPluralOfNoun_ )
							{
							if( commonVariables_->currentInterfaceLanguageWordItem != NULL )
								{
								strcat( commonVariables_->writeSentenceString, commonVariables_->currentInterfaceLanguageWordItem->interfaceString( INTERFACE_GRAMMAR_UNKNOWN_PLURAL_START ) );
								strcat( commonVariables_->writeSentenceString, writeWordString_ );
								strcat( commonVariables_->writeSentenceString, commonVariables_->currentInterfaceLanguageWordItem->interfaceString( INTERFACE_GRAMMAR_UNKNOWN_PLURAL_ENDING ) );
								}
							else
								myWord_->startErrorInWord( functionNameString, moduleNameString_, "The current interface language word item is undefined" );
							}

						if( hasFoundGeneralizationWord_ )
							generalizationStartWordPosition_ = strlen( commonVariables_->writeSentenceString );
						else
							{
							if( hasFoundSpecificationWord_ )
								{
								specificationStartWordPosition_ = strlen( commonVariables_->writeSentenceString );

								// To recovery an unsuccessful specification match
								strcpy( previousSpecificationString_, lastSpecificationString_ );
								strcpy( lastSpecificationString_, commonVariables_->writeSentenceString );
								}
							}
						}
					}
				else
					myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given write specification item is undefined" );
				}
			else
				myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given grammar definition has no word type" );
			}
		else
			myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given definition grammar item is undefined" );

		writeResult.hasFoundWordToWrite = ( writeWordString_ != NULL );
		writeResult.isSkipClearWriteLevel = isSkipClearWriteLevel_;
		writeResult.result = commonVariables_->result;
		return writeResult;
		}
	};

/*************************************************************************
 *
 *	"Your word is a lamp to guide my feet
 *	and a light for my path." (Psalm 119:105)
 *
 *************************************************************************/
