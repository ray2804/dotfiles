/*
 *	Class:			WordTypeItem
 *	Parent class:	Item
 *	Purpose:		To store the word-types of a word
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

class WordTypeItem extends Item
	{
	// Private loadable variables

	private boolean isPropernamePrecededByDefiniteArticle_;

	private short definiteArticleParameter_;
	private short indefiniteArticleParameter_;
	private short wordTypeNr_;
	private short wordTypeLanguageNr_;


	// Private constructible variables

	private short writeLevel_;

	private String wordTypeString_;

	private	String hideKey_;


	// Constructor

	protected WordTypeItem( boolean isPropernamePrecededByDefiniteArticle, short definiteArticleParameter, short indefiniteArticleParameter, short wordTypeLanguageNr, short wordTypeNr, int wordTypeStringLength, String _wordTypeString, List myList, WordItem myWord )
		{
		initializeItemVariables( Constants.NO_SENTENCE_NR, Constants.NO_SENTENCE_NR, Constants.NO_SENTENCE_NR, Constants.NO_SENTENCE_NR, myList, myWord );

		// Private loadable variables

		isPropernamePrecededByDefiniteArticle_ = isPropernamePrecededByDefiniteArticle;

		definiteArticleParameter_ = definiteArticleParameter;
		indefiniteArticleParameter_ = indefiniteArticleParameter;
		wordTypeNr_ = wordTypeNr;
		wordTypeLanguageNr_ = wordTypeLanguageNr;

		// Private constructible variables

		writeLevel_ = Constants.NO_WRITE_LEVEL;

		hideKey_ = null;
		wordTypeString_ = null;

		if( _wordTypeString != null )
			{
			if( _wordTypeString.length() > 0 )
				{
				if( wordTypeStringLength > 0 )
					wordTypeString_ = ( Character.isUpperCase( _wordTypeString.charAt( 0 ) ) && wordTypeNr != Constants.WORD_TYPE_LETTER_CAPITAL && wordTypeNr != Constants.WORD_TYPE_PROPER_NAME ? Character.toLowerCase( _wordTypeString.charAt( 0 ) ) + _wordTypeString.substring( 1, wordTypeStringLength ) : _wordTypeString.substring( 0, wordTypeStringLength ) );
				else
					startSystemErrorInItem( 1, null, null, "The given word type string length is undefined" );
				}
			else
				startSystemErrorInItem( 1, null, null, "The given word type string is empty" );
			}
		else
			startSystemErrorInItem( 1, null, null, "The given word type string is undefined" );
		}


	// Protected virtual methods

	protected void showString( boolean returnQueryToPosition )
		{
		if( CommonVariables.queryStringBuffer == null )
			CommonVariables.queryStringBuffer = new StringBuffer();

		if( itemString() != null )
			{
			if( CommonVariables.hasFoundQuery )
				CommonVariables.queryStringBuffer.append( returnQueryToPosition ? Constants.NEW_LINE_STRING : Constants.QUERY_SEPARATOR_SPACE_STRING );

			if( !isActiveItem() )	// Show status when not active
				CommonVariables.queryStringBuffer.append( statusChar() );

			CommonVariables.hasFoundQuery = true;
			CommonVariables.queryStringBuffer.append( itemString() );
			}
		}

	protected boolean hasFoundParameter( int queryParameter )
		{
		return ( definiteArticleParameter_ == Constants.NO_DEFINITE_ARTICLE_PARAMETER ||
				indefiniteArticleParameter_ == Constants.NO_INDEFINITE_ARTICLE_PARAMETER ||
				wordTypeLanguageNr_ == queryParameter ||
				writeLevel_ == queryParameter ||

				( queryParameter == Constants.MAX_QUERY_PARAMETER &&

				( definiteArticleParameter_ > Constants.NO_DEFINITE_ARTICLE_PARAMETER ||
				definiteArticleParameter_ > Constants.NO_INDEFINITE_ARTICLE_PARAMETER ||
				wordTypeLanguageNr_ > 0 ||
				writeLevel_ > Constants.NO_WRITE_LEVEL ) ) );
		}

	protected boolean hasFoundWordType( short queryWordTypeNr )
		{
		return ( wordTypeNr_ == queryWordTypeNr );
		}

	protected boolean isSorted( Item nextSortItem )
		{
		return ( nextSortItem == null ||
				// Ascending wordTypeLanguageNr
				wordTypeLanguageNr_ < ( (WordTypeItem)nextSortItem ).wordTypeLanguageNr_ );
		}

	protected String itemString()
		{
		return ( hideKey_ == null ? wordTypeString_ : null );
		}

	protected StringBuffer toStringBuffer( short queryWordTypeNr )
		{
		String wordString;
		String wordTypeString = myWord().wordTypeName( wordTypeNr_ );
		String grammarLanguageNameStringString = myWord().grammarLanguageNameString( wordTypeLanguageNr_ );

		baseToStringBuffer( queryWordTypeNr );

		if( hideKey_ != null )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "isHidden" );

		if( isPropernamePrecededByDefiniteArticle_ )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "isPropernamePrecededByDefiniteArticle" );

		if( definiteArticleParameter_ > Constants.NO_DEFINITE_ARTICLE_PARAMETER )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "definiteArticleParameter:" + definiteArticleParameter_ );

		if( indefiniteArticleParameter_ > Constants.NO_INDEFINITE_ARTICLE_PARAMETER )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "indefiniteArticleParameter:" + indefiniteArticleParameter_ );

		CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "wordType:" + ( wordTypeString == null ? Constants.EMPTY_STRING : wordTypeString ) + Constants.QUERY_WORD_TYPE_STRING + wordTypeNr_ );

		if( wordTypeLanguageNr_ > 0 )
			{
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "grammarLanguage:" + ( grammarLanguageNameStringString == null ? wordTypeLanguageNr_ : grammarLanguageNameStringString ) );
			}

		if( ( wordString = itemString() ) != null )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "wordString:" + Constants.QUERY_STRING_START_CHAR + wordString + Constants.QUERY_STRING_END_CHAR );

		return CommonVariables.queryStringBuffer;
		}


	// Protected methods

	protected void clearWriteLevel( short currentWriteLevel )
		{
		if( writeLevel_ > currentWriteLevel )
			writeLevel_ = Constants.NO_WRITE_LEVEL;
		}

	protected boolean hasUndefinedDefiniteArticle()
		{
		return ( definiteArticleParameter_ == Constants.NO_DEFINITE_ARTICLE_PARAMETER );
		}

	protected boolean hasUndefinedIndefiniteArticle()
		{
		return ( indefiniteArticleParameter_ == Constants.NO_INDEFINITE_ARTICLE_PARAMETER );
		}

	protected boolean isCorrectDefiniteArticle( short definiteArticleParameter )
		{
		return ( definiteArticleParameter_ == Constants.NO_DEFINITE_ARTICLE_PARAMETER ||
				definiteArticleParameter_ == definiteArticleParameter );
		}

	protected boolean isCorrectIndefiniteArticle( short indefiniteArticleParameter )
		{
		boolean isStartingWithVowel = isStringStartingWithVowel( itemString() );

		return ( indefiniteArticleParameter_ == indefiniteArticleParameter ||

				// If undefined, fall back to a simple rule
				( indefiniteArticleParameter_ == Constants.NO_INDEFINITE_ARTICLE_PARAMETER &&

				// 'an'
				( ( isStartingWithVowel &&
				indefiniteArticleParameter == Constants.WORD_PARAMETER_ARTICLE_INDEFINITE_1 ) ||

				// 'a'
				( !isStartingWithVowel &&
				indefiniteArticleParameter == Constants.WORD_PARAMETER_ARTICLE_INDEFINITE_2 ) ) ) );
		}

	protected boolean isPropernamePrecededByDefiniteArticle( short definiteArticleParameter )
		{
		return ( isPropernamePrecededByDefiniteArticle_ &&
				isCorrectDefiniteArticle( definiteArticleParameter ) );
		}

	protected boolean isCorrectHiddenWordType( String compareString, String hideKey )
		{
		if( hideKey_ == hideKey &&
		compareString != null &&
		wordTypeString_.equals( compareString ) )
			return true;

		return false;
		}

	protected boolean isWordTypeAdjective()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_ADJECTIVE );
		}

	protected boolean isWordTypeArticle()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_ARTICLE );
		}

	protected boolean isWordTypeConjunction()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_CONJUNCTION );
		}

	protected boolean isWordTypeDefiniteArticle()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_ARTICLE &&	// Filter on articles, because nouns also have a definiteArticleParameter

				( definiteArticleParameter_ == Constants.WORD_PARAMETER_ARTICLE_DEFINITE_1 ||
				definiteArticleParameter_ == Constants.WORD_PARAMETER_ARTICLE_DEFINITE_2 ) );
		}

	protected boolean isWordTypeIndefiniteArticle()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_ARTICLE &&	// Filter on articles, because nouns also have an indefiniteArticleParameter

				( indefiniteArticleParameter_ == Constants.WORD_PARAMETER_ARTICLE_INDEFINITE_1 ||
				indefiniteArticleParameter_ == Constants.WORD_PARAMETER_ARTICLE_INDEFINITE_2 ) );
		}

	protected boolean isWordTypeSingularNoun()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_NOUN_SINGULAR );
		}

	protected boolean isWordTypePluralNoun()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_NOUN_PLURAL );
		}

	protected boolean isWordTypePossessiveDeterminer()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_POSSESSIVE_DETERMINER_SINGULAR ||
				wordTypeNr_ == Constants.WORD_TYPE_POSSESSIVE_DETERMINER_PLURAL );
		}

	protected boolean isWordTypePossessivePronoun()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_POSSESSIVE_PRONOUN_SINGULAR ||
				wordTypeNr_ == Constants.WORD_TYPE_POSSESSIVE_PRONOUN_PLURAL );
		}

	protected boolean isWordTypeSymbol()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_SYMBOL );
		}

	protected boolean isWordTypeLetter()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_LETTER_SMALL ||
				wordTypeNr_ == Constants.WORD_TYPE_LETTER_CAPITAL );
		}

	protected boolean isWordTypeNumeral()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_NUMERAL );
		}

	protected boolean isWordTypeVerb()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_VERB_SINGULAR ||
				wordTypeNr_ == Constants.WORD_TYPE_VERB_PLURAL );
		}

	protected boolean isWordAlreadyWritten()
		{
		return ( writeLevel_ > Constants.NO_WRITE_LEVEL );
		}

	protected short definiteArticleParameter()
		{
		return definiteArticleParameter_;
		}

	protected short indefiniteArticleParameter()
		{
		return indefiniteArticleParameter_;
		}

	protected short wordTypeNr()
		{
		return wordTypeNr_;
		}

	protected short wordTypeLanguageNr()
		{
		return wordTypeLanguageNr_;
		}

	protected byte setDefiniteArticleParameter( short definiteArticleParameter )
		{
		if( definiteArticleParameter == Constants.WORD_PARAMETER_ARTICLE_DEFINITE_1 ||
		definiteArticleParameter == Constants.WORD_PARAMETER_ARTICLE_DEFINITE_2 )
			{
			if( definiteArticleParameter_ == Constants.NO_DEFINITE_ARTICLE_PARAMETER )
				{
				if( isWordTypeSingularNoun() )
					definiteArticleParameter_ = definiteArticleParameter;
				else
					return startErrorInItem( 1, null, itemString(), "I am not a singular noun" );
				}
			else
				return startErrorInItem( 1, null, itemString(), "The current definite article paramater is already defined" );
			}
		else
			return startErrorInItem( 1, null, itemString(), "The given definite article paramater is no definite article paramater" );

		return CommonVariables.result;
		}

	protected byte setIndefiniteArticleParameter( short indefiniteArticleParameter )
		{
		if( indefiniteArticleParameter == Constants.WORD_PARAMETER_ARTICLE_INDEFINITE_1 ||
		indefiniteArticleParameter == Constants.WORD_PARAMETER_ARTICLE_INDEFINITE_2 )
			{
			if( indefiniteArticleParameter_ == Constants.NO_INDEFINITE_ARTICLE_PARAMETER )
				{
				if( isWordTypeSingularNoun() )
					indefiniteArticleParameter_ = indefiniteArticleParameter;
				else
					return startErrorInItem( 1, null, itemString(), "I am not a singular noun" );
				}
			else
				return startErrorInItem( 1, null, itemString(), "The current indefinite article paramater is already defined" );
			}
		else
			return startErrorInItem( 1, null, itemString(), "The given indefinite article paramater is no indefinite article paramater" );

		return CommonVariables.result;
		}

	protected byte markWordTypeAsWritten()
		{
		if( CommonVariables.currentWriteLevel < Constants.MAX_LEVEL )
			{
			if( writeLevel_ == Constants.NO_WRITE_LEVEL )
				writeLevel_ = ++CommonVariables.currentWriteLevel;
			else
				return startErrorInItem( 1, null, itemString(), "My write level is already assigned" );
			}
		else
			return startSystemErrorInItem( 1, null, itemString(), "Current write word level overflow" );

		return CommonVariables.result;
		}

	protected byte hideWordType( String hideKey )
		{
		if( hideKey_ == null )
			hideKey_ = hideKey;
		else
			return startErrorInItem( 1, null, itemString(), "This word type is already hidden" );

		return CommonVariables.result;
		}

	protected byte createNewWordTypeString( String newWordTypeString )
		{
		if( newWordTypeString != null )
			{
			if( newWordTypeString.length() > 0 )
				wordTypeString_ = newWordTypeString;
			else
				return startErrorInItem( 1, null, itemString(), "The given new word type string is empty" );
			}
		else
			return startErrorInItem( 1, null, itemString(), "The given new word type string is undefined" );

		return CommonVariables.result;
		}

	protected WordTypeItem nextWordTypeItem()
		{
		return (WordTypeItem)nextItem;
		}

	protected WordTypeItem nextCurrentLanguageWordTypeItem()
		{
		WordTypeItem nextCurrentLanguageWordTypeItem = nextWordTypeItem();

		return ( nextCurrentLanguageWordTypeItem != null &&
				nextCurrentLanguageWordTypeItem.wordTypeLanguageNr() == CommonVariables.currentGrammarLanguageNr ? nextCurrentLanguageWordTypeItem : null );
		}

	protected WordTypeItem nextWordTypeItem( short wordTypeNr )
		{
		WordTypeItem searchItem = nextCurrentLanguageWordTypeItem();

		while( searchItem != null )
			{
			if( wordTypeNr == Constants.WORD_TYPE_UNDEFINED ||
			searchItem.wordTypeNr_ == wordTypeNr )
				return searchItem;

			searchItem = searchItem.nextCurrentLanguageWordTypeItem();
			}

		return null;
		}
	};

/*************************************************************************
 *
 *	"The Lord gives his people strength.
 *	The Lord blesses them with peace." (Psalm 29:11)
 *
 *************************************************************************/
