/*
 *	Class:			WordItem
 *	Parent class:	Item
 *	Purpose:		To store and process word information
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

// WordItem header

#ifndef WORDITEM
#define WORDITEM 1

#include "Item.h"
#include "CollectionResultType.cpp"
#include "GeneralizationResultType.cpp"
#include "GrammarResultType.cpp"
#include "JustificationResultType.cpp"
#include "ReadResultType.cpp"
#include "SelectionResultType.cpp"
#include "SpecificationResultType.cpp"
#include "WordResultType.cpp"
#include "WriteResultType.cpp"

// Class declarations needed by some compilers, like Code::Blocks
class CollectionItem;
class CollectionList;
class ContextItem;
class ContextList;
class GeneralizationItem;
class GeneralizationList;
class GrammarItem;
class GrammarList;
class InterfaceList;
class Item;
class JustificationItem;
class JustificationList;
class List;
class ScoreList;
class SelectionItem;
class SelectionList;
class SpecificationItem;
class SpecificationList;
class WordAssignment;
class WordCleanup;
class WordCollection;
class WordQuery;
class WordQuestion;
class WordSpecification;
class WordType;
class WordTypeItem;
class WordTypeList;
class WordWrite;
class WordWriteSentence;
class WordWriteWords;
class WriteItem;
class WriteList;

class WordItem : protected Item
	{
	friend class AdminAssumption;
	friend class AdminAuthorization;
	friend class AdminCleanup;
	friend class AdminCollection;
	friend class AdminConclusion;
	friend class AdminContext;
	friend class AdminGrammar;
	friend class AdminImperative;
	friend class AdminItem;
	friend class AdminJustification;
	friend class AdminLanguage;
	friend class AdminRead;
	friend class AdminReadCreateWords;
	friend class AdminReadSentence;
	friend class AdminQuery;
	friend class AdminSelection;
	friend class AdminSolve;
	friend class AdminSpecification;
	friend class AdminWrite;
	friend class CollectionItem;
	friend class CollectionList;
	friend class ContextItem;
	friend class ContextList;
	friend class GeneralizationItem;
	friend class GrammarItem;
	friend class GrammarList;
	friend class Item;
	friend class JustificationItem;
	friend class JustificationList;
	friend class Presentation;
	friend class ReadItem;
	friend class SelectionItem;
	friend class SpecificationItem;
	friend class SpecificationList;
	friend class WordAssignment;
	friend class WordCleanup;
	friend class WordCollection;
	friend class WordList;
	friend class WordQuery;
	friend class WordQuestion;
	friend class WordSpecification;
	friend class WordType;
	friend class WordTypeList;
	friend class WordTypeItem;
	friend class WordWrite;
	friend class WordWriteSentence;
	friend class WordWriteWords;


	// Private constructible variables

	void *changeKey_;

	WordAssignment *wordAssignment_;
	WordCleanup *wordCleanup_;
	WordCollection *wordCollection_;
	WordQuery *wordQuery_;
	WordQuestion *wordQuestion_;
	WordSpecification *wordSpecification_;
	WordType *wordType_;
	WordWrite *wordWrite_;
	WordWriteSentence *wordWriteSentence_;
	WordWriteWords *wordWriteWords_;


	// Private loadable variables

	unsigned short wordParameter_;


	// Private common functions

	char *grammarLanguageNameStringInWord( unsigned short languageNr );
	char *userNameInWord( unsigned short languageNr );


	// Private assignment functions

	SpecificationItem *firstAssignment( bool isDeactive, bool isArchived, bool isQuestion );
	SpecificationItem *firstDeactiveAssignment( bool isIncludingAnsweredQuestions, unsigned short questionParameter );
	SpecificationItem *firstArchivedAssignment( bool isIncludingAnsweredQuestions, unsigned short questionParameter );


	// Private collection functions

	unsigned short highestCollectionOrderNrInWord( unsigned int collectionNr );

	unsigned int collectionNrByCompoundGeneralizationWordInWord( unsigned short collectionWordTypeNr, WordItem *compoundGeneralizationWordItem );
	unsigned int collectionNrByCommonWordInWord( unsigned short collectionWordTypeNr, WordItem *collectionWordItem );
	unsigned int highestCollectionNrInWord();
	unsigned int nonCompoundCollectionNrInWord( unsigned int compoundCollectionNr );


	// Private context functions

	bool isContextCurrentlyUpdatedInWord( bool isPossessive, unsigned int contextNr, WordItem *specificationWordItem );
	bool isContextSimilarInWord( unsigned int firstContextNr, unsigned int secondContextNr );
	bool isContextSubsetInWord( unsigned int fullSetContextNr, unsigned int subsetContextNr );

	ContextItem *contextItemInWord( unsigned int contextNr );


	// Private grammar functions

	char *grammarStringInWord( unsigned short wordTypeNr );


	// Private query functions

	char *nameByCollectionOrderNr( unsigned short collectionOrderNr );


	// Private question functions

	SpecificationItem *firstAnsweredQuestion( bool isAssignment, bool isDeactiveAssignment, bool isArchivedAssignment, unsigned short questionParameter );

	SpecificationItem *firstQuestionSpecification( bool isIncludingAnsweredQuestions, unsigned short questionParameter );


	// Private specification functions

	ResultType checkSpecificationForUsageInWord( SpecificationItem *unusedSpecificationItem );


	protected:
	// Protected constructible variables

	bool isWordCheckedForSolving;

	SpecificationList *assignmentList;
	CollectionList *collectionList;
	ContextList *contextList;
	GeneralizationList *generalizationList;
	GrammarList *grammarList;
	InterfaceList *interfaceList;
	JustificationList *justificationList;
	WriteList *writeList;
	SpecificationList *specificationList;
	WordTypeList *wordTypeList;

	List *wordList[NUMBER_OF_WORD_LISTS];


	// Protected functions

	ResultType addErrorInWord( const char *functionNameString, const char *moduleNameString, const char *errorString );
	ResultType addErrorInWord( const char *functionNameString, const char *moduleNameString, const char *errorString1, unsigned int number1 );
	ResultType addErrorInWord( const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3 );
	ResultType addErrorInWord( const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3, const char *errorString4, const char *errorString5 );

	ResultType addErrorInWord( char listChar, const char *functionNameString, const char *moduleNameString, const char *errorString );

	ResultType startErrorInWord( const char *functionNameString, const char *moduleNameString, const char *errorString );
	ResultType startErrorInWord( const char *functionNameString, const char *moduleNameString, const char *errorString1, unsigned int number1 );
	ResultType startErrorInWord( const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3 );

	ResultType startSystemErrorInWord( const char *functionNameString, const char *moduleNameString, const char *errorString );


	// Constructor

	WordItem();
	WordItem( unsigned short wordParameter, List *myList, CommonVariables *commonVariables );
	~WordItem();


	// Protected virtual functions

	void showWords( bool returnQueryToPosition );

	virtual bool hasFoundParameter( unsigned int queryParameter );
	virtual bool isSorted( Item *nextSortItem );

	virtual ResultType checkForUsage();
	virtual ResultType findMatchingWordReferenceString( char *searchString );

	virtual char *toString( unsigned short queryWordTypeNr );


	// Protected common functions

	bool hasItems();

	bool iAmAdmin();

	bool isAdjectiveAssignedOrClear();
	bool isAdjectiveCalledOrNamed();
	bool isAdjectiveClear();
	bool isAdjectiveNo();
	bool isAdjectiveComparison();
	bool isAdjectiveComparisonLess();
	bool isAdjectiveComparisonEqual();
	bool isAdjectiveComparisonMore();
	bool isAdjectiveOdd();
	bool isAdjectiveEven();
	bool isAdjectiveOddOrEven();

	bool isNounDeveloper();
	bool isNounHead();
	bool isNounTail();
	bool isNounNumber();
	bool isNounPassword();
	bool isNounUser();
	bool isNounValue();

	bool isBasicVerb();
	bool isVerbImperativeLogin();

	bool isPredefinedWord();
	bool isUserDefinedWord();

	bool isNounWordType( unsigned short wordTypeNr );

	bool needsAuthorizationForChanges();

	unsigned short wordParameter();

	ResultType assignChangePermissions( void *changeKey );

	char wordListChar( unsigned short wordListNr );

	char *grammarLanguageNameString( unsigned short languageNr );
	char *userName( unsigned short userNr );
	char *wordTypeName( unsigned short wordTypeNr );

	WordItem *predefinedWordItem( unsigned short wordParameter );
	WordItem *nextWordItem();


	// Protected assignment functions

	unsigned int numberOfActiveAssignments();

	ResultType createNewAssignmentLevel();

	ResultType deleteAssignmentLevelInWord();
	ResultType deactivateActiveAssignment( SpecificationItem *activeItem );
	ResultType archiveDeactiveAssignment( SpecificationItem *deactiveItem );

	SpecificationResultType getAssignmentOrderNr( unsigned short collectionWordTypeNr );
	SpecificationResultType getAssignmentWordParameter();

	SpecificationResultType assignSpecificationInWord( bool isAmbiguousRelationContext, bool isAssignedOrClear, bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, bool isSelfGenerated, unsigned short prepositionParameter, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int originalSentenceNr, unsigned int activeSentenceNr, unsigned int deactiveSentenceNr, unsigned int archiveSentenceNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *specificationWordItem, char *specificationString, void *changeKey );
	SpecificationResultType findAssignmentByRelationContext( bool isIncludingAnsweredQuestions, bool isDeactive, bool isArchived, bool isPossessive, unsigned short questionParameter, WordItem *relationContextWordItem );
	SpecificationResultType createAssignment( bool isAnsweredQuestion, bool isConcludedAssumption, bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, bool isValueSpecification, unsigned short assignmentLevel, unsigned short assumptionLevel, unsigned short grammarLanguageNr, unsigned short prepositionParameter, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int originalSentenceNr, unsigned int activeSentenceNr, unsigned int deactiveSentenceNr, unsigned int archiveSentenceNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *specificationWordItem, char *specificationString );

	SpecificationItem *firstActiveNumeralAssignment();
	SpecificationItem *firstActiveStringAssignment();
	SpecificationItem *firstActiveAssignmentButNotAQuestion();
	SpecificationItem *lastActiveAssignmentButNotAQuestion();

	SpecificationItem *firstActiveAssignment( bool isQuestion );
	SpecificationItem *firstActiveAssignment( bool isIncludingAnsweredQuestions, unsigned short questionParameter );
	SpecificationItem *firstActiveAssignment( bool isDifferentRelationContext, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString );

	SpecificationItem *firstAssignment( bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString );
	SpecificationItem *firstAssignment( bool includeActiveItems, bool includeDeactiveItems, bool includeArchivedItems, bool isNegative, bool isPossessive, bool isSelfGenerated, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, WordItem *specificationWordItem, char *specificationString );
	SpecificationItem *firstAssignment( bool includeActiveItems, bool includeDeactiveItems, bool includeArchivedItems, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString );
	SpecificationItem *firstAssignment( bool includeActiveItems, bool includeDeactiveItems, bool includeArchivedItems, bool isNegative, bool isPossessive, bool isSelfGenerated, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString );


	// Protected cleanup functions

	void deleteWriteList();

	unsigned int highestSentenceNr();

	ResultType getCurrentItemNrInWord();
	ResultType getHighestInUseSentenceNrInWord( bool includeDeletedItems, bool includeLanguageAssignments, bool includeTemporaryLists, unsigned int highestSentenceNr );

	ResultType deleteRollbackInfo();
	ResultType deleteSentencesInWord( bool isAvailableForRollback, unsigned int lowestSentenceNr );

	ResultType rollbackDeletedRedoInfo();

	ResultType undoCurrentSentence();
	ResultType redoCurrentSentence();

	ResultType removeFirstRangeOfDeletedItems();
	ResultType decrementSentenceNrsInWord( unsigned int startSentenceNr );
	ResultType decrementItemNrRangeInWord( unsigned int decrementSentenceNr, unsigned int decrementItemNr, unsigned int decrementOffset );


	// Protected collection functions

	bool hasCollections();
	bool hasCollectionNr( unsigned int collectionNr );
	bool hasCollection( WordItem *commonWordItem );

	bool hasCollectionOrderNr( unsigned int collectionOrderNr );
	bool hasFoundCollection( unsigned int collectionNr, WordItem *collectionWordItem, WordItem *commonWordItem, WordItem *compoundGeneralizationWordItem );

	bool isCompoundCollection( unsigned int collectionNr );
	bool isCompoundCollection( unsigned int collectionNr, WordItem *commonWordItem );
	bool isCollectedCommonWord( WordItem *commonWordItem );
	bool isExclusiveCollection( unsigned int collectionNr );

	unsigned short collectionOrderNrByWordTypeNr( unsigned short collectionWordTypeNr );
	unsigned short collectionOrderNr( unsigned int collectionNr, WordItem *collectionWordItem, WordItem *commonWordItem );
	unsigned short highestCollectionOrderNrInAllWords( unsigned int collectionNr );

	unsigned int collectionNr( unsigned short collectionWordTypeNr );
	unsigned int collectionNr( unsigned short collectionWordTypeNr, WordItem *commonWordItem );
	unsigned int collectionNr( unsigned short collectionWordTypeNr, WordItem *commonWordItem, WordItem *compoundGeneralizationWordItem );
	unsigned int compoundCollectionNr( unsigned short collectionWordTypeNr );
	unsigned int nonCompoundCollectionNr( unsigned short collectionWordTypeNr );

	unsigned int nonCompoundCollectionNrInAllWords( unsigned int compoundCollectionNr );
	unsigned int collectionNrInAllWords( unsigned int contextNr );
	unsigned int collectionNrInAllWords( unsigned short collectionWordTypeNr, WordItem *compoundGeneralizationWordItem );

	unsigned int highestCollectionNrInAllWords();

	CollectionResultType addCollectionByGeneralization( bool isExclusive, bool isExclusiveGeneralization, bool isQuestion, bool tryGeneralizations, unsigned short collectionWordTypeNr, WordItem *generalizationWordItem, WordItem *collectionWordItem );
	CollectionResultType findCollection( bool isAllowingDifferentCommonWord, WordItem *collectionWordItem, WordItem *commonWordItem );

	ResultType addCollection( bool isExclusive, bool isSpecificationGeneralization, unsigned short collectionWordTypeNr, unsigned short commonWordTypeNr, unsigned int collectionNr, WordItem *collectionWordItem, WordItem *commonWordItem, WordItem *compoundGeneralizationWordItem, char *collectionString );

	WordItem *commonWordItem( unsigned int collectionNr, WordItem *compoundGeneralizationWordItem );
	WordItem *compoundCollectionWordItem( unsigned int collectionNr, WordItem *notThisCommonWordItem );


	// Protected context functions

	void clearContextWriteLevelInWord( unsigned short currentWriteLevel, unsigned int contextNr );

	bool hasContextInWord( bool isPossessive, unsigned int contextNr, WordItem *specificationWordItem );

	bool isContextCurrentlyUpdatedInAllWords( bool isPossessive, unsigned int contextNr, WordItem *specificationWordItem );
	bool isContextSimilarInAllWords( unsigned int firstContextNr, unsigned int secondContextNr );
	bool isContextSubsetInAllWords( unsigned int fullSetContextNr, unsigned int subsetContextNr );

	unsigned short contextWordTypeNrInWord( unsigned int contextNr );
	unsigned short contextWordTypeNrInAllWords( unsigned int contextNr );

	unsigned int contextNrInWord( bool isPossessive, unsigned short contextWordTypeNr, WordItem *specificationWordItem );
	unsigned int highestContextNrInWord();
	unsigned int nContextWords( bool isPossessive, unsigned int relationContextNr, WordItem *specificationWordItem );

	ResultType addContext( bool isPossessive, unsigned short contextWordTypeNr, unsigned short specificationWordTypeNr, unsigned int contextNr, WordItem *specificationWordItem );

	ContextItem *firstActiveContext();
	ContextItem *contextItemInWord( bool isPossessive, unsigned short contextWordTypeNr, WordItem *specificationWordItem );
	ContextItem *contextItemInWord( bool isPossessive, unsigned short contextWordTypeNr, unsigned int contextNr, WordItem *specificationWordItem );

	WordItem *contextWordInAllWords( bool isPossessive, unsigned int contextNr, WordItem *specificationWordItem, WordItem *previousWordItem );


	// Protected generalization functions

	GeneralizationResultType findGeneralization( bool isRelation, unsigned short questionParameter, unsigned short generalizationWordTypeNr, WordItem *generalizationWordItem );

	ResultType createGeneralization( bool isRelation, unsigned short questionParameter, unsigned short specificationWordTypeNr, unsigned short generalizationWordTypeNr, WordItem *generalizationWordItem );

	GeneralizationItem *firstActiveGeneralizationItem();
	GeneralizationItem *firstActiveGeneralizationItemOfSpecification();
	GeneralizationItem *firstActiveGeneralizationItemOfRelation();


	// Protected grammar functions

	void setOptionEnd();
	void setChoiceEnd( unsigned int choiceEndItemNr );

	bool isGrammarLanguage();
	bool needToCheckGrammar();

	unsigned short guideByGrammarStringWordTypeNr( char *guideByGrammarString );

	unsigned int numberOfActiveGrammarLanguages();

	GrammarResultType createGrammar( bool isDefinitionStart, bool isNewStart, bool isOptionStart, bool isChoiceStart, bool skipOptionForWriting, unsigned short wordTypeNr, unsigned short grammarParameter, size_t grammarStringLength, char *grammarString, GrammarItem *definitionGrammarItem );
	GrammarResultType findGrammar( bool ignoreValue, unsigned short grammarParameter, size_t grammarStringLength, char *grammarString );
	GrammarResultType removeDuplicateGrammarDefinition();

	ResultType checkGrammar();
	ResultType checkGrammarForUsageInWord( GrammarItem *unusedGrammarItem );
	ResultType linkLaterDefinedGrammarWords();

	GrammarItem *firstPluralNounEndingGrammarItem();
	GrammarItem *startOfGrammarItem();

	char *getGuideByGrammarString( GrammarItem *startGrammarItem );


	// Protected interface functions

	bool isInterfaceLanguage();

	ResultType checkInterface( unsigned short interfaceParameter, char *interfaceString );
	ResultType createInterface( unsigned short interfaceParameter, size_t interfaceStringLength, char *interfaceString );

	const char *interfaceString( unsigned short interfaceParameter );


	// Protected justification functions

	bool needToRecalculateAssumptionsAfterwards();

	JustificationResultType addJustification( bool forceToCreateJustification, unsigned short justificationTypeNr, unsigned short orderNr, unsigned int originalSentenceNr, JustificationItem *attachedJustificationItem, SpecificationItem *definitionSpecificationItem, SpecificationItem *anotherDefinitionSpecificationItem, SpecificationItem *specificSpecificationItem );
	JustificationResultType checkForConfirmedJustifications( bool isExclusiveGeneralization, unsigned short justificationTypeNr, JustificationItem *specificationJustificationItem, SpecificationItem *definitionSpecificationItem, SpecificationItem *specificSpecificationItem, WordItem *specificationWordItem );

	ResultType attachJustification( JustificationItem *attachJustificationItem, SpecificationItem *currentSpecificationItem );
	ResultType archiveJustification( bool isExclusiveGeneralization, JustificationItem *oldJustificationItem, JustificationItem *replacingJustificationItem );
	ResultType checkSpecificationForUsageOfInvolvedWords( SpecificationItem *unusedSpecificationItem );
	ResultType updateSpecificationsInJustificationInWord( SpecificationItem *oldSpecificationItem, SpecificationItem *replacingSpecificationItem );


	// Protected query functions

	void countQuery();
	void clearQuerySelections();

	ResultType itemQueryInWord( bool isSelectOnFind, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, bool isReferenceQuery, unsigned int querySentenceNr, unsigned int queryItemNr );
	ResultType listQueryInWord( bool isSelectOnFind, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *queryListString );
	ResultType wordTypeQueryInWord( bool isSelectOnFind, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, unsigned short queryWordTypeNr );
	ResultType parameterQueryInWord( bool isSelectOnFind, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, unsigned int queryParameter );
	ResultType wordQueryInWord( bool isSelectOnFind, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *wordReferenceNameString );
	ResultType wordReferenceQueryInWord( bool isSelectOnFind, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *wordReferenceNameString );
	ResultType stringQueryInWord( bool isSelectOnFind, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *queryString );

	ResultType showQueryResultInWord( bool showOnlyWords, bool showOnlyWordReferences, bool showOnlyStrings, bool returnQueryToPosition, unsigned short promptTypeNr, unsigned short queryWordTypeNr, size_t queryWidth );


	// Protected question functions

	ResultType findAnswerToNewUserQuestion();
	ResultType findPossibleQuestionAndMarkAsAnswered( unsigned int compoundSpecificationCollectionNr, SpecificationItem *answerSpecificationItem );
	ResultType writeAnswerToQuestion( bool isNegativeAnswer, bool isPositiveAnswer, SpecificationItem *questionSpecificationItem, SpecificationItem *answerSpecificationItem );

	SpecificationResultType findQuestionToAdjustedByCompoundCollection( bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem );


	// Protected selection functions

	ResultType checkSelectionForUsageInWord( SelectionItem *unusedSelectionItem );


	// Protected specification functions

	void clearLastCheckedAssumptionLevelItemNrInWord();
	void clearHasConfirmedAssumption();
	void clearLastShownConflictSpecification();

	bool addSuggestiveQuestionAssumption();
	bool isConfirmedAssumption();
	bool hasPossessiveSpecificationButNotAQuestion();
	bool isAuthorizedForChanges( void *changeKey );
	bool isCorrectedAssumption();
	bool isCorrectedAssumptionByKnowledge();
	bool isCorrectedAssumptionByOppositeQuestion();

	ResultType archiveOrDeletedSpecification( SpecificationItem *oldSpecificationItem, SpecificationItem *replacingSpecificationItem );
	ResultType checkForSpecificationConflict( bool skipCompoundRelatedConflict, bool isExclusive, bool isNegative, bool isPossessive, unsigned short specificationWordTypeNr, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString );
	ResultType checkJustificationForUsageInWord( JustificationItem *unusedJustificationItem );
	ResultType collectGeneralizationAndSpecifications( bool isExclusiveGeneralization, bool isGeneralizationCollection, bool isQuestion, unsigned int collectionNr );
	ResultType confirmSpecificationButNotRelation( SpecificationItem *confirmedSpecificationItem, SpecificationItem *confirmationSpecificationItem );
	ResultType recalculateAssumptionsInWord();
	ResultType recalculateAssumptionsOfInvolvedWords();
	ResultType replaceOlderSpecifications( unsigned int oldRelationContextNr, SpecificationItem *replacingSpecificationItem );

	ResultType updateJustificationInSpecifications( bool isExclusive, bool isExclusiveGeneralization, JustificationItem *oldJustificationItem, JustificationItem *replacingJustificationItem );
	ResultType updateSpecificationsInJustificationOfInvolvedWords( SpecificationItem *oldSpecificationItem, SpecificationItem *replacingSpecificationItem );

	SpecificationResultType addSpecificationInWord( bool isAssignment, bool isConditional, bool isDeactiveAssignment, bool isArchivedAssignment, bool isExclusive, bool isNegative, bool isPossessive, bool isSelection, bool isSpecificationGeneralization, bool isValueSpecification, unsigned short prepositionParameter, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString, void *changeKey );
	SpecificationResultType createSpecification( bool isAnsweredQuestion, bool isConditional, bool isConcludedAssumption, bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, bool isSpecificationGeneralization, bool isValueSpecification, unsigned short assumptionLevel, unsigned short grammarLanguageNr, unsigned short prepositionParameter, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int originalSentenceNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *specificationWordItem, char *specificationString );

	SpecificationResultType findRelatedSpecification( bool checkRelationContext, SpecificationItem *searchSpecificationItem );
	SpecificationResultType findRelatedSpecification( bool includeAssignments, bool includingDeactiveAssignments, bool isExclusive, bool isPossessive, unsigned short questionParameter, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString );

	SpecificationResultType findSpecification( bool includeAssignments, bool includingDeactiveAssignments, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, WordItem *specificationWordItem, WordItem *relationWordItem );

	SpecificationItem *firstActiveQuestionSpecification();

	SpecificationItem *firstAssignmentOrSpecification( bool isPossessive, unsigned short questionParameter, unsigned int relationContextNr, WordItem *specificationWordItem );
	SpecificationItem *firstAssignmentOrSpecification( bool includeAssignments, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem );
	SpecificationItem *firstAssignmentOrSpecification( bool isAllowingEmptyContextResult, bool isIncludingAnsweredQuestions, bool includeAssignments, bool includeDeactiveItems, bool includeArchivedItems, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString );
	SpecificationItem *firstAssignmentOrSpecification( bool isAllowingEmptyContextResult, bool isIncludingAnsweredQuestions, bool includeAssignments, bool includeDeactiveItems, bool includeArchivedItems, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString );
	SpecificationItem *firstAssignmentOrSpecification( bool isAllowingDifferentLanguage, bool isAllowingEmptyContextResult, bool isIncludingAnsweredQuestions, bool includeAssignments, bool includeDeactiveItems, bool includeArchivedItems, bool isNegative, bool isPossessive, bool isSelfGenerated, unsigned short questionParameter, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString );

	SpecificationItem *firstAssumptionSpecification( bool includeAssignments, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, WordItem *specificationWordItem );

	SpecificationItem *firstSelectedSpecification( bool isAssignment, bool isDeactiveAssignment, bool isArchivedAssignment, bool isQuestion );
	SpecificationItem *firstSelectedSpecification( bool isIncludingAnsweredQuestions, bool isAssignment, bool isDeactiveAssignment, bool isArchivedAssignment, unsigned short questionParameter );

	SpecificationItem *firstSpecification( bool isIncludingAnsweredQuestions, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString );

	SpecificationItem *firstSpecificationButNotAQuestion();
	SpecificationItem *firstAssignmentOrSpecificationButNotAQuestion( bool isAllowingDifferentLanguage, bool isAllowingEmptyContextResult, bool includeActiveAssignments, bool includeDeactiveAssignments, bool includeArchivedAssignments, bool isNegative, bool isPossessive, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem );

	SpecificationItem *firstUserSpecification( bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString );

	SpecificationItem *correctedSuggestiveQuestionAssumptionSpecificationItem();


	// Protected word type functions

	void clearWriteLevel( unsigned short currentWriteLevel );

	bool isCorrectDefiniteArticle( unsigned short definiteArticleParameter, unsigned short wordTypeNr );
	bool isCorrectIndefiniteArticle( unsigned short indefiniteArticleParameter, unsigned short wordTypeNr );
	bool isCorrectHiddenWordType( unsigned short wordTypeNr, char *compareString, void *authorizationKey );
	bool isNumeralBoth();
	bool isNumeralWordType();
	bool isNoun();
	bool isSingularNoun();
	bool isPluralNoun();
	bool isPropername();
	bool isPropernamePrecededByDefiniteArticle( unsigned short definiteArticleParameter );

	ResultType addWordType( bool isPropernamePrecededByDefiniteArticle, unsigned short definiteArticleParameter, unsigned short indefiniteArticleParameter, unsigned short wordTypeNr, size_t wordLength, char *wordTypeString );
	ResultType hideWordType( unsigned short wordTypeNr, void *authorizationKey );
	ResultType deleteWordType( unsigned short wordTypeNr );
	ResultType markWordTypeAsWritten( unsigned short wordTypeNr );

	WordResultType checkWordTypeForBeenWritten( unsigned short wordTypeNr );
	WordResultType findWordType( bool checkAllLanguages, unsigned short searchWordTypeNr, char *searchWordString );
	WordResultType findWordTypeInAllWords( bool checkAllLanguages, unsigned short searchWordTypeNr, char *searchWordString, WordItem *previousWordItem );

	char *anyWordTypeString();
	char *wordTypeString( bool checkAllLanguages, unsigned short orderNr, unsigned short wordTypeNr );

	char *activeSingularNounString();
	char *activeWordTypeString( unsigned short wordTypeNr );

	WordTypeItem *activeWordTypeItem( bool checkAllLanguages, unsigned short wordTypeNr );


	// Protected write functions

	ResultType writeJustificationSpecification( SpecificationItem *justificationSpecificationItem );

	ResultType writeSelectedSpecification( bool isWriteGivenSpecificationWordOnly, SpecificationItem *earlierSpecificationItem );
	ResultType writeSelectedSpecification( bool forceResponseNotBeingAssignment, bool forceResponseNotBeingFirstSpecification, bool writeCurrentSentenceOnly, bool isWriteGivenSpecificationWordOnly, unsigned short answerParameter, SpecificationItem *writeSpecificationItem );

	ResultType writeSelectedSpecificationInfo( bool isAssignment, bool isDeactiveAssignment, bool isArchivedAssignment, bool isQuestion, WordItem *writeWordItem );
	ResultType writeSelectedRelationInfo( bool isAssignment, bool isDeactiveAssignment, bool isArchivedAssignment, bool isQuestion, WordItem *writeWordItem );

	ResultType writeSpecification( bool isAdjustedSpecification, bool isCorrectedAssumptionByKnowledge, bool isCorrectedAssumptionByOppositeQuestion, SpecificationItem *writeSpecificationItem );


	// Protected write sentence functions

	ResultType selectGrammarToWriteSentence( bool isWriteGivenSpecificationWordOnly, unsigned short answerParameter, unsigned short grammarLevel, GrammarItem *selectedGrammarItem, SpecificationItem *writeSpecificationItem );


	// Protected write words functions

	void initializeWordWriteWordsVariables();
	void initializeWordWriteWordsSpecificationVariables( size_t startWordPosition );

	WriteResultType writeWordsToSentence( bool isWriteGivenSpecificationWordOnly, unsigned short answerParameter, GrammarItem *definitionGrammarItem, SpecificationItem *writeSpecificationItem );
	};
#endif

/*************************************************************************
 *
 *	"For the angel of the Lord is a guard;
 *	he surrounds and defends all who fear him." (Psalm 34:7)
 *
 *************************************************************************/
