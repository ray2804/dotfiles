/*
 *	Class:		Item
 *	Purpose:	Base class for the knowledge structure
 *	Version:	Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "List.h"
#include "Presentation.cpp"
//Java
//Java
//Java
//Java
//Java
//Java
//Java
//Java
//Java
//Java

	// Private functions

	char *Item::myWordTypeString( unsigned short queryWordTypeNr )
		{
		char *wordTypeString = NULL;

		if( myList_ != NULL &&
		!myList_->isAdminList() &&	// Don't show my word string when the item is in an admin list
		myWord_ != NULL &&
		( wordTypeString = myWord_->wordTypeString( true, NO_ORDER_NR, queryWordTypeNr ) ) == NULL )
			wordTypeString = myWord_->anyWordTypeString();

		return wordTypeString;
		}


	// Constructor

	Item::Item()
		{
		// Private constructible variables

		userNr_ = NO_USER_NR;

		originalSentenceNr_ = NO_SENTENCE_NR;
		creationSentenceNr_ = NO_SENTENCE_NR;

		activeSentenceNr_ = NO_SENTENCE_NR;
		deactiveSentenceNr_ = NO_SENTENCE_NR;
		archiveSentenceNr_ = NO_SENTENCE_NR;
		deleteSentenceNr_ = NO_SENTENCE_NR;

		itemNr_ = NO_ITEM_NR;

		statusChar_ = QUERY_ACTIVE_CHAR;

		// Private loadable variables

		myList_ = NULL;
		myWord_ = NULL;
		commonVariables_ = NULL;

		strcpy( superClassNameString_, "Item" );
		strcpy( classNameString_, EMPTY_STRING );

		// Protected constructible variables

		isAvailableForRollback = false;
		isSelectedByQuery = false;
		wasActiveBeforeArchiving = false;

		nextItem = NULL;
		previousItem = NULL;
		}


	// Protected error functions

	ResultType Item::addErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString )
		{
		if( commonVariables() != NULL &&
		commonVariables()->presentation != NULL )
			commonVariables()->presentation->showError( SYMBOL_QUESTION_MARK, ( moduleNameString == NULL ? classNameString_ : moduleNameString ), ( moduleNameString == NULL ? superClassNameString_ : NULL ), NULL, functionNameString, errorString );
		else
			fprintf( stderr, "\nClass:\t%s\nSubclass:\t%s\nFunction:\t%s\nError:\t\t%s.\n", classNameString_, superClassNameString_, functionNameString, errorString );

		return ( commonVariables() == NULL ? RESULT_ERROR : commonVariables()->result );
		}

	ResultType Item::addErrorInItem( const char *functionNameString, const char *moduleNameString, char *instanceNameString, const char *errorString )
		{
		if( commonVariables() != NULL &&
		commonVariables()->presentation != NULL )
			commonVariables()->presentation->showError( SYMBOL_QUESTION_MARK, ( moduleNameString == NULL ? classNameString_ : moduleNameString ), ( moduleNameString == NULL ? superClassNameString_ : NULL ), instanceNameString, functionNameString, errorString );
		else
			fprintf( stderr, "\nClass:\t%s\nSubclass:\t%s\nFunction:\t%s\nError:\t\t%s.\n", classNameString_, superClassNameString_, functionNameString, errorString );

		return ( commonVariables() == NULL ? RESULT_ERROR : commonVariables()->result );
		}

	ResultType Item::addErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, unsigned int number1 )
		{
		sprintf( tempString, "%s%u", errorString1, number1 );
		return addErrorInItem( functionNameString, moduleNameString, NULL, tempString );
		}

	ResultType Item::addErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, unsigned int number1, const char *errorString2, unsigned int number2 )
		{
		sprintf( tempString, "%s%u%s%u", errorString1, number1, errorString2, number2 );
		return addErrorInItem( functionNameString, moduleNameString, NULL, tempString );
		}

	ResultType Item::addErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3, unsigned int number1 )
		{
		sprintf( tempString, "%s%s%s%u", errorString1, errorString2, errorString3, number1 );
		return addErrorInItem( functionNameString, moduleNameString, NULL, tempString );
		}

	ResultType Item::addErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3 )
		{
		sprintf( tempString, "%s%s%s", errorString1, errorString2, errorString3 );
		return addErrorInItem( functionNameString, moduleNameString, NULL, tempString );
		}

	ResultType Item::addErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3, const char *errorString4, const char *errorString5 )
		{
		sprintf( tempString, "%s%s%s%s%s", errorString1, errorString2, errorString3, errorString4, errorString5 );
		return addErrorInItem( functionNameString, moduleNameString, NULL, tempString );
		}

	ResultType Item::addErrorInItem( char listChar, const char *functionNameString, const char *moduleNameString, const char *errorString )
		{
		if( commonVariables() != NULL &&
		commonVariables()->presentation != NULL )
			commonVariables()->presentation->showError( listChar, ( moduleNameString == NULL ? classNameString_ : moduleNameString ), ( moduleNameString == NULL ? superClassNameString_ : NULL ), NULL, functionNameString, errorString );
		else
			fprintf( stderr, "\nClass:\t%s\nSubclass:\t%s\nFunction:\t%s\nError:\t\t%s.\n", classNameString_, superClassNameString_, functionNameString, errorString );

		return ( commonVariables() == NULL ? RESULT_ERROR : commonVariables()->result );
		}

	ResultType Item::addErrorInItem( char listChar, const char *functionNameString, const char *moduleNameString, char *instanceNameString, const char *errorString )
		{
		if( commonVariables() != NULL &&
		commonVariables()->presentation != NULL )
			commonVariables()->presentation->showError( listChar, ( moduleNameString == NULL ? classNameString_ : moduleNameString ), ( moduleNameString == NULL ? superClassNameString_ : NULL ), instanceNameString, functionNameString, errorString );
		else
			fprintf( stderr, "\nClass:\t%s\nSubclass:\t%s\nFunction:\t%s\nError:\t\t%s.\n", classNameString_, superClassNameString_, functionNameString, errorString );

		return ( commonVariables() == NULL ? RESULT_ERROR : commonVariables()->result );
		}

	ResultType Item::addErrorInItem( char listChar, const char *functionNameString, const char *moduleNameString, const char *errorString1, unsigned int number1 )
		{
		sprintf( tempString, "%s%u", errorString1, number1 );
		return addErrorInItem( listChar, functionNameString, moduleNameString, tempString );
		}

	ResultType Item::addErrorInItem( char listChar, const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3 )
		{
		sprintf( tempString, "%s%s%s", errorString1, errorString2, errorString3 );
		return addErrorInItem( listChar, functionNameString, moduleNameString, tempString );
		}

	ResultType Item::addErrorInItem( char listChar, const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3, const char *errorString4, const char *errorString5 )
		{
		sprintf( tempString, "%s%s%s%s%s", errorString1, errorString2, errorString3, errorString4, errorString5 );
		return addErrorInItem( listChar, functionNameString, moduleNameString, tempString );
		}

	ResultType Item::startErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString )
		{
		addErrorInItem( functionNameString, moduleNameString, NULL, errorString );

		if( commonVariables() != NULL )
		commonVariables()->result = RESULT_ERROR;

		return RESULT_ERROR;
		}

	ResultType Item::startErrorInItem( const char *functionNameString, const char *moduleNameString, char *instanceNameString, const char *errorString )
		{
		addErrorInItem( functionNameString, moduleNameString, instanceNameString, errorString );

		if( commonVariables() != NULL )
		commonVariables()->result = RESULT_ERROR;

		return RESULT_ERROR;
		}

	ResultType Item::startErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, unsigned int number1 )
		{
		sprintf( tempString, "%s%u", errorString1, number1 );
		return startErrorInItem( functionNameString, moduleNameString, NULL, tempString );
		}

	ResultType Item::startErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, unsigned int number1, const char *errorString2, unsigned int number2 )
		{
		sprintf( tempString, "%s%u%s%u", errorString1, number1, errorString2, number2 );
		return startErrorInItem( functionNameString, moduleNameString, tempString );
		}

	ResultType Item::startErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, unsigned int number1, const char *errorString2, unsigned int number2, const char *errorString3, unsigned int number3 )
		{
		sprintf( tempString, "%s%u%s%u%s%u", errorString1, number1, errorString2, number2, errorString3, number3 );
		return startErrorInItem( functionNameString, moduleNameString, tempString );
		}

	ResultType Item::startErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, char char1, const char *errorString2 )
		{
		sprintf( tempString, "%s%c%s", errorString1, char1, errorString2 );
		return startErrorInItem( functionNameString, moduleNameString, tempString );
		}

	ResultType Item::startErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, char char1, const char *errorString2, char char2, const char *errorString3 )
		{
		sprintf( tempString, "%s%c%s%c%s", errorString1, char1, errorString2, char2, errorString3 );
		return startErrorInItem( functionNameString, moduleNameString, tempString );
		}

	ResultType Item::startErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3 )
		{
		sprintf( tempString, "%s%s%s", errorString1, errorString2, errorString3 );
		return startErrorInItem( functionNameString, moduleNameString, tempString );
		}

	ResultType Item::startErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3, const char *errorString4, const char *errorString5 )
		{
		sprintf( tempString, "%s%s%s%s%s", errorString1, errorString2, errorString3, errorString4, errorString5 );
		return startErrorInItem( functionNameString, moduleNameString, tempString );
		}

	ResultType Item::startErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3, const char *errorString4, const char *errorString5, const char *errorString6, const char *errorString7 )
		{
		sprintf( tempString, "%s%s%s%s%s%s%s", errorString1, errorString2, errorString3, errorString4, errorString5, errorString6, errorString7 );
		return startErrorInItem( functionNameString, moduleNameString, tempString );
		}

	ResultType Item::startErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3, unsigned int number1, const char *errorString4, unsigned int number2, const char *errorString5, unsigned int number3 )
		{
		sprintf( tempString, "%s%s%s%u%s%u%s%u", errorString1, errorString2, errorString3, number1, errorString4, number2, errorString5, number3 );
		return startErrorInItem( functionNameString, moduleNameString, tempString );
		}

	ResultType Item::startErrorInItem( char listChar, const char *functionNameString, const char *moduleNameString, const char *errorString )
		{
		addErrorInItem( listChar, functionNameString, moduleNameString, errorString );

		if( commonVariables() != NULL )
		commonVariables()->result = RESULT_ERROR;

		return RESULT_ERROR;
		}

	ResultType Item::startErrorInItem( char listChar, const char *functionNameString, const char *moduleNameString, char *instanceNameString, const char *errorString )
		{
		addErrorInItem( listChar, functionNameString, moduleNameString, instanceNameString, errorString );

		if( commonVariables() != NULL )
		commonVariables()->result = RESULT_ERROR;

		return RESULT_ERROR;
		}

	ResultType Item::startErrorInItem( char listChar, const char *functionNameString, const char *moduleNameString, const char *errorString1, unsigned int number1 )
		{
		sprintf( tempString, "%s%u", errorString1, number1 );
		return startErrorInItem( listChar, functionNameString, moduleNameString, tempString );
		}

	ResultType Item::startErrorInItem( char listChar, const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3 )
		{
		sprintf( tempString, "%s%s%s", errorString1, errorString2, errorString3 );
		return startErrorInItem( listChar, functionNameString, moduleNameString, tempString );
		}

	ResultType Item::startErrorInItem( char listChar, const char *functionNameString, const char *moduleNameString, const char *errorString1, unsigned int number1, const char *errorString2, unsigned int number2 )
		{
		sprintf( tempString, "%s%u%s%u", errorString1, number1, errorString2, number2 );
		return startErrorInItem( listChar, functionNameString, moduleNameString, tempString );
		}

	ResultType Item::startSystemErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString )
		{
		return startSystemErrorInItem( functionNameString, moduleNameString, NULL, errorString );
		}

	ResultType Item::startSystemErrorInItem( const char *functionNameString, const char *moduleNameString, char *instanceNameString, const char *errorString )
		{
		char textChar;
		size_t tempStringPosition = 0;
		size_t errorStringPosition = 0;
		char tempString[MAX_READ_WRITE_STRING_LENGTH] = EMPTY_STRING;

		while( errorStringPosition < strlen( errorString ) )
			{
			if( errorString[errorStringPosition] == TEXT_DIACRITICAL_CHAR )
				{
				errorStringPosition++;

				if( errorStringPosition < strlen( errorString ) &&
				( textChar = commonVariables()->presentation->convertDiacriticalChar( errorString[errorStringPosition] ) ) != NEW_LINE_CHAR )
					tempString[tempStringPosition++] = textChar;
				}
			else
				tempString[tempStringPosition++] = errorString[errorStringPosition];

			errorStringPosition++;
			}

		addErrorInItem( functionNameString, moduleNameString, instanceNameString, tempString );

		if( commonVariables() != NULL )
		commonVariables()->result = RESULT_SYSTEM_ERROR;

		return RESULT_SYSTEM_ERROR;
		}


	// Protected virtual functions

	void Item::showString( bool returnQueryToPosition )
		{
		// This is a virtual function. Therefore the given variables are unreferenced
		}

	void Item::showWordReferences( bool returnQueryToPosition )
		{
		// This is a virtual function. Therefore the given variables are unreferenced
		}

	bool Item::isSorted( Item *nextSortItem )
		{
		return ( nextSortItem == NULL ||
				// Descending creationSentenceNr
				creationSentenceNr() > nextSortItem->creationSentenceNr() );
		}

	bool Item::hasFoundParameter( unsigned int queryParameter )
		{
		// This is a virtual function. Therefore the given variables are unreferenced
		return false;
		}

	bool Item::hasFoundWordType( unsigned short queryWordTypeNr )
		{
		// This is a virtual function. Therefore the given variables are unreferenced
		return false;
		}

	bool Item::hasFoundReferenceItemById( unsigned int querySentenceNr, unsigned int queryItemNr )
		{
		// This is a virtual function. Therefore the given variables are unreferenced
		return false;
		}

	ResultType Item::checkForUsage()
		{
		return commonVariables()->result;
		}

	ResultType Item::findMatchingWordReferenceString( char *queryString )
		{
		// This is a virtual function. Therefore the given variables are unreferenced
		commonVariables()->hasFoundMatchingStrings = false;
		return commonVariables()->result;
		}

	void Item::showWords( bool returnQueryToPosition, unsigned short queryWordTypeNr )
		{
		// This is a virtual function. Therefore the given variables are unreferenced
		char *myWordString;
		char statusString[2] = SPACE_STRING;
		statusString[0] = statusChar_;

//Java
		if( ( myWordString = myWordTypeString( queryWordTypeNr ) ) != NULL )
			{
			if( commonVariables()->hasFoundQuery )
				strcat( commonVariables()->queryString, ( returnQueryToPosition ? NEW_LINE_STRING : QUERY_SEPARATOR_SPACE_STRING ) );

			if( !isActiveItem() )	// Show status when not active
				strcat( commonVariables()->queryString, statusString );

			commonVariables()->hasFoundQuery = true;
			strcat( commonVariables()->queryString, myWordString );
			}
		}

	char *Item::itemString()
		{
		return NULL;
		}

	char *Item::extraItemString()
		{
		return NULL;
		}


	char *Item::toString( unsigned short queryWordTypeNr )
		{
		char *myWordString = myWordTypeString( queryWordTypeNr );
		char *userNameString = ( myWord_ == NULL ? NULL : myWord_->userName( userNr_ ) );
		char statusString[2] = SPACE_STRING;
		statusString[0] = statusChar_;
		strcpy( commonVariables()->queryString, EMPTY_STRING );

		if( !isActiveItem() )	// Show status when not active
			strcat( commonVariables()->queryString, statusString );

		if( myWordString != NULL )
			{
			sprintf( tempString, "%c%s%c", QUERY_WORD_START_CHAR, myWordString, QUERY_WORD_END_CHAR );
			strcat( commonVariables()->queryString, tempString );
			}

		sprintf( tempString, "%c%c%c", QUERY_LIST_START_CHAR, ( myList_ == NULL ? QUERY_NO_LIST_CHAR : myList_->listChar() ), QUERY_LIST_END_CHAR );
		strcat( commonVariables()->queryString, tempString );

		sprintf( tempString, "%c%u%c%u%c", QUERY_ITEM_START_CHAR, creationSentenceNr_, QUERY_SEPARATOR_CHAR, itemNr_, QUERY_ITEM_END_CHAR );
		strcat( commonVariables()->queryString, tempString );

		if( isAvailableForRollback )
			{
			strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
			strcat( commonVariables()->queryString, "isAvailableForRollback" );
			}

/*		if( isSelectedByQuery )		// Always true during query
			{
			strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
			strcat( commonVariables()->queryString, "isSelectedByQuery" );
			}
*/

		if( wasActiveBeforeArchiving )
			{
			strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
			strcat( commonVariables()->queryString, "wasActiveBeforeArchiving" );
			}

		if( userNr_ > NO_USER_NR )
			{
			if( userNameString != NULL )
				sprintf( tempString, "%cuser:%s", QUERY_SEPARATOR_CHAR, userNameString );
			else
				sprintf( tempString, "%cuser:%u", QUERY_SEPARATOR_CHAR, userNr_ );

			strcat( commonVariables()->queryString, tempString );
			}

		if( originalSentenceNr_ > NO_SENTENCE_NR &&
		originalSentenceNr_ != creationSentenceNr_ )
			{
			sprintf( tempString, "%coriginal:%c%u%c", QUERY_SEPARATOR_CHAR, QUERY_DEACTIVE_ITEM_START_CHAR, originalSentenceNr_, QUERY_DEACTIVE_ITEM_END_CHAR );
			strcat( commonVariables()->queryString, tempString );
			}

		if( activeSentenceNr_ > NO_SENTENCE_NR &&
		activeSentenceNr_ != creationSentenceNr_ )
			{
			sprintf( tempString, "%cactive:%c%u%c", QUERY_SEPARATOR_CHAR, QUERY_DEACTIVE_ITEM_START_CHAR, activeSentenceNr_, QUERY_DEACTIVE_ITEM_END_CHAR );
			strcat( commonVariables()->queryString, tempString );
			}

		if( deactiveSentenceNr_ > NO_SENTENCE_NR &&
		deactiveSentenceNr_ != creationSentenceNr_ )
			{
			sprintf( tempString, "%cdeactive:%c%u%c", QUERY_SEPARATOR_CHAR, QUERY_DEACTIVE_ITEM_START_CHAR, deactiveSentenceNr_, QUERY_DEACTIVE_ITEM_END_CHAR );
			strcat( commonVariables()->queryString, tempString );
			}

		if( archiveSentenceNr_ > NO_SENTENCE_NR )
			{
			sprintf( tempString, "%carchive:%c%u%c", QUERY_SEPARATOR_CHAR, QUERY_DEACTIVE_ITEM_START_CHAR, archiveSentenceNr_, QUERY_DEACTIVE_ITEM_END_CHAR );
			strcat( commonVariables()->queryString, tempString );
			}

		if( deleteSentenceNr_ > NO_SENTENCE_NR )
			{
			sprintf( tempString, "%cdelete:%c%u%c", QUERY_SEPARATOR_CHAR, QUERY_DEACTIVE_ITEM_START_CHAR, deleteSentenceNr_, QUERY_DEACTIVE_ITEM_END_CHAR );
			strcat( commonVariables()->queryString, tempString );
			}

		return commonVariables()->queryString;
		}


	// Protected common functions

	void Item::setActiveStatus()
		{
		statusChar_ = QUERY_ACTIVE_CHAR;
		}

	void Item::setDeactiveStatus()
		{
		statusChar_ = QUERY_DEACTIVE_CHAR;
		}

	void Item::setArchivedStatus()
		{
		statusChar_ = QUERY_ARCHIVE_CHAR;
		}

	void Item::setDeletedStatus()
		{
		statusChar_ = QUERY_DELETED_CHAR;
		}

	void Item::setActiveSentenceNr()
		{
		if( activeSentenceNr_ == NO_SENTENCE_NR )
			activeSentenceNr_ = commonVariables_->currentSentenceNr;
		}

	void Item::setDeactiveSentenceNr()
		{
		if( deactiveSentenceNr_ == NO_SENTENCE_NR )
			deactiveSentenceNr_ = commonVariables_->currentSentenceNr;
		}

	void Item::setArchivedSentenceNr()
		{
		if( archiveSentenceNr_ == NO_SENTENCE_NR )
			archiveSentenceNr_ = commonVariables_->currentSentenceNr;
		}

	void Item::setDeletedSentenceNr()
		{
		deleteSentenceNr_ = commonVariables_->currentSentenceNr;
		}

	void Item::clearArchivedSentenceNr()
		{
		archiveSentenceNr_ = NO_SENTENCE_NR;
		}

	// Strictly to init AdminItem
	void Item::initializeItemVariables( const char *classNameString, WordItem *myWord, CommonVariables *commonVariables )
		{
		// Private constructible variables

//		AdminItem has no constructible variables to be initialized

		// Private loadable variables

//		AdminItem has no myList_;
		myWord_ = myWord;
		commonVariables_ = commonVariables;

		if( myWord_ != NULL )
			{
			if( commonVariables_ != NULL )
				{
				if( classNameString != NULL )
					strcpy( classNameString_, classNameString );
				else
					startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, NULL, "The given class name string is undefined" );
				}
			else
				startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, NULL, "The given common variables is undefined" );
			}
		else
			startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, NULL, "The given my word is undefined" );
		}

	void Item::initializeItemVariables( unsigned int originalSentenceNr, unsigned int activeSentenceNr, unsigned int deactiveSentenceNr, unsigned int archiveSentenceNr, const char *classNameString, List *myList, WordItem *myWord, CommonVariables *commonVariables )
		{
		// Private loadable variables

		myList_ = myList;
		myWord_ = myWord;
		commonVariables_ = commonVariables;

		// Private constructible variables

		if( commonVariables_ != NULL )
			{
		if( commonVariables_->currentUserNr > NO_USER_NR )
			userNr_ = commonVariables_->currentUserNr;

		originalSentenceNr_ = ( originalSentenceNr == NO_SENTENCE_NR ? commonVariables_->currentSentenceNr : originalSentenceNr );
		creationSentenceNr_ = commonVariables_->currentSentenceNr;

		activeSentenceNr_ = ( originalSentenceNr == NO_SENTENCE_NR ? commonVariables_->currentSentenceNr : activeSentenceNr );
		deactiveSentenceNr_ = deactiveSentenceNr;
		archiveSentenceNr_ = archiveSentenceNr;

		itemNr_ = ++commonVariables_->currentItemNr;
			}

		if( myList_ != NULL )
			{
			if( myWord_ != NULL )
				{
				if( commonVariables_ != NULL )
					{
					if( classNameString != NULL )
						strcpy( classNameString_, classNameString );
					else
						startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, NULL, "The given class name string is undefined" );
					}
				else
					startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, NULL, "The given common variables is undefined" );
				}
			else
				startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, NULL, "The given my word is undefined" );
			}
		else
			startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, NULL, "The given my list is undefined" );
		}

	bool Item::hasActiveSentenceNr()
		{
		return ( activeSentenceNr_ > NO_SENTENCE_NR );
		}

	bool Item::hasDeactiveSentenceNr()
		{
		return ( deactiveSentenceNr_ > NO_SENTENCE_NR );
		}

	bool Item::hasArchivedSentenceNr()
		{
		return ( archiveSentenceNr_ > NO_SENTENCE_NR );
		}

	bool Item::hasCurrentCreationSentenceNr()
		{
		return ( creationSentenceNr_ == commonVariables_->currentSentenceNr );
		}

	bool Item::hasCurrentActiveSentenceNr()
		{
		return ( activeSentenceNr_ == commonVariables_->currentSentenceNr );
		}

	bool Item::hasCurrentDeactiveSentenceNr()
		{
		return ( deactiveSentenceNr_ == commonVariables_->currentSentenceNr );
		}

	bool Item::hasCurrentArchivedSentenceNr()
		{
		return ( archiveSentenceNr_ == commonVariables_->currentSentenceNr );
		}

	bool Item::hasCurrentDeletedSentenceNr()
		{
		return ( deleteSentenceNr_ == commonVariables_->currentSentenceNr );
		}

	bool Item::isOlderSentence()
		{
		return ( originalSentenceNr_ < commonVariables_->currentSentenceNr );
		}

	bool Item::isActiveItem()
		{
		return ( statusChar_ == QUERY_ACTIVE_CHAR );
		}

	bool Item::isDeactiveItem()
		{
		return ( statusChar_ == QUERY_DEACTIVE_CHAR );
		}

	bool Item::isArchivedItem()
		{
		return ( statusChar_ == QUERY_ARCHIVE_CHAR );
		}

	bool Item::isDeletedItem()
		{
		return ( statusChar_ == QUERY_DELETED_CHAR );
		}

	bool Item::isMoreRecent( Item *checkItem )
		{
		return ( checkItem != NULL &&

				( creationSentenceNr_ > checkItem->creationSentenceNr() ||

				( creationSentenceNr_ == checkItem->creationSentenceNr() &&
				itemNr_ > checkItem->itemNr() ) ) );
		}

	bool Item::isStringStartingWithVowel( char *textString )
		{
		unsigned short index = 0;

		if( textString != NULL )
			{
			while( index < NUMBER_OF_VOWELS )
				{
				if( textString[0] == VOWEL[index] )
					return true;

				index++;
				}
			}

		return false;
		}

	unsigned short Item::userNr()
		{
		return userNr_;
		}

	unsigned int Item::activeSentenceNr()
		{
		return activeSentenceNr_;
		}

	unsigned int Item::deactiveSentenceNr()
		{
		return deactiveSentenceNr_;
		}

	unsigned int Item::originalSentenceNr()
		{
		return originalSentenceNr_;
		}

	unsigned int Item::creationSentenceNr()
		{
		return creationSentenceNr_;
		}

	unsigned int Item::archiveSentenceNr()
		{
		return archiveSentenceNr_;
		}

	unsigned int Item::deleteSentenceNr()
		{
		return deleteSentenceNr_;
		}

	unsigned int Item::itemNr()
		{
		return itemNr_;
		}

	ResultType Item::decrementActiveSentenceNr()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "decrementActiveSentenceNr";
		if( activeSentenceNr_ > NO_SENTENCE_NR )
			activeSentenceNr_--;
		else
			return startErrorInItem( functionNameString, superClassNameString_, "The active sentence number is too low for a decrement" );

		return commonVariables()->result;
		}

	ResultType Item::decrementDeactiveSentenceNr()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "decrementDeactiveSentenceNr";
		if( deactiveSentenceNr_ > NO_SENTENCE_NR )
			deactiveSentenceNr_--;
		else
			return startErrorInItem( functionNameString, superClassNameString_, "The deactive sentence number is too low for a decrement" );

		return commonVariables()->result;
		}

	ResultType Item::decrementOriginalSentenceNr()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "decrementOriginalSentenceNr";
		if( originalSentenceNr_ > NO_SENTENCE_NR )
			originalSentenceNr_--;
		else
			return startErrorInItem( functionNameString, superClassNameString_, "The original sentence number is too low for a decrement" );

		return commonVariables()->result;
		}

	ResultType Item::decrementCreationSentenceNr()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "decrementCreationSentenceNr";
		if( creationSentenceNr_ > NO_SENTENCE_NR )
			creationSentenceNr_--;
		else
			return startErrorInItem( functionNameString, superClassNameString_, "The creation sentence number is too low for a decrement" );

		return commonVariables()->result;
		}

	ResultType Item::decrementArchivedSentenceNr()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "decrementArchivedSentenceNr";
		if( archiveSentenceNr_ > NO_SENTENCE_NR )
			archiveSentenceNr_--;
		else
			return startErrorInItem( functionNameString, superClassNameString_, "The archive sentence number is too low for a decrement" );

		return commonVariables()->result;
		}

	ResultType Item::decrementCreationItemNr( unsigned int decrementOffset )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "decrementCreationItemNr";
		if( itemNr_ > decrementOffset )
			itemNr_ -= decrementOffset;
		else
			return startErrorInItem( functionNameString, superClassNameString_, "The given decrement offset is higher than the creation item number itself" );

		return commonVariables()->result;
		}

	char Item::statusChar()
		{
		return statusChar_;
		}

	List *Item::myList()
		{
		return myList_;
		}

	WordItem *Item::myWord()
		{
		return myWord_;
		}

	CommonVariables *Item::commonVariables()
		{
		return commonVariables_;
		}

/*************************************************************************
 *
 *	"Give thanks to him who made the heavenly lights-
 *		His faithful love endures forever.
 *	the sun to rule the day
 *		His faithful love endures forever.
 *	and the moon and stars to rule the night.
 *		His faithful love endures forever." (Psalm 136:7-9)
 *
 *************************************************************************/
