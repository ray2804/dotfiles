/* License/copyright: At the end of this file or read copyright.txt */

/*---------- Declarations --------------*/
char *tlastrstr(char *line, char *searchedword);
