package mysql_getdoc::h4;
use base qw(mysql_getdoc);
use strict;


1;
