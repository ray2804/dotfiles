// Modified via http://www.w3schools.com/ajax/ajax_example_suggest.asp

var xmlHttp;

function showFiles(str){

	xmlHttp=GetXmlHttpObject()
	if (xmlHttp==null)	{
		return;
	} 
	var url="backshot.php";
	url=url+"?history="+str;
	url=url+"&sid="+Math.random();
	xmlHttp.onreadystatechange=stateChangedHistory;
	xmlHttp.open("GET",url,true);
	xmlHttp.send(null);
}

function showPage(str){

	xmlHttp=GetXmlHttpObject()
	if (xmlHttp==null)	{
		return;
	} 
	var url="backshot.php";
	url=url+"?page="+str;
	url=url+"&sid="+Math.random();
	xmlHttp.onreadystatechange=stateChangedPage;
	xmlHttp.open("GET",url,true);
	xmlHttp.send(null);
	
	if(str == "add"){
		document.getElementById("links").innerHTML="<a href=\"history.php\">history</a> | <a href=\"#\" onclick=\"return showPage(\'main\')\">main</a>"
	} else {
		document.getElementById("links").innerHTML="<a href=\"history.php\">history</a> | <a href=\"#\" onclick=\"return showPage(\'add\')\">add file</a>"
	}	
	
}

function showHint(str){
	if (str.length==0)	{ 
		document.getElementById("suggest").innerHTML="no suggestion";
		return;
	}
	
	xmlHttp=GetXmlHttpObject()
	if (xmlHttp==null)	{
		return;
	} 
	var url="backshot.php";
	url=url+"?value="+str;
	url=url+"&sid="+Math.random();
	xmlHttp.onreadystatechange=stateChangedSuggest;
	xmlHttp.open("GET",url,true);
	xmlHttp.send(null);
}

function stateChangedSuggest(){ 
	if (xmlHttp.readyState==4){ 
		document.getElementById("suggest").innerHTML=xmlHttp.responseText;
	}
}

function stateChangedPage(){ 
	if (xmlHttp.readyState==4){ 
		document.getElementById("page").innerHTML=xmlHttp.responseText;
	}
}

function stateChangedHistory(){ 
	if (xmlHttp.readyState==4){ 
		document.getElementById("history").innerHTML=xmlHttp.responseText;
	}
}

function GetXmlHttpObject(){
	var xmlHttp=null;
	try {
		// Firefox, Opera 8.0+, Safari
		xmlHttp=new XMLHttpRequest();
	}catch (e){
		// Internet Explorer
		try{
			xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e){
			xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
		}
	}
	return xmlHttp;
}
