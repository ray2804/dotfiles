/*
 *	Class:			WordWrite
 *	Supports class:	WordItem
 *	Purpose:		To write selected specifications as sentences
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "Presentation.cpp"
#include "SpecificationItem.cpp"

class WordWrite
	{
	// Private constructible variables

	CommonVariables *commonVariables_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];

	public:
	// Constructor

	WordWrite( WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "WordWrite" );

		if( commonVariables_ != NULL )
			{
		if( myWord_ == NULL )
			strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInWord( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	ResultType writeJustificationSpecification( SpecificationItem *justificationSpecificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeJustificationSpecification";
		if( justificationSpecificationItem != NULL )
			{
			if( writeSelectedSpecification( true, true, false, false, NO_ANSWER_PARAMETER, justificationSpecificationItem ) == RESULT_OK )
				{
				if( strlen( commonVariables_->writeSentenceString ) > 0 )
					{
					if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WRITE, INTERFACE_LISTING_JUSTIFICATION_SENTENCE_START ) == RESULT_OK )
						{
						if( commonVariables_->presentation->writeDiacriticalText( true, false, PRESENTATION_PROMPT_WRITE, commonVariables_->writeSentenceString ) != RESULT_OK )
							return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a justification sentence" );
						}
					else
						return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write the justification sentence start string" );
					}
				else
					return myWord_->startErrorInWord( functionNameString, moduleNameString_, "I couldn't write the selected specification with justification" );
				}
			else
				return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a selected specification with justification" );
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given justification specification item is undefined" );

		return commonVariables_->result;
		}

	ResultType writeSelectedSpecificationInfo( bool isAssignment, bool isDeactive, bool isArchived, bool isQuestion, WordItem *writeWordItem )
		{
		bool isGrammarLanguage = myWord_->isGrammarLanguage();
		SpecificationItem *currentSpecificationItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeSpecificationInfo";

		if( writeWordItem != NULL )
			{
			if( ( currentSpecificationItem = myWord_->firstSelectedSpecification( isAssignment, ( isAssignment && isDeactive ), ( isAssignment && isArchived ), isQuestion ) ) != NULL )
				{
				do	{
					if( currentSpecificationItem->specificationWordItem() == writeWordItem &&

					( isGrammarLanguage ||
					currentSpecificationItem->grammarLanguageNr() == commonVariables_->currentGrammarLanguageNr ) )
						{
						if( writeSelectedSpecification( false, true, false, false, NO_ANSWER_PARAMETER, currentSpecificationItem ) == RESULT_OK )
							{
							if( strlen( commonVariables_->writeSentenceString ) > 0 )
								{
								if( commonVariables_->presentation->writeInterfaceText( true, PRESENTATION_PROMPT_WRITE, ( isQuestion ? INTERFACE_LISTING_SPECIFICATION_QUESTIONS : INTERFACE_LISTING_SPECIFICATIONS ) ) == RESULT_OK )
									{
									if( commonVariables_->presentation->writeDiacriticalText( PRESENTATION_PROMPT_WRITE, commonVariables_->writeSentenceString ) != RESULT_OK )
										return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a sentence" );
									}
								else
									return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a related header" );
								}
							}
						else
							return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a selected specification" );
						}
					}
				while( ( currentSpecificationItem = currentSpecificationItem->nextSelectedSpecificationItem( false ) ) != NULL );
				}
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given write word item is undefined" );

		return commonVariables_->result;
		}

	ResultType writeSelectedRelationInfo( bool isAssignment, bool isDeactive, bool isArchived, bool isQuestion, WordItem *writeWordItem )
		{
		bool isGrammarLanguage = myWord_->isGrammarLanguage();
		SpecificationResultType specificationResult;
		SpecificationItem *foundAssignmentItem;
		SpecificationItem *currentSpecificationItem = NULL;
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeRelatedInfo";

		if( writeWordItem != NULL )
			{
			if( ( currentSpecificationItem = myWord_->firstSelectedSpecification( isAssignment, ( isAssignment && isDeactive ), ( isAssignment && isArchived ), isQuestion ) ) != NULL )
				{
				do	{
					if( writeWordItem->hasContextInWord( currentSpecificationItem->isPossessive(), currentSpecificationItem->relationContextNr(), currentSpecificationItem->specificationWordItem() ) &&

					( isGrammarLanguage ||
					currentSpecificationItem->grammarLanguageNr() == commonVariables_->currentGrammarLanguageNr ) )
						{
						if( ( specificationResult = myWord_->findAssignmentByRelationContext( true, isDeactive, isArchived, currentSpecificationItem->isPossessive(), currentSpecificationItem->questionParameter(), writeWordItem ) ).result == RESULT_OK )
							{
							foundAssignmentItem = specificationResult.foundSpecificationItem;

							if( isQuestion ||

							( isAssignment &&
							foundAssignmentItem != NULL ) ||

							( !isAssignment &&
							foundAssignmentItem == NULL ) )
								{
								if( writeSelectedSpecification( false, false, false, false, NO_ANSWER_PARAMETER, currentSpecificationItem ) == RESULT_OK )
									{
									if( strlen( commonVariables_->writeSentenceString ) > 0 )
										{
										if( commonVariables_->presentation->writeInterfaceText( true, PRESENTATION_PROMPT_NOTIFICATION, ( isQuestion ? INTERFACE_LISTING_RELATED_QUESTIONS : INTERFACE_LISTING_RELATED_INFORMATION ) ) == RESULT_OK )
											{
											if( commonVariables_->presentation->writeDiacriticalText( PRESENTATION_PROMPT_WRITE, commonVariables_->writeSentenceString ) != RESULT_OK )
												return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a sentence" );
											}
										else
											return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a related header" );
										}
									}
								else
									return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a selected specification" );
								}
							}
						else
							return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find an assignment by relation context" );
						}
					}
				while( ( currentSpecificationItem = currentSpecificationItem->nextSelectedSpecificationItem( false ) ) != NULL );
				}
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given write word item is undefined" );

		return commonVariables_->result;
		}

	ResultType writeSelectedSpecification( bool forceResponseNotBeingAssignment, bool forceResponseNotBeingFirstSpecification, bool writeOnlyCurrentSentence, bool writeOnlyGivenSpecificationWord, unsigned short answerParameter, SpecificationItem *writeSpecificationItem )
		{
		SpecificationResultType specificationResult;
		bool isFirstRelatedSpecification;
		bool isSpecificationCompoundCollection;
		bool hasAssignment = false;
		bool isCombinedSpecification = false;
		bool isLastCompoundSpecification = false;
		bool isPossessiveRelation = false;
		bool isSelfGeneratedDefinitionConclusion = false;
		unsigned short currentCollectionOrderNr;
		unsigned short highestCollectionOrderNr;
		SpecificationItem *foundRelatedSpecificationItem;
		WordItem *specificationWordItem;
		char *specificationString;
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeSelectedSpecification";

		strcpy( commonVariables_->writeSentenceString, EMPTY_STRING );

		if( writeSpecificationItem != NULL )
			{
			if( ( specificationResult = myWord_->findRelatedSpecification( !writeSpecificationItem->isSelfGeneratedAssumption(), writeSpecificationItem ) ).result == RESULT_OK )
				{
				isFirstRelatedSpecification = specificationResult.isFirstRelatedSpecification;
				foundRelatedSpecificationItem = specificationResult.relatedSpecificationItem;
				specificationWordItem = writeSpecificationItem->specificationWordItem();
				specificationString = writeSpecificationItem->specificationString();

				if( !writeSpecificationItem->isAssignment() )
					{
					if( myWord_->firstAssignment( writeSpecificationItem->isPossessive(), writeSpecificationItem->questionParameter(), writeSpecificationItem->generalizationContextNr(), writeSpecificationItem->specificationContextNr(), writeSpecificationItem->relationContextNr(), specificationWordItem, specificationString ) != NULL )
						hasAssignment = true;
					}

				isSpecificationCompoundCollection = writeSpecificationItem->isSpecificationCompoundCollection();
				highestCollectionOrderNr = myWord_->highestCollectionOrderNrInAllWords( writeSpecificationItem->specificationCollectionNr() );
				currentCollectionOrderNr = ( specificationWordItem == NULL ? myWord_->collectionOrderNrByWordTypeNr( writeSpecificationItem->specificationWordTypeNr() ) : specificationWordItem->collectionOrderNrByWordTypeNr( writeSpecificationItem->specificationWordTypeNr() ) );

				if( !isFirstRelatedSpecification &&
				isSpecificationCompoundCollection &&
				currentCollectionOrderNr == highestCollectionOrderNr )
					isLastCompoundSpecification = true;

				if( !hasAssignment &&
				writeOnlyCurrentSentence &&
				!isSpecificationCompoundCollection &&
				foundRelatedSpecificationItem != NULL &&
				foundRelatedSpecificationItem->isOlderSentence() &&

				( currentCollectionOrderNr == NO_ORDER_NR ||				// No specification collection
				currentCollectionOrderNr == 1 ||							// First or
				currentCollectionOrderNr == highestCollectionOrderNr ) )	// last specification of a specification collection
					isCombinedSpecification = true;

				if( writeSpecificationItem->isPossessive() &&
				writeSpecificationItem->hasRelationContext() )
					isPossessiveRelation = true;

				if( writeSpecificationItem->isGeneralizationNoun() &&
				writeSpecificationItem->isSelfGeneratedConclusion() )
					isSelfGeneratedDefinitionConclusion = true;

				if( isCombinedSpecification ||

				// Self-generated
				( isSelfGeneratedDefinitionConclusion &&

				( isLastCompoundSpecification ||
				forceResponseNotBeingFirstSpecification ||

				( isFirstRelatedSpecification &&
				!isSpecificationCompoundCollection ) ) ) ||

				// User generated
				( !isSelfGeneratedDefinitionConclusion &&

				( isPossessiveRelation ||
				isFirstRelatedSpecification ||
				forceResponseNotBeingFirstSpecification ||
				foundRelatedSpecificationItem == NULL ) &&

				( !hasAssignment ||
				forceResponseNotBeingAssignment ||
				writeSpecificationItem->isAssignment() ||
				writeSpecificationItem->isConditional() ) ) )
					{
					if( commonVariables_->currentGrammarLanguageWordItem != NULL )
						{
						if( myWord_->selectGrammarToWriteSentence( ( isPossessiveRelation || writeOnlyGivenSpecificationWord ), answerParameter, NO_GRAMMAR_LEVEL, commonVariables_->currentGrammarLanguageWordItem->startOfGrammarItem(), writeSpecificationItem ) != RESULT_OK )
							return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to select the grammar to write a sentence" );
						}
					else
						return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The current language word item is undefined" );
					}
				}
			else
				return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find a related specification" );
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given write specification item is undefined" );

		return commonVariables_->result;
		}

	ResultType writeSpecification( bool isAdjustedSpecification, bool isCorrectedAssumptionByKnowledge, bool isCorrectedAssumptionByOppositeQuestion, SpecificationItem *writeSpecificationItem )
		{
		bool isQuestion;
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeSpecification";

		if( writeSpecificationItem != NULL )
			{
			isQuestion = writeSpecificationItem->isQuestion();

			if( isQuestion ||
			writeSpecificationItem->isSelfGeneratedAssumption() )
				{
				if( writeSpecificationItem->isOlderSentence() )
					{
					if( writeSelectedSpecification( true, true, false, false, NO_ANSWER_PARAMETER, writeSpecificationItem ) == RESULT_OK )
						{
						if( strlen( commonVariables_->writeSentenceString ) > 0 )
							{
							if( commonVariables_->presentation->writeInterfaceText( true, PRESENTATION_PROMPT_NOTIFICATION, ( isCorrectedAssumptionByKnowledge ? INTERFACE_LISTING_MY_CORRECTED_ASSUMPTIONS_BY_KNOWLEDGE : ( isCorrectedAssumptionByOppositeQuestion ? INTERFACE_LISTING_MY_CORRECTED_ASSUMPTIONS_BY_OPPOSITE_QUESTION : ( isAdjustedSpecification ? ( isQuestion ? INTERFACE_LISTING_MY_ADJUSTED_QUESTIONS : INTERFACE_LISTING_MY_ASSUMPTIONS_THAT_ARE_ADJUSTED ) : ( writeSpecificationItem->isSelfGenerated() ? INTERFACE_LISTING_MY_QUESTIONS_THAT_ARE_ANSWERED : INTERFACE_LISTING_YOUR_QUESTIONS_THAT_ARE_ANSWERED ) ) ) ) ) == RESULT_OK )
								{
								if( commonVariables_->presentation->writeDiacriticalText( PRESENTATION_PROMPT_WRITE, commonVariables_->writeSentenceString ) != RESULT_OK )
									return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a sentence" );
								}
							else
								return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a header" );
							}
						}
					else
						return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a selected specification" );
					}
				else
					return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given write specification item isn't old" );
				}
			else
				return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given write specification item isn't a question, nor an assumption" );
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given write specification item is undefined" );

		return commonVariables_->result;
		}
	};

/*************************************************************************
 *
 *	"Tremble, O earth, at the presence of the Lord,
 *	at the presence of the God of Jacob.
 *	He turned the rock into a pool of water;
 *	yes, a spring of water flowed from solid rock." (Psalm 114:7-8)
 *
 *************************************************************************/
