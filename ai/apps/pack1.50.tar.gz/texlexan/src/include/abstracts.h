/* License/copyright: At the end of this file or read copyright.txt */

/*---------- Declarations --------------*/
long int sentencematchclass(char *file_abstract,char *file_dico,char *text,long int *pos_sentence,int nbl,int compress_rate,int rec,char *class_probable,char *title);
long int sentencematchcue(char *file_abstract,char *file_text,char *file_dico,char *text,int nbl,int compress_rate,int rec,char *title,char *target);
int nobrokenwood(char *file_abstract,char *file_text,char *file_brokenwood,int rec,char *title);
long int sentencematchcucl(
	char *file_abstract,char *file_dico1,char *file_dico2,
	char *text,long int *pos_sentence,
	int nbl,int compress_rate,int rec,
	char *class_probable,char *target, char *title);
