/*
 *	Class:			JustificationList
 *	Parent class:	List
 *	Purpose:		To store justification items for the
 *					self-generated knowledge
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#ifndef JUSTIFICATIONLIST
#define JUSTIFICATIONLIST 1
#include "SpecificationItem.cpp"

class JustificationList : private List
	{
	friend class WordItem;

	// Private constructible variables

	bool needToRecalculateAssumptionsAfterwards_;


	// Private deconstructor functions

	void deleteJustificationList( JustificationItem *searchItem )
		{
		JustificationItem *deleteItem;

		while( searchItem != NULL )
			{
			deleteItem = searchItem;
			searchItem = searchItem->nextJustificationItem();
			delete deleteItem;
			}
		}


	// Private functions

	ResultType updateArchivedReplacingJustificationItems( JustificationItem *updateJustificationItem )
		{
		JustificationItem *replacingJustificationItem;
		JustificationItem *searchItem = firstArchivedJustificationItem();
		char functionNameString[FUNCTION_NAME_LENGTH] = "updateArchivedReplacingJustificationItems";

		if( updateJustificationItem != NULL )
			{
			while( searchItem != NULL )
				{
				// Update the justification items that are filtered by getAssignmentItem
				// variable: replacingSpecificationItem
				if( searchItem->replacingJustificationItem == updateJustificationItem &&
				( replacingJustificationItem = updateJustificationItem->replacingJustificationItem ) != NULL )
					searchItem->replacingJustificationItem = replacingJustificationItem;

				searchItem = searchItem->nextJustificationItem();
				}
			}
		else
			return startError( functionNameString, NULL, "The given update justification item is undefined" );

		return commonVariables()->result;
		}

	ResultType checkJustificationItemForUsage( bool isActiveItem, JustificationItem *unusedJustificationItem )
		{
		JustificationItem *searchItem = firstJustificationItem( isActiveItem );
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkJustificationItemForUsage";

		if( unusedJustificationItem != NULL )
			{
			while( searchItem != NULL )
				{
				if( searchItem->attachedJustificationItem() == unusedJustificationItem )
					return startError( functionNameString, NULL, "The attached justification item is still in use" );

				if( searchItem->replacingJustificationItem == unusedJustificationItem )
					{
					if( searchItem->creationSentenceNr() < unusedJustificationItem->creationSentenceNr() ||
					searchItem->creationSentenceNr() < commonVariables()->myFirstSentenceNr )
						searchItem->replacingJustificationItem = NULL;
					else
						return startError( functionNameString, NULL, "The replacing justification item is still in use" );
					}

				searchItem = searchItem->nextJustificationItem();
				}
			}
		else
			return startError( functionNameString, NULL, "The given unused justification item is undefined" );

		return commonVariables()->result;
		}

	ResultType checkSpecificationItemForUsage( bool isActiveItem, SpecificationItem *unusedSpecificationItem )
		{
		JustificationItem *searchItem = firstJustificationItem( isActiveItem );
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkSpecificationItemForUsage";

		if( unusedSpecificationItem != NULL )
			{
			while( searchItem != NULL )
				{
				if( searchItem->definitionSpecificationItem() == unusedSpecificationItem )
					return startError( functionNameString, NULL, "The definition specification item is still in use" );

				if( searchItem->specificSpecificationItem() == unusedSpecificationItem )
					return startError( functionNameString, NULL, "The specific specification item is still in use" );

				searchItem = searchItem->nextJustificationItem();
				}
			}
		else
			return startError( functionNameString, NULL, "The given unused specification item is undefined" );

		return commonVariables()->result;
		}

	JustificationItem *firstActiveJustificationItem()
		{
		return (JustificationItem *)firstActiveItem();
		}

	JustificationItem *firstArchivedJustificationItem()
		{
		return (JustificationItem *)firstArchivedItem();
		}

	JustificationItem *firstJustificationItem( bool isActiveItem )
		{
		return ( isActiveItem ? firstActiveJustificationItem() : firstArchivedJustificationItem() );
		}

	JustificationItem *foundJustificationItem( bool isActiveItem, SpecificationItem *definitionSpecificationItem, SpecificationItem *anotherDefinitionSpecificationItem, SpecificationItem *specificSpecificationItem )
		{
		JustificationItem *searchItem = firstJustificationItem( isActiveItem );

		while( searchItem != NULL )
			{
			if( searchItem->definitionSpecificationItem() == definitionSpecificationItem &&
			searchItem->anotherDefinitionSpecificationItem() == anotherDefinitionSpecificationItem &&
			searchItem->specificSpecificationItem() == specificSpecificationItem )
				return searchItem;

			searchItem = searchItem->nextJustificationItem();
			}

		return NULL;
		}

	JustificationItem *foundSpecificSpecificationJustificationItem( bool hasDefinitionSpecification, bool isPossessive, WordItem *specificSpecificationWordItem, WordItem *specificRelationWordItem )
		{
		JustificationItem *searchItem = firstActiveJustificationItem();
		SpecificationItem *specificSpecificationItem;

		if( specificSpecificationWordItem != NULL &&
		specificRelationWordItem != NULL )
			{
			while( searchItem != NULL )
				{
				if( hasDefinitionSpecification == searchItem->hasDefinitionSpecification() &&
				( specificSpecificationItem = searchItem->specificSpecificationItem() ) != NULL )
					{
					if( specificSpecificationItem->isSelfGeneratedAssumption() &&
					specificSpecificationItem->isPossessive() == isPossessive &&
					specificSpecificationItem->specificationWordItem() == specificSpecificationWordItem &&
					specificSpecificationItem->relationWordItem() == specificRelationWordItem )
						return searchItem;
					}

				searchItem = searchItem->nextJustificationItem();
				}
			}

		return NULL;
		}


	public:
	// Constructor

	JustificationList( WordItem *myWord, CommonVariables *commonVariables )
		{
		needToRecalculateAssumptionsAfterwards_ = false;
		initializeListVariables( WORD_JUSTIFICATION_LIST_SYMBOL, "JustificationList", myWord, commonVariables );
		}

	// Deconstructor

	~JustificationList()
		{
		deleteJustificationList( firstActiveJustificationItem() );
		deleteJustificationList( (JustificationItem *)firstDeactiveItem() );
		deleteJustificationList( firstArchivedJustificationItem() );
		deleteJustificationList( (JustificationItem *)firstDeletedItem() );
		}


	// Protected functions

	bool needToRecalculateAssumptionsAfterwards()
		{
		return needToRecalculateAssumptionsAfterwards_;
		}

	JustificationResultType addJustificationItem( bool forceToCreateJustification, bool isActiveItem, unsigned short justificationTypeNr, unsigned short orderNr, unsigned int originalSentenceNr, JustificationItem *attachedJustificationItem, SpecificationItem *definitionSpecificationItem, SpecificationItem *anotherDefinitionSpecificationItem, SpecificationItem *specificSpecificationItem )
		{
		JustificationResultType justificationResult;
		SpecificationItem *updatedDefinitionSpecificationItem = ( definitionSpecificationItem == NULL ? NULL : definitionSpecificationItem->updatedSpecificationItem() );
		SpecificationItem *updatedAnotherDefinitionSpecificationItem = ( anotherDefinitionSpecificationItem == NULL ? NULL : anotherDefinitionSpecificationItem->updatedSpecificationItem() );
		SpecificationItem *updatedSpecificSpecificationItem = ( specificSpecificationItem == NULL ? NULL : specificSpecificationItem->updatedSpecificationItem() );
		char functionNameString[FUNCTION_NAME_LENGTH] = "addJustificationItem";

		if( definitionSpecificationItem != NULL ||
		specificSpecificationItem != NULL )
			{
			justificationResult.foundJustificationItem = foundJustificationItem( isActiveItem, updatedDefinitionSpecificationItem, updatedAnotherDefinitionSpecificationItem, updatedSpecificSpecificationItem );

			if( !isActiveItem ||
			forceToCreateJustification ||
			justificationResult.foundJustificationItem == NULL ||

			( attachedJustificationItem != NULL &&
			justificationResult.foundJustificationItem->isActiveItem() == isActiveItem &&					// Check state
			justificationResult.foundJustificationItem->justificationTypeNr() == justificationTypeNr &&		// Check type
			justificationResult.foundJustificationItem->attachedJustificationItem() != attachedJustificationItem ) )
				{
				if( justificationResult.foundJustificationItem == NULL ||
				justificationResult.foundJustificationItem->justificationTypeNr() == justificationTypeNr )
					{
					if( commonVariables()->currentItemNr < MAX_ITEM_NR )
						{
						if( ( justificationResult.createdJustificationItem = new JustificationItem( justificationTypeNr, orderNr, originalSentenceNr, attachedJustificationItem, updatedDefinitionSpecificationItem, updatedAnotherDefinitionSpecificationItem, updatedSpecificSpecificationItem, this, myWord(), commonVariables() ) ) != NULL )
							{
							if( isActiveItem )
								{
								if( addItemToActiveList( (Item *)justificationResult.createdJustificationItem ) != RESULT_OK )
									addError( functionNameString, NULL, "I failed to add an active justification item" );
								}
							else	// Archived
								{
								justificationResult.createdJustificationItem->setArchivedStatus();

								if( addItemToArchivedList( (Item *)justificationResult.createdJustificationItem ) != RESULT_OK )
									addError( functionNameString, NULL, "I failed to add an archive justification item" );
								}
							}
						else
							startError( functionNameString, NULL, "I failed to create an justification item" );
						}
					else
						startError( functionNameString, NULL, "The current item number is undefined" );
					}
				else
					startError( functionNameString, NULL, "The found justification type number is different from the given create justification type number" );
				}
			}
		else
			startError( functionNameString, NULL, "None of the given specification items is defined" );

		justificationResult.result = commonVariables()->result;
		return justificationResult;
		}

	JustificationResultType checkForConfirmedJustificationItems( bool isExclusiveGeneralization, unsigned short justificationTypeNr, JustificationItem *specificationJustificationItem, SpecificationItem *definitionSpecificationItem, SpecificationItem *specificSpecificationItem, WordItem *specificationWordItem )
		{
		JustificationResultType justificationResult;
		bool hasFoundConfirmation = false;
		JustificationItem *foundSpecificSpecificationJustification;
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkForConfirmedJustificationItems";

		if( specificationJustificationItem != NULL )
			{
			if( specificationWordItem != NULL )
				{
				if( definitionSpecificationItem != NULL &&
				specificSpecificationItem != NULL )
					{
					if( ( foundSpecificSpecificationJustification = foundSpecificSpecificationJustificationItem( true, !specificSpecificationItem->isPossessive(), specificSpecificationItem->specificationWordItem(), specificSpecificationItem->generalizationWordItem() ) ) != NULL )
						{
						if( archiveJustificationItem( false, isExclusiveGeneralization, foundSpecificSpecificationJustification, specificationJustificationItem ) == RESULT_OK )
							hasFoundConfirmation = true;
						else
							addError( functionNameString, NULL, "I failed to replace an old specific justification item" );
						}

					if( commonVariables()->result == RESULT_OK &&
					( foundSpecificSpecificationJustification = foundSpecificSpecificationJustificationItem( false, !specificSpecificationItem->isPossessive(), specificSpecificationItem->specificationWordItem(), specificSpecificationItem->generalizationWordItem() ) ) != NULL )
						{
						if( ( justificationResult = addJustificationItem( false, true, justificationTypeNr, foundSpecificSpecificationJustification->orderNr, commonVariables()->currentSentenceNr, NULL, NULL, NULL, specificSpecificationItem ) ).result == RESULT_OK )
							{
							if( ( specificationJustificationItem = justificationResult.createdJustificationItem ) != NULL )
								{
								if( archiveJustificationItem( false, isExclusiveGeneralization, foundSpecificSpecificationJustification, justificationResult.createdJustificationItem ) != RESULT_OK )
									addError( functionNameString, NULL, "I failed to replace an old specific justification item without definition specification" );
								}
							else
								startError( functionNameString, NULL, "I couldn't find or create a justification without definition specification" );
							}
						else
							addError( functionNameString, NULL, "I failed to add a justification without definition specification" );
						}
					}
				}
			else
				startError( functionNameString, NULL, "The given specification word item is undefined" );
			}
		else
			startError( functionNameString, NULL, "The given specification justification item is undefined" );

		justificationResult.hasFoundConfirmation = hasFoundConfirmation;
		justificationResult.result = commonVariables()->result;
		return justificationResult;
		}

	ResultType checkJustificationItemForUsage( JustificationItem *unusedJustificationItem )
		{
		if( checkJustificationItemForUsage( true, unusedJustificationItem ) == RESULT_OK )
			return checkJustificationItemForUsage( false, unusedJustificationItem );

		return commonVariables()->result;
		}

	ResultType checkSpecificationItemForUsage( SpecificationItem *unusedSpecificationItem )
		{
		if( checkSpecificationItemForUsage( true, unusedSpecificationItem ) == RESULT_OK )
			return checkSpecificationItemForUsage( false, unusedSpecificationItem );

		return commonVariables()->result;
		}

	ResultType attachJustificationItem( JustificationItem *attachJustificationItem, SpecificationItem *attachSpecificationItem )
		{
		JustificationResultType justificationResult;
		SpecificationResultType specificationResult;
		unsigned short justificationTypeNr;
		unsigned short highestAttachedJustificationOrderNr;
		unsigned short previousAssumptionLevel;
		JustificationItem *firstJustificationItem;
		JustificationItem *lastAttachedJustificationItem;
		JustificationItem *oldJustificationItem = NULL;
		JustificationItem *previousAttachedJustificationItem = NULL;
		SpecificationItem *attachedDefinitionSpecificationItem;
		SpecificationItem *attachedSpecificSpecificationItem;
		SpecificationItem *replacingSpecificationItem = NULL;
		char functionNameString[FUNCTION_NAME_LENGTH] = "attachJustificationItem";

		needToRecalculateAssumptionsAfterwards_ = false;

		if( attachJustificationItem != NULL )
			{
			if( attachSpecificationItem != NULL )
				{
				if( attachJustificationItem->isActiveItem() )
					{
					if( !attachSpecificationItem->isArchivedItem() )
						{
						if( ( firstJustificationItem = attachSpecificationItem->specificationJustificationItem() ) != NULL )
							{
							justificationTypeNr = attachJustificationItem->justificationTypeNr();

							if( !attachSpecificationItem->hasFoundJustificationOfSameType( justificationTypeNr, attachJustificationItem->definitionSpecificationItem(), attachJustificationItem->specificSpecificationItem() ) )
								{
								if( ( highestAttachedJustificationOrderNr = attachSpecificationItem->highestAttachedJustificationOrderNr( justificationTypeNr ) ) < MAX_ORDER_NR )
									attachJustificationItem->orderNr = ( highestAttachedJustificationOrderNr + 1 );
								else
									return startSystemError( functionNameString, NULL, "Justification order number overflow" );
								}

							if( attachJustificationItem->foundSpecificSpecificationQuestion() == NULL &&
							( oldJustificationItem = firstJustificationItem->foundSpecificSpecificationQuestion() ) == NULL )
								{
								attachedDefinitionSpecificationItem = attachJustificationItem->definitionSpecificationItem();

								if( attachedDefinitionSpecificationItem != NULL &&
								attachedDefinitionSpecificationItem->hasRelationContext() )
									oldJustificationItem = firstJustificationItem->definitionSpecificationWithoutRelationContextJustificationItem( attachedDefinitionSpecificationItem, attachJustificationItem->specificSpecificationItem() );
								else
									{
									attachedSpecificSpecificationItem = attachJustificationItem->specificSpecificationItem();

									if( attachedSpecificSpecificationItem != NULL &&
									attachedSpecificSpecificationItem->isUserSpecification() )
										oldJustificationItem = firstJustificationItem->selfGeneratedSpecificSpecificationJustificationItem( attachedDefinitionSpecificationItem, attachJustificationItem->specificSpecificationItem() );
									}

								if( oldJustificationItem != NULL )
									{
									if( archiveJustificationItem( false, false, oldJustificationItem, attachJustificationItem ) == RESULT_OK )
										attachJustificationItem->orderNr = oldJustificationItem->orderNr;
									else
										return addError( functionNameString, NULL, "I failed to archive a justification item" );
									}
								}

							if( oldJustificationItem == NULL )
								{
								// Find a justification item with current sentence number, but without attached justification item
								lastAttachedJustificationItem = firstJustificationItem;

								while( lastAttachedJustificationItem->hasCurrentCreationSentenceNr() &&
								lastAttachedJustificationItem->attachedJustificationItem() != NULL )
									lastAttachedJustificationItem = lastAttachedJustificationItem->attachedJustificationItem();

								if( lastAttachedJustificationItem->hasCurrentCreationSentenceNr() )
									{
									if( ( specificationResult = attachSpecificationItem->getAssumptionLevel() ).result == RESULT_OK )
										{
										previousAssumptionLevel = specificationResult.assumptionLevel;

										if( lastAttachedJustificationItem->attachJustificationItem( attachJustificationItem, attachSpecificationItem ) == RESULT_OK )
											{
											if( ( specificationResult = attachSpecificationItem->recalculateAssumptionLevel() ).result == RESULT_OK )
												{
												if( attachSpecificationItem->isOlderSentence() &&
												specificationResult.assumptionLevel != previousAssumptionLevel )
													{
													// Write adjusted specification
													if( myWord()->writeSpecification( true, false, false, attachSpecificationItem ) != RESULT_OK )
														return addError( functionNameString, NULL, "I failed to write an adjusted specification" );
													}
												}
											else
												return addError( functionNameString, NULL, "I failed to recalculate the assumption level" );
											}
										else
											return addError( functionNameString, NULL, "I failed to attach a justification item" );
										}
									else
										return addError( functionNameString, NULL, "I failed to get the assumption level" );
									}
								else	// Otherwise, attach the justification item to the given specification item
									{
									if( attachJustificationItem->attachedJustificationItem() == NULL )
										{
										if( attachSpecificationItem->hasCurrentActiveSentenceNr() )
											{
											if( attachSpecificationItem->changeJustificationItem( attachJustificationItem ) == RESULT_OK )
												{
												if( attachJustificationItem->attachJustificationItem( firstJustificationItem, attachSpecificationItem ) != RESULT_OK )
													return addError( functionNameString, NULL, "I failed to attach the first justification item to the given attached justification item" );
												}
											else
												return addError( functionNameString, NULL, "I failed to change the attached justification item of the given attach specification item" );
											}
										else
											{
											if( attachSpecificationItem->isAssignment() )
												{
												if( ( specificationResult = myWord()->createAssignment( attachSpecificationItem->isAnsweredQuestion(), attachSpecificationItem->isConcludedAssumption(), attachSpecificationItem->isDeactiveItem(), attachSpecificationItem->isArchivedItem(), attachSpecificationItem->isExclusive(), attachSpecificationItem->isNegative(), attachSpecificationItem->isPossessive(), attachSpecificationItem->isValueSpecification(), attachSpecificationItem->assignmentLevel(), attachSpecificationItem->assumptionLevel(), attachSpecificationItem->grammarLanguageNr(), attachSpecificationItem->prepositionParameter(), attachSpecificationItem->questionParameter(), attachSpecificationItem->generalizationWordTypeNr(), attachSpecificationItem->specificationWordTypeNr(), attachSpecificationItem->generalizationCollectionNr(), attachSpecificationItem->specificationCollectionNr(), attachSpecificationItem->generalizationContextNr(), attachSpecificationItem->specificationContextNr(), attachSpecificationItem->relationContextNr(), attachSpecificationItem->originalSentenceNr(), attachSpecificationItem->activeSentenceNr(), attachSpecificationItem->deactiveSentenceNr(), attachSpecificationItem->archiveSentenceNr(), attachSpecificationItem->nContextRelations(), attachJustificationItem, attachSpecificationItem->specificationWordItem(), attachSpecificationItem->specificationString() ) ).result == RESULT_OK )
													{
													if( ( replacingSpecificationItem = specificationResult.createdSpecificationItem ) == NULL )
														return startError( functionNameString, NULL, "I couldn't create an assignment" );
													}
												else
													return addError( functionNameString, NULL, "I failed to add an assignment" );
												}
											else
												{
												if( ( specificationResult = myWord()->createSpecification( attachSpecificationItem->isAnsweredQuestion(), attachSpecificationItem->isConditional(), attachSpecificationItem->isConcludedAssumption(), attachSpecificationItem->isDeactiveItem(), attachSpecificationItem->isArchivedItem(), attachSpecificationItem->isExclusive(), attachSpecificationItem->isNegative(), attachSpecificationItem->isPossessive(), attachSpecificationItem->isSpecificationGeneralization(), attachSpecificationItem->isValueSpecification(), attachSpecificationItem->assumptionLevel(), attachSpecificationItem->grammarLanguageNr(), attachSpecificationItem->prepositionParameter(), attachSpecificationItem->questionParameter(), attachSpecificationItem->generalizationWordTypeNr(), attachSpecificationItem->specificationWordTypeNr(), attachSpecificationItem->generalizationCollectionNr(), attachSpecificationItem->specificationCollectionNr(), attachSpecificationItem->generalizationContextNr(), attachSpecificationItem->specificationContextNr(), attachSpecificationItem->relationContextNr(), attachSpecificationItem->originalSentenceNr(), attachSpecificationItem->nContextRelations(), attachJustificationItem, attachSpecificationItem->specificationWordItem(), attachSpecificationItem->specificationString() ) ).result == RESULT_OK )
													{
													if( ( replacingSpecificationItem = specificationResult.createdSpecificationItem ) == NULL )
														return startError( functionNameString, NULL, "I couldn't create a specification" );
													}
												else
													return addError( functionNameString, NULL, "I failed to add a specification" );
												}

											if( attachJustificationItem->attachJustificationItem( firstJustificationItem, replacingSpecificationItem ) == RESULT_OK )
												{
												if( myWord()->archiveOrDeletedSpecification( attachSpecificationItem, replacingSpecificationItem ) == RESULT_OK )
													{
													if( replacingSpecificationItem->isOlderSentence() &&
													replacingSpecificationItem->isSelfGeneratedAssumption() )
														needToRecalculateAssumptionsAfterwards_ = true;
													}
												else
													return addError( functionNameString, NULL, "I failed to archive or delete a specification" );
												}
											else
												return addError( functionNameString, NULL, "I failed to attach the first justification item to the given attached justification item" );
											}
										}
									else
										{
										lastAttachedJustificationItem = firstJustificationItem;

										while( lastAttachedJustificationItem->hasCurrentCreationSentenceNr() &&
										lastAttachedJustificationItem->attachedJustificationItem() != NULL )
											{
											previousAttachedJustificationItem = lastAttachedJustificationItem;
											lastAttachedJustificationItem = lastAttachedJustificationItem->attachedJustificationItem();
											}

										// The last attached justification item has no attached justification item
										if( lastAttachedJustificationItem->attachedJustificationItem() == NULL )
											{
											if( previousAttachedJustificationItem != NULL )
												{
												// Attach attachJustificationItem to a copy of the last attached justification item
												if( ( justificationResult = addJustificationItem( false, true, lastAttachedJustificationItem->justificationTypeNr(), lastAttachedJustificationItem->orderNr, lastAttachedJustificationItem->originalSentenceNr(), attachJustificationItem, lastAttachedJustificationItem->definitionSpecificationItem(), lastAttachedJustificationItem->anotherDefinitionSpecificationItem(), lastAttachedJustificationItem->specificSpecificationItem() ) ).result == RESULT_OK )
													{
													if( justificationResult.createdJustificationItem != NULL )
														{
														// Link the created justification item to the previous attached justification item
														if( previousAttachedJustificationItem->changeAttachedJustificationItem( justificationResult.createdJustificationItem ) == RESULT_OK )
															{
															// Archived the lastAttachedJustificationItem
															if( archiveJustificationItem( false, false, lastAttachedJustificationItem, justificationResult.createdJustificationItem ) != RESULT_OK )
																return addError( functionNameString, NULL, "I failed to archive a justification item" );
															}
														else
															return addError( functionNameString, NULL, "I failed to change the attached justification item of the previous justification item" );
														}
													else
														return startError( functionNameString, NULL, "I couldn't create a justification item" );
													}
												else
													return addError( functionNameString, NULL, "I failed to add a justification item" );
												}
											else
												return startError( functionNameString, NULL, "The previous attached justification item is undefined. I have no solution implemented to solve this problem" );
											}
										else
											return startError( functionNameString, NULL, "The last attached justification item isn't the only old one. I have no solution implemented to solve this problem" );
										}
									}
								}
							else
								{
								if( myWord()->updateJustificationInSpecifications( false, false, oldJustificationItem, attachJustificationItem ) != RESULT_OK )
									return addError( functionNameString, NULL, "I failed to update a question justification item by a conclusion justification item" );
								}
							}
						else
							return startError( functionNameString, NULL, "The given attach specification item has no specification justification item" );
						}
					else
						return startError( functionNameString, NULL, "The given attach specification item is archived" );
					}
				else
					return startError( functionNameString, NULL, "The given attached justification item isn't active" );
				}
			else
				return startError( functionNameString, NULL, "The given attach specification item is undefined" );
			}
		else
			return startError( functionNameString, NULL, "The given attached justification item is undefined" );

		return commonVariables()->result;
		}

	ResultType archiveJustificationItem( bool isExclusive, bool isExclusiveGeneralization, JustificationItem *oldJustificationItem, JustificationItem *replacingJustificationItem )
		{
		JustificationItem *predecessorOfOldAttachedJustificationItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "archiveJustificationItem";

		if( oldJustificationItem != NULL )
			{
			if( oldJustificationItem->isOlderSentence() )
				{
				if( oldJustificationItem->replacingJustificationItem == NULL )
					{
					if( replacingJustificationItem == NULL ||
					replacingJustificationItem->replacingJustificationItem == NULL )
						{
						if( oldJustificationItem != replacingJustificationItem )
							{
							predecessorOfOldAttachedJustificationItem = oldJustificationItem->attachedJustificationItem();

							if( predecessorOfOldAttachedJustificationItem != NULL &&							// Old justification has an attached justification,
							replacingJustificationItem != NULL &&
							replacingJustificationItem->hasCurrentActiveSentenceNr() &&			// but the replacing one is current
							replacingJustificationItem->attachedJustificationItem() == NULL )	// and has no attached justifications
								{
								if( replacingJustificationItem->changeAttachedJustificationItem( predecessorOfOldAttachedJustificationItem ) != RESULT_OK )
									return addError( functionNameString, NULL, "I failed to change an attached justification item" );
								}

							if( predecessorOfOldAttachedJustificationItem == NULL ||
							predecessorOfOldAttachedJustificationItem->isArchivedItem() ||

							// Replacing justification item has the same attached justification item
							( replacingJustificationItem != NULL &&
							replacingJustificationItem->attachedJustificationItem() == predecessorOfOldAttachedJustificationItem ) )
								{
								oldJustificationItem->replacingJustificationItem = replacingJustificationItem;

								// Update the justification items that are filtered by getAssignmentItem
								// variable: replacingSpecificationItem
								if( updateArchivedReplacingJustificationItems( oldJustificationItem ) == RESULT_OK )
									{
									if( oldJustificationItem->isActiveItem() )
										{
										if( archiveActiveItem( oldJustificationItem ) != RESULT_OK )
											return addError( functionNameString, NULL, "I failed to archive an active justification item" );
										}

									if( myWord()->updateJustificationInSpecifications( isExclusive, isExclusiveGeneralization, oldJustificationItem, replacingJustificationItem ) != RESULT_OK )
										return addError( functionNameString, NULL, "I failed to update a justification in specifications of my word" );
									}
								else
									return addError( functionNameString, NULL, "I failed to update the replacing specification item of the archived justification items" );
								}
							else
								return startError( functionNameString, NULL, "The given old justification item has an active attached justification item" );
							}
						else
							return startError( functionNameString, NULL, "The given old justification item and the given replacing justification item are the same" );
						}
					else
						return startError( functionNameString, NULL, "The given replacing justification item has a replacing justification item itself" );
					}
				else
					return startError( functionNameString, NULL, "The given old justification item has already a replacing justification item" );
				}
			else
				return startError( functionNameString, NULL, "The given old justification item isn't old" );
			}
		else
			return startError( functionNameString, NULL, "The given old justification item is undefined" );

		return commonVariables()->result;
		}

	ResultType updateSpecificationsInJustificationItems( bool isActiveItem, SpecificationItem *oldSpecificationItem, SpecificationItem *replacingSpecificationItem )
		{
		JustificationResultType justificationResult;
		bool skipArchiving;
		bool isReplaceDefinition;
		bool isReplaceAnotherDefinition;
		bool isReplaceSpecific;
		bool isExclusive = ( replacingSpecificationItem == NULL ? false : replacingSpecificationItem->isExclusive() );
		bool isExclusiveGeneralization = ( replacingSpecificationItem == NULL ? false : replacingSpecificationItem->hasExclusiveGeneralizationCollection() );
		SpecificationItem *definitionSpecificationItem;
		SpecificationItem *anotherDefinitionSpecificationItem;
		SpecificationItem *specificSpecificationItem;
		JustificationItem *createdJustificationItem = NULL;
		JustificationItem *searchItem = firstJustificationItem( isActiveItem );
		char functionNameString[FUNCTION_NAME_LENGTH] = "updateSpecificationsInJustificationItems";

		if( oldSpecificationItem != NULL )
			{
			while( searchItem != NULL )
				{
				definitionSpecificationItem = searchItem->definitionSpecificationItem();
				anotherDefinitionSpecificationItem = searchItem->anotherDefinitionSpecificationItem();
				specificSpecificationItem = searchItem->specificSpecificationItem();

				isReplaceDefinition = ( definitionSpecificationItem == oldSpecificationItem );
				isReplaceAnotherDefinition = ( anotherDefinitionSpecificationItem == oldSpecificationItem );
				isReplaceSpecific = ( specificSpecificationItem == oldSpecificationItem );

				if( isReplaceDefinition ||
				isReplaceAnotherDefinition ||
				isReplaceSpecific )
					{
					if( searchItem->hasCurrentCreationSentenceNr() )
						{
						if( isReplaceDefinition )
							{
							if( searchItem->changeDefinitionSpecificationItem( replacingSpecificationItem ) != RESULT_OK )
								return addError( functionNameString, NULL, "I failed to change the definition specificationItem item of a justification item" );
							}
						else
							{
							if( isReplaceAnotherDefinition )
								{
								if( searchItem->changeAnotherDefinitionSpecificationItem( replacingSpecificationItem ) != RESULT_OK )
									return addError( functionNameString, NULL, "I failed to change the another definition specificationItem item of a justification item" );
								}
							else
								{
								if( searchItem->changeSpecificSpecificationItem( replacingSpecificationItem ) != RESULT_OK )
									return addError( functionNameString, NULL, "I failed to change the specific specificationItem item of a justification item" );
								}
							}

						searchItem = searchItem->nextJustificationItem();
						}
					else
						{
						skipArchiving = false;

						if( replacingSpecificationItem == NULL ||
						myWord()->isCorrectedAssumption() )
							createdJustificationItem = NULL;
						else
							{
							if( ( justificationResult = addJustificationItem( false, isActiveItem, searchItem->justificationTypeNr(), searchItem->orderNr, searchItem->originalSentenceNr(), searchItem->attachedJustificationItem(), ( isReplaceDefinition ? replacingSpecificationItem : definitionSpecificationItem ), ( isReplaceAnotherDefinition ? replacingSpecificationItem : anotherDefinitionSpecificationItem ), ( isReplaceSpecific ? replacingSpecificationItem : specificSpecificationItem ) ) ).result == RESULT_OK )
								{
								if( ( createdJustificationItem = justificationResult.createdJustificationItem ) != NULL )
									{
									if( !isActiveItem )
										{
										skipArchiving = true;
										searchItem->replacingJustificationItem = createdJustificationItem;
										searchItem = searchItem->nextJustificationItem();	// Next active, while justification item is archived
										}
									}
								else
									return startError( functionNameString, NULL, "I couldn't create a justification item" );
								}
							else
								return addError( functionNameString, NULL, "I failed to add an justification item" );
							}

						if( !skipArchiving )
							{
							if( archiveJustificationItem( isExclusive, isExclusiveGeneralization, searchItem, createdJustificationItem ) == RESULT_OK )
								searchItem = ( createdJustificationItem == NULL ? searchItem->nextJustificationItem() : firstActiveJustificationItem() );
							else
								return addError( functionNameString, NULL, "I failed to archive a justification item" );
							}
						}
					}
				else
					searchItem = searchItem->nextJustificationItem();
				}
			}
		else
			return startError( functionNameString, NULL, "The given old specification item is undefined" );

		return commonVariables()->result;
		}
	};
#endif

/*************************************************************************
 *
 *	"I will praise you every day;
 *	yes, I will praise you forever." (Psalm 145:2)
 *
 *************************************************************************/
