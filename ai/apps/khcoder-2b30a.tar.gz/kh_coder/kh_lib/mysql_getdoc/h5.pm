package mysql_getdoc::h5;
use base qw(mysql_getdoc);
use strict;


1;
