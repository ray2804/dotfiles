#!/bin/sh
echo
echo "Installer ver. 0.09  -  I am going to install TexLexAn "
echo "-------------------------------------------------------------"
echo "The programs will be located in the folder: ~/texlexan_prog"
echo "The dictionnaries will be located in: ~/texlexan_dico"
echo "The results (abstract) will be located in: ~/texlexan_result"
echo "The documents and summaries archived will be located in: ~/texlexan_archive"
echo "The documents archived will be located in: ~/texlexan_archive"
echo "The configuration file will be located in: ~/texlexan_cfg"
echo "The documentation will be located in: ~/texlexan_doc"
echo "-------------------------------------------------------------"
echo "You will need python-gtk2, wget, antiword, poppler-utils, ppthtml, odt2txt"
echo "If there are not installed yet; type (debian based distribution):" 
echo "sudo apt-get install python-gtk2"
echo "sudo apt-get install wget"
echo "sudo apt-get install antiword"
echo "sudo apt-get install poppler-utils"
echo "sudo apt-get install ppthtml"
echo "sudo apt-get install odt2txt"
echo "-------------------------------------------------------------"
echo "To run the text analyzer, type: ./texlexan_prog/texlexan.py"
echo "To search archived summaries, type: ./texlexan_prog/tlsearch.py"
echo "-------------------------------------------------------------"
echo "Press ctr-c to exit else press Enter to begin"
read line
if test -d $HOME"/texlexan_prog";
  then echo "/texlexan_prog exist."
  else
    echo "I create ~/texlexan_prog"
    mkdir $HOME/texlexan_prog
fi
if test -d $HOME"/texlexan_dico"; 
  then echo "/texlexan_dico exist, we will copy these files interactively."
    cp -i ./dico/keyworder* $HOME/texlexan_dico
    cp -i ./dico/excluded* $HOME/texlexan_dico
    cp -i ./dico/basic* $HOME/texlexan_dico
    cp -i ./dico/languages* $HOME/texlexan_dico
  else
    echo "I create ~/texlexan_dico"
    mkdir $HOME/texlexan_dico
    echo "I copy dictionnaries in ~/texlexan_dico"
    cp ./dico/keyworder* $HOME/texlexan_dico
    echo "I copy excluded and basicwords files in ~/texlexan_dico"
    cp ./dico/excluded* $HOME/texlexan_dico
    cp ./dico/basic* $HOME/texlexan_dico
    cp ./dico/languages* $HOME/texlexan_dico
fi
if test -d $HOME"/texlexan_doc";
  then echo "/texlexan_doc exist."
  else
    echo "I create ~/texlexan_doc"
    mkdir $HOME/texlexan_doc
fi
echo "I copy the python programs texlexan.py, tlsearch.py, tlstart.py in ~/texlexan_prog"
cp ./src/python/texlexan.py $HOME/texlexan_prog
cp ./src/python/tlsearch.py $HOME/texlexan_prog
cp ./src/python/tlstart.py $HOME/texlexan_prog
echo "I copy the engines texlexan, lazylearner, sis in ~/texlexan_prog"
cp ./src/texlexan $HOME/texlexan_prog
cp ./src/lazylearner $HOME/texlexan_prog
cp ./src/sis $HOME/texlexan_prog
echo "I copy the small script run in ~/texlexan_prog"
echo "This script is only useful for debugging."
cp ./src/run $HOME/texlexan_prog
if test -d $HOME"/Desktop";
  then 
    echo "I copy texlexan.desktop in ~/Desktop"
    cp ./texlexan.desktop $HOME/Desktop
fi
if test -d $HOME"/Bureau";
  then 
    echo "I copy texlexan.desktop in ~/Bureau"
    cp ./texlexan.desktop $HOME/Bureau
fi
echo "I copy documentations in ~/texlexan_doc"
cp ./docs/*.txt $HOME/texlexan_doc
echo "-------------------------------------------------------------"
echo "To install the Firefox extension. Drag and drop texlexanlauncher.xpi in the Firefox window."
echo "I am going to start texlexan.py"
echo "Press ctr-c to exit else Enter to start Texlexan"
read line
$HOME/texlexan_prog/texlexan.py
