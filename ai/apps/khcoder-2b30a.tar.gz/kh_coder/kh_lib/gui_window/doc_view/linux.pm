package gui_window::doc_view::linux;
use base qw(gui_window::doc_view);
use strict;

1;