/*
 *	Class:			ListQuery
 *	Supports class:	List
 *	Purpose:		To process queries
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "List.h"
#include "Presentation.cpp"

class ListQuery
	{
	// Private constructible variables

	CommonVariables *commonVariables_;
	List *myList_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	void itemQuery( bool isSelectOnFind, bool isReferenceQuery, unsigned int querySentenceNr, unsigned int queryItemNr, Item *queryItem )
		{
		while( queryItem != NULL )
			{
			if( ( isReferenceQuery &&
			queryItem->hasFoundReferenceItemById( querySentenceNr, queryItemNr ) ) ||

			( !isReferenceQuery &&
			( querySentenceNr == NO_SENTENCE_NR ||
			querySentenceNr == queryItem->creationSentenceNr() ) &&

			( queryItemNr == NO_SENTENCE_NR ||
			queryItemNr == queryItem->itemNr() ) ) )
				{
				if( isSelectOnFind &&
				!queryItem->isSelectedByQuery )
					{
					commonVariables_->hasFoundQuery = true;
					queryItem->isSelectedByQuery = true;
					}
				}
			else
				{
				if( !isSelectOnFind &&
				queryItem->isSelectedByQuery )
					queryItem->isSelectedByQuery = false;
				}

			queryItem = queryItem->nextItem;
			}
		}

	void listQuery( bool isSelectOnFind, Item *queryItem )
		{
		while( queryItem != NULL )
			{
			if( isSelectOnFind )
				{
				if( !queryItem->isSelectedByQuery )
					{
					commonVariables_->hasFoundQuery = true;
					queryItem->isSelectedByQuery = true;
					}
				}
			else
				{
				if( queryItem->isSelectedByQuery )
					queryItem->isSelectedByQuery = false;
				}

			queryItem = queryItem->nextItem;
			}
		}

	void wordTypeQuery( bool isSelectOnFind, unsigned short queryWordTypeNr, Item *queryItem )
		{
		while( queryItem != NULL )
			{
			if( queryItem->hasFoundWordType( queryWordTypeNr ) )
				{
				if( isSelectOnFind &&
				!queryItem->isSelectedByQuery )
					{
					commonVariables_->hasFoundQuery = true;
					queryItem->isSelectedByQuery = true;
					}
				}
			else
				{
				if( !isSelectOnFind &&
				queryItem->isSelectedByQuery )
					queryItem->isSelectedByQuery = false;
				}

			queryItem = queryItem->nextItem;
			}
		}

	void parameterQuery( bool isSelectOnFind, unsigned int queryParameter, Item *queryItem )
		{
		while( queryItem != NULL )
			{
			if( queryItem->hasFoundParameter( queryParameter ) )
				{
				if( isSelectOnFind &&
				!queryItem->isSelectedByQuery )
					{
					commonVariables_->hasFoundQuery = true;
					queryItem->isSelectedByQuery = true;
					}
				}
			else
				{
				if( !isSelectOnFind &&
				queryItem->isSelectedByQuery )
					queryItem->isSelectedByQuery = false;
				}

			queryItem = queryItem->nextItem;
			}
		}

	void wordQuery( bool isSelectOnFind, Item *queryItem )
		{
		while( queryItem != NULL )
			{
			if( isSelectOnFind )
				{
				if( !queryItem->isSelectedByQuery )
					{
					commonVariables_->hasFoundQuery = true;
					queryItem->isSelectedByQuery = true;
					}
				}
			else
				{
				if( queryItem->isSelectedByQuery )
					queryItem->isSelectedByQuery = false;
				}

			queryItem = queryItem->nextItem;
			}
		}

	void clearQuerySelections( Item *searchItem )
		{
		while( searchItem != NULL )
			{
			searchItem->isSelectedByQuery = false;
			searchItem = searchItem->nextItem;
			}
		}

	ResultType wordReferenceQuery( bool isSelectOnFind, char *wordReferenceNameString, Item *queryItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "wordReferenceQuery";
		while( queryItem != NULL )
			{
			if( queryItem->findMatchingWordReferenceString( wordReferenceNameString ) == RESULT_OK )
				{
				if( commonVariables_->hasFoundMatchingStrings )
					{
					if( isSelectOnFind &&
					!queryItem->isSelectedByQuery )
						{
						commonVariables_->hasFoundQuery = true;
						queryItem->isSelectedByQuery = true;
						}
					}
				else
					{
					if( !isSelectOnFind &&
					queryItem->isSelectedByQuery )
						queryItem->isSelectedByQuery = false;
					}

				queryItem = queryItem->nextItem;
				}
			else
				return myList_->addError( functionNameString, moduleNameString_, "I failed to check the word references" );
			}

		return commonVariables_->result;
		}

	ResultType stringQuery( bool isSelectOnFind, char *wordString, Item *queryItem )
		{
		bool hasFoundString;
		char *itemString;
		char functionNameString[FUNCTION_NAME_LENGTH] = "stringQuery";

		while( queryItem != NULL )
			{
			hasFoundString = false;

			if( ( itemString = queryItem->itemString() ) != NULL )
				{
				if( compareStrings( wordString, itemString ) == RESULT_OK )
					{
					if( commonVariables_->hasFoundMatchingStrings )
						hasFoundString = true;
					}
				else
					return myList_->addError( functionNameString, moduleNameString_, "I failed to compare two strings" );
				}

			if( !hasFoundString &&
			( itemString = queryItem->extraItemString() ) != NULL )
				{
				if( compareStrings( wordString, itemString ) == RESULT_OK )
					{
					if( commonVariables_->hasFoundMatchingStrings )
						hasFoundString = true;
					}
				else
					return myList_->addError( functionNameString, moduleNameString_, "I failed to compare two strings" );
				}

			if( hasFoundString )
				{
				if( isSelectOnFind &&
				!queryItem->isSelectedByQuery )
					{
					commonVariables_->hasFoundQuery = true;
					queryItem->isSelectedByQuery = true;
					}
				}
			else
				{
				if( !isSelectOnFind &&
				queryItem->isSelectedByQuery )
					queryItem->isSelectedByQuery = false;
				}

			queryItem = queryItem->nextItem;
			}

		return commonVariables_->result;
		}

	ResultType showQueryResult( bool showOnlyWords, bool showOnlyWordReferences, bool showOnlyStrings, bool returnQueryToPosition, unsigned short promptTypeNr, unsigned short queryWordTypeNr, size_t queryWidth, Item *queryItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "showQueryResult";
		while( queryItem != NULL )
			{
			if( queryItem->isSelectedByQuery )
				{
				if( showOnlyWords )
					queryItem->showWords( returnQueryToPosition, queryWordTypeNr );
				else
					{
					if( showOnlyWordReferences )
						queryItem->showWordReferences( returnQueryToPosition );
					else
						{
						if( showOnlyStrings )
							queryItem->showString( returnQueryToPosition );
						else
							{
							if( commonVariables_->presentation->writeText( true, promptTypeNr, queryWidth, queryItem->toString( queryWordTypeNr ) ) != RESULT_OK )
								return myList_->addError( functionNameString, moduleNameString_, "I failed to show the info of an active item" );
							}
						}
					}
				}

			queryItem = queryItem->nextItem;
			}

		return commonVariables_->result;
		}


	public:
	// Constructor

	ListQuery( List *myList, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		myList_ = myList;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "ListQuery" );

		if( commonVariables_ != NULL )
			{
		if( myList_ == NULL )
			strcpy( errorString, "The given my list is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myList_ != NULL )
				myList_->startSystemError( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	void countQuery()
		{
		Item *searchItem = myList_->firstActiveItem();

		while( searchItem != NULL )
			{
			if( searchItem->isSelectedByQuery )
				commonVariables_->nActiveQueryItems++;

			searchItem = searchItem->nextItem;
			}

		searchItem = myList_->firstDeactiveItem();

		while( searchItem != NULL )
			{
			if( searchItem->isSelectedByQuery )
				commonVariables_->nDeactiveQueryItems++;

			searchItem = searchItem->nextItem;
			}

		searchItem = myList_->firstArchivedItem();

		while( searchItem != NULL )
			{
			if( searchItem->isSelectedByQuery )
				commonVariables_->nArchivedQueryItems++;

			searchItem = searchItem->nextItem;
			}

		searchItem = myList_->firstDeletedItem();

		while( searchItem != NULL )
			{
			if( searchItem->isSelectedByQuery )
				commonVariables_->nDeletedQueryItems++;

			searchItem = searchItem->nextItem;
			}
		}

	void clearQuerySelections()
		{
		clearQuerySelections( myList_->firstActiveItem() );
		clearQuerySelections( myList_->firstDeactiveItem() );
		clearQuerySelections( myList_->firstArchivedItem() );
		clearQuerySelections( myList_->firstDeletedItem() );
		}

	void itemQuery( bool isSelectOnFind, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, bool isReferenceQuery, unsigned int querySentenceNr, unsigned int queryItemNr )
		{
		if( isSelectActiveItems )
			itemQuery( isSelectOnFind, isReferenceQuery, querySentenceNr, queryItemNr, myList_->firstActiveItem() );

		if( isSelectDeactiveItems )
			itemQuery( isSelectOnFind, isReferenceQuery, querySentenceNr, queryItemNr, myList_->firstDeactiveItem() );

		if( isSelectArchivedItems )
			itemQuery( isSelectOnFind, isReferenceQuery, querySentenceNr, queryItemNr, myList_->firstArchivedItem() );

		if( isSelectDeletedItems )
			itemQuery( isSelectOnFind, isReferenceQuery, querySentenceNr, queryItemNr, myList_->firstDeletedItem() );
		}

	void listQuery( bool isSelectOnFind, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems )
		{
		if( isSelectActiveItems )
			listQuery( isSelectOnFind, myList_->firstActiveItem() );

		if( isSelectDeactiveItems )
			listQuery( isSelectOnFind, myList_->firstDeactiveItem() );

		if( isSelectArchivedItems )
			listQuery( isSelectOnFind, myList_->firstArchivedItem() );

		if( isSelectDeletedItems )
			listQuery( isSelectOnFind, myList_->firstDeletedItem() );
		}

	void wordTypeQuery( bool isSelectOnFind, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, unsigned short queryWordTypeNr )
		{
		if( isSelectActiveItems )
			wordTypeQuery( isSelectOnFind, queryWordTypeNr, myList_->firstActiveItem() );

		if( isSelectDeactiveItems )
			wordTypeQuery( isSelectOnFind, queryWordTypeNr, myList_->firstDeactiveItem() );

		if( isSelectArchivedItems )
			wordTypeQuery( isSelectOnFind, queryWordTypeNr, myList_->firstArchivedItem() );

		if( isSelectDeletedItems )
			wordTypeQuery( isSelectOnFind, queryWordTypeNr, myList_->firstDeletedItem() );
		}

	void parameterQuery( bool isSelectOnFind, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, unsigned int queryParameter )
		{
		if( isSelectActiveItems )
			parameterQuery( isSelectOnFind, queryParameter, myList_->firstActiveItem() );

		if( isSelectDeactiveItems )
			parameterQuery( isSelectOnFind, queryParameter, myList_->firstDeactiveItem() );

		if( isSelectArchivedItems )
			parameterQuery( isSelectOnFind, queryParameter, myList_->firstArchivedItem() );

		if( isSelectDeletedItems )
			parameterQuery( isSelectOnFind, queryParameter, myList_->firstDeletedItem() );
		}

	void wordQuery( bool isSelectOnFind, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems )
		{
		if( isSelectActiveItems )
			wordQuery( isSelectOnFind, myList_->firstActiveItem() );

		if( isSelectDeactiveItems )
			wordQuery( isSelectOnFind, myList_->firstDeactiveItem() );

		if( isSelectArchivedItems )
			wordQuery( isSelectOnFind, myList_->firstArchivedItem() );

		if( isSelectDeletedItems )
			wordQuery( isSelectOnFind, myList_->firstDeletedItem() );
		}

	ResultType compareStrings( char *searchString, char *sourceString )
		{
		bool stop;
		size_t searchStringPosition = 0;
		size_t sourceStringPosition = 0;
		char functionNameString[FUNCTION_NAME_LENGTH] = "compareStrings";

		commonVariables_->hasFoundMatchingStrings = false;

		if( searchString != NULL )
			{
			if( sourceString != NULL )
				{
				if( searchString != sourceString )
					{
					commonVariables_->hasFoundMatchingStrings = true;

					while( commonVariables_->hasFoundMatchingStrings &&
					searchStringPosition < strlen( searchString ) &&
					sourceStringPosition < strlen( sourceString ) )
						{
						if( searchString[searchStringPosition] == sourceString[sourceStringPosition] ||
						searchString[searchStringPosition] == SYMBOL_QUESTION_MARK )
							{
							searchStringPosition++;
							sourceStringPosition++;
							}
						else
							{
							if( searchString[searchStringPosition] == SYMBOL_ASTERISK )
								{
								if( ++searchStringPosition < strlen( searchString ) )
									{
									stop = false;

									while( !stop &&
									sourceStringPosition < strlen( sourceString ) )
										{
										if( searchString[searchStringPosition] == sourceString[sourceStringPosition] )
											{
											// Check remaining strings
											if( compareStrings( &searchString[searchStringPosition], &sourceString[sourceStringPosition] ) == RESULT_OK )
												{
												if( commonVariables_->hasFoundMatchingStrings )
													{
													stop = true;
													searchStringPosition++;
													}
												else
													commonVariables_->hasFoundMatchingStrings = true;	// Reset indicator

												sourceStringPosition++;
												}
											else
												return myList_->addError( functionNameString, moduleNameString_, "I failed to compare the remaining strings" );
											}
										else
											sourceStringPosition++;					// Skip source characters when not equal
										}
									}
								else
									sourceStringPosition = strlen( sourceString );	// Empty source string after asterisk
								}
							else
								commonVariables_->hasFoundMatchingStrings = false;
							}
						}

					if( commonVariables_->hasFoundMatchingStrings &&
					sourceStringPosition == strlen( sourceString ) )
						{
						// Check search string for extra asterisks
						while( searchStringPosition < strlen( searchString ) &&
						searchString[searchStringPosition] == SYMBOL_ASTERISK )
							searchStringPosition++;		// Skip extra asterisks
						}

					if( searchStringPosition < strlen( searchString ) ||
					sourceStringPosition < strlen( sourceString ) )
						commonVariables_->hasFoundMatchingStrings = false;
					}
				else
					return myList_->startError( functionNameString, moduleNameString_, "The given strings are the same" );
				}
			else
				return myList_->startError( functionNameString, moduleNameString_, "The given source string is undefined" );
			}
		else
			return myList_->startError( functionNameString, moduleNameString_, "The given search string is undefined" );

		return commonVariables_->result;
		}

	ResultType wordReferenceQuery( bool isSelectOnFind, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *wordReferenceNameString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "wordReferenceQuery";
		if( isSelectActiveItems )
			{
			if( wordReferenceQuery( isSelectOnFind, wordReferenceNameString, myList_->firstActiveItem() ) != RESULT_OK )
				return myList_->addError( functionNameString, moduleNameString_, "I failed to check the word references of an active word" );
			}

		if( isSelectDeactiveItems )
			{
			if( wordReferenceQuery( isSelectOnFind, wordReferenceNameString, myList_->firstDeactiveItem() ) != RESULT_OK )
				return myList_->addError( functionNameString, moduleNameString_, "I failed to check the word references of a deactive word" );
			}

		if( isSelectArchivedItems )
			{
			if( wordReferenceQuery( isSelectOnFind, wordReferenceNameString, myList_->firstArchivedItem() ) != RESULT_OK )
				return myList_->addError( functionNameString, moduleNameString_, "I failed to check the word references of an archive word" );
			}

		if( isSelectDeletedItems )
			{
			if( wordReferenceQuery( isSelectOnFind, wordReferenceNameString, myList_->firstDeletedItem() ) != RESULT_OK )
				return myList_->addError( functionNameString, moduleNameString_, "I failed to check the word references of a deleted word" );
			}

		return commonVariables_->result;
		}

	ResultType stringQuery( bool isSelectOnFind, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *wordString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "stringQuery";
		if( isSelectActiveItems )
			{
			if( stringQuery( isSelectOnFind, wordString, myList_->firstActiveItem() ) != RESULT_OK )
				return myList_->addError( functionNameString, moduleNameString_, "I failed to string query an active word" );
			}

		if( isSelectDeactiveItems )
			{
			if( stringQuery( isSelectOnFind, wordString, myList_->firstDeactiveItem() ) != RESULT_OK )
				return myList_->addError( functionNameString, moduleNameString_, "I failed to string query a deactive word" );
			}

		if( isSelectArchivedItems )
			{
			if( stringQuery( isSelectOnFind, wordString, myList_->firstArchivedItem() ) != RESULT_OK )
				return myList_->addError( functionNameString, moduleNameString_, "I failed to string query an archive word" );
			}

		if( isSelectDeletedItems )
			{
			if( stringQuery( isSelectOnFind, wordString, myList_->firstDeletedItem() ) != RESULT_OK )
				return myList_->addError( functionNameString, moduleNameString_, "I failed to string query a deleted word" );
			}

		return commonVariables_->result;
		}

	ResultType showQueryResult( bool showOnlyWords, bool showOnlyWordReferences, bool showOnlyStrings, bool returnQueryToPosition, unsigned short promptTypeNr, unsigned short queryWordTypeNr, size_t queryWidth )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "showQueryResult";
		if( showQueryResult( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth, myList_->firstActiveItem() ) == RESULT_OK )
			{
			if( showQueryResult( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth, myList_->firstDeactiveItem() ) == RESULT_OK )
				{
				if( showQueryResult( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth, myList_->firstArchivedItem() ) == RESULT_OK )
					{
					if( showQueryResult( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth, myList_->firstDeletedItem() ) != RESULT_OK )
						return myList_->addError( functionNameString, moduleNameString_, "I failed to show the query result of a deleted word" );
					}
				else
					return myList_->addError( functionNameString, moduleNameString_, "I failed to show the query result of an archive word" );
				}
			else
				return myList_->addError( functionNameString, moduleNameString_, "I failed to show the query result of a deactive word" );
			}
		else
			return myList_->addError( functionNameString, moduleNameString_, "I failed to show the query result of an active word" );

		return commonVariables_->result;
		}
	};

/*************************************************************************
 *
 *	"Your name, O Lord, endures forever;
 *	your name, O Lord, is known to every generation." (Psalm 135:13)
 *
 *************************************************************************/
