/*
 *	Class:			AdminCleanup
 *	Supports class:	AdminItem
 *	Purpose:		To cleanup unnecessary items
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "AdminItem.h"
#include "Presentation.cpp"
#include "ReadList.cpp"
#include "WordList.cpp"
#include "WordTypeItem.cpp"

class AdminCleanup
	{
	// Private constructible variables

	bool dontIncrementCurrentSentenceNr_;
	bool hasFoundChange_;
	bool wasUndoOrRedo_;

	CommonVariables *commonVariables_;
	AdminItem *admin_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	void deleteResponseListsInAllWords()
		{
		WordItem *currentWordItem;

		if( ( currentWordItem = commonVariables_->firstWordItem ) != NULL )		// Do in all words
			{
			do	currentWordItem->deleteWriteList();
			while( ( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}
		}

	ResultType getHighestInUseSentenceNr( bool includeDeletedItems, bool includeLanguageAssignments, bool includeTemporaryLists, unsigned int highestSentenceNr )
		{
		unsigned short adminListNr = 0;
		char functionNameString[FUNCTION_NAME_LENGTH] = "getHighestInUseSentenceNr";

		commonVariables_->highestInUseSentenceNr = NO_SENTENCE_NR;

		if( admin_->wordList != NULL )						// Inside words
			{
			if( admin_->wordList->getHighestInUseSentenceNrInWordList( includeDeletedItems, includeLanguageAssignments, includeTemporaryLists, highestSentenceNr ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check if the given sentence is empty in my word list" );
			}

		while( commonVariables_->highestInUseSentenceNr < highestSentenceNr &&
		adminListNr < NUMBER_OF_ADMIN_LISTS )
			{
			if( admin_->adminList[adminListNr] != NULL &&	// Inside admin lists

			( includeTemporaryLists ||
			!admin_->adminList[adminListNr]->isTemporaryList() ) )
				{
				if( admin_->adminList[adminListNr]->getHighestInUseSentenceNrInList( includeDeletedItems, highestSentenceNr ) != RESULT_OK )
					return myWord_->addErrorInItem( admin_->adminListChar( adminListNr ), functionNameString, moduleNameString_, "I failed to check if the given sentence is empty" );
				}

			adminListNr++;
			}

		return commonVariables_->result;
		}

	ResultType undoCurrentSentenceInAllWords()
		{
		WordItem *currentWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "undoCurrentSentenceInAllWords";

		if( ( currentWordItem = commonVariables_->firstWordItem ) != NULL )		// Do in all words
			{
			do	currentWordItem->undoCurrentSentence();
			while( commonVariables_->result == RESULT_OK &&
			( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The first word item is undefined" );

		return commonVariables_->result;
		}

	ResultType redoCurrentSentenceInAllWords()
		{
		WordItem *currentWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "redoCurrentSentenceInAllWords";

		if( ( currentWordItem = commonVariables_->firstWordItem ) != NULL )		// Do in all words
			{
			do	currentWordItem->redoCurrentSentence();
			while( commonVariables_->result == RESULT_OK &&
			( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The first word item is undefined" );

		return commonVariables_->result;
		}

	ResultType rollbackDeletedRedoInfo()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "rollbackDeletedRedoInfo";
		if( admin_->wordList != NULL )						// Inside words
			{
			if( admin_->wordList->rollbackDeletedRedoInfoInWordList() != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete the current redo info of my words in my word list" );
			}

		for( unsigned short adminListNr = 0; adminListNr < NUMBER_OF_ADMIN_LISTS; adminListNr++ )
			{
			if( admin_->adminList[adminListNr] != NULL )	// Inside admin lists
				{
				if( admin_->adminList[adminListNr]->rollbackDeletedRedoInfoInList() != RESULT_OK )
					return myWord_->addErrorInItem( admin_->adminListChar( adminListNr ), functionNameString, moduleNameString_, "I failed to delete the current redo info" );
				}
			}

		return commonVariables_->result;
		}

	ResultType undoCurrentSentence()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "undoCurrentSentence";
		if( undoCurrentSentenceInAllWords() == RESULT_OK )		// Inside words
			{
			for( unsigned short adminListNr = 0; adminListNr < NUMBER_OF_ADMIN_LISTS; adminListNr++ )
				{
				if( admin_->adminList[adminListNr] != NULL )	// Inside admin lists
					{
					if( admin_->adminList[adminListNr]->undoCurrentSentenceInList() != RESULT_OK )
						return myWord_->addErrorInItem( admin_->adminListChar( adminListNr ), functionNameString, moduleNameString_, "I failed to undo the current sentence" );
					}
				}
			}
		else
			return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to undo the current sentence in my word list" );

		return commonVariables_->result;
		}

	ResultType redoCurrentSentence()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "redoCurrentSentence";
		if( redoCurrentSentenceInAllWords() == RESULT_OK )		// Inside words
			{
			for( unsigned short adminListNr = 0; adminListNr < NUMBER_OF_ADMIN_LISTS; adminListNr++ )
				{
				if( admin_->adminList[adminListNr] != NULL )	// Inside admin lists
					{
					if( admin_->adminList[adminListNr]->redoCurrentSentenceInList() != RESULT_OK )
						return myWord_->addErrorInItem( admin_->adminListChar( adminListNr ), functionNameString, moduleNameString_, "I failed to redo the current sentence" );
					}
				}
			}
		else
			return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to redo the current sentence in my word list" );

		return commonVariables_->result;
		}

	ResultType deleteUnusedWordTypes( bool deactiveItems, bool deleteAllActiveWordTypes )
		{
		ReadResultType readResult;
		unsigned short nReadWordReferences;
		char *pluralNounString;
		WordTypeItem *unusedWordTypeItem;
		WordTypeItem *singularNounWordTypeItem;
		ReadItem *previousReadItem = NULL;
		ReadItem *unusedReadItem = ( deactiveItems ? admin_->firstDeactiveReadItem() : admin_->firstActiveReadItem() );
		WordItem *unusedReadWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteUnusedWordTypes";

		if( admin_->readList != NULL )
			{
			while( unusedReadItem != NULL )
				{
				if( deactiveItems ||
				deleteAllActiveWordTypes ||

				( previousReadItem != NULL &&
				!unusedReadItem->isReadWordSingularNoun() &&
				previousReadItem->wordOrderNr() == unusedReadItem->wordOrderNr() ) )		// More word types for this word number
					{
					if( ( unusedReadWordItem = unusedReadItem->readWordItem() ) != NULL )	// Skip text
						{
						if( ( unusedWordTypeItem = unusedReadItem->activeReadWordTypeItem() ) != NULL )
							{
							if( unusedWordTypeItem->hasCurrentCreationSentenceNr() )
								{
								if( !deleteAllActiveWordTypes &&
								unusedReadItem->isReadWordPluralNoun() &&	// Wrong assumption: This noun isn't plural but singular
								unusedReadWordItem->isUserDefinedWord() &&
								( pluralNounString = unusedWordTypeItem->itemString() ) != NULL &&
								( singularNounWordTypeItem = unusedReadWordItem->activeWordTypeItem( false, WORD_TYPE_NOUN_SINGULAR ) ) != NULL )
									{
									if( singularNounWordTypeItem->createNewWordTypeString( pluralNounString ) != RESULT_OK )
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create a new word string for a singular noun word type of an active read word" );
									}

								if( ( readResult = admin_->readList->numberOfReadWordReferences( unusedReadItem->wordTypeNr(), unusedReadWordItem ) ).result == RESULT_OK )
									{
									if( ( nReadWordReferences = readResult.nReadWordReferences ) >= 1 )
										{
										unusedReadItem->isUnusedReadItem = true;

										if( nReadWordReferences == 1 )
											{
											if( unusedReadWordItem->deleteWordType( unusedReadItem->wordTypeNr() ) != RESULT_OK )
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete an unused word type item" );
											}
										}
									else
										return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found an invalid number of read word references" );
									}
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get the number of read word references" );
								}
							}
						else
							return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I couldn't find the word type of an active read word" );
						}
					}

				previousReadItem = unusedReadItem;
				unusedReadItem = unusedReadItem->nextReadItem();
				}
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The read list isn't created yet" );

		return commonVariables_->result;
		}

	ResultType deleteUnusedWordTypes( bool deleteAllActiveWordTypes )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteUnusedWordTypes";
		if( deleteUnusedWordTypes( false, deleteAllActiveWordTypes ) == RESULT_OK )		// From active read items
			{
			if( deleteUnusedWordTypes( true, deleteAllActiveWordTypes ) != RESULT_OK )	// From deactive read items
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete the active unused word types" );
			}
		else
			return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete the deactive unused word types" );

		return commonVariables_->result;
		}

	ResultType removeFirstRangeOfDeletedItems()
		{
		unsigned short adminListNr = 0;
		char functionNameString[FUNCTION_NAME_LENGTH] = "removeFirstRangeOfDeletedItems";

		commonVariables_->nDeletedItems = 0;
		commonVariables_->removeSentenceNr = NO_SENTENCE_NR;
		commonVariables_->removeStartItemNr = NO_ITEM_NR;

		if( admin_->wordList != NULL )						// Inside words
			{
			if( admin_->wordList->removeFirstRangeOfDeletedItemsInWordList() != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to remove the first deleted items in my word list" );
			}

		while( adminListNr < NUMBER_OF_ADMIN_LISTS &&
		commonVariables_->nDeletedItems == 0 )
			{
			if( admin_->adminList[adminListNr] != NULL )	// Inside admin lists
				{
				if( admin_->adminList[adminListNr]->removeFirstRangeOfDeletedItemsInList() != RESULT_OK )
					return myWord_->addErrorInItem( admin_->adminListChar( adminListNr ), functionNameString, moduleNameString_, "I failed to remove the first deleted items" );
				}

			adminListNr++;
			}

		return commonVariables_->result;
		}

	ResultType decrementSentenceNrs( unsigned int startSentenceNr )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "decrementSentenceNrs";
		if( admin_->wordList != NULL )						// Inside words
			{
			if( admin_->wordList->decrementSentenceNrsInWordList( startSentenceNr ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to decrement the sentence numbers from the current sentence number in my word list" );
			}

		for( unsigned short adminListNr = 0; adminListNr < NUMBER_OF_ADMIN_LISTS; adminListNr++ )
			{
			if( admin_->adminList[adminListNr] != NULL )	// Inside admin lists
				{
				if( admin_->adminList[adminListNr]->decrementSentenceNrsInList( startSentenceNr ) != RESULT_OK )
					return myWord_->addErrorInItem( admin_->adminListChar( adminListNr ), functionNameString, moduleNameString_, "I failed to decrement the sentence numbers from the current sentence number in one of my lists" );
				}
			}

		return commonVariables_->result;
		}

	ResultType decrementCurrentSentenceNr()
		{
		unsigned int myFirstSentenceNr = admin_->myFirstSentenceNr();
		char functionNameString[FUNCTION_NAME_LENGTH] = "decrementCurrentSentenceNr";

		if( commonVariables_->currentSentenceNr > NO_SENTENCE_NR )
			{
			if( commonVariables_->currentSentenceNr - 1 >= myFirstSentenceNr )		// Is my sentence
				{
				if( getHighestInUseSentenceNr( false, true, false, --commonVariables_->currentSentenceNr ) == RESULT_OK )
					{
					if( commonVariables_->highestInUseSentenceNr < commonVariables_->currentSentenceNr )
						commonVariables_->currentSentenceNr = ( commonVariables_->highestInUseSentenceNr > myFirstSentenceNr ? commonVariables_->highestInUseSentenceNr : myFirstSentenceNr );

					// Necessary after decrement of current sentence number
					if( currentItemNr() != RESULT_OK )
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get the current item number after decrementation" );
					}
				else
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find out if this sentence is empty" );
				}
			else
				dontIncrementCurrentSentenceNr_ = true;
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The current sentence number is undefined" );

		return commonVariables_->result;
		}

	ResultType decrementItemNrRange( unsigned int decrementSentenceNr, unsigned int startDecrementItemNr, unsigned int decrementOffset )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "decrementItemNrRange";
		if( commonVariables_->currentSentenceNr == decrementSentenceNr &&
		commonVariables_->currentItemNr > startDecrementItemNr )
			commonVariables_->currentItemNr -= decrementOffset;

		if( admin_->wordList != NULL )						// Inside words
			{
			if( admin_->wordList->decrementItemNrRangeInWordList( decrementSentenceNr, startDecrementItemNr, decrementOffset ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to decrement item number range in my word list" );
			}

		for( unsigned short adminListNr = 0; adminListNr < NUMBER_OF_ADMIN_LISTS; adminListNr++ )
			{
			if( admin_->adminList[adminListNr] != NULL )	// Inside admin lists
				{
				if( admin_->adminList[adminListNr]->decrementItemNrRangeInList( decrementSentenceNr, startDecrementItemNr, decrementOffset ) != RESULT_OK )
					return myWord_->addErrorInItem( admin_->adminListChar( adminListNr ), functionNameString, moduleNameString_, "I failed to decrement item number range" );
				}
			}

		return commonVariables_->result;
		}


	public:
	// Constructor

	AdminCleanup( AdminItem *admin, WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		dontIncrementCurrentSentenceNr_ = false;
		hasFoundChange_ = false;
		wasUndoOrRedo_ = false;

		admin_ = admin;
		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "AdminCleanup" );

		if( commonVariables_ != NULL )
			{
		if( admin_ != NULL )
			{
			if( myWord_ == NULL )
				strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given admin is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	void clearDontIncrementCurrentSentenceNr()
		{
		dontIncrementCurrentSentenceNr_ = false;
		}

	bool dontIncrementCurrentSentenceNr()
		{
		return dontIncrementCurrentSentenceNr_;
		}

	bool hasFoundChange()
		{
		return hasFoundChange_;
		}

	bool wasUndoOrRedo()
		{
		return wasUndoOrRedo_;
		}

	unsigned int highestSentenceNr()
		{
		unsigned int tempSentenceNr;
		unsigned int highestSentenceNr = NO_SENTENCE_NR;

		if( admin_->wordList != NULL )						// Inside words
			highestSentenceNr = admin_->wordList->highestSentenceNrInWordList();

		for( unsigned short adminListNr = 0; adminListNr < NUMBER_OF_ADMIN_LISTS; adminListNr++ )
			{
			if( admin_->adminList[adminListNr] != NULL &&	// Inside admin lists
			( tempSentenceNr = admin_->adminList[adminListNr]->highestSentenceNrInList() ) > highestSentenceNr )
				highestSentenceNr = tempSentenceNr;
			}

		return highestSentenceNr;
		}

	ResultType checkForChanges()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkForChanges";
		hasFoundChange_ = true;

		if( getHighestInUseSentenceNr( false, false, false, commonVariables_->currentSentenceNr ) == RESULT_OK )
			{
			if( commonVariables_->highestInUseSentenceNr < commonVariables_->currentSentenceNr )
				hasFoundChange_ = false;
			else
				clearDontIncrementCurrentSentenceNr();		// Found new knowledge
			}
		else
			return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find out if the sentence is empty" );

		return commonVariables_->result;
		}

	ResultType cleanupDeletedItems()
		{
		unsigned int previousRemoveSentenceNr = NO_SENTENCE_NR;
		char functionNameString[FUNCTION_NAME_LENGTH] = "cleanupDeletedItems";

//		if( !admin_->isSystemStartingUp() )
//			commonVariables_->presentation->showStatus( INTERFACE_CONSOLE_I_AM_CLEANING_UP_DELETED_ITEMS );

		do	{
			if( removeFirstRangeOfDeletedItems() == RESULT_OK )
				{
				if( previousRemoveSentenceNr > NO_SENTENCE_NR &&
				previousRemoveSentenceNr != commonVariables_->removeSentenceNr )		// Previous deleted sentence is may be empty
					{
					if( getHighestInUseSentenceNr( true, true, true, previousRemoveSentenceNr ) == RESULT_OK )
						{
						if( commonVariables_->highestInUseSentenceNr < previousRemoveSentenceNr )	// All items of this sentence are deleted
							{																// So, decrement all higher sentence numbers
							if( decrementSentenceNrs( previousRemoveSentenceNr ) == RESULT_OK )
								{
								if( commonVariables_->removeSentenceNr > previousRemoveSentenceNr )
									commonVariables_->removeSentenceNr--;

								if( commonVariables_->currentSentenceNr >= previousRemoveSentenceNr )
									{
									if( decrementCurrentSentenceNr() != RESULT_OK )
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to decrement the current sentence number" );
									}
								}
							else
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to decrement the sentence numbers from the current sentence number" );
							}
						}
					else
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check if the deleted sentence is empty" );
					}

				if( commonVariables_->nDeletedItems > 0 )
					{
					if( decrementItemNrRange( commonVariables_->removeSentenceNr, commonVariables_->removeStartItemNr, commonVariables_->nDeletedItems ) == RESULT_OK )
						previousRemoveSentenceNr = commonVariables_->removeSentenceNr;
					else
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to decrement item number range" );
					}
				}
			else
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to remove the first deleted items" );
			}
		while( commonVariables_->nDeletedItems > 0 );

//		commonVariables_->presentation->clearStatus();

		return commonVariables_->result;
		}

	ResultType currentItemNr()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "currentItemNr";
		commonVariables_->currentItemNr = NO_ITEM_NR;

		if( admin_->wordList != NULL )						// Inside words
			{
			if( admin_->wordList->getCurrentItemNrInWordList() != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get the current item number of my word list" );
			}

		for( unsigned short adminListNr = 0; adminListNr < NUMBER_OF_ADMIN_LISTS; adminListNr++ )
			{
			if( admin_->adminList[adminListNr] != NULL )	// Inside admin lists
				{
				if( admin_->adminList[adminListNr]->getCurrentItemNrInList() != RESULT_OK )
					return myWord_->addErrorInItem( admin_->adminListChar( adminListNr ), functionNameString, moduleNameString_, "I failed to get the current item number" );
				}
			}

		return commonVariables_->result;
		}

	ResultType deleteRollbackInfo()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteRollbackInfo";
		if( admin_->wordList != NULL )						// Inside words
			{
			if( admin_->wordList->deleteRollbackInfoInWordList() != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete the rollback info of my words in my word list" );
			}

		for( unsigned short adminListNr = 0; adminListNr < NUMBER_OF_ADMIN_LISTS; adminListNr++ )
			{
			if( admin_->adminList[adminListNr] != NULL )	// Inside admin lists
				{
				if( admin_->adminList[adminListNr]->deleteRollbackInfoInList() != RESULT_OK )
					return myWord_->addErrorInItem( admin_->adminListChar( adminListNr ), functionNameString, moduleNameString_, "I failed to delete the rollback info in my lists" );
				}
			}

		return commonVariables_->result;
		}

	ResultType deleteAllTemporaryLists()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteAllTemporaryLists";
		wasUndoOrRedo_ = false;

		admin_->deleteReadList();				// Read list is a temporary list
		admin_->deleteScoreList();				// Score list is a temporary list

		deleteResponseListsInAllWords();		// Response lists are temporary lists

		if( cleanupDeletedItems() != RESULT_OK )
			return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to cleanup the deleted items" );

		return commonVariables_->result;
		}

	ResultType deleteUnusedInterpretations( bool deleteAllActiveWordTypes )
		{
		unsigned short adminListNr;
		unsigned short previousWordOrderNr = NO_ORDER_NR;
		WordItem *unusedWordItem;
		ReadItem *unusedReadItem = admin_->firstActiveReadItem();
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteUnusedInterpretations";

		if( admin_->readList != NULL )
			{
			if( admin_->wordList != NULL )
				{
				if( deleteUnusedWordTypes( deleteAllActiveWordTypes ) == RESULT_OK )	// From active read items
					{
					while( unusedReadItem != NULL )
						{
						if( unusedReadItem->isUnusedReadItem ||
						unusedReadItem->wordOrderNr() == previousWordOrderNr )
							{
							previousWordOrderNr = unusedReadItem->wordOrderNr();
							unusedWordItem = unusedReadItem->readWordItem();

							if( admin_->readList->deleteActiveItem( false, unusedReadItem ) == RESULT_OK )
								{
								if( unusedWordItem != NULL &&	// Skip text
								!unusedWordItem->hasItems() &&
								!unusedWordItem->isDeletedItem() &&
								unusedWordItem->hasCurrentCreationSentenceNr() )
									{
									adminListNr = 0;
									commonVariables_->hasFoundWordReference = false;

									while( !commonVariables_->hasFoundWordReference &&
									adminListNr < NUMBER_OF_ADMIN_LISTS )
										{
										if( admin_->adminList[adminListNr] != NULL )
											{
											// Check the selection lists for a reference to this word
											if( admin_->adminList[adminListNr]->findWordReference( unusedWordItem ) != RESULT_OK )
												return myWord_->addErrorInItem( admin_->adminListChar( adminListNr ), functionNameString, moduleNameString_, "I failed to find a reference to an active word \"", unusedWordItem->anyWordTypeString(), "\" in one of my lists" );
											}

										adminListNr++;
										}

									if( !commonVariables_->hasFoundWordReference )
										{
										if( admin_->wordList->deleteActiveItem( false, unusedWordItem ) != RESULT_OK )
											return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete a word item" );
										}
									}

								unusedReadItem = admin_->readList->nextReadListItem();
								}
							else
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete an active item" );
							}
						else
							{
							previousWordOrderNr = unusedReadItem->wordOrderNr();
							unusedReadItem = unusedReadItem->nextReadItem();
							}
						}

					while( ( unusedReadItem = admin_->firstDeactiveReadItem() ) != NULL )
						{
						if( admin_->readList->deleteDeactiveItem( false, unusedReadItem ) == RESULT_OK )
							{
							unusedWordItem = unusedReadItem->readWordItem();

							if( unusedWordItem != NULL &&
							!unusedWordItem->hasItems() &&
							!unusedWordItem->isDeletedItem() &&
							unusedWordItem->hasCurrentCreationSentenceNr() )
								{
								adminListNr = 0;
								commonVariables_->hasFoundWordReference = false;

								while( !commonVariables_->hasFoundWordReference &&
								adminListNr < NUMBER_OF_ADMIN_LISTS )
									{
									if( admin_->adminList[adminListNr] != NULL )
										{
										// Check my lists for a reference to this word
										if( admin_->adminList[adminListNr]->findWordReference( unusedWordItem ) != RESULT_OK )
											return myWord_->addErrorInItem( admin_->adminListChar( adminListNr ), functionNameString, moduleNameString_, "I failed to find a reference to a deactive word \"", unusedWordItem->anyWordTypeString(), "\" in one of my lists" );
										}

									adminListNr++;
									}

								if( !commonVariables_->hasFoundWordReference )
									{
									if( admin_->wordList->deleteActiveItem( false, unusedWordItem ) != RESULT_OK )
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete a word item" );
									}
								}
							}
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete an unused (deactive) read word" );
						}
					}
				else
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete the unused word types" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The word list isn't created yet" );
			}

		return commonVariables_->result;
		}

	ResultType deleteSentences( bool isAvailableForRollback, unsigned int lowestSentenceNr )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteSentences";
		if( admin_->wordList != NULL )						// Inside words
			{
			if( admin_->wordList->deleteSentencesInWordList( isAvailableForRollback, lowestSentenceNr ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete sentences in my word list" );
			}

		for( unsigned short adminListNr = 0; adminListNr < NUMBER_OF_ADMIN_LISTS; adminListNr++ )
			{
			if( admin_->adminList[adminListNr] != NULL )	// Inside admin lists
				{
				if( admin_->adminList[adminListNr]->deleteSentencesInList( isAvailableForRollback, lowestSentenceNr ) != RESULT_OK )
					return myWord_->addErrorInItem( admin_->adminListChar( adminListNr ), functionNameString, moduleNameString_, "I failed to delete sentences in a list" );
				}
			}

		if( cleanupDeletedItems() != RESULT_OK )
			return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to cleanup the deleted items" );

		return commonVariables_->result;
		}

	ResultType undoLastSentence()
		{
		bool skipUndo = false;
		char functionNameString[FUNCTION_NAME_LENGTH] = "undoLastSentence";

		if( commonVariables_->currentSentenceNr > NO_SENTENCE_NR )
			{
			if( deleteAllTemporaryLists() == RESULT_OK )			// Deleted read words of the undo sentence
				{
				if( commonVariables_->currentSentenceNr > highestSentenceNr() )
					{
					if( commonVariables_->currentSentenceNr - 1 >= admin_->myFirstSentenceNr() )		// Is my sentence
						{
						commonVariables_->currentSentenceNr--;

						if( currentItemNr() != RESULT_OK )			// Necessary after decrement of current sentence number
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get the current item number after decrementation" );
						}
					else
						{
						if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_NOTIFICATION, INTERFACE_IMPERATIVE_NOTIFICATION_UNDO_SENTENCE_OF_ANOTHER_USER ) == RESULT_OK )
							{
							skipUndo = true;
							dontIncrementCurrentSentenceNr_ = true;
							}
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface notification about another user" );
						}
					}

				if( !skipUndo )
					{
					if( rollbackDeletedRedoInfo() == RESULT_OK )	// Roll-back Undo sentence. Handle it as a command, not as a sentence
						{
						if( undoCurrentSentence() == RESULT_OK )
							{
							if( commonVariables_->presentation->writeInterfaceText( PRESENTATION_PROMPT_NOTIFICATION, INTERFACE_IMPERATIVE_NOTIFICATION_I_HAVE_UNDONE_SENTENCE_NR, commonVariables_->currentSentenceNr, INTERFACE_IMPERATIVE_NOTIFICATION_SENTENCE_NR_END ) == RESULT_OK )
								{
								wasUndoOrRedo_ = true;
								dontIncrementCurrentSentenceNr_ = true;
								admin_->dontShowConclusions();
								}
							else
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface notification about having undone a sentence" );
							}
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to undo the current sentence" );
						}
					else
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to rollback the deleted redo info" );
					}
				}
			else
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete all temporary lists" );
			}
		else
			{
			if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_NOTIFICATION, INTERFACE_IMPERATIVE_NOTIFICATION_NO_SENTENCES_LEFT_TO_UNDO ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface notification about no sentences left to undo" );
			}

		return commonVariables_->result;
		}

	ResultType redoLastUndoneSentence()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "redoLastUndoneSentence";
		if( deleteAllTemporaryLists() == RESULT_OK )	// Deleted read words of the undo sentence
			{
			if( !dontIncrementCurrentSentenceNr_ &&
			commonVariables_->currentSentenceNr > highestSentenceNr() )
				{
				if( rollbackDeletedRedoInfo() == RESULT_OK )
					{
					if( redoCurrentSentence() == RESULT_OK )
						{
						if( commonVariables_->presentation->writeInterfaceText( PRESENTATION_PROMPT_NOTIFICATION, INTERFACE_IMPERATIVE_NOTIFICATION_I_HAVE_REDONE_SENTENCE_NR, commonVariables_->currentSentenceNr, INTERFACE_IMPERATIVE_NOTIFICATION_SENTENCE_NR_END ) == RESULT_OK )
							{
							wasUndoOrRedo_ = true;
							admin_->dontShowConclusions();
							}
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface notification about having redone a sentence" );
						}
					else
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to redo the current sentence" );
					}
				else
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to rollback the deleted redo info" );
				}
			else
				{
				if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_NOTIFICATION, INTERFACE_IMPERATIVE_NOTIFICATION_NO_SENTENCES_TO_REDO ) != RESULT_OK )
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface notification about no sentences to redo" );
				}
			}
		else
			return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete all temporary lists" );

		return commonVariables_->result;
		}
	};

/*************************************************************************
 *
 *	"How great is the Lord,
 *	how deserving of praise,
 *	in the city of our God,
 *	which sits on his holy mountain!" (Psalm 48:1)
 *
 *************************************************************************/
