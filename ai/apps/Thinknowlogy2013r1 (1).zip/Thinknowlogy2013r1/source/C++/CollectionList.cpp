/*
 *	Class:			CollectionList
 *	Parent class:	List
 *	Purpose:		To store collection items
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "CollectionItem.cpp"
#include "List.h"

class CollectionList : private List
	{
	friend class WordCollection;


	// Private deconstructor functions

	void deleteCollectionsInList( CollectionItem *searchItem )
		{
		CollectionItem *deleteItem;

		while( searchItem != NULL )
			{
			deleteItem = searchItem;
			searchItem = searchItem->nextCollectionItem();
			delete deleteItem;
			}
		}


	// Private functions

	CollectionItem *firstActiveCollectionItem()
		{
		return (CollectionItem *)firstActiveItem();
		}


	public:
	// Constructor

	CollectionList( WordItem *myWord, CommonVariables *commonVariables )
		{
		initializeListVariables( WORD_COLLECTION_LIST_SYMBOL, "CollectionList", myWord, commonVariables );
		}

	// Deconstructor

	~CollectionList()
		{
		deleteCollectionsInList( firstActiveCollectionItem() );
		deleteCollectionsInList( (CollectionItem *)firstDeactiveItem() );
		deleteCollectionsInList( (CollectionItem *)firstArchivedItem() );
		deleteCollectionsInList( (CollectionItem *)firstDeletedItem() );
		}


	// Protected functions

	bool hasCollectionNr( unsigned int collectionNr )
		{
		CollectionItem *searchItem = firstActiveCollectionItem();

		if( collectionNr > NO_COLLECTION_NR )
			{
			while( searchItem != NULL )
				{
				if( searchItem->collectionNr() == collectionNr )
					return true;

				searchItem = searchItem->nextCollectionItem();
				}
			}

		return false;
		}

	bool hasCollectionOrderNr( unsigned int collectionOrderNr )
		{
		CollectionItem *searchItem = firstActiveCollectionItem();

		while( searchItem != NULL )
			{
			if( searchItem->collectionOrderNr() == collectionOrderNr )
				return true;

			searchItem = searchItem->nextCollectionItem();
			}

		return false;
		}

	bool hasCollectionItem( WordItem *commonWordItem )
		{
		CollectionItem *searchItem = firstActiveCollectionItem();

		while( searchItem != NULL )
			{
			if( commonWordItem == NULL ||
			searchItem->commonWordItem() == commonWordItem )
				return true;

			searchItem = searchItem->nextCollectionItem();
			}

		return false;
		}

	bool hasFoundCollection( unsigned int collectionNr, WordItem *collectionWordItem, WordItem *commonWordItem, WordItem *compoundGeneralizationWordItem )
		{
		CollectionItem *searchItem = firstActiveCollectionItem();

		if( collectionNr > NO_COLLECTION_NR &&
		collectionWordItem != NULL &&
		commonWordItem != NULL )
			{
			while( searchItem != NULL )
				{
				if( searchItem->collectionNr() == collectionNr &&
				searchItem->collectionWordItem() == collectionWordItem &&
				searchItem->commonWordItem() == commonWordItem &&
				searchItem->compoundGeneralizationWordItem() == compoundGeneralizationWordItem )
					return searchItem->isExclusive();

				searchItem = searchItem->nextCollectionItem();
				}
			}

		return false;
		}

	bool isCollectedCommonWord( WordItem *commonWordItem )
		{
		CollectionItem *searchItem = firstActiveCollectionItem();

		if( commonWordItem != NULL )
			{
			while( searchItem != NULL )
				{
				if( commonWordItem->hasCollectionNr( searchItem->collectionNr() ) )
					return true;

				searchItem = searchItem->nextCollectionItem();
				}
			}

		return false;
		}

	bool isCompoundCollection( unsigned int collectionNr )
		{
		CollectionItem *searchItem = firstActiveCollectionItem();

		if( collectionNr > NO_COLLECTION_NR )
			{
			while( searchItem != NULL )
				{
				if( searchItem->collectionNr() == collectionNr )
					return ( searchItem->compoundGeneralizationWordItem() != NULL );

				searchItem = searchItem->nextCollectionItem();
				}
			}

		return false;
		}

	bool isCompoundCollection( unsigned int collectionNr, WordItem *commonWordItem )
		{
		CollectionItem *searchItem = firstActiveCollectionItem();

		if( collectionNr > NO_COLLECTION_NR &&
		commonWordItem != NULL )
			{
			while( searchItem != NULL )
				{
				if( searchItem->collectionNr() == collectionNr &&
				searchItem->commonWordItem() == commonWordItem )
					return ( searchItem->compoundGeneralizationWordItem() != NULL );

				searchItem = searchItem->nextCollectionItem();
				}
			}

		return false;
		}

	bool isExclusiveCollection( unsigned int collectionNr )
		{
		CollectionItem *searchItem = firstActiveCollectionItem();

		if( collectionNr > NO_COLLECTION_NR )
			{
			while( searchItem != NULL )
				{
				if( searchItem->collectionNr() == collectionNr )
					return searchItem->isExclusive();

				searchItem = searchItem->nextCollectionItem();
				}
			}

		return false;
		}

	unsigned short highestCollectionOrderNr( unsigned int collectionNr )
		{
		unsigned short highestCollectionOrderNr = NO_ORDER_NR;
		CollectionItem *searchItem = firstActiveCollectionItem();

		while( searchItem != NULL )
			{
			if( searchItem->collectionNr() == collectionNr &&
			searchItem->collectionOrderNr() > highestCollectionOrderNr )
				highestCollectionOrderNr = searchItem->collectionOrderNr();

			searchItem = searchItem->nextCollectionItem();
			}

		return highestCollectionOrderNr;
		}

	unsigned short collectionOrderNrByWordTypeNr( unsigned short collectionWordTypeNr )
		{
		CollectionItem *searchItem = firstActiveCollectionItem();

		while( searchItem != NULL )
			{
			if( searchItem->collectionWordTypeNr() == collectionWordTypeNr )
				return searchItem->collectionOrderNr();

			searchItem = searchItem->nextCollectionItem();
			}

		return NO_ORDER_NR;
		}

	unsigned short collectionOrderNr( unsigned int collectionNr, WordItem *collectionWordItem, WordItem *commonWordItem )
		{
		CollectionItem *searchItem = firstActiveCollectionItem();

		while( searchItem != NULL )
			{
			if( searchItem->collectionNr() == collectionNr &&
			searchItem->collectionWordItem() == collectionWordItem &&
			searchItem->commonWordItem() == commonWordItem )
				return searchItem->collectionOrderNr();

			searchItem = searchItem->nextCollectionItem();
			}

		return NO_ORDER_NR;
		}

	unsigned int collectionNr( unsigned short collectionWordTypeNr )
		{
		CollectionItem *searchItem = firstActiveCollectionItem();

		while( searchItem != NULL )
			{
			if( searchItem->isMatchingCollectionWordTypeNr( collectionWordTypeNr ) )
				return searchItem->collectionNr();

			searchItem = searchItem->nextCollectionItem();
			}

		return NO_COLLECTION_NR;
		}

	unsigned int collectionNr( unsigned short collectionWordTypeNr, WordItem *commonWordItem )
		{
		CollectionItem *searchItem = firstActiveCollectionItem();

		while( searchItem != NULL )
			{
			if( searchItem->isMatchingCollectionWordTypeNr( collectionWordTypeNr ) &&

			( searchItem->commonWordItem() == commonWordItem ||
			searchItem->commonWordItem()->isCollectedCommonWord( commonWordItem ) ) )
				return searchItem->collectionNr();

			searchItem = searchItem->nextCollectionItem();
			}

		return NO_COLLECTION_NR;
		}

	unsigned int collectionNr( unsigned short collectionWordTypeNr, WordItem *commonWordItem, WordItem *compoundGeneralizationWordItem )
		{
		CollectionItem *searchItem = firstActiveCollectionItem();

		while( searchItem != NULL )
			{
			if( searchItem->isMatchingCollectionWordTypeNr( collectionWordTypeNr ) &&
			searchItem->compoundGeneralizationWordItem() == compoundGeneralizationWordItem &&

			( searchItem->commonWordItem() == commonWordItem ||

			( searchItem->commonWordItem() != NULL &&
			searchItem->commonWordItem()->isCollectedCommonWord( commonWordItem ) ) ) )
				return searchItem->collectionNr();

			searchItem = searchItem->nextCollectionItem();
			}

		return NO_COLLECTION_NR;
		}

	unsigned int compoundCollectionNr( unsigned short collectionWordTypeNr )
		{
		CollectionItem *searchItem = firstActiveCollectionItem();

		while( searchItem != NULL )
			{
			if( searchItem->compoundGeneralizationWordItem() != NULL &&
			searchItem->isMatchingCollectionWordTypeNr( collectionWordTypeNr ) )
				return searchItem->collectionNr();

			searchItem = searchItem->nextCollectionItem();
			}

		return NO_COLLECTION_NR;
		}

	unsigned int nonCompoundCollectionNr( unsigned short collectionWordTypeNr )
		{
		CollectionItem *searchItem = firstActiveCollectionItem();

		while( searchItem != NULL )
			{
			if( searchItem->compoundGeneralizationWordItem() == NULL &&
			searchItem->isMatchingCollectionWordTypeNr( collectionWordTypeNr ) )
				return searchItem->collectionNr();

			searchItem = searchItem->nextCollectionItem();
			}

		return NO_COLLECTION_NR;
		}

	unsigned int collectionNrByCommonWord( unsigned short collectionWordTypeNr, WordItem *commonWordItem )
		{
		CollectionItem *searchItem = firstActiveCollectionItem();

		while( searchItem != NULL )
			{
			if( searchItem->commonWordItem() == commonWordItem &&
			searchItem->isMatchingCollectionWordTypeNr( collectionWordTypeNr ) )
				return searchItem->collectionNr();

			searchItem = searchItem->nextCollectionItem();
			}

		return NO_COLLECTION_NR;
		}

	unsigned int collectionNrByCompoundGeneralizationWord( unsigned short collectionWordTypeNr, WordItem *compoundGeneralizationWordItem )
		{
		CollectionItem *searchItem = firstActiveCollectionItem();

		while( searchItem != NULL )
			{
			if( searchItem->isMatchingCollectionWordTypeNr( collectionWordTypeNr ) &&
			searchItem->compoundGeneralizationWordItem() == compoundGeneralizationWordItem )
				return searchItem->collectionNr();

			searchItem = searchItem->nextCollectionItem();
			}

		return NO_COLLECTION_NR;
		}

	unsigned int highestCollectionNr()
		{
		unsigned int highestCollectionNr = NO_COLLECTION_NR;
		CollectionItem *searchItem = firstActiveCollectionItem();

		while( searchItem != NULL )
			{
			if( searchItem->collectionNr() > highestCollectionNr )
				highestCollectionNr = searchItem->collectionNr();

			searchItem = searchItem->nextCollectionItem();
			}

		return highestCollectionNr;
		}

	unsigned int nonCompoundCollectionNr( unsigned int compoundCollectionNr )
		{
		unsigned int nonCompoundCollectionNr;
		CollectionItem *searchItem = firstActiveCollectionItem();
		WordItem *collectionWordItem;

		while( searchItem != NULL )
			{
			if( searchItem->collectionNr() == compoundCollectionNr &&
			( collectionWordItem = searchItem->collectionWordItem() ) != NULL )
				{
				if( ( nonCompoundCollectionNr = collectionWordItem->nonCompoundCollectionNr( searchItem->collectionWordTypeNr() ) ) > NO_COLLECTION_NR )
					return nonCompoundCollectionNr;
				}

			searchItem = searchItem->nextCollectionItem();
			}

		return NO_COLLECTION_NR;
		}

	ResultType checkWordItemForUsage( WordItem *unusedWordItem )
		{
		CollectionItem *searchItem = firstActiveCollectionItem();
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkWordItemForUsage";

		if( unusedWordItem != NULL )
			{
			while( searchItem != NULL )
				{
				if( searchItem->collectionWordItem() == unusedWordItem )
					return startError( functionNameString, NULL, "The collected word item is still in use" );

				if( searchItem->commonWordItem() == unusedWordItem )
					return startError( functionNameString, NULL, "The common word item is still in use" );

				if( searchItem->compoundGeneralizationWordItem() == unusedWordItem )
					return startError( functionNameString, NULL, "The compound word item is still in use" );

				searchItem = searchItem->nextCollectionItem();
				}
			}
		else
			return startError( functionNameString, NULL, "The given unused word item is undefined" );

		return commonVariables()->result;
		}

	ResultType createCollectionItem( bool isExclusive, unsigned short collectionOrderNr, unsigned short collectionWordTypeNr, unsigned short commonWordTypeNr, unsigned int collectionNr, WordItem *collectionWordItem, WordItem *commonWordItem, WordItem *compoundGeneralizationWordItem, char *collectionString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "createCollectionItem";
		if( collectionWordTypeNr > WORD_TYPE_UNDEFINED &&
		collectionWordTypeNr < NUMBER_OF_WORD_TYPES )
			{
			if( commonVariables()->currentItemNr < MAX_ITEM_NR )
				{
				if( addItemToActiveList( (Item *)( new CollectionItem( isExclusive, collectionOrderNr, collectionWordTypeNr, commonWordTypeNr, collectionNr, collectionWordItem, commonWordItem, compoundGeneralizationWordItem, collectionString, this, myWord(), commonVariables() ) ) ) != RESULT_OK )
					return addError( functionNameString, NULL, "I failed to add an active collection item" );
				}
			else
				return startError( functionNameString, NULL, "The current item number is undefined" );
			}
		else
			return startError( functionNameString, NULL, "The given collected word type number is undefined or out of bounds" );

		return commonVariables()->result;
		}

	WordItem *commonWordItem( unsigned int collectionNr, WordItem *compoundGeneralizationWordItem )
		{
		CollectionItem *searchItem = firstActiveCollectionItem();

		if( collectionNr > NO_COLLECTION_NR &&
		compoundGeneralizationWordItem != NULL )
			{
			while( searchItem != NULL )
				{
				if( searchItem->collectionNr() == collectionNr &&
				searchItem->compoundGeneralizationWordItem() == compoundGeneralizationWordItem )
					return searchItem->commonWordItem();

				searchItem = searchItem->nextCollectionItem();
				}
			}

		return NULL;
		}

	CollectionResultType findCollectionItem( bool isAllowingDifferentCommonWord, WordItem *collectionWordItem, WordItem *commonWordItem )
		{
		CollectionResultType collectionResult;
		CollectionItem *currentCollectionItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findCollectionItem";

		if( commonWordItem != NULL )
			{
			if( collectionWordItem != NULL )
				{
				if( ( currentCollectionItem = firstActiveCollectionItem() ) != NULL )
					{
					do	{
						if( currentCollectionItem->collectionWordItem() == collectionWordItem &&

						( currentCollectionItem->commonWordItem() == commonWordItem ||

						( isAllowingDifferentCommonWord &&
						collectionWordItem->hasCollectionNr( currentCollectionItem->collectionNr() ) ) ) )
							collectionResult.isCollected = true;
						}
					while( !collectionResult.isCollected &&
					( currentCollectionItem = currentCollectionItem->nextCollectionItem() ) != NULL );
					}
				}
			else
				startError( functionNameString, NULL, "The given common word is undefined" );
			}
		else
			startError( functionNameString, NULL, "The given collected word is undefined" );

		collectionResult.result = commonVariables()->result;
		return collectionResult;
		}

	WordItem *compoundCollectionWordItem( unsigned int collectionNr, WordItem *notThisCommonWordItem )
		{
		CollectionItem *searchItem = firstActiveCollectionItem();

		while( searchItem != NULL )
			{
			if( searchItem->collectionNr() == collectionNr &&
			searchItem->commonWordItem() != notThisCommonWordItem &&
			searchItem->compoundGeneralizationWordItem() != NULL )
				return searchItem->collectionWordItem();

			searchItem = searchItem->nextCollectionItem();
			}

		return NULL;
		}
	};

/*************************************************************************
 *
 *	"Give thanks to the Lords of lords.
 *	His faithful love endures forever." (Psalm 136:3)
 *
 *************************************************************************/
