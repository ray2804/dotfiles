/*
 *	Class:			WordQuery
 *	Supports class:	WordItem
 *	Purpose:		To process queries
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

class WordQuery
	{
	// Private constructible variables

	private WordItem myWord_;
	private String moduleNameString_;


	// Constructor

	protected WordQuery( WordItem myWord )
		{
		String errorString = null;

		myWord_ = myWord;
		moduleNameString_ = this.getClass().getName();

		if( myWord_ == null )
			errorString = "The given my word is undefined";

		if( errorString != null )
			{
			if( myWord_ != null )
				myWord_.startSystemErrorInWord( 1, moduleNameString_, errorString );
			else
				{
				CommonVariables.result = Constants.RESULT_SYSTEM_ERROR;
				Console.addError( "\nClass:" + moduleNameString_ + "\nMethod:\t" + Constants.PRESENTATION_ERROR_CONSTRUCTOR_METHOD_NAME + "\nError:\t\t" + errorString + ".\n" );
				}
			}
		}


	// Protected virtual methods

	protected StringBuffer toStringBuffer( short queryWordTypeNr )
		{
		myWord_.baseToStringBuffer( queryWordTypeNr );

		CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + Constants.QUERY_WORD_START_CHAR + myWord_.wordTypeString( true, Constants.NO_ORDER_NR, queryWordTypeNr ) + Constants.QUERY_WORD_END_CHAR );

		if( myWord_.needsAuthorizationForChanges() )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "needsAuthorizationForChanges" );

		if( myWord_.wordParameter() > Constants.NO_WORD_PARAMETER )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "wordParameter:" + myWord_.wordParameter() );

		return CommonVariables.queryStringBuffer;
		}


	// Protected methods

	protected void countQuery()
		{
		for( short wordListNr : Constants.WordLists )
			{
			if( myWord_.wordList[wordListNr] != null )
				myWord_.wordList[wordListNr].countQueryInList();
			}
		}

	protected void clearQuerySelections()
		{
		for( short wordListNr : Constants.WordLists )
			{
			if( myWord_.wordList[wordListNr] != null )
				myWord_.wordList[wordListNr].clearQuerySelectionsInList();
			}
		}

	protected byte itemQuery( boolean isFirstInstruction, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, boolean isReferenceQuery, int querySentenceNr, int queryItemNr )
		{
		for( short wordListNr : Constants.WordLists )
			{
			if( myWord_.wordList[wordListNr] != null )
				{
				if( myWord_.wordList[wordListNr].itemQueryInList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, isReferenceQuery, querySentenceNr, queryItemNr ) != Constants.RESULT_OK )
					return myWord_.addErrorInWord( myWord_.wordListChar( wordListNr ), 1, moduleNameString_, "I failed to query item numbers" );
				}
			}

		return CommonVariables.result;
		}

	protected byte listQuery( boolean isFirstInstruction, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, StringBuffer queryListStringBuffer )
		{
		for( short wordListNr : Constants.WordLists )
			{
			if( myWord_.wordList[wordListNr] != null )
				{
				if( myWord_.wordList[wordListNr].listQueryInList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryListStringBuffer ) != Constants.RESULT_OK )
					return myWord_.addErrorInWord( myWord_.wordListChar( wordListNr ), 1, moduleNameString_, "I failed to do a list query list" );
				}
			}

		return CommonVariables.result;
		}

	protected byte wordTypeQuery( boolean isFirstInstruction, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, short queryWordTypeNr )
		{
		for( short wordListNr : Constants.WordLists )
			{
			if( myWord_.wordList[wordListNr] != null )
				{
				if( myWord_.wordList[wordListNr].wordTypeQueryInList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryWordTypeNr ) != Constants.RESULT_OK )
					return myWord_.addErrorInWord( myWord_.wordListChar( wordListNr ), 1, moduleNameString_, "I failed to query word types" );
				}
			}

		return CommonVariables.result;
		}

	protected byte parameterQuery( boolean isFirstInstruction, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, int queryParameter )
		{
		for( short wordListNr : Constants.WordLists )
			{
			if( myWord_.wordList[wordListNr] != null )
				{
				if( myWord_.wordList[wordListNr].parameterQueryInList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryParameter ) != Constants.RESULT_OK )
					return myWord_.addErrorInWord( myWord_.wordListChar( wordListNr ), 1, moduleNameString_, "I failed to query parameters" );
				}
			}

		return CommonVariables.result;
		}

	protected byte wordQuery( boolean isFirstInstruction, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, String wordNameString )
		{
		if( myWord_.findMatchingWordReferenceString( wordNameString ) == Constants.RESULT_OK )
			{
			if( CommonVariables.hasFoundMatchingStrings )
				{
				if( isFirstInstruction &&
				!myWord_.isSelectedByQuery )
					{
					CommonVariables.hasFoundQuery = true;
					myWord_.isSelectedByQuery = true;
					}
				}
			else
				{
				if( !isFirstInstruction &&
				myWord_.isSelectedByQuery )
					myWord_.isSelectedByQuery = false;
				}

			for( short wordListNr : Constants.WordLists )
				{
				if( myWord_.wordList[wordListNr] != null )
					{
					if( myWord_.wordList[wordListNr].wordQueryInList( ( isFirstInstruction && CommonVariables.hasFoundMatchingStrings ), isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems ) != Constants.RESULT_OK )
						return myWord_.addErrorInWord( myWord_.wordListChar( wordListNr ), 1, moduleNameString_, "I failed to query word items" );
					}
				}
			}
		else
			return myWord_.addErrorInWord( 1, moduleNameString_, "I failed to find words" );

		return CommonVariables.result;
		}

	protected byte wordReferenceQuery( boolean isFirstInstruction, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, String wordReferenceNameString )
		{
		for( short wordListNr : Constants.WordLists )
			{
			if( myWord_.wordList[wordListNr] != null )
				{
				if( myWord_.wordList[wordListNr].wordReferenceQueryInList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordReferenceNameString ) != Constants.RESULT_OK )
					return myWord_.addErrorInWord( myWord_.wordListChar( wordListNr ), 1, moduleNameString_, "I failed to query word references" );
				}
			}

		return CommonVariables.result;
		}

	protected byte stringQuery( boolean isFirstInstruction, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, String queryString )
		{
		for( short wordListNr : Constants.WordLists )
			{
			if( myWord_.wordList[wordListNr] != null )
				{
				if( myWord_.wordList[wordListNr].stringQueryInList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryString ) != Constants.RESULT_OK )
					return myWord_.addErrorInWord( myWord_.wordListChar( wordListNr ), 1, moduleNameString_, "I failed to query strings" );
				}
			}

		return CommonVariables.result;
		}

	protected byte showQueryResult( boolean showOnlyWords, boolean showOnlyWordReferences, boolean showOnlyStrings, boolean returnQueryToPosition, short promptTypeNr, short queryWordTypeNr, int queryWidth )
		{
		for( short wordListNr : Constants.WordLists )
			{
			if( myWord_.wordList[wordListNr] != null )
				{
				if( myWord_.wordList[wordListNr].showQueryResultInList( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth ) != Constants.RESULT_OK )
					return myWord_.addErrorInWord( myWord_.wordListChar( wordListNr ), 1, moduleNameString_, "I failed to show the items" );
				}
			}

		return CommonVariables.result;
		}
	};

/*************************************************************************
 *
 *	"Who can be compared with the Lord or God,
 *	who is enthroned on high?" (Psalm 113:5)
 *
 *************************************************************************/
