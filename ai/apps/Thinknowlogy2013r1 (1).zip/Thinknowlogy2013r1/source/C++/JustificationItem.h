/*
 *	Class:			JustificationItem
 *	Parent class:	Item
 *	Purpose:		To store info need to write the justification reports
 *					for the self-generated knowledge
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

// Justification Item header

// Class declarations needed by some compilers, like Code::Blocks
class SpecificationItem;
class SpecificationResultType;

class JustificationItem : private Item
	{
	friend class AdminAssumption;
	friend class AdminConclusion;
	friend class AdminJustification;
	friend class JustificationList;
	friend class SpecificationItem;
	friend class SpecificationList;

	// Private loadable variables

	unsigned short justificationTypeNr_;

	JustificationItem *attachedJustificationItem_;

	SpecificationItem *definitionSpecificationItem_;
	SpecificationItem *anotherDefinitionSpecificationItem_;
	SpecificationItem *specificSpecificationItem_;


	// Private functions

	bool isSameJustificationType( JustificationItem *referenceJustificationItem );


	protected:
	// Protected constructible variables

	unsigned short orderNr;

	JustificationItem *replacingJustificationItem;


	// Constructor

	JustificationItem( unsigned short justificationTypeNr, unsigned short orderNr, unsigned int originalSentenceNr, JustificationItem *attachedJustificationItem, SpecificationItem *definitionSpecificationItem, SpecificationItem *anotherDefinitionSpecificationItem, SpecificationItem *specificSpecificationItem, List *myList, WordItem *myWord, CommonVariables *commonVariables );


	// Protected virtual functions

	virtual bool hasFoundReferenceItemById( unsigned int querySentenceNr, unsigned int queryItemNr );

	virtual ResultType checkForUsage();

	virtual char *toString( unsigned short queryWordTypeNr );


	// Protected functions

	bool hasDefinitionSpecification();
	bool hasSpecificSpecification();

	bool hasNewInformation();
	bool hasOnlyExclusiveSpecificationSubstitutionAssumptionsWithoutDefinition();

	bool isAssumption();
//	bool isConclusion();
	bool isQuestion();

	bool isOppositePossessiveConditionalSpecificationAssumption();
	bool isPossessiveReversibleConclusion();

	unsigned short assumptionGrade();
	unsigned short justificationTypeNr();

	unsigned int nJustificationContextRelations( unsigned int relationContextNr, unsigned int nSpecificationRelationWords );

	ResultType attachJustificationItem( JustificationItem *attachedJustificationItem, SpecificationItem *mySpecificationItem );
	ResultType changeAttachedJustificationItem( JustificationItem *replacingAttachedJustificationItem );

	ResultType changeDefinitionSpecificationItem( SpecificationItem *replacingSpecificationItem );
	ResultType changeAnotherDefinitionSpecificationItem( SpecificationItem *replacingSpecificationItem );
	ResultType changeSpecificSpecificationItem( SpecificationItem *replacingSpecificationItem );

	SpecificationResultType getCombinedAssumptionLevel();

	JustificationItem *attachedJustificationItem();
	JustificationItem *predecessorOfOldAttachedJustificationItem( JustificationItem *oldJustificationItem );

	JustificationItem *nextJustificationItem();
	JustificationItem *nextJustificationItemWithSameTypeAndOrderNr();
	JustificationItem *nextJustificationItemWithDifferentTypeOrOrderNr( JustificationItem *firstJustificationItem );

	JustificationItem *definitionSpecificationWithoutRelationContextJustificationItem( SpecificationItem *definitionSpecificationItem, SpecificationItem *specificSpecificationItem );
	JustificationItem *foundSpecificSpecificationQuestion();
	JustificationItem *selfGeneratedSpecificSpecificationJustificationItem( SpecificationItem *definitionSpecificationItem, SpecificationItem *specificSpecificationItem );
//	JustificationItem *updatedJustificationItem();

	SpecificationItem *definitionSpecificationItem();
	SpecificationItem *anotherDefinitionSpecificationItem();
	SpecificationItem *specificSpecificationItem();
	};

/*************************************************************************
 *
 *	"Come, let us tell of the Lord's greatness;
 *	let us exalt his name together." (Psalm 34:3)
 *
 *************************************************************************/
