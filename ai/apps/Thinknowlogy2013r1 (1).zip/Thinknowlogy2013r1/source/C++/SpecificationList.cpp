/*
 *	Class:			SpecificationList
 *	Parent class:	List
 *	Purpose:		To store specification items
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#ifndef SPECIFICATIONLIST
#define SPECIFICATIONLIST 1
#include "SpecificationItem.cpp"

class SpecificationList : private List
	{
	friend class WordAssignment;
	friend class WordSpecification;

	// Private deconstructor functions

	void deleteSpecificationList( SpecificationItem *searchItem )
		{
		SpecificationItem *deleteItem;

		while( searchItem != NULL )
			{
			deleteItem = searchItem;
			searchItem = searchItem->nextSpecificationItem();
			delete deleteItem;
			}
		}


	// Private assignment functions

	ResultType createNewAssignmentLevel( bool isDeactive, bool isArchived )
		{
		SpecificationItem *searchItem = firstSpecificationItem( isDeactive, isArchived );
		char functionNameString[FUNCTION_NAME_LENGTH] = "createNewAssignmentLevel";

		if( searchItem != NULL &&
		searchItem->assignmentLevel() > commonVariables()->currentAssignmentLevel )
			searchItem = searchItem->nextAssignmentItemWithCurrentLevel();

		while( searchItem != NULL )
			{
			if( createAssignmentItem( searchItem->isAnsweredQuestion(), searchItem->isConcludedAssumption(), isDeactive, isArchived, searchItem->isExclusive(), searchItem->isNegative(), searchItem->isPossessive(), searchItem->isValueSpecification(), (unsigned short)(searchItem->assignmentLevel() + 1 ), searchItem->assumptionLevel(), searchItem->grammarLanguageNr(), searchItem->prepositionParameter(), searchItem->questionParameter(), searchItem->generalizationWordTypeNr(), searchItem->specificationWordTypeNr(), searchItem->generalizationCollectionNr(), searchItem->specificationCollectionNr(), searchItem->generalizationContextNr(), searchItem->specificationContextNr(), searchItem->relationContextNr(), searchItem->originalSentenceNr(), searchItem->activeSentenceNr(), searchItem->deactiveSentenceNr(), searchItem->archiveSentenceNr(), searchItem->nContextRelations(), searchItem->specificationJustificationItem(), searchItem->specificationWordItem(), searchItem->specificationString() ).result == RESULT_OK )
				searchItem = searchItem->nextAssignmentItemWithCurrentLevel();
			else
				return addError( functionNameString, NULL, "I failed to create an assignment item" );
			}

		return commonVariables()->result;
		}

	ResultType updateArchivedReplacingSpecificationItems( SpecificationItem *updateSpecificationItem )
		{
		SpecificationItem *searchItem = firstSpecificationItem( false, true );
		char functionNameString[FUNCTION_NAME_LENGTH] = "updateArchivedReplacingSpecificationItems";

		if( updateSpecificationItem != NULL )
			{
			while( searchItem != NULL )
				{
				// Update the specification items that are filtered by getAssignmentItem
				// variable: replacingSpecificationItem
				if( searchItem->replacingSpecificationItem == updateSpecificationItem &&
				updateSpecificationItem->replacingSpecificationItem != NULL )
					searchItem->replacingSpecificationItem = updateSpecificationItem->replacingSpecificationItem;

				searchItem = searchItem->nextSpecificationItem();
				}
			}
		else
			return startError( functionNameString, NULL, "The given update specification item is undefined" );

		return commonVariables()->result;
		}

	SpecificationItem *_firstAssignmentItem( bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, bool isSelfGenerated, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationItem *searchItem = firstAssignmentItem( false, isDeactive, isArchived, questionParameter );

		while( searchItem != NULL )
			{
			if( searchItem->isNegative() == isNegative &&
			searchItem->isPossessive() == isPossessive &&
			searchItem->isSelfGenerated() == isSelfGenerated &&
			searchItem->specificationWordItem() == specificationWordItem &&
			searchItem->isMatchingGeneralizationContextNr( true, generalizationContextNr ) &&
			searchItem->isMatchingSpecificationContextNr( true, specificationContextNr ) &&
			searchItem->hasRelationContext() &&

			( specificationString == NULL ||
			searchItem->specificationString() == NULL ||
			strcmp( searchItem->specificationString(), specificationString ) == 0 ) )
				return searchItem;

			searchItem = searchItem->nextSpecificationItemWithSameQuestionParameter( false );
			}

		return NULL;
		}

	SpecificationItem *_firstAssignmentItem( bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationItem *searchItem = firstAssignmentItem( false, isDeactive, isArchived, questionParameter );

		while( searchItem != NULL )
			{
			if( searchItem->isNegative() == isNegative &&
			searchItem->isPossessive() == isPossessive &&
			searchItem->specificationWordItem() == specificationWordItem &&
			searchItem->isMatchingGeneralizationContextNr( true, generalizationContextNr ) &&
			searchItem->isMatchingSpecificationContextNr( true, specificationContextNr ) &&
			searchItem->isMatchingRelationContextNr( true, relationContextNr ) &&

			( specificationString == NULL ||
			searchItem->specificationString() == NULL ||
			strcmp( searchItem->specificationString(), specificationString ) == 0 ) )
				return searchItem;

			searchItem = searchItem->nextSpecificationItemWithSameQuestionParameter( false );
			}

		return NULL;
		}

	SpecificationItem *_firstAssignmentItem( bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, bool isSelfGenerated, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationItem *searchItem = firstAssignmentItem( false, isDeactive, isArchived, questionParameter );

		while( searchItem != NULL )
			{
			if( searchItem->isNegative() == isNegative &&
			searchItem->isPossessive() == isPossessive &&
			searchItem->isSelfGenerated() == isSelfGenerated &&
			searchItem->specificationWordItem() == specificationWordItem &&
			searchItem->isMatchingGeneralizationContextNr( true, generalizationContextNr ) &&
			searchItem->isMatchingSpecificationContextNr( true, specificationContextNr ) &&
			searchItem->isMatchingRelationContextNr( true, relationContextNr ) &&

			( specificationString == NULL ||
			searchItem->specificationString() == NULL ||
			strcmp( searchItem->specificationString(), specificationString ) == 0 ) )
				return searchItem;

			searchItem = searchItem->nextSpecificationItemWithSameQuestionParameter( false );
			}

		return NULL;
		}


	// Private specification functions

	ResultType changeOlderSpecificationItem( bool isExclusiveGeneralization, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, SpecificationItem *olderSpecificationItem )
		{
		SpecificationResultType specificationResult;
		SpecificationItem *replacingSpecificationItem = NULL;
		char functionNameString[FUNCTION_NAME_LENGTH] = "changeOlderSpecificationItem";

		if( olderSpecificationItem != NULL )
			{
			if( olderSpecificationItem->isOlderSentence() )
				{
				if( ( isExclusiveGeneralization ||
				!olderSpecificationItem->isExclusive() ) ||

				( generalizationCollectionNr > NO_COLLECTION_NR ||
				!olderSpecificationItem->hasGeneralizationCollection() ) ||

				( specificationCollectionNr > NO_COLLECTION_NR &&
				!olderSpecificationItem->hasSpecificationCollection() ) )
					{
					if( isAssignmentList() )
						{
						if( ( specificationResult = createAssignmentItem( olderSpecificationItem->isAnsweredQuestion(), olderSpecificationItem->isConcludedAssumption(), olderSpecificationItem->isDeactiveItem(), olderSpecificationItem->isArchivedItem(), ( isExclusiveGeneralization || olderSpecificationItem->isExclusive() ), olderSpecificationItem->isNegative(), olderSpecificationItem->isPossessive(), olderSpecificationItem->isValueSpecification(), olderSpecificationItem->assignmentLevel(), olderSpecificationItem->assumptionLevel(), olderSpecificationItem->grammarLanguageNr(), olderSpecificationItem->prepositionParameter(), olderSpecificationItem->questionParameter(), olderSpecificationItem->generalizationWordTypeNr(), olderSpecificationItem->specificationWordTypeNr(), ( generalizationCollectionNr > NO_COLLECTION_NR ? generalizationCollectionNr : olderSpecificationItem->generalizationCollectionNr() ), ( specificationCollectionNr > NO_COLLECTION_NR ? specificationCollectionNr : olderSpecificationItem->specificationCollectionNr() ), olderSpecificationItem->generalizationContextNr(), olderSpecificationItem->specificationContextNr(), olderSpecificationItem->relationContextNr(), olderSpecificationItem->originalSentenceNr(), olderSpecificationItem->activeSentenceNr(), olderSpecificationItem->deactiveSentenceNr(), olderSpecificationItem->archiveSentenceNr(), olderSpecificationItem->nContextRelations(), olderSpecificationItem->specificationJustificationItem(), olderSpecificationItem->specificationWordItem(), olderSpecificationItem->specificationString() ) ).result == RESULT_OK )
							{
							if( ( replacingSpecificationItem = specificationResult.createdSpecificationItem ) == NULL )
								startError( functionNameString, NULL, "I couldn't create an assignment" );
							}
						else
							return addError( functionNameString, NULL, "I failed to create an assignment" );
						}
					else
						{
						if( ( specificationResult = createSpecificationItem( olderSpecificationItem->isAnsweredQuestion(), olderSpecificationItem->isConditional(), olderSpecificationItem->isConcludedAssumption(), olderSpecificationItem->isDeactiveItem(), olderSpecificationItem->isArchivedItem(), ( isExclusiveGeneralization || olderSpecificationItem->isExclusive() ), olderSpecificationItem->isNegative(), olderSpecificationItem->isPossessive(), olderSpecificationItem->isSpecificationGeneralization(), olderSpecificationItem->isValueSpecification(), olderSpecificationItem->assumptionLevel(), olderSpecificationItem->grammarLanguageNr(), olderSpecificationItem->prepositionParameter(), olderSpecificationItem->questionParameter(), olderSpecificationItem->generalizationWordTypeNr(), olderSpecificationItem->specificationWordTypeNr(), ( generalizationCollectionNr > NO_COLLECTION_NR ? generalizationCollectionNr : olderSpecificationItem->generalizationCollectionNr() ), ( specificationCollectionNr > NO_COLLECTION_NR ? specificationCollectionNr : olderSpecificationItem->specificationCollectionNr() ), olderSpecificationItem->generalizationContextNr(), olderSpecificationItem->specificationContextNr(), ( isExclusiveGeneralization ? NO_CONTEXT_NR : olderSpecificationItem->relationContextNr() ), olderSpecificationItem->originalSentenceNr(), olderSpecificationItem->nContextRelations(), olderSpecificationItem->specificationJustificationItem(), olderSpecificationItem->specificationWordItem(), olderSpecificationItem->specificationString() ) ).result == RESULT_OK )
							{
							if( ( replacingSpecificationItem = specificationResult.createdSpecificationItem ) == NULL )
								startError( functionNameString, NULL, "I couldn't create a specification" );
							}
						else
							return addError( functionNameString, NULL, "I failed to create a specification" );
						}

					if( archiveOrDeletedSpecificationItem( olderSpecificationItem, replacingSpecificationItem ) != RESULT_OK )
						return addError( functionNameString, NULL, "I failed to archive or delete the given specification" );
					}
				else
					return startError( functionNameString, NULL, "I couldn't find any changing parameter" );
				}
			else
				return startError( functionNameString, NULL, "The given older specification item isn't old" );
			}
		else
			return startError( functionNameString, NULL, "The given older specification item is undefined" );

		return commonVariables()->result;
		}

	SpecificationResultType _findSpecificationItem( bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, WordItem *specificationWordItem, WordItem *relationContextWordItem )
		{
		SpecificationResultType specificationResult;
		SpecificationItem *searchItem = firstAssignmentOrSpecificationItem( false, isDeactive, isArchived, questionParameter );
		char functionNameString[FUNCTION_NAME_LENGTH] = "findSpecificationItem";

		if( relationContextWordItem != NULL )
			{
			while( searchItem != NULL &&
			specificationResult.foundSpecificationItem == NULL )
				{
				if( searchItem->isNegative() == isNegative &&
				searchItem->isPossessive() == isPossessive &&
				searchItem->hasRelationContext() &&
				searchItem->specificationWordItem() == specificationWordItem &&
				searchItem->isMatchingGeneralizationContextNr( true, generalizationContextNr ) &&
				searchItem->isMatchingSpecificationContextNr( true, specificationContextNr ) &&
				relationContextWordItem->hasContextInWord( isPossessive, searchItem->relationContextNr(), specificationWordItem ) )
					specificationResult.foundSpecificationItem = searchItem;
				else
					searchItem = searchItem->nextSpecificationItemWithSameQuestionParameter( false );
				}
			}
		else
			startError( functionNameString, NULL, "The given relation context word item is undefined" );

		specificationResult.result = commonVariables()->result;
		return specificationResult;
		}

	SpecificationItem *firstActiveSpecificationItem()
		{
		return (SpecificationItem *)firstActiveItem();
		}

	SpecificationItem *firstDeactiveSpecificationItem()
		{
		return (SpecificationItem *)firstDeactiveItem();
		}

	SpecificationItem *firstArchivedSpecificationItem()
		{
		return (SpecificationItem *)firstArchivedItem();
		}

	SpecificationItem *firstAssignmentItem( bool isDeactive, bool isArchived )
		{
		SpecificationItem *firstAssignmentItem = firstSpecificationItem( isDeactive, isArchived );

		return ( firstAssignmentItem == NULL ? NULL : firstAssignmentItem->getAssignmentItem( false, true ) );
		}

	SpecificationItem *firstSpecificationItem( bool isDeactive, bool isArchived )
		{
		return ( isArchived ? firstArchivedSpecificationItem() : ( isDeactive ? firstDeactiveSpecificationItem() : firstActiveSpecificationItem() ) );
		}

	SpecificationItem *firstAssignmentOrSpecificationItem( bool isDeactive, bool isArchived )
		{
		return ( isAssignmentList() ? firstAssignmentItem( isDeactive, isArchived ) : firstActiveSpecificationItem() );
		}

	SpecificationItem *firstAssignmentOrSpecificationItem( bool isIncludingAnsweredQuestions, bool isDeactive, bool isArchived, bool isQuestion )
		{
		return ( isAssignmentList() ? firstAssignmentItem( isIncludingAnsweredQuestions, isDeactive, isArchived, isQuestion ) : firstActiveSpecificationItem( isIncludingAnsweredQuestions, isQuestion ) );
		}

	SpecificationItem *firstAssignmentOrSpecificationItem( bool isIncludingAnsweredQuestions, bool isDeactive, bool isArchived, unsigned short questionParameter )
		{
		return ( isAssignmentList() ? firstAssignmentItem( isIncludingAnsweredQuestions, isDeactive, isArchived, questionParameter ) : firstActiveSpecificationItem( isIncludingAnsweredQuestions, questionParameter ) );
		}

	SpecificationItem *_firstSpecificationItem( bool isAllowingDifferentLanguage, bool isAllowingEmptyContextResult, bool isIncludingAnsweredQuestions, bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem )
		{
		SpecificationItem *foundSpecificationItem = NULL;
		SpecificationItem *searchItem = firstAssignmentOrSpecificationItem( isIncludingAnsweredQuestions, isDeactive, isArchived, questionParameter );

		while( searchItem != NULL )
			{
			if( searchItem->isNegative() == isNegative &&
			searchItem->isPossessive() == isPossessive &&

			( searchItem->specificationWordItem() == specificationWordItem ||

			( !searchItem->isSpecificationGeneralization() &&
			specificationCollectionNr > NO_COLLECTION_NR &&
			searchItem->specificationCollectionNr() == specificationCollectionNr ) ) &&

			( isAllowingDifferentLanguage ||
			searchItem->grammarLanguageNr() == commonVariables()->currentGrammarLanguageNr ) &&

			searchItem->isMatchingGeneralizationContextNr( isAllowingEmptyContextResult, generalizationContextNr ) &&
			searchItem->isMatchingSpecificationContextNr( isAllowingEmptyContextResult, specificationContextNr ) &&
			searchItem->isMatchingRelationContextNr( isAllowingEmptyContextResult, relationContextNr ) )
				return searchItem;

			searchItem = searchItem->nextSpecificationItemWithSameQuestionParameter( isIncludingAnsweredQuestions );
			}

		return foundSpecificationItem;
		}

	SpecificationItem *_firstUserSpecificationItem( bool isIncludingAnsweredQuestions, bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationItem *searchItem = firstAssignmentOrSpecificationItem( isIncludingAnsweredQuestions, isDeactive, isArchived, questionParameter );

		while( searchItem != NULL )
			{
			if( searchItem->isUserSpecification() &&
			searchItem->isNegative() == isNegative &&
			searchItem->isPossessive() == isPossessive &&
			searchItem->specificationWordItem() == specificationWordItem &&
			searchItem->isMatchingGeneralizationContextNr( true, generalizationContextNr ) &&
			searchItem->isMatchingSpecificationContextNr( true, specificationContextNr ) &&
			searchItem->isMatchingRelationContextNr( true, relationContextNr ) &&

			( specificationString == NULL ||
			searchItem->specificationString() == NULL ||
			strcmp( searchItem->specificationString(), specificationString ) == 0 ) )
				return searchItem;

			searchItem = searchItem->nextSpecificationItemWithSameQuestionParameter( isIncludingAnsweredQuestions );
			}

		return NULL;
		}

	SpecificationItem *_firstSpecificationItem( bool isAllowingEmptyContextResult, bool isIncludingAnsweredQuestions, bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationItem *searchItem = firstAssignmentOrSpecificationItem( isIncludingAnsweredQuestions, isDeactive, isArchived, questionParameter );

		while( searchItem != NULL )
			{
			if( searchItem->isNegative() == isNegative &&
			searchItem->isPossessive() == isPossessive &&
			searchItem->specificationWordItem() == specificationWordItem &&
			searchItem->isMatchingGeneralizationContextNr( isAllowingEmptyContextResult, generalizationContextNr ) &&
			searchItem->isMatchingSpecificationContextNr( isAllowingEmptyContextResult, specificationContextNr ) &&
			searchItem->isMatchingRelationContextNr( isAllowingEmptyContextResult, relationContextNr ) &&

			( specificationString == NULL ||
			searchItem->specificationString() == NULL ||
			strcmp( searchItem->specificationString(), specificationString ) == 0 ) )
				return searchItem;

			searchItem = searchItem->nextSpecificationItemWithSameQuestionParameter( isIncludingAnsweredQuestions );
			}

		return NULL;
		}

	SpecificationItem *_firstSpecificationItem( bool isAllowingEmptyContextResult, bool isIncludingAnsweredQuestions, bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationItem *searchItem = firstAssignmentOrSpecificationItem( isIncludingAnsweredQuestions, isDeactive, isArchived, questionParameter );

		while( searchItem != NULL )
			{
			if( searchItem->isNegative() == isNegative &&
			searchItem->isPossessive() == isPossessive &&
			searchItem->specificationCollectionNr() == specificationCollectionNr &&
			searchItem->specificationWordItem() == specificationWordItem &&
			searchItem->isMatchingGeneralizationContextNr( isAllowingEmptyContextResult, generalizationContextNr ) &&
			searchItem->isMatchingSpecificationContextNr( isAllowingEmptyContextResult, specificationContextNr ) &&
			searchItem->isMatchingRelationContextNr( isAllowingEmptyContextResult, relationContextNr ) &&

			( specificationString == NULL ||
			searchItem->specificationString() == NULL ||
			strcmp( searchItem->specificationString(), specificationString ) == 0 ) )
				return searchItem;

			searchItem = searchItem->nextSpecificationItemWithSameQuestionParameter( isIncludingAnsweredQuestions );
			}

		return NULL;
		}

	SpecificationItem *_firstSpecificationItem( bool isAllowingDifferentLanguage, bool isAllowingEmptyContextResult, bool isIncludingAnsweredQuestions, bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, bool isSelfGenerated, unsigned short questionParameter, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationItem *searchItem = firstAssignmentOrSpecificationItem( isIncludingAnsweredQuestions, isDeactive, isArchived, questionParameter );

		while( searchItem != NULL )
			{
			if( searchItem->isNegative() == isNegative &&
			searchItem->isPossessive() == isPossessive &&
			searchItem->isSelfGenerated() == isSelfGenerated &&
			searchItem->specificationWordItem() == specificationWordItem &&

			( isAllowingDifferentLanguage ||
			searchItem->grammarLanguageNr() == commonVariables()->currentGrammarLanguageNr ) &&

			searchItem->isMatchingGeneralizationContextNr( isAllowingEmptyContextResult, generalizationContextNr ) &&
			searchItem->isMatchingSpecificationContextNr( isAllowingEmptyContextResult, specificationContextNr ) &&
			searchItem->isMatchingRelationContextNr( isAllowingEmptyContextResult, relationContextNr ) &&

			( searchItem->specificationCollectionNr() == specificationCollectionNr ||

			// Also check for compound collection to avoid duplicates
			( specificationWordItem != NULL &&
			specificationWordItem->isCompoundCollection( specificationCollectionNr ) ) ) &&

			( specificationString == NULL ||
			searchItem->specificationString() == NULL ||
			strcmp( searchItem->specificationString(), specificationString ) == 0 ) )
				return searchItem;

			searchItem = searchItem->nextSpecificationItemWithSameQuestionParameter( isIncludingAnsweredQuestions );
			}

		return NULL;
		}

	SpecificationItem *_firstAssumptionSpecificationItem( bool isAllowingEmptyContextResult, bool isIncludingAnsweredQuestions, bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, WordItem *specificationWordItem )
		{
		SpecificationItem *searchItem = firstAssignmentOrSpecificationItem( isIncludingAnsweredQuestions, isDeactive, isArchived, questionParameter );

		while( searchItem != NULL )
			{
			if( searchItem->isSelfGeneratedAssumption() &&
			searchItem->hasRelationContext() &&
			searchItem->isNegative() == isNegative &&
			searchItem->isPossessive() == isPossessive &&
			searchItem->specificationWordItem() == specificationWordItem &&
			searchItem->isMatchingGeneralizationContextNr( isAllowingEmptyContextResult, generalizationContextNr ) &&
			searchItem->isMatchingSpecificationContextNr( isAllowingEmptyContextResult, specificationContextNr ) )
				return searchItem;

			searchItem = searchItem->nextSpecificationItemWithSameQuestionParameter( isIncludingAnsweredQuestions );
			}

		return NULL;
		}

	SpecificationItem *nextSpecificationListItem()
		{
		return (SpecificationItem *)nextListItem();
		}


	public:
	// Constructor

	SpecificationList( char _listChar, WordItem *myWord, CommonVariables *commonVariables )
		{
		initializeListVariables( _listChar, "SpecificationList", myWord, commonVariables );
		}

	// Deconstructor

	~SpecificationList()
		{
		deleteSpecificationList( firstActiveSpecificationItem() );
		deleteSpecificationList( firstDeactiveSpecificationItem() );
		deleteSpecificationList( firstArchivedSpecificationItem() );
		deleteSpecificationList( (SpecificationItem *)firstDeletedItem() );
		}


	// Protected assignment functions

	unsigned int numberOfActiveAssignments()
		{
		unsigned int nItems = 0;
		SpecificationItem *searchItem = firstAssignmentItem( false, false, false, false );

		while( searchItem != NULL )
			{
			nItems++;
			searchItem = searchItem->nextAssignmentItemButNotAQuestion();
			}

		return nItems;
		}

	ResultType createNewAssignmentLevel()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "createNewAssignmentLevel";
		if( commonVariables()->currentAssignmentLevel < MAX_LEVEL )
			{
			if( createNewAssignmentLevel( false, false ) == RESULT_OK )
				{
				if( createNewAssignmentLevel( true, false ) == RESULT_OK )
					{
					if( createNewAssignmentLevel( false, true ) != RESULT_OK )
						return addError( functionNameString, NULL, "I failed to create an archive assignment level" );
					}
				else
					return addError( functionNameString, NULL, "I failed to create a deactive assignment level" );
				}
			else
				return addError( functionNameString, NULL, "I failed to create an active assignment level" );
			}
		else
			return startSystemError( functionNameString, NULL, "Assignment level overflow" );

		return commonVariables()->result;
		}

	ResultType deleteAssignmentLevelInList()
		{
		SpecificationItem *searchItem = firstActiveSpecificationItem();
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteAssignmentLevelInList";

		if( commonVariables()->currentAssignmentLevel > NO_ASSIGNMENT_LEVEL )
			{
			while( searchItem != NULL &&
			searchItem->assignmentLevel() >= commonVariables()->currentAssignmentLevel )
				{
				if( searchItem->assignmentLevel() == commonVariables()->currentAssignmentLevel )
					{
					if( deleteActiveItem( false, searchItem ) == RESULT_OK )
//						{
//						commonVariables()->isAssignmentChanged = true;		// Don't indicate change on higher assignment level
						searchItem = nextSpecificationListItem();
//						}
					else
						return addError( functionNameString, NULL, "I failed to delete an active item" );
					}
				else
					searchItem = searchItem->nextSpecificationItem();
				}

			searchItem = firstDeactiveSpecificationItem();

			while( searchItem != NULL &&
			searchItem->assignmentLevel() >= commonVariables()->currentAssignmentLevel )
				{
				if( searchItem->assignmentLevel() == commonVariables()->currentAssignmentLevel )
					{
					if( deleteDeactiveItem( false, searchItem ) == RESULT_OK )
//						{
//						commonVariables()->isAssignmentChanged = true;		// Don't indicate change on higher assignment level
						searchItem = nextSpecificationListItem();
//						}
					else
						return addError( functionNameString, NULL, "I failed to delete a deactive item" );
					}
				else
					searchItem = searchItem->nextSpecificationItem();
				}

			searchItem = firstArchivedSpecificationItem();

			while( searchItem != NULL &&
			searchItem->assignmentLevel() >= commonVariables()->currentAssignmentLevel )
				{
				if( searchItem->assignmentLevel() == commonVariables()->currentAssignmentLevel )
					{
					if( deleteArchivedItem( false, searchItem ) == RESULT_OK )
//						{
//						commonVariables()->isAssignmentChanged = true;		// Don't indicate change on higher assignment level
						searchItem = nextSpecificationListItem();
//						}
					else
						return addError( functionNameString, NULL, "I failed to delete an archive item" );
					}
				else
					searchItem = searchItem->nextSpecificationItem();
				}
			}
		else
			return startError( functionNameString, NULL, "The current assignment level is undefined" );

		return commonVariables()->result;
		}

	SpecificationResultType findAssignmentItemByRelationContext( bool isIncludingAnsweredQuestions, bool isDeactive, bool isArchived, bool isPossessive, unsigned short questionParameter, WordItem *relationContextWordItem )
		{
		SpecificationResultType specificationResult;
		SpecificationItem *searchItem = firstAssignmentItem( isIncludingAnsweredQuestions, isDeactive, isArchived, questionParameter );
		char functionNameString[FUNCTION_NAME_LENGTH] = "findAssignmentItemByRelationContext";

		if( relationContextWordItem != NULL )
			{
			while( searchItem != NULL &&
			specificationResult.foundSpecificationItem == NULL )
				{
				if( searchItem->isPossessive() == isPossessive &&
				relationContextWordItem->hasContextInWord( isPossessive, searchItem->relationContextNr(), searchItem->specificationWordItem() ) )
					specificationResult.foundSpecificationItem = searchItem;
				else
					searchItem = searchItem->nextSpecificationItemWithSameQuestionParameter( isIncludingAnsweredQuestions );
				}
			}
		else
			startError( functionNameString, NULL, "The given relation context word is undefined" );

		specificationResult.result = commonVariables()->result;
		return specificationResult;
		}

	SpecificationResultType createAssignmentItem( bool isAnsweredQuestion, bool isConcludedAssumption, bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, bool isValueSpecification, unsigned short assignmentLevel, unsigned short assumptionLevel, unsigned short grammarLanguageNr, unsigned short prepositionParameter, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int originalSentenceNr, unsigned int activeSentenceNr, unsigned int deactiveSentenceNr, unsigned int archiveSentenceNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "createAssignmentItem";

		if( isAssignmentList() )
			{
			if( generalizationWordTypeNr > WORD_TYPE_UNDEFINED &&
			generalizationWordTypeNr < NUMBER_OF_WORD_TYPES )
				{
				if( specificationWordTypeNr > WORD_TYPE_UNDEFINED &&
				specificationWordTypeNr < NUMBER_OF_WORD_TYPES )
					{
					if( commonVariables()->currentItemNr < MAX_ITEM_NR )
						{
						if( specificationJustificationItem == NULL ||
						specificationJustificationItem->isActiveItem() ||

						( isArchived &&
						specificationJustificationItem->isArchivedItem() ) )
							{
							if( ( specificationResult.createdSpecificationItem = new SpecificationItem( isAnsweredQuestion, false, isConcludedAssumption, isExclusive, isNegative, isPossessive, false, isValueSpecification, assignmentLevel, assumptionLevel, grammarLanguageNr, prepositionParameter, questionParameter, generalizationWordTypeNr, specificationWordTypeNr, generalizationCollectionNr, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, originalSentenceNr, activeSentenceNr, deactiveSentenceNr, archiveSentenceNr, nContextRelations, specificationJustificationItem, specificationWordItem, specificationString, this, myWord(), commonVariables() ) ) != NULL )
								{
								if( isArchived )
									{
									specificationResult.createdSpecificationItem->setArchivedStatus();

									if( addItemToArchivedList( (Item *)specificationResult.createdSpecificationItem ) != RESULT_OK )
										addError( functionNameString, NULL, "I failed to add an archive assignment item" );
									}
								else
									{
									if( isDeactive )
										{
										specificationResult.createdSpecificationItem->setDeactiveStatus();

										if( addItemToDeactiveList( (Item *)specificationResult.createdSpecificationItem ) != RESULT_OK )
											addError( functionNameString, NULL, "I failed to add a deactive assignment item" );
										}
									else
										{
										if( addItemToActiveList( (Item *)specificationResult.createdSpecificationItem ) != RESULT_OK )
											addError( functionNameString, NULL, "I failed to add an active assignment item" );
										}
									}

								if( commonVariables()->result == RESULT_OK &&
								assignmentLevel == NO_ASSIGNMENT_LEVEL &&
								originalSentenceNr == commonVariables()->currentSentenceNr )
									commonVariables()->isAssignmentChanged = true;
								}
							else
								startError( functionNameString, NULL, "I failed to create an assignment item" );
							}
						else
							startError( functionNameString, NULL, "The given specification justification item isn't active" );
						}
					else
						startError( functionNameString, NULL, "The current item number is undefined" );
					}
				else
					startError( functionNameString, NULL, "The given specification word type number is undefined or out of bounds" );
				}
			else
				startError( functionNameString, NULL, "The given generalization word type number is undefined or out of bounds" );
			}
		else
			startError( functionNameString, NULL, "I am not an assignment list" );

		specificationResult.result = commonVariables()->result;
		return specificationResult;
		}

	SpecificationItem *firstNumeralAssignmentItem( bool isIncludingAnsweredQuestions, bool isDeactive, bool isArchived, bool isQuestion )
		{
		SpecificationItem *currentAssignmentItem = firstSpecificationItem( isDeactive, isArchived );

		if( currentAssignmentItem != NULL &&
		// This is the first assignment. Now get the first valid assignment.
		( currentAssignmentItem = currentAssignmentItem->getAssignmentItem( isIncludingAnsweredQuestions, true, isQuestion ) ) != NULL )
			{
			do	{
				if( currentAssignmentItem->isSpecificationNumeral() )
					return currentAssignmentItem;
				}
			while( ( currentAssignmentItem = currentAssignmentItem->getAssignmentItem( isIncludingAnsweredQuestions, false, isQuestion ) ) != NULL );
			}

		return NULL;
		}

	SpecificationItem *firstStringAssignmentItem( bool isIncludingAnsweredQuestions, bool isDeactive, bool isArchived, bool isQuestion )
		{
		SpecificationItem *currentAssignmentItem = firstSpecificationItem( isDeactive, isArchived );

		if( currentAssignmentItem != NULL &&
		// This is the first assignment. Now get the first valid assignment.
		( currentAssignmentItem = currentAssignmentItem->getAssignmentItem( isIncludingAnsweredQuestions, true, isQuestion ) ) != NULL )
			{
			do	{
				if( currentAssignmentItem->specificationString() != NULL )
					return currentAssignmentItem;
				}
			while( ( currentAssignmentItem = currentAssignmentItem->getAssignmentItem( isIncludingAnsweredQuestions, false, isQuestion ) ) != NULL );
			}

		return NULL;
		}

	SpecificationItem *firstAssignmentItem( bool isIncludingAnsweredQuestions, bool isDeactive, bool isArchived, bool isQuestion )
		{
		// This is the first assignment
		SpecificationItem *firstAssignmentItem = firstSpecificationItem( isDeactive, isArchived );

		// Now get the first valid assignment
		return ( firstAssignmentItem == NULL ? NULL : firstAssignmentItem->getAssignmentItem( isIncludingAnsweredQuestions, true, isQuestion ) );
		}

	SpecificationItem *lastAssignmentItem( bool isIncludingAnsweredQuestions, bool isDeactive, bool isArchived, bool isQuestion )
		{
		SpecificationItem *lastAssignmentItem = NULL;
		SpecificationItem *currentAssignmentItem = firstSpecificationItem( isDeactive, isArchived );

		if( currentAssignmentItem != NULL &&
		// This is the first assignment. Now get the first valid assignment.
		( currentAssignmentItem = currentAssignmentItem->getAssignmentItem( isIncludingAnsweredQuestions, true, isQuestion ) ) != NULL )
			{
			do	lastAssignmentItem = currentAssignmentItem;
			while( ( currentAssignmentItem = currentAssignmentItem->getAssignmentItem( isIncludingAnsweredQuestions, false, isQuestion ) ) != NULL );
			}

		return lastAssignmentItem;
		}

	SpecificationItem *firstAssignmentItem( bool isIncludingAnsweredQuestions, bool isDeactive, bool isArchived, unsigned short questionParameter )
		{
		SpecificationItem *firstAssignmentItem = firstSpecificationItem( isDeactive, isArchived );

		return ( firstAssignmentItem == NULL ? NULL : firstAssignmentItem->getAssignmentItem( isIncludingAnsweredQuestions, true, questionParameter ) );
		}

	SpecificationItem *firstAssignmentItem( bool isDifferentRelationContext, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationItem *foundAssignmentItem;

		if( ( foundAssignmentItem = firstAssignmentItem( false, false, isDifferentRelationContext, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString ) ) == NULL )
			{
			if( ( foundAssignmentItem = firstAssignmentItem( false, true, isDifferentRelationContext, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString ) ) == NULL )
				foundAssignmentItem = firstAssignmentItem( true, false, isDifferentRelationContext, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );
			}

		return foundAssignmentItem;
		}

	SpecificationItem *firstAssignmentItem( bool isDeactive, bool isArchived, bool isDifferentRelationContext, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationItem *searchItem = firstAssignmentItem( false, isDeactive, isArchived, questionParameter );

		while( searchItem != NULL )
			{
			if( searchItem->isPossessive() == isPossessive &&
			searchItem->specificationWordItem() == specificationWordItem &&
			searchItem->isMatchingGeneralizationContextNr( true, generalizationContextNr ) &&
			searchItem->isMatchingSpecificationContextNr( true, specificationContextNr ) &&

			( ( !isDifferentRelationContext &&
			searchItem->isMatchingRelationContextNr( true, relationContextNr ) ) ||

			( isDifferentRelationContext &&
			searchItem->hasRelationContext() &&
			searchItem->relationContextNr() != relationContextNr ) ) &&

			( specificationString == NULL ||
			searchItem->specificationString() == NULL ||
			strcmp( searchItem->specificationString(), specificationString ) == 0 ) )
				return searchItem;

			searchItem = searchItem->nextSpecificationItemWithSameQuestionParameter( false );
			}

		return NULL;
		}

	SpecificationItem *firstAssignmentItem( bool includeActiveItems, bool includeDeactiveItems, bool includeArchivedItems, bool isNegative, bool isPossessive, bool isSelfGenerated, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationItem *foundAssignmentItem = NULL;

		if( includeActiveItems )
			foundAssignmentItem = _firstAssignmentItem( false, false, isNegative, isPossessive, isSelfGenerated, questionParameter, generalizationContextNr, specificationContextNr, specificationWordItem, specificationString );

		if( includeDeactiveItems &&
		foundAssignmentItem == NULL )
			foundAssignmentItem = _firstAssignmentItem( true, false, isNegative, isPossessive, isSelfGenerated, questionParameter, generalizationContextNr, specificationContextNr, specificationWordItem, specificationString );

		if( includeArchivedItems &&
		foundAssignmentItem == NULL )
			return _firstAssignmentItem( false, true, isNegative, isPossessive, isSelfGenerated, questionParameter, generalizationContextNr, specificationContextNr, specificationWordItem, specificationString );

		return foundAssignmentItem;
		}

	SpecificationItem *firstAssignmentItem( bool includeActiveItems, bool includeDeactiveItems, bool includeArchivedItems, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationItem *foundAssignmentItem = NULL;

		if( includeActiveItems )
			foundAssignmentItem = _firstAssignmentItem( false, false, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

		if( includeDeactiveItems &&
		foundAssignmentItem == NULL )
			foundAssignmentItem = _firstAssignmentItem( true, false, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

		if( includeArchivedItems &&
		foundAssignmentItem == NULL )
			return _firstAssignmentItem( false, true, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

		return foundAssignmentItem;
		}

	SpecificationItem *firstAssignmentItem( bool includeActiveItems, bool includeDeactiveItems, bool includeArchivedItems, bool isNegative, bool isPossessive, bool isSelfGenerated, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationItem *foundAssignmentItem = NULL;

		if( includeActiveItems )
			foundAssignmentItem = _firstAssignmentItem( false, false, isNegative, isPossessive, isSelfGenerated, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

		if( includeDeactiveItems &&
		foundAssignmentItem == NULL )
			foundAssignmentItem = _firstAssignmentItem( true, false, isNegative, isPossessive, isSelfGenerated, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

		if( includeArchivedItems &&
		foundAssignmentItem == NULL )
			return _firstAssignmentItem( false, true, isNegative, isPossessive, isSelfGenerated, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

		return foundAssignmentItem;
		}


	// Protected specification functions

	void clearLastCheckedAssumptionLevelItemNr( bool isDeactive, bool isArchived )
		{
		SpecificationItem *searchItem = firstSpecificationItem( isDeactive, isArchived );

		while( searchItem != NULL )
			{
			searchItem->clearLastCheckedAssumptionLevelItemNr();
			searchItem = searchItem->nextSpecificationItem();
			}
		}

	bool hasPossessiveSpecificationItemButNotAQuestion()
		{
		SpecificationItem *searchItem = firstActiveSpecificationItem( false, false );

		while( searchItem != NULL )
			{
			if( searchItem->isPossessive() )
				return true;

			searchItem = searchItem->nextSpecificationItemWithSameQuestionParameter( false );
			}

		return false;
		}

	ResultType archiveOrDeletedSpecificationItem( SpecificationItem *oldSpecificationItem, SpecificationItem *replacingSpecificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "archiveOrDeletedSpecificationItem";
		if( oldSpecificationItem != NULL )
			{
			if( oldSpecificationItem->hasCurrentArchivedSentenceNr() )
				oldSpecificationItem->replacingSpecificationItem = replacingSpecificationItem;
			else
				{
				if( !oldSpecificationItem->isArchivedItem() ||
				oldSpecificationItem->replacingSpecificationItem == NULL )
					{
					if( replacingSpecificationItem == NULL ||
					replacingSpecificationItem->replacingSpecificationItem == NULL )
						{
						if( oldSpecificationItem != replacingSpecificationItem )
							{
							if( oldSpecificationItem->isAssignment() == isAssignmentList() )
								{
								if( replacingSpecificationItem == NULL ||
								replacingSpecificationItem->isAssignment() == isAssignmentList() )
									{
									oldSpecificationItem->replacingSpecificationItem = replacingSpecificationItem;

									// Update the specification items that are filtered by getAssignmentItem
									// variables: replacingSpecificationItem
									if( updateArchivedReplacingSpecificationItems( oldSpecificationItem ) == RESULT_OK )
										{
										if( oldSpecificationItem->hasCurrentCreationSentenceNr() )
											{
											if( oldSpecificationItem->isActiveItem() )
												{
												if( deleteActiveItem( false, oldSpecificationItem ) != RESULT_OK )
													return addError( functionNameString, NULL, "I failed to delete an active assignment item" );
												}
											else
												{
												if( oldSpecificationItem->isDeactiveItem() )
													{
													if( deleteDeactiveItem( false, oldSpecificationItem ) != RESULT_OK )
														return addError( functionNameString, NULL, "I failed to delete a deactive assignment item" );
													}
												}
											}
										else
											{
											if( oldSpecificationItem->isActiveItem() )
												{
												if( archiveActiveItem( oldSpecificationItem ) != RESULT_OK )
													return addError( functionNameString, NULL, "I failed to archive an active specification item" );
												}
											else
												{
												if( oldSpecificationItem->isDeactiveItem() )
													{
													if( archiveDeactiveItem( oldSpecificationItem ) != RESULT_OK )
														return addError( functionNameString, NULL, "I failed to archive a deactive specification item" );
													}
												}
											}

										if( myWord()->updateSpecificationsInJustificationOfInvolvedWords( oldSpecificationItem, replacingSpecificationItem ) != RESULT_OK )
											return addError( functionNameString, NULL, "I failed to update the specifications in the justification of involved words" );
										}
									else
										return addError( functionNameString, NULL, "I failed to update the replacing specification item of the archive specification items" );
									}
								else
									return startError( functionNameString, NULL, "The given replacing specification item is an assignment item and I am a specification list, or the given replacing specification item is a specification item and I am an assignment list" );
								}
							else
								return startError( functionNameString, NULL, "The given old specification item is an assignment item and I am a specification list, or the given old specification item is a specification item and I am an assignment list" );
							}
						else
							return startError( functionNameString, NULL, "The given old specification item and the given replacing specification item are the same" );
						}
					else
						return startError( functionNameString, NULL, "The given replacing specification item has a replacing specification item itself" );
					}
				else
					return startError( functionNameString, NULL, "The given old specification item is already archived and has already a replacing specification item" );
				}
			}
		else
			return startError( functionNameString, NULL, "The given old specification item is undefined" );

		return commonVariables()->result;
		}

	ResultType collectGeneralizationAndSpecifications( bool isDeactive, bool isArchived, bool isExclusiveGeneralization, bool isGeneralizationCollection, bool isQuestion, unsigned int collectionNr )
		{
		bool isCollectGeneralization;
		bool isCollectSpecification;
		SpecificationItem *searchItem = firstAssignmentOrSpecificationItem( false, isDeactive, isArchived, isQuestion );
		WordItem *specificationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "collectGeneralizationAndSpecifications";

		if( collectionNr > NO_COLLECTION_NR )
			{
			while( searchItem != NULL )
				{
				if( ( specificationWordItem = searchItem->specificationWordItem() ) == NULL )
					specificationWordItem = myWord();	// Specification string

				isCollectGeneralization = ( isGeneralizationCollection &&
										!searchItem->hasGeneralizationCollection() &&
										myWord()->hasCollectionNr( collectionNr ) );

				isCollectSpecification = ( !isGeneralizationCollection &&
										!searchItem->hasSpecificationCollection() &&
										specificationWordItem->hasCollectionNr( collectionNr ) );

				if( isCollectGeneralization ||
				isCollectSpecification )
					{
					if( searchItem->hasCurrentCreationSentenceNr() )
						{
						if( searchItem->collectSpecificationItem( isCollectGeneralization, isCollectSpecification, isExclusiveGeneralization, collectionNr ) == RESULT_OK )
							searchItem = searchItem->nextSelectedSpecificationItem( false );
						else
							return addError( functionNameString, NULL, "I failed to collect a specification" );
						}
					else
						{
						if( changeOlderSpecificationItem( isExclusiveGeneralization, ( isCollectGeneralization ? collectionNr : NO_COLLECTION_NR ), ( isCollectSpecification ? collectionNr : NO_COLLECTION_NR ), searchItem ) == RESULT_OK )
							searchItem = firstAssignmentOrSpecificationItem( false, isDeactive, isArchived, isQuestion );
						else
							return addError( functionNameString, NULL, "I failed to collect an older specification" );
						}
					}
				else
					searchItem = searchItem->nextSelectedSpecificationItem( false );
				}
			}
		else
			return startError( functionNameString, NULL, "The given collection number is undefined" );

		return commonVariables()->result;
		}

	ResultType checkJustificationItemForUsage( bool isDeactive, bool isArchived, JustificationItem *unusedJustificationItem )
		{
		SpecificationItem *searchItem = firstSpecificationItem( isDeactive, isArchived );
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkJustificationItemForUsage";

		if( unusedJustificationItem != NULL )
			{
			while( searchItem != NULL )
				{
				if( searchItem->specificationJustificationItem() == unusedJustificationItem )
					return startError( functionNameString, NULL, "The specification justification item is still in use" );

				searchItem = searchItem->nextSpecificationItem();
				}
			}
		else
			return startError( functionNameString, NULL, "The given unused justification item is undefined" );

		return commonVariables()->result;
		}

	ResultType checkSpecificationItemForUsage( bool isDeactive, bool isArchived, SpecificationItem *unusedSpecificationItem )
		{
		SpecificationItem *searchItem = firstSpecificationItem( isDeactive, isArchived );
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkSpecificationItemForUsage";

		if( unusedSpecificationItem != NULL )
			{
			while( searchItem != NULL )
				{
				if( searchItem->replacingSpecificationItem == unusedSpecificationItem )
					{
					if( searchItem->creationSentenceNr() < unusedSpecificationItem->creationSentenceNr() ||
					searchItem->creationSentenceNr() < commonVariables()->myFirstSentenceNr )
						searchItem->replacingSpecificationItem = NULL;
					else
						return startError( functionNameString, NULL, "The replacing specification item is still in use" );
					}

				searchItem = searchItem->nextSpecificationItem();
				}
			}
		else
			return startError( functionNameString, NULL, "The given unused specification item is undefined" );

		return commonVariables()->result;
		}

	ResultType checkWordItemForUsage( bool isDeactive, bool isArchived, WordItem *unusedWordItem )
		{
		SpecificationItem *searchItem = firstSpecificationItem( isDeactive, isArchived );
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkWordItemForUsage";

		if( unusedWordItem != NULL )
			{
			while( searchItem != NULL )
				{
				if( searchItem->specificationWordItem() == unusedWordItem )
					return startError( functionNameString, NULL, "The specification word item is still in use" );

				searchItem = searchItem->nextSpecificationItem();
				}
			}
		else
			return startError( functionNameString, NULL, "The given unused word item is undefined" );

		return commonVariables()->result;
		}

	ResultType confirmSpecificationButNotRelation( bool isDeactive, bool isArchived, SpecificationItem *confirmedSpecificationItem, SpecificationItem *confirmationSpecificationItem )
		{
		JustificationResultType justificationResult;
		JustificationItem *replacingJustificationItem;
		JustificationItem *foundDefinitionSpecificationJustificationItem;
		SpecificationItem *searchItem = firstAssignmentOrSpecificationItem( isDeactive, isArchived );
		char functionNameString[FUNCTION_NAME_LENGTH] = "confirmSpecificationButNotRelation";

		if( confirmedSpecificationItem != NULL )
			{
			if( confirmedSpecificationItem->isSelfGenerated() )
				{
				if( confirmationSpecificationItem != NULL )
					{
					if( confirmationSpecificationItem->isUserSpecification() )
						{
						while( searchItem != NULL )
							{
							if( !searchItem->hasRelationContext() &&
							( foundDefinitionSpecificationJustificationItem = searchItem->foundDefinitionSpecificationJustificationItem( confirmedSpecificationItem ) ) != NULL )
								{
								if( ( justificationResult = myWord()->addJustification( false, foundDefinitionSpecificationJustificationItem->justificationTypeNr(), foundDefinitionSpecificationJustificationItem->orderNr, foundDefinitionSpecificationJustificationItem->originalSentenceNr(), foundDefinitionSpecificationJustificationItem->attachedJustificationItem(), confirmationSpecificationItem, foundDefinitionSpecificationJustificationItem->anotherDefinitionSpecificationItem(), foundDefinitionSpecificationJustificationItem->specificSpecificationItem() ) ).result == RESULT_OK )
									{
									if( ( replacingJustificationItem = justificationResult.createdJustificationItem ) != NULL )
										{
										if( myWord()->archiveJustification( searchItem->hasExclusiveGeneralizationCollection(), foundDefinitionSpecificationJustificationItem, replacingJustificationItem ) == RESULT_OK )
											searchItem = firstAssignmentOrSpecificationItem( isDeactive, isArchived );
										else
											return addError( functionNameString, NULL, "I failed to archive the attached justification item before the archived justification item in my word" );
										}
									else
										return startError( functionNameString, NULL, "I couldn't create a replacing specification justification" );
									}
								else
									return addError( functionNameString, NULL, "I failed to add a justification" );
								}
							else
								searchItem = searchItem->nextAssignmentOrSpecificationItem();
							}
						}
					else
						return startError( functionNameString, NULL, "The given confirmation specification item isn't a user specification" );
					}
				else
					return startError( functionNameString, NULL, "The given confirmation specification item is undefined" );
				}
			else
				return startError( functionNameString, NULL, "The given confirmed specification but not its relation(s) specification item isn't self-generated" );
			}
		else
			return startError( functionNameString, NULL, "The given confirmed specification but not its relation(s) specification item is undefined" );

		return commonVariables()->result;
		}

	ResultType recalculateAssumptions( bool isDeactive, bool isArchived )
		{
		SpecificationResultType specificationResult;
		unsigned short previousAssumptionLevel;
		SpecificationItem *searchItem = firstAssignmentOrSpecificationItem( isDeactive, isArchived );
		char functionNameString[FUNCTION_NAME_LENGTH] = "recalculateAssumptions";

		while( searchItem != NULL )
			{
			if( searchItem->isOlderSentence() &&
			searchItem->isSelfGeneratedAssumption() )
				{
				if( ( specificationResult = searchItem->getAssumptionLevel() ).result == RESULT_OK )
					{
					previousAssumptionLevel = specificationResult.assumptionLevel;

					if( searchItem->hasOnlyExclusiveSpecificationSubstitutionAssumptionsWithoutDefinition() )
						searchItem->markAsConcludedAssumption();

					if( ( specificationResult = searchItem->recalculateAssumptionLevel() ).result == RESULT_OK )
						{
						if( specificationResult.assumptionLevel == NO_ASSUMPTION_LEVEL )
							searchItem->markAsConcludedAssumption();
						else
							{
							if( specificationResult.assumptionLevel != previousAssumptionLevel )
								{
								// Write adjusted specification
								if( myWord()->writeSpecification( true, false, false, searchItem ) != RESULT_OK )
									return addError( functionNameString, NULL, "I failed to write an adjusted specification" );
								}
							}
						}
					else
						return addError( functionNameString, NULL, "I failed to recalculate the assumption level" );
					}
				else
					return addError( functionNameString, NULL, "I failed to get the assumption level" );
				}

			searchItem = searchItem->nextAssignmentOrSpecificationItem();
			}

		return commonVariables()->result;
		}

	ResultType replaceOlderSpecificationItems( unsigned int oldRelationContextNr, SpecificationItem *replacingSpecificationItem )
		{
		JustificationResultType justificationResult;
		JustificationItem *specificationJustificationItem;
		SpecificationItem *searchItem = firstActiveSpecificationItem();
		char functionNameString[FUNCTION_NAME_LENGTH] = "replaceOlderSpecificationItems";

		if( replacingSpecificationItem != NULL )
			{
			while( searchItem != NULL )
				{
				if( searchItem->isOlderSentence() &&
				searchItem->relationContextNr() == oldRelationContextNr &&
				( specificationJustificationItem = searchItem->specificationJustificationItem() ) != NULL )
					{
					replacingSpecificationItem->markAsConcludedAssumption();

					if( archiveOrDeletedSpecificationItem( searchItem, replacingSpecificationItem ) == RESULT_OK )
						{
						if( !specificationJustificationItem->hasCurrentActiveSentenceNr() )
							{
							if( ( justificationResult = myWord()->addJustification( true, specificationJustificationItem->justificationTypeNr(), specificationJustificationItem->orderNr, specificationJustificationItem->originalSentenceNr(), specificationJustificationItem->attachedJustificationItem(), specificationJustificationItem->definitionSpecificationItem(), specificationJustificationItem->anotherDefinitionSpecificationItem(), specificationJustificationItem->specificSpecificationItem() ) ).result == RESULT_OK )
								{
								if( justificationResult.createdJustificationItem != NULL )
									{
									if( myWord()->archiveJustification( false, specificationJustificationItem, justificationResult.createdJustificationItem ) == RESULT_OK )
										specificationJustificationItem = justificationResult.createdJustificationItem;
									else
										return addError( functionNameString, NULL, "I failed to archive a justification item" );
									}
								else
									return startError( functionNameString, NULL, "I couldn't create a justification item" );
								}
							else
								return addError( functionNameString, NULL, "I failed to add a justification item" );
							}

						if( myWord()->attachJustification( specificationJustificationItem, replacingSpecificationItem ) == RESULT_OK )
							searchItem = nextSpecificationListItem();
						else
							return addError( functionNameString, NULL, "I failed to attach a justification item" );
						}
					else
						return addError( functionNameString, NULL, "I failed to archive or delete a specification" );
					}
				else
					searchItem = searchItem->nextSpecificationItem();
				}
			}
		else
			return startError( functionNameString, NULL, "The given replacing specification item is undefined" );

		return commonVariables()->result;
		}

	ResultType updateJustificationInSpecificationItems( bool isExclusive, bool isExclusiveGeneralization, bool isDeactive, bool isArchived, JustificationItem *oldJustificationItem, JustificationItem *replacingJustificationItem )
		{
		JustificationResultType justificationResult;
		SpecificationResultType specificationResult;
		unsigned int archiveSentenceNr;
		JustificationItem *predecessorOfOldAttachedJustificationItem;
		JustificationItem *replacingAttachedJustificationItem;
		JustificationItem *specificationJustificationItem;
		SpecificationItem *replacingSpecificationItem;
		SpecificationItem *searchItem = firstSpecificationItem( isDeactive, isArchived );
		char functionNameString[FUNCTION_NAME_LENGTH] = "updateJustificationInSpecificationItems";

		if( oldJustificationItem != NULL )
			{
			while( searchItem != NULL )
				{
				if( ( searchItem->hasCurrentArchivedSentenceNr() ||
				searchItem->replacingSpecificationItem == NULL ) &&

				( specificationJustificationItem = searchItem->specificationJustificationItem() ) != NULL )
					{
					if( specificationJustificationItem == oldJustificationItem )
						{
						if( searchItem->hasCurrentCreationSentenceNr() )	// Allowed to change without archiving this one and creating a new one
							{
							if( searchItem->changeJustificationItem( replacingJustificationItem ) == RESULT_OK )
								searchItem = searchItem->nextSpecificationItem();
							else
								return addError( functionNameString, NULL, "I failed to change to specification justification item of a specification item" );
							}
						else
							{
							replacingSpecificationItem = NULL;

							if( replacingJustificationItem == NULL )
								{
								if( myWord()->isCorrectedAssumption() )
									{
									// Write corrected specification
									if( myWord()->writeSpecification( false, myWord()->isCorrectedAssumptionByKnowledge(), myWord()->isCorrectedAssumptionByOppositeQuestion(), searchItem ) != RESULT_OK )
										return addError( functionNameString, NULL, "I failed to write an adjusted specification" );
									}
								}
							else
								{
								if( isAssignmentList() )
									{
									if( ( specificationResult = createAssignmentItem( searchItem->isAnsweredQuestion(), searchItem->isConcludedAssumption(), searchItem->isDeactiveItem(), isArchived, ( isExclusive || isExclusiveGeneralization || searchItem->isExclusive() ), searchItem->isNegative(), searchItem->isPossessive(), searchItem->isValueSpecification(), searchItem->assignmentLevel(), searchItem->assumptionLevel(), searchItem->grammarLanguageNr(), searchItem->prepositionParameter(), searchItem->questionParameter(), searchItem->generalizationWordTypeNr(), searchItem->specificationWordTypeNr(), searchItem->generalizationCollectionNr(), searchItem->specificationCollectionNr(), searchItem->generalizationContextNr(), searchItem->specificationContextNr(), searchItem->relationContextNr(), searchItem->originalSentenceNr(), searchItem->activeSentenceNr(), searchItem->deactiveSentenceNr(), searchItem->archiveSentenceNr(), searchItem->nContextRelations(), replacingJustificationItem, searchItem->specificationWordItem(), searchItem->specificationString() ) ).result == RESULT_OK )
										{
										if( ( replacingSpecificationItem = specificationResult.createdSpecificationItem ) == NULL )
											return startError( functionNameString, NULL, "I couldn't create an assignment" );
										}
									else
										return addError( functionNameString, NULL, "I failed to create an assignment" );
									}
								else
									{
									if( ( specificationResult = createSpecificationItem( searchItem->isAnsweredQuestion(), searchItem->isConditional(), searchItem->isConcludedAssumption(), searchItem->isDeactiveItem(), isArchived, ( isExclusive || isExclusiveGeneralization || searchItem->isExclusive() ), searchItem->isNegative(), searchItem->isPossessive(), searchItem->isSpecificationGeneralization(), searchItem->isValueSpecification(), searchItem->assumptionLevel(), searchItem->grammarLanguageNr(), searchItem->prepositionParameter(), searchItem->questionParameter(), searchItem->generalizationWordTypeNr(), searchItem->specificationWordTypeNr(), searchItem->generalizationCollectionNr(), searchItem->specificationCollectionNr(), searchItem->generalizationContextNr(), searchItem->specificationContextNr(), ( isExclusiveGeneralization ? NO_CONTEXT_NR : searchItem->relationContextNr() ), searchItem->originalSentenceNr(), searchItem->nContextRelations(), replacingJustificationItem, searchItem->specificationWordItem(), searchItem->specificationString() ) ).result == RESULT_OK )
										{
										if( ( replacingSpecificationItem = specificationResult.createdSpecificationItem ) == NULL )
											return startError( functionNameString, NULL, "I couldn't create a specification" );
										}
									else
										return addError( functionNameString, NULL, "I failed to create a specification" );
									}
								}

							archiveSentenceNr = searchItem->archiveSentenceNr();	// Remember the archive sentence number

							if( archiveOrDeletedSpecificationItem( searchItem, replacingSpecificationItem ) == RESULT_OK )
								{
								if( !isAssignmentList() &&
								isExclusiveGeneralization )
									{
									if( myWord()->assignSpecificationInWord( false, false, true, false, searchItem->isNegative(), searchItem->isPossessive(), searchItem->isSelfGenerated(), searchItem->prepositionParameter(), searchItem->questionParameter(), searchItem->generalizationContextNr(), searchItem->specificationContextNr(), searchItem->relationContextNr(), searchItem->originalSentenceNr(), searchItem->activeSentenceNr(), searchItem->deactiveSentenceNr(), archiveSentenceNr, searchItem->nContextRelations(), replacingJustificationItem, searchItem->specificationWordItem(), NULL, searchItem->specificationString() ).result != RESULT_OK )
										return addError( functionNameString, NULL, "I failed to create an assignment" );
									}

								if( commonVariables()->isSpecificationConfirmedByUser &&
								replacingSpecificationItem != NULL &&
								replacingSpecificationItem->isSelfGeneratedAssumption() )
									{
									if( myWord()->recalculateAssumptionsInWord() != RESULT_OK )
										return addError( functionNameString, NULL, "I failed to recalculate the assumptions in my word" );
									}

								searchItem = ( isArchived ? searchItem->nextSpecificationItem() : firstSpecificationItem( isDeactive, isArchived ) );
								}
							else
								return addError( functionNameString, NULL, "I failed to archive or delete a specification" );
							}
						}
					else	// Check attached justification items
						{
						if( ( predecessorOfOldAttachedJustificationItem = specificationJustificationItem->predecessorOfOldAttachedJustificationItem( oldJustificationItem ) ) != NULL )
							{
							if( predecessorOfOldAttachedJustificationItem->hasCurrentCreationSentenceNr() )
								{
								if( predecessorOfOldAttachedJustificationItem->changeAttachedJustificationItem( replacingJustificationItem ) == RESULT_OK )
									searchItem = searchItem->nextSpecificationItem();
								else
									return addError( functionNameString, NULL, "I failed to change the attached justification item of a justification item" );
								}
							else
								{
								if( ( justificationResult = myWord()->addJustification( false, predecessorOfOldAttachedJustificationItem->justificationTypeNr(), predecessorOfOldAttachedJustificationItem->orderNr, predecessorOfOldAttachedJustificationItem->originalSentenceNr(), replacingJustificationItem, predecessorOfOldAttachedJustificationItem->definitionSpecificationItem(), predecessorOfOldAttachedJustificationItem->anotherDefinitionSpecificationItem(), predecessorOfOldAttachedJustificationItem->specificSpecificationItem() ) ).result == RESULT_OK )
									{
									if( ( replacingAttachedJustificationItem = justificationResult.createdJustificationItem ) != NULL )
										{
										if( myWord()->archiveJustification( isExclusiveGeneralization, predecessorOfOldAttachedJustificationItem, replacingAttachedJustificationItem ) == RESULT_OK )
											searchItem = firstSpecificationItem( isDeactive, isArchived );
										else
											return addError( functionNameString, NULL, "I failed to archive the attached justification item before the archived justification item in my word" );
										}
									else
										searchItem = searchItem->nextSpecificationItem();
									}
								else
									return addError( functionNameString, NULL, "I failed to add a replacing attached justification item" );
								}
							}
						else
							searchItem = searchItem->nextSpecificationItem();
						}
					}
				else
					searchItem = searchItem->nextSpecificationItem();
				}
			}
		else
			return startError( functionNameString, NULL, "The given old justification item is undefined" );

		return commonVariables()->result;
		}

	SpecificationResultType findSpecificationItem( bool includeDeactiveItems, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, WordItem *specificationWordItem, WordItem *relationContextWordItem )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findSpecificationItem";

		if( ( specificationResult = _findSpecificationItem( false, false, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, specificationWordItem, relationContextWordItem ) ).result == RESULT_OK )
			{
			if( includeDeactiveItems &&
			specificationResult.foundSpecificationItem == NULL )
				{
				if( ( specificationResult = _findSpecificationItem( true, false, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, specificationWordItem, relationContextWordItem ) ).result != RESULT_OK )
					addError( functionNameString, NULL, "I failed to find a deactive specification item with relation" );
				}
			}
		else
			addError( functionNameString, NULL, "I failed to find an active specification item with relation" );

		specificationResult.result = commonVariables()->result;
		return specificationResult;
		}

	SpecificationResultType createSpecificationItem( bool isAnsweredQuestion, bool isConditional, bool isConcludedAssumption, bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, bool isSpecificationGeneralization, bool isValueSpecification, unsigned short assumptionLevel, unsigned short grammarLanguageNr, unsigned short prepositionParameter, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int originalSentenceNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "createSpecificationItem";

		if( !isAssignmentList() )
			{
			if( generalizationWordTypeNr >= WORD_TYPE_UNDEFINED &&
			generalizationWordTypeNr < NUMBER_OF_WORD_TYPES )
				{
				if( specificationWordTypeNr > WORD_TYPE_UNDEFINED &&
				specificationWordTypeNr < NUMBER_OF_WORD_TYPES )
					{
					if( commonVariables()->currentItemNr < MAX_ITEM_NR )
						{
						if( specificationJustificationItem == NULL ||
						specificationJustificationItem->isActiveItem() ||

						( isArchived &&
						specificationJustificationItem->isArchivedItem() ) )
							{
							if( ( specificationResult.createdSpecificationItem = new SpecificationItem( isAnsweredQuestion, isConditional, isConcludedAssumption, isExclusive, isNegative, isPossessive, isSpecificationGeneralization, isValueSpecification, NO_ASSIGNMENT_LEVEL, assumptionLevel, grammarLanguageNr, prepositionParameter, questionParameter, generalizationWordTypeNr, specificationWordTypeNr, generalizationCollectionNr, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, originalSentenceNr, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, nContextRelations, specificationJustificationItem, specificationWordItem, specificationString, this, myWord(), commonVariables() ) ) != NULL )
								{
								if( isArchived )
									{
									specificationResult.createdSpecificationItem->setArchivedStatus();

									if( addItemToArchivedList( (Item *)specificationResult.createdSpecificationItem ) != RESULT_OK )
										addError( functionNameString, NULL, "I failed to add an archive specification item" );
									}
								else
									{
									if( isDeactive )
										{
										specificationResult.createdSpecificationItem->setDeactiveStatus();

										if( addItemToDeactiveList( (Item *)specificationResult.createdSpecificationItem ) != RESULT_OK )
											addError( functionNameString, NULL, "I failed to add a deactive specification item" );
										}
									else
										{
										if( addItemToActiveList( (Item *)specificationResult.createdSpecificationItem ) != RESULT_OK )
											addError( functionNameString, NULL, "I failed to add an active specification item" );
										}
									}
								}
							else
								startError( functionNameString, NULL, "I failed to create a specification item" );
							}
						else
							startError( functionNameString, NULL, "The given specification justification item isn't active" );
						}
					else
						startError( functionNameString, NULL, "The current item number is undefined" );
					}
				else
					startError( functionNameString, NULL, "The given specification word type number is undefined or out of bounds" );
				}
			else
				startError( functionNameString, NULL, "The given generalization word type number is undefined or out of bounds" );
			}
		else
			startError( functionNameString, NULL, "I am an assignment list" );

		specificationResult.result = commonVariables()->result;
		return specificationResult;
		}

	SpecificationItem *firstActiveSpecificationItem( bool isIncludingAnsweredQuestions, bool isQuestion )
		{
		SpecificationItem *firstSpecificationItem;

		if( ( firstSpecificationItem = firstActiveSpecificationItem() ) != NULL )
			return firstSpecificationItem->getSpecificationItem( isIncludingAnsweredQuestions, true, isQuestion );

		return NULL;
		}

	SpecificationItem *firstActiveSpecificationItem( bool isIncludingAnsweredQuestions, unsigned short questionParameter )
		{
		SpecificationItem *firstSpecificationItem;

		if( ( firstSpecificationItem = firstActiveSpecificationItem() ) != NULL )
			return firstSpecificationItem->getSpecificationItem( isIncludingAnsweredQuestions, true, questionParameter );

		return NULL;
		}

	SpecificationItem *firstActiveSpecificationItem( bool isPossessive, unsigned short questionParameter, unsigned int relationContextNr, WordItem *specificationWordItem )
		{
		SpecificationItem *searchItem = firstAssignmentOrSpecificationItem( false, false, false, questionParameter );

		while( searchItem != NULL )
			{
			if( searchItem->isPossessive() == isPossessive &&
			searchItem->relationContextNr() == relationContextNr &&
			searchItem->specificationWordItem() == specificationWordItem )
				return searchItem;

			searchItem = searchItem->nextSelectedSpecificationItem( false );
			}

		return NULL;
		}

	SpecificationItem *firstSpecificationItem( bool isAllowingDifferentLanguage, bool isAllowingEmptyContextResult, bool isIncludingAnsweredQuestions, bool includeActiveItems, bool includeDeactiveItems, bool includeArchivedItems, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem )
		{
		SpecificationItem *foundSpecificationItem = NULL;

		if( includeActiveItems )
			foundSpecificationItem = _firstSpecificationItem( isAllowingDifferentLanguage, isAllowingEmptyContextResult, isIncludingAnsweredQuestions, false, false, isNegative, isPossessive, questionParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem );

		if( includeDeactiveItems &&
		foundSpecificationItem == NULL )
			foundSpecificationItem = _firstSpecificationItem( isAllowingDifferentLanguage, isAllowingEmptyContextResult, isIncludingAnsweredQuestions, true, false, isNegative, isPossessive, questionParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem );

		if( includeArchivedItems &&
		foundSpecificationItem == NULL )
			return _firstSpecificationItem( isAllowingDifferentLanguage, isAllowingEmptyContextResult, isIncludingAnsweredQuestions, false, true, isNegative, isPossessive, questionParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem );

		return foundSpecificationItem;
		}

	SpecificationItem *firstUserSpecificationItem( bool isIncludingAnsweredQuestions, bool includeDeactiveItems, bool includeArchivedItems, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationItem *foundSpecificationItem;

		if( ( foundSpecificationItem = _firstUserSpecificationItem( isIncludingAnsweredQuestions, false, false, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString ) ) == NULL )
			{
			if( includeDeactiveItems )
				foundSpecificationItem = _firstUserSpecificationItem( isIncludingAnsweredQuestions, true, false, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

			if( includeArchivedItems &&
			foundSpecificationItem == NULL )
				return _firstUserSpecificationItem( isIncludingAnsweredQuestions, false, true, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );
			}

		return foundSpecificationItem;
		}

	SpecificationItem *firstSpecificationItem( bool isAllowingEmptyContextResult, bool isIncludingAnsweredQuestions, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationItem *searchItem = firstActiveSpecificationItem( isIncludingAnsweredQuestions, questionParameter );

		while( searchItem != NULL )
			{
			if( searchItem->isPossessive() == isPossessive &&
			searchItem->specificationWordItem() == specificationWordItem &&
			searchItem->isMatchingGeneralizationContextNr( isAllowingEmptyContextResult, generalizationContextNr ) &&
			searchItem->isMatchingSpecificationContextNr( isAllowingEmptyContextResult, specificationContextNr ) &&
			searchItem->isMatchingRelationContextNr( isAllowingEmptyContextResult, relationContextNr ) &&

			( specificationString == NULL ||
			searchItem->specificationString() == NULL ||
			strcmp( searchItem->specificationString(), specificationString ) == 0 ) )
				return searchItem;

			searchItem = searchItem->nextSpecificationItemWithSameQuestionParameter( isIncludingAnsweredQuestions );
			}

		return NULL;
		}

	SpecificationItem *firstSpecificationItem( bool isAllowingEmptyContextResult, bool isIncludingAnsweredQuestions, bool includeDeactiveItems, bool includeArchivedItems, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationItem *foundSpecificationItem;

		if( ( foundSpecificationItem = _firstSpecificationItem( isAllowingEmptyContextResult, isIncludingAnsweredQuestions, false, false, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString ) ) == NULL )
			{
			if( includeDeactiveItems )
				foundSpecificationItem = _firstSpecificationItem( isAllowingEmptyContextResult, isIncludingAnsweredQuestions, true, false, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

			if( includeArchivedItems &&
			foundSpecificationItem == NULL )
				return _firstSpecificationItem( isAllowingEmptyContextResult, isIncludingAnsweredQuestions, false, true, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );
			}

		return foundSpecificationItem;
		}

	SpecificationItem *findSpecificationItem( bool isAllowingEmptyContextResult, bool isIncludingAnsweredQuestions, bool includeDeactiveItems, bool includeArchivedItems, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationItem *foundSpecificationItem;

		if( ( foundSpecificationItem = _firstSpecificationItem( isAllowingEmptyContextResult, isIncludingAnsweredQuestions, false, false, isNegative, isPossessive, questionParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString ) ) == NULL )
			{
			if( includeDeactiveItems )
				foundSpecificationItem = _firstSpecificationItem( isAllowingEmptyContextResult, isIncludingAnsweredQuestions, true, false, isNegative, isPossessive, questionParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

			if( includeArchivedItems &&
			foundSpecificationItem == NULL )
				return _firstSpecificationItem( isAllowingEmptyContextResult, isIncludingAnsweredQuestions, false, true, isNegative, isPossessive, questionParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );
			}

		return foundSpecificationItem;
		}

	SpecificationItem *firstSpecificationItem( bool isAllowingDifferentLanguage, bool isAllowingEmptyContextResult, bool isIncludingAnsweredQuestions, bool includeDeactiveItems, bool includeArchivedItems, bool isNegative, bool isPossessive, bool isSelfGenerated, unsigned short questionParameter, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationItem *foundSpecificationItem;

		if( ( foundSpecificationItem = _firstSpecificationItem( isAllowingDifferentLanguage, isAllowingEmptyContextResult, isIncludingAnsweredQuestions, false, false, isNegative, isPossessive, isSelfGenerated, questionParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString ) ) == NULL )
			{
			if( includeDeactiveItems )
				foundSpecificationItem = _firstSpecificationItem( isAllowingDifferentLanguage, isAllowingEmptyContextResult, isIncludingAnsweredQuestions, true, false, isNegative, isPossessive, isSelfGenerated, questionParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

			if( includeArchivedItems &&
			foundSpecificationItem == NULL )
				return _firstSpecificationItem( isAllowingDifferentLanguage, isAllowingEmptyContextResult, isIncludingAnsweredQuestions, false, true, isNegative, isPossessive, isSelfGenerated, questionParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );
			}

		return foundSpecificationItem;
		}

	SpecificationItem *firstAssumptionSpecificationItem( bool isAllowingEmptyContextResult, bool isIncludingAnsweredQuestions, bool includeDeactiveItems, bool includeArchivedItems, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, WordItem *specificationWordItem )
		{
		SpecificationItem *foundSpecificationItem;

		if( ( foundSpecificationItem = _firstAssumptionSpecificationItem( isAllowingEmptyContextResult, isIncludingAnsweredQuestions, false, false, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, specificationWordItem ) ) == NULL )
			{
			if( includeDeactiveItems )
				foundSpecificationItem = _firstAssumptionSpecificationItem( isAllowingEmptyContextResult, isIncludingAnsweredQuestions, true, false, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, specificationWordItem );

			if( includeArchivedItems &&
			foundSpecificationItem == NULL )
				return _firstAssumptionSpecificationItem( isAllowingEmptyContextResult, isIncludingAnsweredQuestions, false, true, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, specificationWordItem );
			}

		return foundSpecificationItem;
		}
	};
#endif

/*************************************************************************
 *
 *	"Good comes to those who lend money generously
 *	and conduct their business fairly.
 *	Such people will not be overcome by evil.
 *	Those who are righteous will be long remembered" (Psalm 112:5-6)
 *
 *************************************************************************/
