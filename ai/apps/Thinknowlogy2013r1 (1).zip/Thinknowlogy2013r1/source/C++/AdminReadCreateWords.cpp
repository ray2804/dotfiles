/*
 *	Class:			AdminReadCreateWords
 *	Supports class:	AdminItem
 *	Purpose:		To create words of the read sentence
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "AdminItem.h"
#include "GeneralizationItem.cpp"
#include "ReadList.cpp"
#include "WordList.cpp"
#include "WordTypeItem.cpp"

class AdminReadCreateWords
	{
	// Private constructible variables

	bool hasCreatedReadWord_;
	bool isProbablyPluralNoun_;

	unsigned short currentWordOrderNr_;
	unsigned short wordTypeNr_;

	size_t nextTextStringPosition_;
	size_t singularWordLength_;

	char exactWordString_[MAX_WORD_LENGTH];
	char lowerCaseWordString_[MAX_WORD_LENGTH];
	char singularNounString_[MAX_WORD_LENGTH];

	CommonVariables *commonVariables_;
	AdminItem *admin_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	bool isSymbol( char character )
		{
		return ( character == SYMBOL_COMMA ||
			character == SYMBOL_COLON ||
			character == SYMBOL_SEMI_COLON ||
			character == SYMBOL_DOUBLE_COLON ||
			character == SYMBOL_QUESTION_MARK ||
			character == SYMBOL_EXCLAMATION_MARK ||
			character == SYMBOL_PIPE ||
			character == SYMBOL_AMPERSAND ||
			character == SYMBOL_ASTERISK ||
			character == SYMBOL_PERCENT ||
			character == SYMBOL_DOLLAR ||
			character == SYMBOL_SLASH ||
			character == SYMBOL_BACK_SLASH ||
			character == SYMBOL_QUOTE ||
			// Don't add SYMBOL_DOUBLE_QUOTE to avoid analyzing in text strings
			character == SYMBOL_OPEN_ROUNDED_BRACKET ||
			character == SYMBOL_CLOSE_ROUNDED_BRACKET ||
			character == SYMBOL_OPEN_CURVED_BRACKET ||
			character == SYMBOL_CLOSE_CURVED_BRACKET ||
			character == SYMBOL_OPEN_HOOKED_BRACKET ||
			character == SYMBOL_CLOSE_HOOKED_BRACKET ||
			character == SYMBOL_OPEN_SQUARE_BRACKET ||
			character == SYMBOL_CLOSE_SQUARE_BRACKET );
		}

	ReadResultType createWordStrings( size_t startPosition, char *wordString )
		{
		ReadResultType readResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "createWordStrings";
		strcpy( exactWordString_, EMPTY_STRING );
		strcpy( lowerCaseWordString_, EMPTY_STRING );

		if( wordString != NULL )
			{
			if( ( readResult = getWordInfo( false, startPosition, wordString ) ).result == RESULT_OK )
				{
				if( readResult.wordLength > 0 )
					{
					if( readResult.wordLength < MAX_WORD_LENGTH )
						{
						strncpy( exactWordString_, &wordString[startPosition], readResult.wordLength );
						exactWordString_[readResult.wordLength] = NULL_CHAR;

						strcpy( lowerCaseWordString_, exactWordString_ );

						for( unsigned i = 0; i < readResult.wordLength; i++ )
							lowerCaseWordString_[i] = (char)tolower( exactWordString_[i] );

						lowerCaseWordString_[readResult.wordLength] = NULL_CHAR;
						}
					else
						myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given word string is too long" );
					}
				else
					myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given word string is empty or has no words left anymore" );
				}
			else
				myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get the length of the given word string" );
			}
		else
			myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given word string is undefined" );

		readResult.result = commonVariables_->result;
		return readResult;
		}

	ResultType comparePluralEndingOfWord( size_t singularNounWordStringLength, size_t nounWordStringLength, char *singularNounEndingString, char *nounWordString, char *pluralNounEndingString )
		{
		size_t tempWordLength;
		size_t pluralNounEndingStringLength;
		char functionNameString[FUNCTION_NAME_LENGTH] = "comparePluralEndingOfWord";

		isProbablyPluralNoun_ = false;
		singularWordLength_ = 0;
		strcpy( singularNounString_, EMPTY_STRING );

		if( nounWordStringLength > 0 )
			{
			if( nounWordString != NULL )
				{
				if( pluralNounEndingString != NULL )
					{
					pluralNounEndingStringLength = strlen( pluralNounEndingString );
					tempWordLength = ( nounWordStringLength - pluralNounEndingStringLength );
					singularWordLength_ = ( nounWordStringLength + singularNounWordStringLength - pluralNounEndingStringLength );

					if( tempWordLength >= 0 &&
					singularWordLength_ > 0 )
						{
						if( strncmp( &nounWordString[tempWordLength], pluralNounEndingString, pluralNounEndingStringLength ) == 0 )
							{
							isProbablyPluralNoun_ = true;

							strcpy( singularNounString_, nounWordString );
							singularNounString_[tempWordLength] = NULL_CHAR;

							if( singularNounEndingString != NULL )
								strcat( singularNounString_, singularNounEndingString );
							}
						}
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The grammar string is undefined" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given noun word string is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The noun word string length is undefined" );

		return commonVariables_->result;
		}

	ResultType checkNounWordType( size_t nounWordStringLength, char *nounWordString, GrammarItem *pluralNounEndingGrammarItem )
		{
		char *singularNounEndingString = NULL;
		GrammarItem *singularNounEndingGrammarItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkNounWordType";

		isProbablyPluralNoun_ = false;
		singularWordLength_ = 0;
		strcpy( singularNounString_, EMPTY_STRING );

		if( nounWordStringLength > 0 )
			{
			if( nounWordString != NULL )
				{
				if( pluralNounEndingGrammarItem != NULL )
					{
					do	{
						if( pluralNounEndingGrammarItem->isDefinitionStart() )
							{
							singularNounEndingGrammarItem = pluralNounEndingGrammarItem->nextDefinitionGrammarItem;
							singularNounEndingString = ( singularNounEndingGrammarItem == NULL ? NULL : singularNounEndingGrammarItem->grammarString() );

							if( comparePluralEndingOfWord( ( singularNounEndingString == NULL ? 0 : strlen( singularNounEndingString ) ), nounWordStringLength, singularNounEndingString, nounWordString, pluralNounEndingGrammarItem->itemString() ) != RESULT_OK )
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find the plural ending of an undefined word type" );
							}
						}
					while( !isProbablyPluralNoun_ &&
					( pluralNounEndingGrammarItem = pluralNounEndingGrammarItem->nextPluralNounEndingGrammarItem() ) != NULL );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The current grammar language word item is undefined" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given noun word string is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given noun word string is empty" );

		return commonVariables_->result;
		}

	ResultType checkNounWordTypeOfAllLanguages( size_t nounWordStringLength, char *nounWordString )
		{
		GeneralizationItem *currentGeneralizationItem;
		GrammarItem *pluralNounEndingGrammarItem;
		WordItem *currentGeneralizationWordItem;
		WordItem *currentGrammarLanguageWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkNounWordTypeOfAllLanguages";

		singularWordLength_ = 0;
		strcpy( singularNounString_, EMPTY_STRING );

		if( ( currentGrammarLanguageWordItem = commonVariables_->currentGrammarLanguageWordItem ) != NULL )
			{
			if( ( pluralNounEndingGrammarItem = commonVariables_->currentGrammarLanguageWordItem->firstPluralNounEndingGrammarItem() ) != NULL )
				{
				if( checkNounWordType( nounWordStringLength, nounWordString, pluralNounEndingGrammarItem ) == RESULT_OK )
					{
					if( !isProbablyPluralNoun_ )
						{
						if( commonVariables_->predefinedNounGrammarLanguageWordItem != NULL )
							{
							if( ( currentGeneralizationItem = commonVariables_->predefinedNounGrammarLanguageWordItem->firstActiveGeneralizationItemOfSpecification() ) != NULL )
								{
								do	{
									if( ( currentGeneralizationWordItem = currentGeneralizationItem->generalizationWordItem() ) != NULL )
										{
										if( currentGeneralizationWordItem != currentGrammarLanguageWordItem )
											{
											if( ( pluralNounEndingGrammarItem = currentGeneralizationWordItem->firstPluralNounEndingGrammarItem() ) != NULL )
												{
												if( checkNounWordType( nounWordStringLength, nounWordString, pluralNounEndingGrammarItem ) != RESULT_OK )
													return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check for noun type" );
												}
											else
												return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I failed to get the first plural noun ending grammar item of grammar word \"", currentGeneralizationWordItem->anyWordTypeString(), "\"" );
											}
										}
									}
								while( !isProbablyPluralNoun_ &&
								( currentGeneralizationItem = currentGeneralizationItem->nextGeneralizationItemOfSpecification() ) != NULL );
								}
							}
						else
							return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The predefined grammar language noun word item is undefined" );
						}
					}
				else
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check for noun type" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I failed to get the first plural noun ending grammar item" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The current grammar language word item is undefined" );

		return commonVariables_->result;
		}

	ResultType getWordTypeNr( bool checkPropername, size_t wordTypeStringLength, char *wordTypeString )
		{
		size_t wordPosition = 0;
		char functionNameString[FUNCTION_NAME_LENGTH] = "getWordTypeNr";

		wordTypeNr_ = WORD_TYPE_UNDEFINED;

		if( wordTypeString != NULL )
			{
			if( wordTypeStringLength > 0 )
				{
				if( isalpha( wordTypeString[wordPosition] ) )
					{
					if( wordTypeStringLength == 1 )
						wordTypeNr_ = ( isupper( wordTypeString[wordPosition] ) ? WORD_TYPE_LETTER_CAPITAL : WORD_TYPE_LETTER_SMALL );
					else
						{
						if( checkPropername &&
						isupper( wordTypeString[wordPosition] ) )
							wordTypeNr_ = WORD_TYPE_PROPER_NAME;
						}
					}
				else
					{
					while( wordPosition < wordTypeStringLength &&
					isdigit( wordTypeString[wordPosition] ) )
						wordPosition++;

					if( wordPosition == wordTypeStringLength )
						wordTypeNr_ = WORD_TYPE_NUMERAL;
					}
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given word type string is empty" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given word type string is undefined" );

		return commonVariables_->result;
		}


	public:
	// Constructor

	AdminReadCreateWords( AdminItem *admin, WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		hasCreatedReadWord_ = false;
		isProbablyPluralNoun_ = false;

		currentWordOrderNr_ = NO_ORDER_NR;
		wordTypeNr_ = WORD_TYPE_UNDEFINED;

		nextTextStringPosition_ = 0;
		singularWordLength_ = 0;

		strcpy( exactWordString_, EMPTY_STRING );
		strcpy( lowerCaseWordString_, EMPTY_STRING );
		strcpy( singularNounString_, EMPTY_STRING );

		admin_ = admin;
		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "AdminReadCreateWords" );

		if( commonVariables_ != NULL )
			{
		if( admin_ != NULL )
			{
			if( myWord_ == NULL )
				strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given admin is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	ReadResultType createReadWord( unsigned short wordOrderNr, unsigned short wordTypeNr, size_t textStringStartPosition, char *textString, WordItem *readWordItem )
		{
		ReadResultType readResult;
		unsigned short wordParameter = ( wordTypeNr == WORD_TYPE_NOUN_PLURAL || readWordItem == NULL ? NO_WORD_PARAMETER : readWordItem->wordParameter() );
		char *readString = NULL;
		char functionNameString[FUNCTION_NAME_LENGTH] = "createReadWord";

		hasCreatedReadWord_ = false;
		nextTextStringPosition_ = 0;

		if( wordTypeNr > WORD_TYPE_UNDEFINED )
			{
			if( textString != NULL ||
			readWordItem != NULL )
				{
				if( textString != NULL )
					{
					if( ( readResult = getWordInfo( true, textStringStartPosition, textString ) ).result == RESULT_OK )
						{
						if( readResult.startWordPosition < strlen( textString ) )
							{
							nextTextStringPosition_ = readResult.nextWordPosition;
							readString = &textString[readResult.startWordPosition];
							}
						else
							myWord_->startErrorInItem( functionNameString, moduleNameString_, "The found start word position is invalid" );
						}
					else
						myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get the length of the current text string" );
					}

				if( commonVariables_->result == RESULT_OK )
					{
					if( admin_->readList == NULL )
						{
						// Create list
						if( ( admin_->readList = new ReadList( myWord_, commonVariables_ ) ) != NULL )
							admin_->adminList[ADMIN_READ_LIST] = admin_->readList;
						else
							myWord_->startErrorInItem( functionNameString, moduleNameString_, "I failed to create a read list" );
						}
					else
						{
						// Find out if already exists
						if( admin_->readList->hasFoundReadItem( wordOrderNr, wordParameter, wordTypeNr, commonVariables_->currentGrammarLanguageNr, readString, readWordItem ) )
							myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given read item already exists" );
						}

					if( ( readResult = admin_->readList->createReadItem( wordOrderNr, wordParameter, wordTypeNr, readResult.wordLength, readString, readWordItem ) ).result == RESULT_OK )
						hasCreatedReadWord_ = true;
					else
						myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create an admin read words item" );
					}
				}
			else
				myWord_->startErrorInItem( functionNameString, moduleNameString_, "Both the given text string and the given read word item are undefined" );
			}
		else
			myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given word type number is undefined" );

		readResult.result = commonVariables_->result;
		return readResult;
		}

	ReadResultType createReadWords( char *readSentenceString )
		{
		ReadResultType readResult;
		WordResultType wordResult;
		bool hasFoundExactWord;
		bool hasFoundSingularNounWord;
		bool hasFoundPluralNounWord;
		bool isFirstFind;
		bool wasPreviousWordAdjective;
		bool wasPreviousWordArticle;
		bool wasPreviousWordConjunction;
		bool wasPreviousWordPossessiveDeterminer;
		bool wasPreviousWordPossessivePronoun;
		bool wasPreviousWordSymbol;
		bool wasPreviousWordUndefined = false;
		bool isFirstWord = true;
		bool isSymbol = false;
		bool isLetter = false;
		bool isNumeral = false;
		bool isAdjective = false;
		bool isArticle = false;
		bool isConjunction = false;
		bool isPossessiveDeterminer = false;
		bool isPossessivePronoun = false;
		bool isUndefinedWord = false;
		bool isBasicVerb = false;
		bool isVerb = false;
		unsigned short previousWordDefiniteArticleParameter;
		unsigned short previousWordIndefiniteArticleParameter;
		unsigned short currentWordDefiniteArticleParameter = NO_DEFINITE_ARTICLE_PARAMETER;
		unsigned short currentWordIndefiniteArticleParameter = NO_INDEFINITE_ARTICLE_PARAMETER;
		size_t readSentenceStringLength;
		size_t wordStringLength;
		size_t nextWordPosition = 0;
		size_t readPosition = 0;
		WordItem *createdWordItem;
		WordItem *foundWordItem;
		WordItem *pluralNounWordItem;
		WordItem *singularNounWordItem;
		WordTypeItem *foundWordTypeItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "createReadWords";

		hasCreatedReadWord_ = true;		// Set to pass while loop for the first time
		currentWordOrderNr_ = NO_ORDER_NR;

		if( readSentenceString != NULL )
			{
			if( ( readSentenceStringLength = strlen( readSentenceString ) ) > 0 )
				{
				do	{
					if( ++currentWordOrderNr_ < MAX_ORDER_NR )
						{
						if( currentWordOrderNr_ > 1 )
							isFirstWord = false;

						hasCreatedReadWord_ = false;

						if( readSentenceString[readPosition] == SYMBOL_DOUBLE_QUOTE )
							{
							if( createReadWord( currentWordOrderNr_, WORD_TYPE_TEXT, readPosition, readSentenceString, NULL ).result == RESULT_OK )
								nextWordPosition = nextTextStringPosition_;
							else
								myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create a read word" );
							}
						else
							{
							hasFoundExactWord = false;
							hasFoundSingularNounWord = false;
							hasFoundPluralNounWord = false;

							wasPreviousWordAdjective = isAdjective;
							wasPreviousWordArticle = isArticle;
							wasPreviousWordConjunction = isConjunction;
							wasPreviousWordPossessiveDeterminer = isPossessiveDeterminer;
							wasPreviousWordPossessivePronoun = isPossessivePronoun;
							wasPreviousWordSymbol = isSymbol;
							wasPreviousWordUndefined = isUndefinedWord;

							previousWordDefiniteArticleParameter = currentWordDefiniteArticleParameter;
							previousWordIndefiniteArticleParameter = currentWordIndefiniteArticleParameter;

							isSymbol = false;
							isLetter = false;
							isNumeral = false;
							isAdjective = false;
							isArticle = false;
							isConjunction = false;
							isPossessiveDeterminer = false;
							isPossessivePronoun = false;
							isUndefinedWord = false;
							isBasicVerb = false;
							isVerb = false;

							currentWordDefiniteArticleParameter = NO_DEFINITE_ARTICLE_PARAMETER;
							currentWordIndefiniteArticleParameter = NO_INDEFINITE_ARTICLE_PARAMETER;

							createdWordItem = NULL;
							pluralNounWordItem = NULL;
							singularNounWordItem = NULL;

							if( ( readResult = createWordStrings( readPosition, readSentenceString ) ).result == RESULT_OK )
								{
								nextWordPosition = readResult.nextWordPosition;
								wordStringLength = readResult.wordLength;
								foundWordItem = NULL;

								// Step 1: Find exact word types in all words
								do	{
									if( ( wordResult = myWord_->findWordTypeInAllWords( false, WORD_TYPE_UNDEFINED, exactWordString_, foundWordItem ) ).result == RESULT_OK )
										{
										foundWordItem = wordResult.foundWordItem;
										foundWordTypeItem = wordResult.foundWordTypeItem;

										if( foundWordItem != NULL &&
										foundWordTypeItem != NULL )		// Found exact word
											{
											if( createReadWord( currentWordOrderNr_, foundWordTypeItem->wordTypeNr(), 0, NULL, foundWordItem ).result == RESULT_OK )
												{
												hasFoundExactWord = true;

												if( foundWordItem->isBasicVerb() )
													isBasicVerb = true;

												if( foundWordTypeItem->isWordTypeAdjective() )
													{
													isAdjective = true;

													if( wordResult.foundWordItem != NULL &&
													wordResult.foundWordItem->isAdjectiveNo() )		// Adjective 'no' can be used as article
														isArticle = true;
													}

												if( foundWordTypeItem->isWordTypeArticle() )
													isArticle = true;

												if( foundWordTypeItem->isWordTypeConjunction() )
													isConjunction = true;

												if( foundWordTypeItem->isWordTypeLetter() )
													isLetter = true;

												if( foundWordTypeItem->isWordTypeNumeral() )
													isNumeral = true;

												if( foundWordTypeItem->isWordTypePossessiveDeterminer() )
													isPossessiveDeterminer = true;

												if( foundWordTypeItem->isWordTypePossessivePronoun() )
													isPossessivePronoun = true;

												if( foundWordTypeItem->isWordTypeSymbol() )
													isSymbol = true;

												if( foundWordTypeItem->isWordTypeDefiniteArticle() )
													currentWordDefiniteArticleParameter = foundWordTypeItem->definiteArticleParameter();

												if( foundWordTypeItem->isWordTypeIndefiniteArticle() )
													currentWordIndefiniteArticleParameter = foundWordTypeItem->indefiniteArticleParameter();

												if( foundWordTypeItem->isWordTypePluralNoun() )
													hasFoundPluralNounWord = true;

												if( foundWordTypeItem->isWordTypeSingularNoun() )
													{
													hasFoundSingularNounWord = true;

													if( foundWordTypeItem->hasUndefinedDefiniteArticle() &&

													( previousWordDefiniteArticleParameter == WORD_PARAMETER_ARTICLE_DEFINITE_1 ||
													previousWordDefiniteArticleParameter == WORD_PARAMETER_ARTICLE_DEFINITE_2 ) )
														{
														if( foundWordTypeItem->setDefiniteArticleParameter( previousWordDefiniteArticleParameter ) != RESULT_OK )
															myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to set the definite article parameter of a singular noun" );
														}
													else
														{
														// Typically for English: Store the use of 'a' or 'an'
														if( foundWordTypeItem->hasUndefinedIndefiniteArticle() &&

														( previousWordIndefiniteArticleParameter == WORD_PARAMETER_ARTICLE_INDEFINITE_1 ||
														previousWordIndefiniteArticleParameter == WORD_PARAMETER_ARTICLE_INDEFINITE_2 ) )
															{
															if( foundWordTypeItem->setIndefiniteArticleParameter( previousWordIndefiniteArticleParameter ) != RESULT_OK )
																myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to set the indefinite article parameter of a singular noun" );
															}
														}
													}
												}
											else
												myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create another read word" );
											}
										}
									else
										myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find an exact word type in all words" );
									}
								while( commonVariables_->result == RESULT_OK &&
								foundWordItem != NULL );	// Allow multiple finds

								if( commonVariables_->result == RESULT_OK &&
								isFirstWord &&
								isupper( readSentenceString[readPosition] ) )
									{
									if( getWordTypeNr( false, wordStringLength, lowerCaseWordString_ ) == RESULT_OK )
										{
										foundWordItem = NULL;

										if( wordTypeNr_ == WORD_TYPE_UNDEFINED )
											isUndefinedWord = true;

										// Step 2: Find word type with lowercase first letter in all words
										do	{
											if( ( wordResult = myWord_->findWordTypeInAllWords( true, WORD_TYPE_UNDEFINED, lowerCaseWordString_, foundWordItem ) ).result == RESULT_OK )
												{
												foundWordItem = wordResult.foundWordItem;
												foundWordTypeItem = wordResult.foundWordTypeItem;

												if( foundWordItem != NULL &&
												foundWordTypeItem != NULL )		// Found word type with lowercase first letter
													{
													if( foundWordTypeItem->wordTypeNr() == wordTypeNr_ &&
													foundWordTypeItem->wordTypeLanguageNr() != commonVariables_->currentGrammarLanguageNr )
														{
														// Create same word type for different language
														if( foundWordItem->addWordType( false, NO_DEFINITE_ARTICLE_PARAMETER, NO_INDEFINITE_ARTICLE_PARAMETER, wordTypeNr_, wordStringLength, lowerCaseWordString_ ) != RESULT_OK )
															myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a word type with lowercase first letter" );
														}

													if( createReadWord( currentWordOrderNr_, foundWordTypeItem->wordTypeNr(), 0, NULL, foundWordItem ).result == RESULT_OK )
														{
														if( foundWordTypeItem->isWordTypeAdjective() )
															{
															isAdjective = true;

															if( wordResult.foundWordItem != NULL &&
															wordResult.foundWordItem->isAdjectiveNo() )		// Adjective 'no' can be used as article
																isArticle = true;
															}

														if( foundWordTypeItem->isWordTypeArticle() )
															isArticle = true;

														if( foundWordTypeItem->isWordTypeLetter() )
															isLetter = true;

														if( foundWordTypeItem->isWordTypePossessiveDeterminer() )
															isPossessiveDeterminer = true;

														if( foundWordTypeItem->isWordTypePossessivePronoun() )
															isPossessivePronoun = true;

														if( foundWordTypeItem->isWordTypeSingularNoun() )
															hasFoundSingularNounWord = true;

														if( foundWordTypeItem->isWordTypePluralNoun() )
															hasFoundPluralNounWord = true;

														if( foundWordTypeItem->isWordTypeVerb() )
															isVerb = true;

														if( foundWordTypeItem->isWordTypeDefiniteArticle() )
															currentWordDefiniteArticleParameter = foundWordTypeItem->definiteArticleParameter();

														if( foundWordTypeItem->isWordTypeIndefiniteArticle() )
															currentWordIndefiniteArticleParameter = foundWordTypeItem->indefiniteArticleParameter();
														}
													else
														myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create a read word with a word type with difference case of the first letter" );
													}
												}
											else
												myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a word type with difference case of the first letter in all words" );
											}
										while( commonVariables_->result == RESULT_OK &&
										foundWordItem != NULL );	// Allow multiple finds

										if( commonVariables_->result == RESULT_OK &&
										!isUndefinedWord &&
										wordStringLength == 1 )
											{
											// Step 3: Typically for English: Find or create lowercase letter 'a' as first letter of a sentence.
											if( ( wordResult = myWord_->findWordTypeInAllWords( true, wordTypeNr_, lowerCaseWordString_, NULL ) ).result == RESULT_OK )
												{
												if( wordResult.foundWordItem == NULL )
													{
													if( ( wordResult = createWord( NO_DEFINITE_ARTICLE_PARAMETER, NO_INDEFINITE_ARTICLE_PARAMETER, wordTypeNr_, NO_WORD_PARAMETER, wordStringLength, lowerCaseWordString_ ) ).result == RESULT_OK )
														{
														if( ( createdWordItem = wordResult.createdWordItem ) != NULL )
															{
															if( createReadWord( currentWordOrderNr_, wordTypeNr_, 0, NULL, createdWordItem ).result != RESULT_OK )
																myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create a read word with lowercase letter" );
															}
														else
															myWord_->startErrorInItem( functionNameString, moduleNameString_, "The created word with lowercase letter is undefined" );
														}
													else
														myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create word with lowercase letter" );
													}
												}
											else
												myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a lowercase letter" );
											}
										}
									else
										myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get the word type number of a lowercase word" );
									}

								if( commonVariables_->result == RESULT_OK &&

								( !hasFoundExactWord ||
								isPossessivePronoun ) )		// Typically for Dutch: 'u' is a letter as well as a possessive pronoun
									{
									isFirstFind = true;
									foundWordItem = NULL;

									// Step 4: Find exact word types in all words
									do	{
										if( ( wordResult = myWord_->findWordTypeInAllWords( true, WORD_TYPE_UNDEFINED, exactWordString_, foundWordItem ) ).result == RESULT_OK )
											{
											createdWordItem = NULL;
											foundWordItem = wordResult.foundWordItem;
											foundWordTypeItem = wordResult.foundWordTypeItem;

											if( isFirstFind ||

											( foundWordItem != NULL &&
											foundWordTypeItem != NULL ) )	// Skip if later runs have no result
												{
												if( getWordTypeNr( true, wordStringLength, exactWordString_ ) == RESULT_OK )
													{
													if( wordTypeNr_ == WORD_TYPE_UNDEFINED )
														isUndefinedWord = true;
													else
														{
														if( foundWordItem == NULL )
															{
															// Small letters, capital letters, numerals and proper-names
															if( ( wordResult = createWord( previousWordDefiniteArticleParameter, previousWordIndefiniteArticleParameter, wordTypeNr_, NO_WORD_PARAMETER, wordStringLength, exactWordString_ ) ).result == RESULT_OK )
																{
																if( ( createdWordItem = wordResult.createdWordItem ) == NULL )
																	myWord_->startErrorInItem( functionNameString, moduleNameString_, "The last created exact word is undefined" );
																}
															else
																myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create an exact word" );
															}
														else
															{
															if( foundWordTypeItem->wordTypeNr() == wordTypeNr_ &&
															foundWordTypeItem->wordTypeLanguageNr() != commonVariables_->currentGrammarLanguageNr )
																{
																// Create same word type for different language
																if( foundWordItem->addWordType( false, NO_DEFINITE_ARTICLE_PARAMETER, NO_INDEFINITE_ARTICLE_PARAMETER, wordTypeNr_, wordStringLength, exactWordString_ ) == RESULT_OK )
																	createdWordItem = foundWordItem;
																else
																	myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add an exact word type" );
																}
															}

														if( commonVariables_->result == RESULT_OK &&
														createdWordItem != NULL )
															{
															if( createReadWord( currentWordOrderNr_, wordTypeNr_, 0, NULL, createdWordItem ).result == RESULT_OK )
																isFirstFind = false;
															else
																myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create an exact read word" );
															}
														}
													}
												else
													myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get the word type number of an exact word" );
												}
											}
										else
											myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find an exact word" );
										}
									while( commonVariables_->result == RESULT_OK &&
									foundWordItem != NULL );	// Allow multiple finds
									}

								// Create a noun
								if( commonVariables_->result == RESULT_OK &&
								!isSymbol &&
								!isLetter &&
								!isNumeral &&
								!isAdjective &&
								!isArticle &&
								!isConjunction &&
								!isPossessiveDeterminer &&
								!isPossessivePronoun &&
								!isBasicVerb &&
								!isVerb &&
								wordStringLength > 1 &&

								( isUndefinedWord ||
								wasPreviousWordArticle ||
								wasPreviousWordConjunction ||
								wasPreviousWordSymbol ) &&

								( isFirstWord ||
								!isupper( readSentenceString[readPosition] ) ) )
									{
									if( checkNounWordTypeOfAllLanguages( wordStringLength, exactWordString_ ) == RESULT_OK )
										{
										if( isFirstWord ||
										isProbablyPluralNoun_ ||
										wasPreviousWordAdjective ||
										wasPreviousWordArticle ||
										wasPreviousWordConjunction ||
										wasPreviousWordSymbol ||
										wasPreviousWordPossessiveDeterminer ||
										wasPreviousWordPossessivePronoun )
											{
											if( isProbablyPluralNoun_ )
												{
												if( ( wordResult = myWord_->findWordTypeInAllWords( true, WORD_TYPE_NOUN_SINGULAR, singularNounString_, NULL ) ).result == RESULT_OK )
													{
													if( ( foundWordItem = wordResult.foundWordItem ) == NULL )
														{
														if( !hasFoundSingularNounWord )
															{
															if( ( wordResult = createWord( NO_DEFINITE_ARTICLE_PARAMETER, NO_INDEFINITE_ARTICLE_PARAMETER, WORD_TYPE_NOUN_PLURAL, NO_WORD_PARAMETER, wordStringLength, exactWordString_ ) ).result == RESULT_OK )
																{
																if( ( pluralNounWordItem = wordResult.createdWordItem ) != NULL )
																	{
																	if( pluralNounWordItem->addWordType( false, NO_DEFINITE_ARTICLE_PARAMETER, NO_INDEFINITE_ARTICLE_PARAMETER, WORD_TYPE_NOUN_SINGULAR, singularWordLength_, singularNounString_ ) == RESULT_OK )
																		singularNounWordItem = pluralNounWordItem;
																	else
																		myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a singular noun word type item for plural noun word \"", pluralNounWordItem->anyWordTypeString(), "\"" );
																	}
																else
																	myWord_->startErrorInItem( functionNameString, moduleNameString_, "The created word item is undefined" );
																}
															else
																myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create a singular noun word" );
															}
														}
													else	// Found singular noun
														{
														if( !hasFoundPluralNounWord )
															{
															if( foundWordItem->addWordType( false, NO_DEFINITE_ARTICLE_PARAMETER, NO_INDEFINITE_ARTICLE_PARAMETER, WORD_TYPE_NOUN_PLURAL, wordStringLength, exactWordString_ ) == RESULT_OK )
																pluralNounWordItem = foundWordItem;
															else
																myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a plural noun word type item for word \"", foundWordItem->anyWordTypeString(), "\"" );
															}
														}
													}
												else
													myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find if a singular noun word already exists" );
												}
											else
												{
												if( !hasFoundSingularNounWord )
													{
													if( ( wordResult = createWord( previousWordDefiniteArticleParameter, previousWordIndefiniteArticleParameter, WORD_TYPE_NOUN_SINGULAR, NO_WORD_PARAMETER, wordStringLength, exactWordString_ ) ).result == RESULT_OK )
														singularNounWordItem = wordResult.createdWordItem;
													else
														myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create a singular noun word" );
													}
												}

											if( commonVariables_->result == RESULT_OK &&
											singularNounWordItem != NULL )
												{
												if( createReadWord( currentWordOrderNr_, WORD_TYPE_NOUN_SINGULAR, 0, NULL, singularNounWordItem ).result != RESULT_OK )
													myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create a singular noun read word" );
												}

											if( commonVariables_->result == RESULT_OK &&
											pluralNounWordItem != NULL )
												{
												if( createReadWord( currentWordOrderNr_, WORD_TYPE_NOUN_PLURAL, 0, NULL, pluralNounWordItem ).result != RESULT_OK )
													myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create a plural noun read word" );
												}
											}

										// Create an adjective
										if( commonVariables_->result == RESULT_OK &&
										!hasFoundExactWord &&
										!wasPreviousWordUndefined &&

										( wasPreviousWordConjunction ||
										wasPreviousWordSymbol ||
										pluralNounWordItem == NULL ) )
											{
											if( ( wordResult = createWord( NO_DEFINITE_ARTICLE_PARAMETER, NO_INDEFINITE_ARTICLE_PARAMETER, WORD_TYPE_ADJECTIVE, NO_WORD_PARAMETER, wordStringLength, lowerCaseWordString_ ) ).result == RESULT_OK )
												{
												if( ( createdWordItem = wordResult.createdWordItem ) != NULL )
													{
													if( createReadWord( currentWordOrderNr_, WORD_TYPE_ADJECTIVE, 0, NULL, createdWordItem ).result == RESULT_OK )
														isAdjective = true;
													else
														myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create an adjective read word" );
													}
												else
													myWord_->startErrorInItem( functionNameString, moduleNameString_, "The last created adjective word is undefined" );
												}
											else
												myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create an adjective word" );
											}
										}
									else
										myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check a noun word type in all languages" );
									}
								}
							else
								myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create the word strings" );
							}

						readPosition = nextWordPosition;
						}
					else
						myWord_->startSystemErrorInItem( functionNameString, moduleNameString_, "Word order number overflow! I can't accept more words" );
					}
				while( commonVariables_->result == RESULT_OK &&
				hasCreatedReadWord_ &&
				readPosition < readSentenceStringLength );
				}
			else
				myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given read sentence string is empty" );
			}
		else
			myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given read sentence string is undefined" );

		readResult.hasCreatedAllReadWords = hasCreatedReadWord_;
		readResult.result = commonVariables_->result;
		return readResult;
		}

	ReadResultType getWordInfo( bool skipDoubleQuotes, size_t startWordPosition, char *wordString )
		{
		ReadResultType readResult;
		bool text = false;
		bool wordStartedWithDoubleQuote = false;
		size_t wordStringLength;
		size_t wordPosition = startWordPosition;
		char functionNameString[FUNCTION_NAME_LENGTH] = "getWordInfo";

		if( wordString != NULL )
			{
			wordStringLength = strlen( wordString );

			if( wordPosition < wordStringLength )
				{
				while( wordPosition < wordStringLength &&
				isspace( wordString[wordPosition] ) )
					wordPosition++;

				if( wordPosition < wordStringLength )
					{
					readResult.startWordPosition = wordPosition;

					if( isSymbol( wordString[wordPosition] ) )
						{
						wordPosition++;
						readResult.wordLength++;
						}
					else
						{
						if( skipDoubleQuotes &&
						wordString[wordPosition] == SYMBOL_DOUBLE_QUOTE )
							wordStartedWithDoubleQuote = true;

						while( wordPosition < wordStringLength &&

						( text ||
						( !isspace( wordString[wordPosition] ) &&
						!isSymbol( wordString[wordPosition] ) ) ) )
							{
							if( wordString[wordPosition] == SYMBOL_DOUBLE_QUOTE &&

							( wordPosition == 0 ||
							wordString[wordPosition - 1] != SYMBOL_BACK_SLASH ) )	// Skip escaped double quote character
								text = !text;

							wordPosition++;
							readResult.wordLength++;
							}

						if( wordStartedWithDoubleQuote &&
						readResult.wordLength > 1 )
							readResult.wordLength--;

						if( skipDoubleQuotes &&
						wordPosition > 1 &&
						readResult.wordLength > 1 &&
						wordString[wordPosition - 1] == SYMBOL_DOUBLE_QUOTE )
							{
							readResult.wordLength--;
							readResult.startWordPosition++;
							}
						}

					while( wordPosition < wordStringLength &&
					isspace( wordString[wordPosition] ) )
						wordPosition++;
					}
				}
			else
				myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given start word position is invalid" );
			}
		else
			myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given word string is undefined" );

		readResult.result = commonVariables_->result;
		readResult.nextWordPosition = wordPosition;
		return readResult;
		}

	WordResultType createWord( unsigned short previousWordDefiniteArticleParameter, unsigned short previousWordIndefiniteArticleParameter, unsigned short wordTypeNr, unsigned short wordParameter, size_t wordTypeStringLength, char *wordTypeString )
		{
		WordResultType wordResult;
		bool isPropernamePrecededByDefiniteArticle;
		bool wasPreviousWordDefiniteArticle = ( previousWordDefiniteArticleParameter > NO_DEFINITE_ARTICLE_PARAMETER );
		bool wasPreviousWordIndefiniteArticle = ( previousWordIndefiniteArticleParameter > NO_INDEFINITE_ARTICLE_PARAMETER );
		unsigned short definiteArticleParameter = NO_DEFINITE_ARTICLE_PARAMETER;
		unsigned short indefiniteArticleParameter = NO_INDEFINITE_ARTICLE_PARAMETER;
		WordItem *createdWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "createWord";

		if( wordTypeString != NULL )
			{
			if( wordTypeStringLength > 0 &&
			strlen( wordTypeString ) > 0 )
				{
				if( wordTypeNr > WORD_TYPE_UNDEFINED )
					{
					if( admin_->wordList == NULL )
						{
						// Create list
						if( ( admin_->wordList = new WordList( myWord_, commonVariables_ ) ) != NULL )
							admin_->adminList[ADMIN_WORD_LIST] = admin_->wordList;
						else
							myWord_->startErrorInItem( functionNameString, moduleNameString_, "I failed to create a word list" );
						}

					if( ( wordResult = myWord_->findWordTypeInAllWords( false, wordTypeNr, wordTypeString, NULL ) ).result == RESULT_OK )
						{
						if( wordParameter == NO_WORD_PARAMETER ||
						wordResult.foundWordItem == NULL ||
						wordResult.foundWordItem->wordParameter() != wordParameter )
							{
							if( ( wordResult = admin_->wordList->createWordItem( wordParameter ) ).result == RESULT_OK )
								{
								if( ( createdWordItem = wordResult.createdWordItem ) != NULL )
									{
									if( commonVariables_->firstWordItem == NULL )
										commonVariables_->firstWordItem = createdWordItem;		// Initialize the first word

									isPropernamePrecededByDefiniteArticle = ( wasPreviousWordDefiniteArticle &&
																			wordTypeNr == WORD_TYPE_PROPER_NAME );

									if( wordParameter == WORD_PARAMETER_ARTICLE_DEFINITE_1 ||
									wordParameter == WORD_PARAMETER_ARTICLE_DEFINITE_2 )
										definiteArticleParameter = wordParameter;
									else
										{
										if( wasPreviousWordDefiniteArticle &&

										( wordTypeNr == WORD_TYPE_PROPER_NAME ||
										wordTypeNr == WORD_TYPE_NOUN_SINGULAR ||
										wordTypeNr == WORD_TYPE_NOUN_PLURAL ) )
											definiteArticleParameter = previousWordDefiniteArticleParameter;
										}

									if( wordParameter == WORD_PARAMETER_ARTICLE_INDEFINITE_1 ||
									wordParameter == WORD_PARAMETER_ARTICLE_INDEFINITE_2 )
										indefiniteArticleParameter = wordParameter;
									else
										{
										if( wasPreviousWordIndefiniteArticle &&

										( wordTypeNr == WORD_TYPE_NOUN_SINGULAR ||
										wordTypeNr == WORD_TYPE_NOUN_PLURAL ) )
											indefiniteArticleParameter = previousWordIndefiniteArticleParameter;
										}

									if( createdWordItem->addWordType( isPropernamePrecededByDefiniteArticle, definiteArticleParameter, indefiniteArticleParameter, wordTypeNr, wordTypeStringLength, wordTypeString ) != RESULT_OK )
										myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a word type to a new word" );
									}
								else
									myWord_->startErrorInItem( functionNameString, moduleNameString_, "The last created word item is undefined" );
								}
							else
								myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create a word item" );
							}
						else
							myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given word type string already exists with the same word parameter" );
						}
					else
						myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a word type in all words" );
					}
				else
					myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given word type number is undefined" );
				}
			else
				myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given word type string is empty or has no words left anymore" );
			}
		else
			myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given word type string is undefined" );

		wordResult.result = commonVariables_->result;
		return wordResult;
		}
	};

/*************************************************************************
 *
 *	"How joyful are those who fear the Lord-
 *	all who follow his ways!" (Psalm 128:1)
 *
 *************************************************************************/
