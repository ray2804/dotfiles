/*
 *	Class:			ReadList
 *	Parent class:	List
 *	Purpose:		To temporarily store read items
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

class ReadList extends List
	{
	// Private constructible variables

	private short lastCreatedWordOrderNr_;
	private short lastActivatedWordOrderNr_;


	// Constructor

	protected ReadList( WordItem myWord )
		{
		lastCreatedWordOrderNr_ = Constants.NO_ORDER_NR;
		lastActivatedWordOrderNr_ = Constants.NO_ORDER_NR;

		initializeListVariables( Constants.ADMIN_READ_LIST_SYMBOL, myWord );
		}


	// Protected virtual methods

	protected boolean isTemporaryList()
		{
		return true;
		}

	protected byte findWordReference( WordItem referenceWordItem )
		{
		ReadItem searchItem = firstActiveReadItem();

		CommonVariables.hasFoundWordReference = false;

		while( searchItem != null &&
		!CommonVariables.hasFoundWordReference )
			{
			if( searchItem.findWordReference( referenceWordItem ) == Constants.RESULT_OK )
				searchItem = searchItem.nextReadItem();
			else
				return addError( 1, null, "I failed to check for a reference word item in an active read item" );
			}

		searchItem = firstDeactiveReadItem();

		while( searchItem != null &&
		!CommonVariables.hasFoundWordReference )
			{
			if( searchItem.findWordReference( referenceWordItem ) == Constants.RESULT_OK )
				searchItem = searchItem.nextReadItem();
			else
				return addError( 1, null, "I failed to check for a reference word item in a deactive read item" );
			}

		// Don't search in the deleted items - since this method is used for cleanup purposes

		return CommonVariables.result;
		}


	// Protected methods

	protected void initForParsingReadWords()
		{
		lastActivatedWordOrderNr_ = Constants.NO_ORDER_NR;
		}

	protected boolean createImperativeSentence()
		{
		short previousWordOrderNr = Constants.NO_ORDER_NR;
		int nWords = 0;
		String readWordString;
		ReadItem startItem = null;
		ReadItem searchItem = firstActiveReadItem();

		CommonVariables.writeSentenceStringBuffer = null;

		while( searchItem != null )
			{
			if( ( nWords > 0 ||
			searchItem.isSpecificationWord() ) &&					// Trigger

			searchItem.wordOrderNr() > previousWordOrderNr )		// First appearance of new word
				{
				nWords++;
				previousWordOrderNr = searchItem.wordOrderNr();

				if( startItem == null )
					startItem = searchItem;
				}

			searchItem = searchItem.nextReadItem();
			}

		if( nWords > 2 )	// Start creation of imperative sentence
			{
			previousWordOrderNr = Constants.NO_ORDER_NR;
			searchItem = startItem;
			CommonVariables.writeSentenceStringBuffer = new StringBuffer();

			while( searchItem != null )
				{
				if( searchItem.wordOrderNr() > previousWordOrderNr &&
				searchItem.readWordItem() != null &&	// Skip text
				( readWordString = searchItem.readWordTypeString() ) != null )
					{
					if( previousWordOrderNr > Constants.NO_ORDER_NR &&
					searchItem.grammarParameter != Constants.GRAMMAR_SENTENCE )	// End of string (colon, question mark, etc)
						CommonVariables.writeSentenceStringBuffer.append( Constants.SPACE_STRING );

					previousWordOrderNr = searchItem.wordOrderNr();
					CommonVariables.writeSentenceStringBuffer.append( readWordString );
					}

				searchItem = searchItem.nextReadItem();
				}
			}

		return ( nWords > 2 );
		}

	protected boolean hasFoundReadItem( short wordOrderNr, short wordParameter, short wordTypeNr, short wordTypeLanguageNr, String readString, WordItem readWordItem )
		{
		ReadItem searchItem = firstActiveReadItem();

		while( searchItem != null )
			{
			if( searchItem.wordOrderNr() == wordOrderNr &&
			searchItem.wordParameter() == wordParameter &&
			searchItem.wordTypeNr() == wordTypeNr &&
			searchItem.wordTypeLanguageNr() == wordTypeLanguageNr &&

			( ( searchItem.readString == null &&
			readString == null ) ||

			( searchItem.readString != null &&
			readString != null &&
			searchItem.readString.equals( readString ) ) ) &&

			searchItem.readWordItem() == readWordItem )
				return true;

			searchItem = searchItem.nextReadItem();
			}

		return false;
		}

	protected boolean hasPassedGrammarIntegrityCheck()
		{
		ReadItem searchItem = firstActiveReadItem();

		while( searchItem != null )
			{
			if( !searchItem.isWordPassingGrammarIntegrityCheck )
				return false;

			searchItem = searchItem.nextReadItem();
			}

		return true;
		}

	protected short lastCreatedWordOrderNr()
		{
		return lastCreatedWordOrderNr_;
		}

	protected ReadResultType createReadItem( short wordOrderNr, short wordParameter, short wordTypeNr, int readStringLength, String readString, WordItem readWordItem )
		{
		ReadResultType readResult = new ReadResultType();

		if( wordTypeNr > Constants.WORD_TYPE_UNDEFINED &&
		wordTypeNr < Constants.NUMBER_OF_WORD_TYPES )
			{
			if( CommonVariables.currentItemNr < Constants.MAX_ITEM_NR )
				{
				if( ( readResult.createdReadItem = new ReadItem( wordOrderNr, wordParameter, wordTypeNr, CommonVariables.currentGrammarLanguageNr, readStringLength, readString, readWordItem, this, myWord() ) ) != null )
					{
					if( addItemToActiveList( (Item)readResult.createdReadItem ) == Constants.RESULT_OK )
						lastCreatedWordOrderNr_ = wordOrderNr;
					else
						addError( 1, null, "I failed to add an active read item" );
					}
				else
					startError( 1, null, "I failed to create a read item" );
				}
			else
				startError( 1, null, "The current item number is undefined" );
			}
		else
			startError( 1, null, "The given read word type number is undefined or out of bounds" );

		readResult.result = CommonVariables.result;
		return readResult;
		}

	protected ReadResultType findMoreInterpretations()
		{
		ReadResultType readResult = new ReadResultType();
		ReadItem activeReadItem = firstActiveReadItem();
		ReadItem deactiveReadItem = firstDeactiveReadItem();

		// Clear grammar parameters of all active read items
		while( activeReadItem != null )
			{
			activeReadItem.grammarParameter = Constants.NO_GRAMMAR_PARAMETER;
			activeReadItem = activeReadItem.nextReadItem();
			}

		// Get last deactive item
		while( deactiveReadItem != null &&
		deactiveReadItem.nextReadItem() != null )
			deactiveReadItem = deactiveReadItem.nextReadItem();

		if( deactiveReadItem != null )
			{
			readResult.hasFoundMoreInterpretations = true;
			lastActivatedWordOrderNr_ = deactiveReadItem.wordOrderNr();

			if( activateDeactiveItem( deactiveReadItem ) != Constants.RESULT_OK )
				addError( 1, null, "I failed to active a deactive item" );
			}

		readResult.result = CommonVariables.result;
		return readResult;
		}

	protected ReadResultType numberOfReadWordReferences( short wordTypeNr, WordItem readWordItem )
		{
		ReadResultType readResult = new ReadResultType();
		ReadItem searchItem = firstActiveReadItem();

		if( readWordItem != null )
			{
			while( searchItem != null )
				{
				if( !searchItem.isUnusedReadItem &&
				searchItem.wordTypeNr() == wordTypeNr &&
				searchItem.readWordItem() == readWordItem )
					readResult.nReadWordReferences++;

				searchItem = searchItem.nextReadItem();
				}

			searchItem = firstDeactiveReadItem();

			while( searchItem != null )
				{
				if( !searchItem.isUnusedReadItem &&
				searchItem.readWordItem() == readWordItem &&
				searchItem.wordTypeNr() == wordTypeNr )
					readResult.nReadWordReferences++;

				searchItem = searchItem.nextReadItem();
				}
			}
		else
			startError( 1, null, "The given read word is undefined" );

		readResult.result = CommonVariables.result;
		return readResult;
		}

	protected ReadResultType selectMatchingWordType( short currentWordOrderNr, short wordParameter, short wordTypeNr )
		{
		ReadResultType readResult = new ReadResultType();
		ReadItem activeReadItem;
		ReadItem currentReadItem = firstActiveReadItem();

		if( currentWordOrderNr > Constants.NO_ORDER_NR )	// Find current word position
			{
			while( currentReadItem != null &&
			currentReadItem.wordOrderNr() <= currentWordOrderNr )
				currentReadItem = currentReadItem.nextReadItem();
			}

		activeReadItem = currentReadItem;

		while( CommonVariables.result == Constants.RESULT_OK &&
		!readResult.hasFoundMatchingWordType &&
		currentReadItem != null )
			{
			if( currentReadItem.wordOrderNr() == currentWordOrderNr + 1 )
				{
				if( currentReadItem.wordTypeNr() == wordTypeNr &&
				currentReadItem.wordParameter() == wordParameter )
					{
					while( CommonVariables.result == Constants.RESULT_OK &&
					activeReadItem != currentReadItem )
						{
						if( deactivateActiveItem( activeReadItem ) == Constants.RESULT_OK )
							activeReadItem = nextReadListItem();
						else
							addError( 1, null, "I failed to deactive an active item" );
						}

					readResult.hasFoundMatchingWordType = true;
					}
				else
					currentReadItem = ( currentReadItem.wordOrderNr() <= lastActivatedWordOrderNr_ ? null : currentReadItem.nextReadItem() );
				}
			else
				currentReadItem = null;
			}

		readResult.result = CommonVariables.result;
		return readResult;
		}

	protected byte deleteActiveReadWords()
		{
		ReadItem searchItem = firstActiveReadItem();

		while( searchItem != null )
			{
			if( deleteActiveItem( false, searchItem ) == Constants.RESULT_OK )
				searchItem = nextReadListItem();
			else
				return addError( 1, null, "I failed to deactivate an active item" );
			}

		return CommonVariables.result;
		}

	protected byte setGrammarParameter( boolean isValid, short startWordOrderNr, short endWordOrderNr, GrammarItem definitionGrammarItem )
		{
		boolean hasFound = false;
		boolean isMarked = true;
		String definitionGrammarString;
		ReadItem searchItem = firstActiveReadItem();

		if( endWordOrderNr > Constants.NO_ORDER_NR )
			{
			if( startWordOrderNr < endWordOrderNr )
				{
				if( definitionGrammarItem != null )
					{
					if( isValid )
						{
						while( isMarked &&
						searchItem != null &&
						searchItem.wordOrderNr() <= endWordOrderNr )
							{
							if( !searchItem.isMarkedBySetGrammarParameter &&
							searchItem.wordOrderNr() > startWordOrderNr &&
							searchItem.wordOrderNr() <= endWordOrderNr )
								isMarked = false;

							searchItem = searchItem.nextReadItem();
							}

						searchItem = firstActiveReadItem();
						}

					while( searchItem != null &&
					searchItem.wordOrderNr() <= endWordOrderNr )
						{
						if( searchItem.wordOrderNr() > startWordOrderNr &&
						searchItem.wordOrderNr() <= endWordOrderNr )
							{
							hasFound = true;

							if( isValid )
								{
								if( isMarked ||
								definitionGrammarItem.grammarParameter() > searchItem.grammarParameter )
									{
									searchItem.isMarkedBySetGrammarParameter = false;
									searchItem.grammarParameter = definitionGrammarItem.grammarParameter();

									searchItem.definitionGrammarItem = definitionGrammarItem;

									if( searchItem.readString == null &&
									( definitionGrammarString = definitionGrammarItem.grammarString() ) != null )
										{
										if( searchItem.readString != null )
											searchItem.readString = definitionGrammarString;
										else
											searchItem.readString = definitionGrammarString;
										}
									}
								}
							else
								searchItem.isMarkedBySetGrammarParameter = true;
							}

						searchItem = searchItem.nextReadItem();
						}

					if( !hasFound )
						return startError( 1, null, "I couldn't find any item between the given word order numbers" );
					}
				else
					return startError( 1, null, "The given grammar definition word item is undefined" );
				}
			else
				return startError( 1, null, "The given start word order number is equal or higher than the given end word order number" );
			}
		else
			return startError( 1, null, "The given end word order number is undefined" );

		return CommonVariables.result;
		}

	protected ReadItem firstActiveReadItem()
		{
		return (ReadItem)firstActiveItem();
		}

	protected ReadItem firstDeactiveReadItem()
		{
		return (ReadItem)firstDeactiveItem();
		}

	protected ReadItem nextReadListItem()
		{
		return (ReadItem)nextListItem();
		}
	};

/*************************************************************************
 *
 *	"Everything he does reveals his glory and majesty.
 *	His righteousness never fails." (Psalm 111:3)
 *
 *************************************************************************/
