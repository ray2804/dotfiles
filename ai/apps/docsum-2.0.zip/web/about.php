<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">                                                                             
<html>
<?php 
	$page = "about";
	include 'head.php'; 
	echo $header_html;
?>
<body>
<?php echo "<center>$logo_html</center>"; ?>
<br>
<center>
<a href="<?php echo $pj_url; ?>">Docsum SF Page</a> | 
<a href="<?php echo $main_page; ?>">Try it</a> | 
<a href="http://svn.sourceforge.net/viewcvs.cgi/docsum/">Project Source Code</a> | 
<a href="docsum-use-drawing.png">Usage Drawing</a> | 
<a href="docsum-db.png">Database Drawing</a> | 
<a href="COPY">Copyright</a>
</center>
<h3 class="indented">What &amp; why</h3>
<p class="indented">Docsum is a document summary tool. Say for instance you are researching a topic
and you have a several hundred pages per document you discover. Rather then reading
all the text, a summary would be nice to have to determine the relevant parts of the 
documents, as well as across documents. This is what docsum is intended to do. The
results of the search is will not be a list of links pointing to text in the relevant
information, docsum will produce a summary document with the information you need
based on your query. </p>

<h3 class="indented">How</h3>
<p class="indented">Docum is driven by Python and MySQL. The web end is basic HTML and PHP. Via the command
line (Python) or the web (PHP), the a user can generate summaries, post content, and
perform other administrative stuff. </p>

<h3 class="indented">Limits</h3>
<p class="indented">First off, docsum currently only handles plain text. Hopefully I
can find some libraries pre-made to read files such as PDF and MS Word files. This
tool should really be used for long documents you don't feel like reading, but you've
looked the document over enough to realize it is relavant.</p>

<h3 class="indented">Security</h3>
<p class="indented">This project is developing and security is being added where possible.
Please do not hack this site or the demo. Thank you.</p>
<p class="indented">If you would like to make security related suggestions, or actually
contribute to the security of this project, please feel free to do so. You can start
with a simple e-mail explaining suggestions, with sample changed code. Thanks.</p>

<h3 class="indented">Privacy</h3>
<p class="indented">This application tracks information about how the user uses the application.
All actions such as page navigation, content added, topic searches, etc, might be tracked. 
Unless provided in this fashion, no personal information is stored for any purpose. All
information gahtered is for the improvement and development of this application.</p>

<center><a href="http://sourceforge.net"><img src="http://sflogo.sourceforge.net/sflogo.php?group_id=167349&amp;type=2" width="125" height="37" border="0" alt="SourceForge.net Logo" /></a>
<br><?php echo "version $version"; ?></center>
<center><br><a href="http://us2.php.net/">PHP</a> | <a href="http://www.mysql.com/">MySQL</a> | <a href="http://www.python.org/">Python</a> | <a href="http://sourceforge.net/projects/mysql-python">MySQL Python Module</a></center>
</body>
</html>
