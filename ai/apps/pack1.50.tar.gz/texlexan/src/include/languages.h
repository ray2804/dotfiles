/* License/copyright: At the end of this file or read copyright.txt */

/*---------- Declarations --------------*/
int testhtml(char *file_input);
int testansi7(char *file_input);
int testutf8(char *file_input);
int testutf16(char *file_input);
int teststransi7(char *s);
int teststrutf8(char *s);
int teststrutf16(char *s);
char *htmltotext(char *file_input, char *file_temp,char *title_str);
int utf8toansi7b(char *file_input,char *file_temp,char *file_iso);
int isotoansi7b(char *file_input,char *file_temp);
int plainansi7b(char *file_input,char *file_temp);
int strutf8toansi7b(char *s1,char *s2);
int strisotoansi7b(char *s1,char *s2);
char *testlanguage(char *path_dictionary,char *file_input);
int chgtosingular(char *word,char *lang);
int noplural(char *word,char *lang);
int strcleanup(char *str);
int char2utf8(char *out,char *in);
float readingtime
    (char *path_dictionary,char * lang,long nbts,long nbtw,long nbtc,long nbl);

