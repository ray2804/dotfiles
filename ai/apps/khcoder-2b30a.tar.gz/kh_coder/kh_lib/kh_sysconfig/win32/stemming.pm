package kh_sysconfig::win32::stemming;
use base qw(kh_sysconfig::win32);

sub config_morph{
	return 1;
}

sub path_check{
	return 1;
}


1;
__END__
