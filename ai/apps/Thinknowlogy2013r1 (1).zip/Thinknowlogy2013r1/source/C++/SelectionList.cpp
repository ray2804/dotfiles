/*
 *	Class:			SelectionList
 *	Parent class:	List
 *	Purpose:		To store selection items
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "SelectionList.h"
	// Private deconstructor functions

	void SelectionList::deleteSelectionList( SelectionItem *searchItem )
		{
		SelectionItem *deleteItem;

		while( searchItem != NULL )
			{
			deleteItem = searchItem;
			searchItem = searchItem->nextSelectionItem();
			delete deleteItem;
			}
		}
	// Private selection functions

	unsigned int SelectionList::getLowerSentenceNr( unsigned int duplicateSentenceNr )
		{
		Item *searchItem = firstActiveItem();
		unsigned int lowerSentenceNr = NO_SENTENCE_NR;

		while( searchItem != NULL )
			{
			if( searchItem->activeSentenceNr() < duplicateSentenceNr &&
			searchItem->activeSentenceNr() > lowerSentenceNr )
				lowerSentenceNr = searchItem->activeSentenceNr();

			searchItem = searchItem->nextItem;
			}

		return lowerSentenceNr;
		}

	SelectionItem *SelectionList::firstDeactiveSelectionItem()
		{
		return (SelectionItem *)firstDeactiveItem();
		}


	// Constructor

	SelectionList::SelectionList( char _listChar, WordItem *myWord, CommonVariables *commonVariables )
		{
		initializeListVariables( _listChar, "SelectionList", myWord, commonVariables );
		}

	// Deconstructor

	SelectionList::~SelectionList()
		{
		deleteSelectionList( firstActiveSelectionItem() );
		deleteSelectionList( firstDeactiveSelectionItem() );
		deleteSelectionList( (SelectionItem *)firstArchivedItem() );
		deleteSelectionList( (SelectionItem *)firstDeletedItem() );
		}


	// Protected virtual functions

	ResultType SelectionList::findWordReference( WordItem *referenceWordItem )
		{
		SelectionItem *searchItem = firstActiveSelectionItem();
		char functionNameString[FUNCTION_NAME_LENGTH] = "findWordReference";

		commonVariables()->hasFoundWordReference = false;

		while( searchItem != NULL &&
		!commonVariables()->hasFoundWordReference )
			{
			if( searchItem->findWordReference( referenceWordItem ) == RESULT_OK )
				searchItem = searchItem->nextSelectionItem();
			else
				return addError( functionNameString, NULL, "I failed to check for a reference word item in an active selection item" );
			}

		searchItem = firstDeactiveSelectionItem();

		while( searchItem != NULL &&
		!commonVariables()->hasFoundWordReference )
			{
			if( searchItem->findWordReference( referenceWordItem ) == RESULT_OK )
				searchItem = searchItem->nextSelectionItem();
			else
				return addError( functionNameString, NULL, "I failed to check for a reference word item in a deactive selection item" );
			}

		// Don't search in the deleted items - since this function is used for cleanup purposes

		return commonVariables()->result;
		}


	// Protected functions

	void SelectionList::clearConditionChecksForSolving( unsigned short selectionLevel, unsigned int conditionSentenceNr )
		{
		SelectionItem *searchItem = firstActiveSelectionItem();

		while( searchItem != NULL )
			{
			if( searchItem->selectionLevel() < selectionLevel &&
			searchItem->activeSentenceNr() == conditionSentenceNr )
				searchItem->isConditionCheckedForSolving = false;

			searchItem = searchItem->nextSelectionItem();
			}
		}

	ResultType SelectionList::checkSelectionItemForUsage( SelectionItem *unusedSelectionItem )
		{
		SelectionItem *searchItem = firstActiveSelectionItem();
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkSelectionForUsageInWord";

		if( unusedSelectionItem != NULL )
			{
			while( searchItem != NULL )
				{
				if( searchItem->nextExecutionItem() == unusedSelectionItem )
					return startError( functionNameString, NULL, "The reference selection item is still in use" );

				searchItem = searchItem->nextSelectionItem();
				}
			}
		else
			return startError( functionNameString, NULL, "The given unused justification item is undefined" );

		return commonVariables()->result;
		}

	ResultType SelectionList::checkWordItemForUsage( WordItem *unusedWordItem )
		{
		SelectionItem *searchItem = firstActiveSelectionItem();
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkWordItemForUsage";

		if( unusedWordItem != NULL )
			{
			while( searchItem != NULL )
				{
				if( searchItem->generalizationWordItem() == unusedWordItem )
					return startError( functionNameString, NULL, "The generalization word item is still in use" );

				if( searchItem->specificationWordItem() == unusedWordItem )
					return startError( functionNameString, NULL, "The specification word item is still in use" );

				searchItem = searchItem->nextSelectionItem();
				}
			}
		else
			return startError( functionNameString, NULL, "The given unused word item is undefined" );

		return commonVariables()->result;
		}

	SelectionResultType SelectionList::checkDuplicateCondition()
		{
		SelectionResultType selectionResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkDuplicateCondition";

		selectionResult.duplicateConditionSentenceNr = commonVariables()->currentSentenceNr;

		do	{
			if( ( selectionResult.duplicateConditionSentenceNr = getLowerSentenceNr( selectionResult.duplicateConditionSentenceNr ) ) > NO_SENTENCE_NR )
				{
				if( ( selectionResult = checkDuplicateSelectionPart( selectionResult.duplicateConditionSentenceNr ) ).result != RESULT_OK )
					addError( functionNameString, NULL, "I failed to check if the alternative selection part is duplicate" );
				}
			}
		while( commonVariables()->result == RESULT_OK &&
		!selectionResult.hasFoundDuplicateSelection &&
		selectionResult.duplicateConditionSentenceNr > NO_SENTENCE_NR );

		selectionResult.result = commonVariables()->result;
		return selectionResult;
		}

	SelectionResultType SelectionList::checkDuplicateSelectionPart( unsigned int duplicateConditionSentenceNr )
		{
		SelectionResultType selectionResult;
		SelectionItem *currentSelectionItem = NULL;
		SelectionItem *searchItem = firstActiveSelectionItem();
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkDuplicateSelectionPart";

		if( duplicateConditionSentenceNr > NO_SENTENCE_NR )
			{
			if( duplicateConditionSentenceNr < commonVariables()->currentSentenceNr )
				{
				selectionResult.hasFoundDuplicateSelection = true;

				while( searchItem != NULL &&
				searchItem->activeSentenceNr() >= duplicateConditionSentenceNr )
					{
					if( searchItem->activeSentenceNr() == duplicateConditionSentenceNr )
						{
						currentSelectionItem = firstActiveSelectionItem();

						do	{
							if( currentSelectionItem->isAction() == searchItem->isAction() &&
							currentSelectionItem->isAssignedOrClear() == searchItem->isAssignedOrClear() &&
							currentSelectionItem->isNegative() == searchItem->isNegative() &&
							currentSelectionItem->isNewStart() == searchItem->isNewStart() &&
							currentSelectionItem->selectionLevel() == searchItem->selectionLevel() &&
							currentSelectionItem->generalizationWordItem() == searchItem->generalizationWordItem() &&
							currentSelectionItem->specificationWordItem() == searchItem->specificationWordItem() )
								{
								if( currentSelectionItem->specificationString() != NULL &&
								searchItem->specificationString() != NULL )
									selectionResult.hasFoundDuplicateSelection = ( strcmp( currentSelectionItem->specificationString(), searchItem->specificationString() ) == 0 );
								else
									{
									if( currentSelectionItem->specificationString() != NULL ||
									searchItem->specificationString() != NULL )
										selectionResult.hasFoundDuplicateSelection = false;
									}

								if( selectionResult.hasFoundDuplicateSelection )
									{
									currentSelectionItem = ( currentSelectionItem->nextSelectionItem() != NULL &&
															currentSelectionItem->nextSelectionItem()->hasCurrentCreationSentenceNr() ? currentSelectionItem->nextSelectionItem() : NULL );

									searchItem = ( searchItem->nextSelectionItem() != NULL &&
												searchItem->nextSelectionItem()->activeSentenceNr() == duplicateConditionSentenceNr ? searchItem->nextSelectionItem() : NULL );
									}
								else
									searchItem = NULL;
								}
							else
								{
								selectionResult.hasFoundDuplicateSelection = false;
								searchItem = NULL;
								}
							}
						while( selectionResult.hasFoundDuplicateSelection &&
						currentSelectionItem != NULL &&
						searchItem != NULL );
						}
					else
						searchItem = searchItem->nextSelectionItem();
					}
				}
			else
				startError( functionNameString, NULL, "The given duplicate sentence number is equal or higher than the current sentence number" );
			}
		else
			startError( functionNameString, NULL, "The given duplicate sentence number is undefined" );

		selectionResult.result = commonVariables()->result;
		return selectionResult;
		}

	SelectionResultType SelectionList::createSelectionItem( bool isAction, bool isAssignedOrClear, bool isDeactive, bool isArchived, bool isFirstComparisonPart, bool isNewStart, bool isNegative, bool isPossessive, bool isValueSpecification, unsigned short selectionLevel, unsigned short imperativeParameter, unsigned short prepositionParameter, unsigned short specificationWordParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int nContextRelations, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString )
		{
		SelectionResultType selectionResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "createSelectionItem";

		if( generalizationWordTypeNr > WORD_TYPE_UNDEFINED &&
		generalizationWordTypeNr < NUMBER_OF_WORD_TYPES )
			{
			if( specificationWordTypeNr > WORD_TYPE_UNDEFINED &&
			specificationWordTypeNr < NUMBER_OF_WORD_TYPES )
				{
				if( commonVariables()->currentItemNr < MAX_ITEM_NR )
					{
					if( ( selectionResult.lastCreatedSelectionItem = new SelectionItem( isAction, isAssignedOrClear, isDeactive, isArchived, isFirstComparisonPart, isNewStart, isNegative, isPossessive, isValueSpecification, selectionLevel, imperativeParameter, prepositionParameter, specificationWordParameter, generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, generalizationContextNr, specificationContextNr, relationContextNr, nContextRelations, generalizationWordItem, specificationWordItem, relationWordItem, specificationString, this, myWord(), commonVariables() ) ) != NULL )
						{
						if( addItemToActiveList( (Item *)selectionResult.lastCreatedSelectionItem ) != RESULT_OK )
							addError( functionNameString, NULL, "I failed to add an active selection item" );
						}
					else
						startError( functionNameString, NULL, "I failed to create a selection item" );
					}
				else
					startError( functionNameString, NULL, "The current item number is undefined" );
				}
			else
				startError( functionNameString, NULL, "The given specification word type number is undefined or out of bounds" );
			}
		else
			startError( functionNameString, NULL, "The given generalization word type number is undefined or out of bounds" );

		selectionResult.result = commonVariables()->result;
		return selectionResult;
		}

	SelectionItem *SelectionList::executionStartEntry( unsigned short executionLevel, unsigned int executionSentenceNr )
		{
		SelectionItem *searchItem = firstActiveSelectionItem();

		while( searchItem != NULL &&
		searchItem->activeSentenceNr() >= executionSentenceNr )
			{
			if( searchItem->activeSentenceNr() == executionSentenceNr &&
			searchItem->selectionLevel() == executionLevel )
				return searchItem;

			searchItem = searchItem->nextSelectionItem();
			}

		return NULL;
		}

	SelectionItem *SelectionList::firstActiveSelectionItem()
		{
		return (SelectionItem *)firstActiveItem();
		}

	SelectionItem *SelectionList::firstConditionSelectionItem( unsigned int conditionSentenceNr )
		{
		SelectionItem *searchItem = firstActiveSelectionItem();

		while( searchItem != NULL &&
		searchItem->activeSentenceNr() >= conditionSentenceNr )
			{
			if( searchItem->activeSentenceNr() == conditionSentenceNr )
				return searchItem;

			searchItem = searchItem->nextSelectionItem();
			}

		return NULL;
		}

	SelectionResultType SelectionList::findFirstExecutionItem( WordItem *solveWordItem )
		{
		SelectionResultType selectionResult;
		SelectionItem *firstSelectionItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findFirstExecutionItem";

		if( ( firstSelectionItem = firstActiveSelectionItem() ) != NULL )
			{
			if( firstSelectionItem->findNextExecutionSelectionItem( true, solveWordItem ) == RESULT_OK )
				selectionResult.firstExecutionItem = firstSelectionItem->nextExecutionItem();
			else
				addError( functionNameString, NULL, "I failed to find the first execution selection item" );
			}

		selectionResult.result = commonVariables()->result;
		return selectionResult;
		}

/*************************************************************************
 *
 *	"Everywhere - from east to west -
 *	praise the name of the Lord.
 *	For the Lord is high above the nations;
 *	his glory is higher than the heavens." (Psalm 113:3-4)
 *
 *************************************************************************/
