/* License/copyright: read copyright.txt */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>
#include <unistd.h>
#include <time.h>
#include "utils.h"
#include "definitions.h"

/*------------- functions ------------*/
void errmalloc(char *msg) {
  ERRPOS
  fprintf(stderr," memory allocation - %s\n",msg);
  exit(EXIT_FAILURE);
}

/* --------- string functions ----------- */
void strtolower(char *s){
/* convert to lower ascii string */
  while (*s) {
    *s=tolower(*s);
    s++;
  }
}

int StrToChar(char *s0,char *s1,char s2) {
/* in s0, replace a substring s1 with a single char s2
 return the nb of operation
 ex. &nbsp; => ' ' &quot; => ':'
*/
char *str_ptr;
int nb,lg;

  lg=strlen(s1);
  str_ptr=s0;
  nb=0;
  while ((str_ptr=strstr(str_ptr,s1)) != NULL) { 
    nb++;
    *str_ptr=s2;
    strcpy(str_ptr+1,str_ptr+lg);
  }
  return nb;
}

int StripSpace(char *s) {
/*strip space before and after*/
char *str_ptr;
int i=0;
  while (*(s+i) == ' ') i++;
  if (i > 0) strcpy(s,s+i);
  str_ptr=s+strlen(s)-1; //point to the end-of-string
  while (*str_ptr == ' ') {*str_ptr='\0'; str_ptr--; i++;}
  return i;
}

int chartoi(char c) {
/*convert single char in integer, int (0..35):0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ*/
int val;
  val=((int)(c))-48; //numeric
  if (val < 0) return 0;
  if (val > 9) {
    val=((int)(c))-55; //uppercase
    if ((val < 10) || (val > 35)) return 0;
  }
  return val;
}

/* --------- file functions ------------- */
long int filesize(char *filename){
/*return size of the file, -1 if does not exist*/
FILE *fp;
long int size;
  if ((fp=fopen(filename,"rb")) == NULL) return -1;
  fseek(fp,0,SEEK_END);
  size=ftell(fp);
  fclose(fp);
  return size;
}

int testdir(char *path_dictionary){
/* Correct a little bit the path name and verify if access is possible*/
FILE *fp;
char file_test[MEDIUM_STR];
  if (path_dictionary[strlen(path_dictionary)-1] != '/') strcat(path_dictionary,"/");
  if (strlen(path_dictionary) >= MEDIUM_STR-24) return(0); //too long
  strcpy(file_test,path_dictionary);
  strcat(file_test,"texlexan_justaweird.test"); //24 chars
  if ((fp=fopen(file_test,"w"))==NULL) return(0); //access pb?
  fclose(fp);
  remove(file_test);
  return(1); //good
}

int readandsave(char *file) {
/*Unbrainy function to get char from stdin and save it in file
useful with pipe in shell - return nb of byte recorded
*/
FILE *fp;
int lg=0;
char ch;
  if ((fp=fopen(file,"w")) == NULL) {
    ERRPOS
    fprintf(stderr,"Unable to create %s ->Exit!\n",file);
    exit(EXIT_FAILURE);
  }
  while (scanf("%c",&ch) != EOF) {
    fprintf(fp,"%c",ch);
    lg++;
  }
  fclose(fp);
  return lg;
}

void inverseordre(char *result,int nb,int width){
/*First line will be the last*/
long int i,j;
char *word;

  if ((word = (char*)malloc(width+1)) == NULL) errmalloc("inverseordre");  
  j=(nb-1)*width;
  for(i=0;i<j;i+=width) {
    strcpy(word,result+i);
    strcpy(result+i,result+j);
    strcpy(result+j,word);
    /*printf("w%s i%s=i%i j%s=j%i\n",word,result+i,i,result+j,j);*/
    j-=width;
  }
  free(word);
}

int syllablescount(char *strpt, char efinal) {
/*
 Count syllable in a word
 it is approximate because e accent is simple e 
*/
  char ch,prevch;
  int n=0;
  int i=0;
  int j=0;
  if (strpt == '\0') { 
    ERRPOS
    fprintf(stderr,"Syllablescount->empty word\n"); 
	return 0;
  }
  while ((ch=*strpt++) != '\0') {
    if (isalpha(ch)) {
      if (strchr("aeiouy",ch) != NULL) {
        i=1;
        if (i != j) n++;
      }
      else i=0;
      j=i;
      prevch=ch;
    }
  }
  if ((efinal) && (n>1) && ('e'==prevch)) n--;
  return n;
}

int minimum(int a,int b,int c) {
/*Gets the minimum of three values*/
  int min=a;
  if(b<min) min=b;
  if(c<min) min=c;
  return min;
}

int levenshtein_distance(char *s,char *t) {
/*Compute levenshtein distance between s and t*/
  int k,i,j,n,m,cost,*d,distance;
  n=strlen(s); 
  m=strlen(t);
  if ((n!=0) && (m!=0))
  {
    if ((d=malloc((sizeof(int))*(m+1)*(n+1))) == NULL) errmalloc("levenshtein");
    m++;
    n++;
    for(k=0;k<n;k++) d[k]=k;
    for(k=0;k<m;k++) d[k*n]=k;
    for(i=1;i<n;i++)
      for(j=1;j<m;j++) {
        if(s[i-1]==t[j-1]) cost=0;
        else cost=1;
        d[j*n+i]=minimum(d[(j-1)*n+i]+1,d[j*n+i-1]+1,d[(j-1)*n+i-1]+cost);
      }
    distance=d[n*m-1];
    free(d);
    return distance;
  }
  else return -1; //string empty.
}

char *strjstr(char *s1,char *s2,char delimiter,int nbcharprefix) {
//!!! not fully tested
/* Search s2 in s1 - each word in s1 must be delimited
 * ex: delimiter is '/'
 * /...prefix1....----word1----/...prefix2....-----word2------/
 * Should be a little bit faster than strstr if nbcharprefix is large */
char *str_ptr1,*str_ptr2,*str_ptr_delim;
  str_ptr1=s1;
  str_ptr2=s2;
  while(*str_ptr1 != '\0') {
    if (*str_ptr1 == *str_ptr2) { //both chars match, continue to the next chars
      str_ptr1++;
      str_ptr2++;
      if (*str_ptr2 == '\0') return str_ptr_delim; //end of s2, term found, return pointer to delimiter before the term
    }
    else { //no match, skip to the next term in s1, reset pointer to the beginning of s2
      str_ptr2=s2;
      //seach for the delimiter, a waste of time, a table of pointers on each terms will be better!
      str_ptr1=strchr(str_ptr1,delimiter);
	  if ( !str_ptr1 ) return 0; //not found & no delimiter
	  str_ptr1+=nbcharprefix; //skip to the next term
      str_ptr_delim=str_ptr1;
    }
  }
  return 0; //not found
}


char *astrstr(char *s1, char *s2, int nocase, int *errcnt) {
//!!! not fully tested - created dec 14,2009
/* Approximate search of s2 in s1
 * nocase==0 => cases must match
 * return a pointer on the first occurence of s1 in s2 and the
 * number of errors.
 * return NULL if not found
 * can fail in some cases, for instance:  
 * astrstr("ubuntu,ubunotu") works but astrstr("ubuntu,ubunutu) fails 
 * cost O(mn)
 */
char *str_ptr0, *str_ptr1,*str_ptr2;
  str_ptr0=s1;
  str_ptr1=s1;
  str_ptr2=s2;
  *errcnt=0;
  while( *str_ptr1 != '\0' ) {
	if (( *str_ptr1 == *str_ptr2 ) || 
	     ( nocase && (toupper(*str_ptr1) == toupper(*str_ptr2)))) 
	{
		/* both chars match, continue */
		str_ptr1++;
		str_ptr2++;
		if (*str_ptr2 == '\0') return str_ptr0; //found
		if (*(str_ptr2+1) == '\0') {
			if ( *str_ptr1 == *str_ptr2 ) return str_ptr0; //found
			if ( nocase && (toupper(*str_ptr1) == toupper(*str_ptr2)))
				return str_ptr0; //found
			(*errcnt)++;
			return str_ptr0; //found
		}
	}
	/* wrong char? */
	else if (( *(str_ptr1+1) == *(str_ptr2+1) ) || 
		( nocase && (toupper(*(str_ptr1+1)) == toupper(*(str_ptr2+1)))))
	{
		str_ptr1+=2;
		str_ptr2+=2;
		(*errcnt)++;
		if (*str_ptr2 == '\0') return str_ptr0; //found
	}
	/* inversion */
	else if (( *(str_ptr1) == *(str_ptr2+1) && *(str_ptr1+1) == *str_ptr2 ) || 
		( nocase && ( toupper(*str_ptr1) == toupper(*(str_ptr2+1)) && 
			( nocase && ( toupper(*(str_ptr1+1)) == toupper(*str_ptr2) )))))
	{
		/* inversion */
		str_ptr1+=2;
		str_ptr2+=2;
		(*errcnt)++;
		if (*str_ptr2 == '\0') return str_ptr0; //found
	}
	/* missing char in s2? */
	else if ( str_ptr2 > s2 && ( *(str_ptr1+1) == *str_ptr2  || 
		( nocase && (toupper(*(str_ptr1+1)) == toupper(*str_ptr2)))))
	{
		str_ptr1+=2;
		str_ptr2++;
		(*errcnt)++;
		if (*str_ptr2 == '\0') return str_ptr0; //found
	}
	/* missing char in s1? */
	else if ( str_ptr2 > s2 && ( *str_ptr1 == *(str_ptr2+1)  || 
		( nocase && (toupper(*str_ptr1) == toupper(*(str_ptr2+1))))))
	{
		str_ptr1++;
		str_ptr2+=2;
		(*errcnt)++;
		if (*str_ptr2 == '\0') return str_ptr0; //found
	}
	else {
	  /* next char in s1, reset to the beginning of s2 */
	  str_ptr2=s2;
	  str_ptr1++;
	  *errcnt=0;
	  str_ptr0=str_ptr1;
	}
  }
  return NULL; //no found
}

char *weakstemmer(char *word){
// created dec 14,2009
/* Simplify a word a very tiny bit */
char *w;
int lg;
	lg=strlen(word);
    if (lg < 3) return word; //exclude as, es...
	w=strdup(word);
	lg--;
    if (w[lg]=='s') lg--;
	if (w[lg]=='e') lg--;
	if (w[lg]==w[lg-1]) lg--;
	if (strchr("aeiou",w[lg]) != NULL) lg--;
	w[lg+1]='\0';
	return w;
}

int arenumbers(char *word) {
/*Return 1 if it's only a number 
null or eol terminated string*/
int i=0;
  while (word[i] != '\0'&& word[i] != '\n') {
    if (!isdigit(word[i])) return 0;
	i++;
  }
  return 1;
}

int numberinbraket(char *word) {
/*Return 1 if number between brakets*/
int i,j;
  j=strlen(word);
  if (j < 3) return 0;
  if (strchr("({[",word[0]) == NULL) return 0;
  if (strchr(")}]",word[j]) == NULL) return 0;
  for (i=1;i<j;i++) if (strchr("0123456789",word[i]) == NULL) return 0;
  return 1;
}

int str_cmp(const void *a,const void *b){
//sort from the highest to the lowest in a linear array (*result)
  return strcmp(b,a);
}

int array_str_cmp(const void *a,const void *b){
//sort from the lowest to the highest in a 2 dim array (**classname) 
    return(strcmp(*(char **)a,*(char **)b));
}

char *clever_print(int linewidth,char *strtoprint) {
/*
   insert '\n' after linewidth printed but avoid to cut words
   need to be optimized
*/
static int lineprinted; //nb of char currently printed
static char strline[SIZE_SENTENCE];
char *str;
int i,lg;

  *strline='\0';
  i=0;
  if (linewidth == 0) lineprinted=0; //reset
  str=strtoprint;
  if ((lg=strlen(str)) > SIZE_SENTENCE) {
    ERRPOS
    fprintf(stderr," in clever_print.\n");
    exit(EXIT_FAILURE);
  }
  while (lg > 0) {
    if (linewidth-lineprinted > lg) { //easy just concatenate string
      lineprinted+=lg;
      while (lg--) strline[i++]=*(str++);
      if (linewidth-lineprinted < lg+2) { //2 chars available is too tiny
        strline[i++]='\n'; //newline
	lineprinted=0; //recount from 0 because of newline
      }
      strline[i]='\0';
      //printf("|%i|",lg);
      return strline;
    }
    /*will exceed linewidth so inset '\n' just before a space char*/
    lg=linewidth-lineprinted-1; //lg of string if we accept to cut a word
    /*search the first space before lg chars*/
    while (--lg>2) {
      if (*(str+lg) == ' ') { 
        /*space found - copy from the beginning and quit the loop*/
        lg++;
        while (lg-->0) strline[i++]=*(str++);
        break;
      }
    }
    strline[i++]='\n'; //insert newline
    lg=strlen(str); //update length
    //lg=0; while (*(str+lg) != '\0') lg++;
    lineprinted=0; //recount from 0 because of newline
    //printf("{%i}",lg);
  }
  return strline;
}

char *strlevenstr(char *s1,char *s2,char delimiter1,char delimiter2,int distance) {
/*Search s2 in s1 - each word in s1 must be delimited - use Levenstein*/
char word[SIZE_WORD];
char *str_ptr,*str_ptrprev,*best_str_ptr=NULL;
int val,bestval;

  bestval=distance;
  best_str_ptr=0;
  str_ptr=s1;
  if ((str_ptr=strchr(str_ptr,delimiter1)) != NULL) {
    str_ptrprev=++str_ptr;
    while ((str_ptr=strchr(str_ptr,delimiter2)) != NULL) {
      if ((str_ptr-str_ptrprev) > 0) { //skip single char
        strncpy(word,str_ptrprev,(str_ptr-str_ptrprev+1));
        word[str_ptr-str_ptrprev]=0;
        val=levenshtein_distance(word,s2);
        if (val < bestval) {
          bestval=val;
          best_str_ptr=str_ptrprev;
        }
      }
      if ((str_ptr=strchr(str_ptr,delimiter1)) == NULL) break;
      str_ptrprev=++str_ptr;
    }
  }
  return best_str_ptr;
}

char toansi7b(unsigned char c) {
/*replace accentued char with unaccentued char*/
  /*uppercase*/
  if ((c>=0xc0) && (c<=0xc5)) return 'a';
  else if (c==0xc6) return '_'; //ae
  else if (c==0xc7) return 'c';
  else if ((c>=0xc8) && (c<=0xcb)) return 'e';
  else if ((c>=0xcc) && (c<=0xcf)) return 'i';
  else if (c==0xd0) return '_'; //?
  else if (c==0xd1) return '_'; //?
  else if ((c>=0xd2) && (c<=0xd6)) return 'o';
  else if (c==0xd7) return '/';
  else if (c==0xd8) return '_'; //?
  else if ((c>=0xd9) && (c<=0xdc)) return 'u';
  else if (c==0xdd) return 'y';
  else if (c==0xde) return '_'; //?
  else if (c==0xdf) return 'y';
  /*lowercase*/
  else if ((c>=0xe0) && (c<=0xe5)) return 'a';
  else if (c==0xe6) return '_'; //ae
  else if (c==0xe7) return 'c';
  else if ((c>=0xe8) && (c<=0xeb)) return 'e';
  else if ((c>=0xec) && (c<=0xef)) return 'i';
  else if (c==0xf0) return '_'; //?
  else if (c==0xf1) return '_'; //?
  else if ((c>=0xf2) && (c<=0xf6)) return 'o';
  else if (c==0xf7) return '/';
  else if (c==0xf8) return '_'; //?
  else if ((c>=0xf9) && (c<=0xfc)) return 'u';
  else if (c==0xfd) return 'y';
  else if (c==0xfe) return '_'; //?
  else if (c==0xff) return 'y';
  else return c;
}

char *str7bstr(char *s1,char *s2,int end) {
/*
  Almost like strstr but for the string s1 uppercase are replaced with lowercase
  and accentued chars are replaced with unaccentued (ascii 7bits)
  s2 is not converted and must contain only ascii 7 bits
  end==1 return the end of the s2 in s1, end==0 return the beginning of s2 in s1
*/
long int offset;
char *start_pos;

  if ((*s1=='\0') || (*s2=='\0')) return '\0';
  
  while (*s1 != '\0') {
    offset=0;
	start_pos=s1;
    while (tolower(toansi7b(*s1)) == *(s2+offset)) {
      offset++;
      if (*(s2+offset) == '\0') {
	    if (end) return s1-1;
		else return start_pos;
	  }
      s1++;
      if (*s1 == '\0') return '\0';
    }
    s1++;
  }
  return '\0';
}

char *strlstr(char *s1,char *s2) {
/*
  Almost like strstr but for the string s1 uppercase are replaced with lowercase
  and accentued chars are replaced with unaccentued (ascii 7bits)
  s2 is not converted and must contain only ascii 7 bits
  end==1 return the end of the s2 in s1
*/
long int offset;
char *start_pos;

  if ((*s1=='\0') || (*s2=='\0')) return '\0';
  
  while (*s1 != '\0') {
    offset=0;
	start_pos=s1;
    while (tolower(*s1) == *(s2+offset)) {
      offset++;
      if (*(s2+offset) == '\0') {
	    return start_pos;
	  }
      s1++;
      if (*s1 == '\0') return '\0';
    }
    s1++;
  }
  return '\0';
}


int countword(char *s) {
/*count separator/space (continuous separator are counted as one)
nb of word = nb of separator + 1 */
int prev_sep=1; //want the first char not a separator
int cnt_sep=0;

  while (*s != '\0') {
    if (*s == ' ') {
	  if (!prev_sep) { //don't count continuous separator
	    cnt_sep++;
		prev_sep=1;
	  }
	} else prev_sep=0;
	s++;
  }
  if (!prev_sep) cnt_sep++; //count the last word
  return cnt_sep;
}

char *deletebetween(char *text,char del1,char del2) {
/*Delete sentences between 2 delimiters del1, del2
if there's punctuation after del2 the space before del1 is crunched 
*/
  char *top_text,*str_ptr1;

  top_text=text;
  while (*text != '\0') {
    if (*text == del1) {
	  str_ptr1=text;
	  text++;
	  while (*text != '\0') {
        if (*text == del2) {
		  if (strchr(".,;?!",*(text+1)) != NULL 
		          && str_ptr1 > top_text 
			            && *(str_ptr1-1)==' ') {
			/*punctuation crunches the space*/
		    strcpy(str_ptr1-1,text+1);
		  } else strcpy(str_ptr1,text+1);
		  text=str_ptr1;
		  break;
		}
	    text++;
      } 
	}
	text++;
  }
  text=top_text;
  return str_ptr1;
}

long int countalpha(char *s) {
/*count only alphabetic chars*/
long int i=0;
  while (*s!= '\0') {
    if (isalpha(*s)) i++;
    s++;
  }
  return i;
}

long int countchar(char *s,char ch) {
/*count only alphabetic chars*/
long int i=0;
char *str_ptr=s;

  while ((str_ptr=strchr(str_ptr,ch)) != 0) {i++; str_ptr++;}  
  return i;
}


long int hashsentence(char *s) {
/* 
 * Return a value enough characterisc of the sentence
 * 2000000000
 */
long int v1=0,v2=0,v3=0,v4=0,v5=0,v6=0,v7=0;
  if (*s=='\0') return 0;
  v1=countword(s);
  if (v1>99) { v1=99; fprintf(stderr,"\nhashsentence, v1 err.\n"); }
  v2=syllablescount(s,0);
  if (v2>99) { v2=99; fprintf(stderr,"\nhashsentence, v2 err.\n"); }
  v3=countchar(s,'r');
  if (v3>9) { v3=9; fprintf(stderr,"\nhashsentence, v3 err.\n"); }
  v4=countchar(s,'k');
  if (v4>9) { v4=9; fprintf(stderr,"\nhashsentence, v4 err.\n"); }
  v5=countchar(s,'j');
  if (v5>9) { v5=9; fprintf(stderr,"\nhashsentence, v5 err.\n"); }
  v5=countchar(s,'g');
  if (v6>9) { v5=9; fprintf(stderr,"\nhashsentence, v6 err.\n"); }
  v5=countchar(s,'d');
  if (v7>9) { v5=9; fprintf(stderr,"\nhashsentence, v7 err.\n"); }
  /* |v1 2 digits|v2 2 digits|v3 1 digit|v4 1 digit|v5 1 digit|v6 1 digit|v7 1 digit| */
  return 10*(10*(10*(10*(10*(100*v1+v2)+v3)+v4)+v5)+v6)+v7;
}

unsigned long long weakhashsentence(char *s,char *lang) {
/* 
 * Return a value enough characterisc of the sentence
 * 2000000000
 */
unsigned int v0=0,v1=0,v2=0,v3=0,v4=0,v5=0,v6=0,v7=0,v8=0,v9=0;
unsigned int v10=0,v11=0,v12=0,v13=0,v14=0;
unsigned long long result;
char *str_ptr;
char previous;

  str_ptr=s;
  if (strcmp(lang,"en")==0) {
    while (*str_ptr != 0) {
      if (*str_ptr == ' ' && previous != ' ' && v0<0xFF) {v0++; previous=*str_ptr;}
      else if (*str_ptr=='z' && previous !='z' && v1<0x0F) {v1++; previous=*str_ptr;}
      else if (*str_ptr=='w' && previous !='w' && v2<0x0F) {v2++; previous=*str_ptr;}
      else if (*str_ptr=='v' && previous !='v' && v3<0x0F) {v3++; previous=*str_ptr;}
      else if (*str_ptr=='q' && previous !='q' && v4<0x0F) {v4++; previous=*str_ptr;}
      else if (*str_ptr=='m' && previous !='m' && v5<0x0F) {v5++; previous=*str_ptr;}
      else if (*str_ptr=='l' && previous !='l' && v6<0x0F) {v6++; previous=*str_ptr;}
      else if (*str_ptr=='k' && previous !='k' && v7<0x0F) {v7++; previous=*str_ptr;}
      else if (*str_ptr=='j' && previous !='j' && v8<0x0F) {v8++; previous=*str_ptr;}
      else if (*str_ptr=='h' && previous !='h' && v9<0x0F) {v9++; previous=*str_ptr;}
      else if (*str_ptr=='g' && previous !='g' && v10<0x0F) {v10++; previous=*str_ptr;}
      else if (*str_ptr=='f' && previous !='f' && v11<0x0F) {v11++; previous=*str_ptr;}
      else if (*str_ptr=='d' && previous !='d' && v12<0x0F) {v12++; previous=*str_ptr;}
      else if (*str_ptr=='c' && previous !='c' && v13<0x0F) {v13++; previous=*str_ptr;}
      else if (*str_ptr=='b' && previous !='b' && v14<0x0F) {v14++; previous=*str_ptr;}
      else previous=*str_ptr;
      str_ptr++;
    }
  }
  else if (strcmp(lang,"fr")==0) {
    while (*str_ptr != 0) {
      if (*str_ptr == ' ' && previous != ' ' && v0<0xFF) {v0++; previous=*str_ptr;}
      else if (*str_ptr=='z' && previous !='z' && v1<0x0F) {v1++; previous=*str_ptr;}
      else if (*str_ptr=='w' && previous !='w' && v2<0x0F) {v2++; previous=*str_ptr;}
      else if (*str_ptr=='v' && previous !='v' && v3<0x0F) {v3++; previous=*str_ptr;}
      else if (*str_ptr=='q' && previous !='q' && v4<0x0F) {v4++; previous=*str_ptr;}
      else if (*str_ptr=='m' && previous !='m' && v5<0x0F) {v5++; previous=*str_ptr;}
      else if (*str_ptr=='l' && previous !='l' && v6<0x0F) {v6++; previous=*str_ptr;}
      else if (*str_ptr=='k' && previous !='k' && v7<0x0F) {v7++; previous=*str_ptr;}
      else if (*str_ptr=='j' && previous !='j' && v8<0x0F) {v8++; previous=*str_ptr;}
      else if (*str_ptr=='h' && previous !='h' && v9<0x0F) {v9++; previous=*str_ptr;}
      else if (*str_ptr=='g' && previous !='g' && v10<0x0F) {v10++; previous=*str_ptr;}
      else if (*str_ptr=='f' && previous !='f' && v11<0x0F) {v11++; previous=*str_ptr;}
      else if (*str_ptr=='d' && previous !='d' && v12<0x0F) {v12++; previous=*str_ptr;}
      else if (*str_ptr=='c' && previous !='c' && v13<0x0F) {v13++; previous=*str_ptr;}
      else if (*str_ptr=='b' && previous !='b' && v14<0x0F) {v14++; previous=*str_ptr;}
      else previous=*str_ptr;
      str_ptr++;
    }
  }
  else {
    while (*str_ptr != 0) {
      if (*str_ptr == ' ' && previous != ' ' && v0<0xFF) {v0++; previous=*str_ptr;}
      else if (*str_ptr=='z' && previous !='z' && v1<0x0F) {v1++; previous=*str_ptr;}
      else if (*str_ptr=='w' && previous !='w' && v2<0x0F) {v2++; previous=*str_ptr;}
      else if (*str_ptr=='v' && previous !='v' && v3<0x0F) {v3++; previous=*str_ptr;}
      else if (*str_ptr=='q' && previous !='q' && v4<0x0F) {v4++; previous=*str_ptr;}
      else if (*str_ptr=='m' && previous !='m' && v5<0x0F) {v5++; previous=*str_ptr;}
      else if (*str_ptr=='l' && previous !='l' && v6<0x0F) {v6++; previous=*str_ptr;}
      else if (*str_ptr=='k' && previous !='k' && v7<0x0F) {v7++; previous=*str_ptr;}
      else if (*str_ptr=='j' && previous !='j' && v8<0x0F) {v8++; previous=*str_ptr;}
      else if (*str_ptr=='h' && previous !='h' && v9<0x0F) {v9++; previous=*str_ptr;}
      else if (*str_ptr=='g' && previous !='g' && v10<0x0F) {v10++; previous=*str_ptr;}
      else if (*str_ptr=='f' && previous !='f' && v11<0x0F) {v11++; previous=*str_ptr;}
      else if (*str_ptr=='d' && previous !='d' && v12<0x0F) {v12++; previous=*str_ptr;}
      else if (*str_ptr=='c' && previous !='c' && v13<0x0F) {v13++; previous=*str_ptr;}
      else if (*str_ptr=='b' && previous !='b' && v14<0x0F) {v14++; previous=*str_ptr;}
      else previous=*str_ptr;
      str_ptr++;
    }
  }
    
  /* result 64bits     cumul bits */
  result=v0;              //  8
  result=(result<<4)+v1;  // 12
  result=(result<<4)+v2;  // 16
  result=(result<<4)+v3;  // 20
  result=(result<<4)+v4;  // 24
  result=(result<<4)+v5;  // 28
  result=(result<<4)+v6;  // 32
  result=(result<<4)+v7;  // 36
  result=(result<<4)+v8;  // 40
  result=(result<<4)+v9;  // 44
  result=(result<<4)+v10; // 48
  result=(result<<4)+v11; // 52
  result=(result<<4)+v12; // 56
  result=(result<<4)+v13; // 60
  result=(result<<4)+v14; // 64

  return result;
}

char *extract_val(long int *value,char *line,char *sub_str) {
/*extract between a sub_string and a char other than a digit
 * return the value and the position of the next char*/
char *str_ptr1,*str_ptr2;
  
  if ((str_ptr1=strstr(line,sub_str)) != NULL) {
    str_ptr1+=strlen(sub_str);
    str_ptr2=str_ptr1;
    while (isdigit(*str_ptr2)) str_ptr2++;
    *value=atol(str_ptr1);
    return str_ptr2; //position of the first char none digit
  }
  return NULL; //no found or error
}

char *extract_str(char *s,int lg,char *line,char *sub_str) {
/*extract between a sub_string and a space/tab/eol
 * return the string and the position of the space*/
char *str_ptr1,*str_ptr2;
long int i=0;
  
  if ((str_ptr1=strstr(line,sub_str)) != NULL) {
    str_ptr1+=strlen(sub_str);
    str_ptr2=str_ptr1;
    while (isprint(*str_ptr2) && *str_ptr2 != ' ') {
			str_ptr2++; 
			i++;
		}
		if (i>=lg) { ERRPOS return NULL; }
    strncpy(s,str_ptr1,i);
	s[i]='\0';
    return str_ptr2; //position of the first char none alpha or space
  }
  return NULL; //no found or error
}

/* get environment information */
char *env(char *key) {
	FILE *fp;
	char *str,*str_ptr;
	char line[1024];
	fp = popen("env","r");
	if (fp==NULL) {
		ERRPOS;
		fprintf(stderr,"ERR cmd env");
		return 0;
	}
	while ( fgets(line,1024,fp) ) {
		if ((str_ptr=strstr(line,key)) != NULL)
			if (*(str_ptr+strlen(key)) == '=') {
				str=strdup(str_ptr+strlen(key)+1);
				if ((str_ptr=strchr(str,'\n')) != NULL)
					*str_ptr='\0';
				break;
			}
	}
	pclose(fp);
	return str;
}

/* extract a sub-string in a string delimited
 * return the position of the next delimiter or zero when done
 * truncate the substring when > size
 * use:
 * // SIZE of the substr
 * char strlist[]="toto,truc,bidule"; char substr[SIZE]; int i=0;
 * while ( (i=foreachstr(substr,strlist,",;",SIZE,i)) ) {...}
 */
int foreachstr(char *substring, char *stringslist, char *delimiters, int size, int i) {
	char *str_ptr;
	int j=0;
	
	str_ptr=stringslist;
	str_ptr+=i; //str_ptr points the first char or the previous delimiter
	if ( *str_ptr == '\0' ) return 0; //end of string
	if ( i > 0 ) { //char after the delimiter
		str_ptr++; 
		i++;
	}
	/* search a delimiter or end of string */
	while ( *(str_ptr+j) ) { //while not end of string
		if ( strchr(delimiters,*(str_ptr+j)) ) break; //if delimited
		j++;
	}
	/* copy the substring */
	if ( j < size ) {
		strncpy(substring,str_ptr,j);
		substring[j]='\0';
	} 
	else {
		strncpy(substring,str_ptr,size);
		substring[size]='\0';
	}
	return i+j;
}

/* make a list of labels of texlexan dictionary
 * struct: NN<space>label:..... 
 * or      label:.....  */
int listlabels(char *list,char *file,int size) {
  FILE *fp;
  char line[size];
  char *str_ptr;
  int n=0;

  fp=fopen(file,"r"); //dico
  if (fp==NULL){
    ERRPOS
    fprintf(stderr,"Unable to open %s ->Exit!\n",file);
    exit(EXIT_FAILURE);
  }
 
  fseek(fp,0,SEEK_SET);
  while ( fgets(line,size,fp) ) {
    if (line[0] != '#') { //skip comment
      if ((str_ptr=strchr(line,':')) != NULL) *str_ptr=0; //end of label
      if (strlen(line) < size) {
		  if ((str_ptr=strchr(line,' ')) == NULL) str_ptr=line+1; //beginning of label
		  if ( *list ) strcat(list,","); //delimiter of the list
		  strcat(list,str_ptr-1);
		  n++; //cnt label
	  }
      else {
	    ERRPOS
	    fprintf(stderr,"Err label too long\n");
	  }
    }
  } //endwhile
  return n;
}
