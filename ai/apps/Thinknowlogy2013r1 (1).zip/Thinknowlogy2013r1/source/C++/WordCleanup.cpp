/*
 *	Class:			WordCleanup
 *	Supports class:	WordItem
 *	Purpose:		To cleanup unnecessary items
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "List.h"
#include "WordItem.h"

class WordCleanup
	{
	// Private constructible variables

	CommonVariables *commonVariables_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	public:
	// Constructor

	WordCleanup( WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "WordCleanup" );

		if( commonVariables_ != NULL )
			{
		if( myWord_ == NULL )
			strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInWord( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
				if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	ResultType currentItemNr()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "currentItemNr";
		for( unsigned short wordListNr = 0; wordListNr < NUMBER_OF_WORD_LISTS; wordListNr++ )
			{
			if( myWord_->wordList[wordListNr] != NULL )
				{
				if( myWord_->wordList[wordListNr]->getCurrentItemNrInList() != RESULT_OK )
					return myWord_->addErrorInWord( myWord_->wordListChar( wordListNr ), functionNameString, moduleNameString_, "I failed to get the current item number" );
				}
			}

		return commonVariables_->result;
		}

	ResultType getHighestInUseSentenceNr( bool includeDeletedItems, bool includeLanguageAssignments, bool includeTemporaryLists, unsigned int highestSentenceNr )
		{
		unsigned short wordListNr = 0;
		char functionNameString[FUNCTION_NAME_LENGTH] = "getHighestInUseSentenceNr";

		while( wordListNr < NUMBER_OF_WORD_LISTS &&
		commonVariables_->highestInUseSentenceNr < highestSentenceNr )
			{
			if( myWord_->wordList[wordListNr] != NULL &&

			( includeLanguageAssignments ||
			!myWord_->isGrammarLanguage() ||
			wordListNr != WORD_ASSIGNMENT_LIST ) &&

			( includeTemporaryLists ||
			!myWord_->wordList[wordListNr]->isTemporaryList() ) )
				{
				if( myWord_->wordList[wordListNr]->getHighestInUseSentenceNrInList( includeDeletedItems, highestSentenceNr ) != RESULT_OK )
					return myWord_->addErrorInWord( myWord_->wordListChar( wordListNr ), functionNameString, moduleNameString_, "I failed to check if the given sentence is empty" );
				}

			wordListNr++;
			}

		return commonVariables_->result;
		}

	ResultType rollbackDeletedRedoInfo()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "rollbackDeletedRedoInfo";
		for( unsigned short wordListNr = 0; wordListNr < NUMBER_OF_WORD_LISTS; wordListNr++ )
			{
			if( myWord_->wordList[wordListNr] != NULL )
				{
				if( myWord_->wordList[wordListNr]->rollbackDeletedRedoInfoInList() != RESULT_OK )
					return myWord_->addErrorInWord( myWord_->wordListChar( wordListNr ), functionNameString, moduleNameString_, "I failed to delete the current redo info" );
				}
			}

		return commonVariables_->result;
		}

	ResultType deleteRollbackInfo()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteRollbackInfo";
		for( unsigned short wordListNr = 0; wordListNr < NUMBER_OF_WORD_LISTS; wordListNr++ )
			{
			if( myWord_->wordList[wordListNr] != NULL )
				{
				if( myWord_->wordList[wordListNr]->deleteRollbackInfoInList() != RESULT_OK )
					return myWord_->addErrorInWord( myWord_->wordListChar( wordListNr ), functionNameString, moduleNameString_, "I failed to delete the rollback info" );
				}
			}

		return commonVariables_->result;
		}

	ResultType decrementSentenceNrs( unsigned int startSentenceNr )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "decrementSentenceNrs";
		for( unsigned short wordListNr = 0; wordListNr < NUMBER_OF_WORD_LISTS; wordListNr++ )
			{
			if( myWord_->wordList[wordListNr] != NULL )
				{
				if( myWord_->wordList[wordListNr]->decrementSentenceNrsInList( startSentenceNr ) != RESULT_OK )
					return myWord_->addErrorInWord( myWord_->wordListChar( wordListNr ), functionNameString, moduleNameString_, "I failed to decrement the sentence numbers from the current sentence number in one of my lists" );
				}
			}

		return commonVariables_->result;
		}

	ResultType undoCurrentSentence()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "undoCurrentSentence";
		for( unsigned short wordListNr = 0; wordListNr < NUMBER_OF_WORD_LISTS; wordListNr++ )
			{
			if( myWord_->wordList[wordListNr] != NULL )
				{
				if( myWord_->wordList[wordListNr]->undoCurrentSentenceInList() != RESULT_OK )
					return myWord_->addErrorInWord( myWord_->wordListChar( wordListNr ), functionNameString, moduleNameString_, "I failed to undo the current sentence" );
				}
			}

		return commonVariables_->result;
		}

	ResultType redoCurrentSentence()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "redoCurrentSentence";
		for( unsigned short wordListNr = 0; wordListNr < NUMBER_OF_WORD_LISTS; wordListNr++ )
			{
			if( myWord_->wordList[wordListNr] != NULL )
				{
				if( myWord_->wordList[wordListNr]->redoCurrentSentenceInList() != RESULT_OK )
					return myWord_->addErrorInWord( myWord_->wordListChar( wordListNr ), functionNameString, moduleNameString_, "I failed to redo the current sentence" );
				}
			}

		return commonVariables_->result;
		}

	ResultType removeFirstRangeOfDeletedItems()
		{
		unsigned short wordListNr = 0;
		char functionNameString[FUNCTION_NAME_LENGTH] = "removeFirstRangeOfDeletedItems";

		while( wordListNr < NUMBER_OF_WORD_LISTS &&
		commonVariables_->nDeletedItems == 0 )
			{
			if( myWord_->wordList[wordListNr] != NULL )
				{
				if( myWord_->wordList[wordListNr]->removeFirstRangeOfDeletedItemsInList() != RESULT_OK )
					return myWord_->addErrorInWord( myWord_->wordListChar( wordListNr ), functionNameString, moduleNameString_, "I failed to remove the first deleted items" );
				}

			wordListNr++;
			}

		return commonVariables_->result;
		}

	ResultType decrementItemNrRange( unsigned int decrementSentenceNr, unsigned int decrementItemNr, unsigned int decrementOffset )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "decrementItemNrRange";
		for( unsigned short wordListNr = 0; wordListNr < NUMBER_OF_WORD_LISTS; wordListNr++ )
			{
			if( myWord_->wordList[wordListNr] != NULL )
				{
				if( myWord_->wordList[wordListNr]->decrementItemNrRangeInList( decrementSentenceNr, decrementItemNr, decrementOffset ) != RESULT_OK )
					return myWord_->addErrorInWord( myWord_->wordListChar( wordListNr ), functionNameString, moduleNameString_, "I failed to decrement item number range" );
				}
			}

		return commonVariables_->result;
		}

	ResultType deleteSentences( bool isAvailableForRollback, unsigned int lowestSentenceNr )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteSentences";
		for( unsigned short wordListNr = 0; wordListNr < NUMBER_OF_WORD_LISTS; wordListNr++ )
			{
			if( myWord_->wordList[wordListNr] != NULL )
				{
				if( myWord_->wordList[wordListNr]->deleteSentencesInList( isAvailableForRollback, lowestSentenceNr ) != RESULT_OK )
					return myWord_->addErrorInWord( myWord_->wordListChar( wordListNr ), functionNameString, moduleNameString_, "I failed to delete sentences in one of my lists" );
				}
			}

		return commonVariables_->result;
		}
	};

/*************************************************************************
 *
 *	"He has paid a full ransom for his people.
 *	He has guaranteed his convenant with them forever.
 *	What a holy, awe-inspiring name he has!" (Psalm 111:9)
 *
 *************************************************************************/
