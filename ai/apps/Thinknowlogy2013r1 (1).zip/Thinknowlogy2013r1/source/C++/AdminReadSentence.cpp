/*
 *	Class:			AdminReadSentence
 *	Supports class:	AdminItem
 *	Purpose:		To read and analyze sentences
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "AdminItem.h"
#include "Presentation.cpp"
#include "ReadList.cpp"

class AdminReadSentence
	{
	// Private constructible variables

	bool areReadItemsStillValid_;
	bool deleteRollbackInfo_;
	bool isAssignment_;
	bool isConditional_;
	bool isExclusive_;
	bool isDeactiveAssignment_;
	bool isArchivedAssignment_;
	bool isPossessive_;
	bool isSpecificationGeneralization_;
	bool isLinkedGeneralizationConjunction_;
	bool showConclusions_;

	unsigned short currentParseWordOrderNr_;
	unsigned short prepositionParameter_;
	unsigned short questionParameter_;

	unsigned int specificationCollectionNr_;
	unsigned int generalizationContextNr_;
	unsigned int specificationContextNr_;
	unsigned int relationContextNr_;

	ReadItem *currentReadItem_;
	ReadItem *startGeneralizationWordReadItem_;
	ReadItem *endGeneralizationWordReadItem_;
	ReadItem *startSpecificationWordReadItem_;
	ReadItem *endSpecificationWordReadItem_;
	ReadItem *startRelationWordReadItem_;
	ReadItem *endRelationWordReadItem_;

	CommonVariables *commonVariables_;
	AdminItem *admin_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	void setVerbVariables( unsigned short wordParameter )
		{
		switch( wordParameter )
			{
			case WORD_PARAMETER_SINGULAR_VERB_CAN_BE:
			case WORD_PARAMETER_PLURAL_VERB_CAN_BE:
				isConditional_ = true;
				break;

			case WORD_PARAMETER_SINGULAR_VERB_WAS:
			case WORD_PARAMETER_PLURAL_VERB_WERE:
				isAssignment_ = true;
				isArchivedAssignment_ = true;
				break;

			case WORD_PARAMETER_SINGULAR_VERB_HAS:
			case WORD_PARAMETER_PLURAL_VERB_HAVE:
				isPossessive_ = true;
				break;

			case WORD_PARAMETER_SINGULAR_VERB_HAD:
			case WORD_PARAMETER_PLURAL_VERB_HAD:
				isAssignment_ = true;
				isArchivedAssignment_ = true;
				isPossessive_ = true;
				break;
			}
		}

	void clearLastCheckedAssumptionLevelItemNrInAllWords()
		{
		WordItem *currentWordItem;

		if( ( currentWordItem = commonVariables_->firstWordItem ) != NULL )		// Do in all words
			{
			do	currentWordItem->clearLastCheckedAssumptionLevelItemNrInWord();
			while( ( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}
		}

	ResultType scanSpecification( char *readSentenceString )
		{
		ContextResultType contextResult;
		bool stop = false;
		unsigned short wordOrderNr;
		unsigned short wordParameter;
		unsigned short wordTypeNr;
		ReadItem *previousReadItem = NULL;
		WordItem *readWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "scanSpecification";

		isAssignment_ = false;
		isConditional_ = false;
		isExclusive_ = false;
		isDeactiveAssignment_ = false;
		isArchivedAssignment_ = false;
		isPossessive_ = false;
		isSpecificationGeneralization_ = false;

		currentParseWordOrderNr_ = NO_ORDER_NR;
		prepositionParameter_ = NO_PREPOSITION_PARAMETER;
		questionParameter_ = NO_QUESTION_PARAMETER;

		generalizationContextNr_ = NO_CONTEXT_NR;
		specificationContextNr_ = NO_CONTEXT_NR;
		relationContextNr_ = NO_CONTEXT_NR;

		startSpecificationWordReadItem_ = NULL;
		endSpecificationWordReadItem_ = NULL;
		startRelationWordReadItem_ = NULL;
		endRelationWordReadItem_ = NULL;

		if( currentReadItem_ != NULL )
			{
			if( isLinkedGeneralizationConjunction_ )
				isLinkedGeneralizationConjunction_ = false;
			else
				{
				startGeneralizationWordReadItem_ = NULL;
				endGeneralizationWordReadItem_ = NULL;
				}

			do	{
				wordOrderNr = currentReadItem_->wordOrderNr();
				wordParameter = currentReadItem_->wordParameter();
				wordTypeNr = currentReadItem_->wordTypeNr();
				readWordItem = currentReadItem_->readWordItem();

				switch( currentReadItem_->grammarParameter )
					{
					case GRAMMAR_SENTENCE:
						if( !currentReadItem_->isSeparator() )
							{
							if( readSentenceString != NULL &&
							admin_->isSystemStartingUp() )
								return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found an unknown word in sentence \"", readSentenceString, "\" at position ", wordOrderNr, " with grammar parameter ", currentReadItem_->grammarParameter, " and word parameter ", wordParameter );
							else
								return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found an unknown word at position ", wordOrderNr, " with grammar parameter ", currentReadItem_->grammarParameter, " and word parameter ", wordParameter );
							}

						break;

					case GRAMMAR_ANSWER:
						break;	// Needs to be implemented

					case GRAMMAR_GENERALIZATION_ASSIGNMENT:		// Assignment generalization-specification
						isAssignment_ = true;

						// Don't insert a break statement here

					case GRAMMAR_IMPERATIVE:
					case GRAMMAR_GENERALIZATION_SPECIFICATION:
					case GRAMMAR_GENERALIZATION_PART:
					case GRAMMAR_GENERALIZATION_WORD:
						if( currentReadItem_->isAdjectivePrevious() )
							{
							isAssignment_ = true;
							isDeactiveAssignment_ = true;
							}

						if( currentReadItem_->isReadWordDeterminerOrPronoun() )
							{
							if( generalizationContextNr_ == NO_CONTEXT_NR )
								{
								if( ( contextResult = admin_->addPronounContext( wordTypeNr, readWordItem ) ).result == RESULT_OK )
									generalizationContextNr_ = contextResult.contextNr;
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a generalization pronoun context" );
								}
							else
								return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The generalization context number is already assigned" );
							}

						if( startGeneralizationWordReadItem_ == NULL )
							startGeneralizationWordReadItem_ = currentReadItem_;

						endGeneralizationWordReadItem_ = currentReadItem_;

						break;

					case GRAMMAR_LINKED_GENERALIZATION_CONJUNCTION:
						stop = true;
						isLinkedGeneralizationConjunction_ = true;

						break;

					case GRAMMAR_EXCLUSIVE_SPECIFICATION_CONJUNCTION:
						isExclusive_ = true;

						break;

					case GRAMMAR_RELATION_PART:
					case GRAMMAR_RELATION_WORD:
							if( currentReadItem_->isPreposition() )
								prepositionParameter_ = wordParameter;

							if( startSpecificationWordReadItem_ == NULL )
								startSpecificationWordReadItem_ = currentReadItem_;

							endSpecificationWordReadItem_ = currentReadItem_;

							if( startRelationWordReadItem_ == NULL )
								startRelationWordReadItem_ = currentReadItem_;

							endRelationWordReadItem_ = currentReadItem_;

						switch( wordParameter )
							{
							case WORD_PARAMETER_NUMERAL_BOTH:				// Typically for English: in both ... and ...
							case WORD_PARAMETER_CONJUNCTION_DUTCH_ZOWEL:	// Typically for Dutch: in zowel ... als ...
								isExclusive_ = true;
								break;
							}

						break;

					case GRAMMAR_ASSIGNMENT_PART:
					case GRAMMAR_SPECIFICATION_ASSIGNMENT:
						isAssignment_ = true;

						if( currentReadItem_->isNegative() ||
						currentReadItem_->isReadWordDeterminerOrPronoun() )
							{
							if( specificationContextNr_ == NO_CONTEXT_NR )
								{
								if( ( contextResult = admin_->addPronounContext( wordTypeNr, readWordItem ) ).result == RESULT_OK )
									specificationContextNr_ = contextResult.contextNr;
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a specification pronoun context" );
								}
							else
								return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The specification context number is already assigned" );
							}

						// Don't insert a break statement here

					case GRAMMAR_SPECIFICATION_PART:
					case GRAMMAR_SPECIFICATION_WORD:
					case GRAMMAR_TEXT:
						if( startSpecificationWordReadItem_ == NULL )
							startSpecificationWordReadItem_ = currentReadItem_;

						endSpecificationWordReadItem_ = currentReadItem_;

						break;

					case GRAMMAR_RELATION_ASSIGNMENT:
						isAssignment_ = true;

						if( currentReadItem_->isNegative() ||
						currentReadItem_->isReadWordDeterminerOrPronoun() )
							{
							if( relationContextNr_ == NO_CONTEXT_NR )
								{
								if( ( contextResult = admin_->addPronounContext( wordTypeNr, readWordItem ) ).result == RESULT_OK )
									relationContextNr_ = contextResult.contextNr;
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a relation pronoun context" );
								}
							else
								return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The relation context number is already assigned" );
							}

						break;

					case GRAMMAR_QUESTION_VERB:
						questionParameter_ = WORD_PARAMETER_SINGULAR_VERB_IS;

						// Don't insert a break statement here

					case GRAMMAR_VERB:
						setVerbVariables( wordParameter );

						if( startSpecificationWordReadItem_ == NULL )
							startSpecificationWordReadItem_ = currentReadItem_;

						endSpecificationWordReadItem_ = currentReadItem_;

						break;

					case GRAMMAR_GENERALIZATION_QUESTION_VERB:
						questionParameter_ = WORD_PARAMETER_SINGULAR_VERB_IS;

						// Don't insert a break statement here

					case GRAMMAR_GENERALIZATION_VERB:
						isSpecificationGeneralization_ = true;
						setVerbVariables( wordParameter );

						if( startSpecificationWordReadItem_ == NULL )
							startSpecificationWordReadItem_ = currentReadItem_;

						endSpecificationWordReadItem_ = currentReadItem_;

						break;

					default:
						if( previousReadItem != NULL )
							{
							stop = true;
							currentReadItem_ = previousReadItem;
							}
						else
							return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found a word that does not belong to an assignment or a specification" );
					}

				previousReadItem = currentReadItem_;
				}
			while( !stop &&
			( currentReadItem_ = currentReadItem_->nextReadItem() ) != NULL );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The read item is undefined" );

		return commonVariables_->result;
		}

	ResultType parseSentence( char *readSentenceString )
		{
		bool isAction = false;
		bool isNewStart = true;
		unsigned short wordOrderNr;
		unsigned short wordParameter;
		unsigned short selectionLevel = NO_SELECTION_LEVEL;
		unsigned short selectionListNr = NO_LIST_NR;
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;
		char functionNameString[FUNCTION_NAME_LENGTH] = "parseSentence";

		isLinkedGeneralizationConjunction_ = false;

		admin_->initializeLinkedWord();
		endGeneralizationWordReadItem_ = NULL;
		startGeneralizationWordReadItem_ = NULL;

		if( ( currentReadItem_ = admin_->firstActiveReadItem() ) != NULL )
			{
			do	{
				if( !currentReadItem_->isSeparator() )
					{
					wordOrderNr = currentReadItem_->wordOrderNr();
					wordParameter = currentReadItem_->wordParameter();

					switch( currentReadItem_->grammarParameter )
						{
						case GRAMMAR_GENERALIZATION_SPECIFICATION:
						case GRAMMAR_GENERALIZATION_PART:
						case GRAMMAR_GENERALIZATION_WORD:
						case GRAMMAR_SPECIFICATION_PART:
						case GRAMMAR_ASSIGNMENT_PART:
						case GRAMMAR_SPECIFICATION_WORD:
						case GRAMMAR_RELATION_PART:
						case GRAMMAR_RELATION_WORD:
						case GRAMMAR_GENERALIZATION_ASSIGNMENT:
						case GRAMMAR_SPECIFICATION_ASSIGNMENT:
						case GRAMMAR_RELATION_ASSIGNMENT:
						case GRAMMAR_VERB:
						case GRAMMAR_QUESTION_VERB:
						case GRAMMAR_GENERALIZATION_VERB:
						case GRAMMAR_GENERALIZATION_QUESTION_VERB:
							if( readSpecification( isAction, isNewStart, selectionLevel, selectionListNr, readSentenceString ) == RESULT_OK )
								isNewStart = false;
							else
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to read a specification" );

							break;

						case GRAMMAR_IMPERATIVE:
							if( readImperative( isAction, isNewStart, selectionLevel, selectionListNr, readSentenceString ) == RESULT_OK )
								isNewStart = false;
							else
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to read an imperative" );

							break;

						case GRAMMAR_ANSWER:
							if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WARNING, INTERFACE_SENTENCE_WARNING_NOT_ABLE_TO_LINK_YES_NO_TO_QUESTION ) != RESULT_OK )
								return myWord_->addErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I failed to write an interface warning" );

							break;

						case GRAMMAR_SENTENCE_CONJUNCTION:
							switch( wordParameter )
								{
								case WORD_PARAMETER_SYMBOL_COMMA:
								case WORD_PARAMETER_CONJUNCTION_AND:
								case WORD_PARAMETER_CONJUNCTION_DUTCH_ALS:		// Typically for Dutch: in zowel ... als ...
									break;

								case WORD_PARAMETER_CONJUNCTION_OR:
									isNewStart = true;

									break;

								default:
									return myWord_->startErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I found an illegal conjunction word parameter: ", wordParameter );
								}

							break;

						case GRAMMAR_SELECTION:
						case WORD_PARAMETER_SELECTION_IF:	// In case "then" is missing
						case WORD_PARAMETER_SELECTION_THEN:
						case WORD_PARAMETER_SELECTION_ELSE:
							switch( wordParameter )
								{
								case WORD_PARAMETER_SELECTION_IF:
									if( selectionListNr != NO_LIST_NR )
										{
										if( ++selectionLevel == MAX_LEVEL )
											{
											sprintf( errorString, "Selection overflow in list <%c> at position %u", admin_->adminListChar( selectionListNr ), wordOrderNr );
											return myWord_->startSystemErrorInItem( functionNameString, moduleNameString_, errorString );
											}
										}

									isNewStart = true;
									selectionListNr = ADMIN_CONDITION_LIST;

									break;

								case WORD_PARAMETER_SELECTION_THEN:
									isNewStart = true;
									isAction = true;
									selectionListNr = ADMIN_ACTION_LIST;

									break;

								case WORD_PARAMETER_SELECTION_ELSE:
									isNewStart = true;
									isAction = false;
									selectionListNr = ADMIN_ALTERNATIVE_LIST;

									break;

								default:
									return myWord_->startErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I found an illegal selection word" );
								}

							break;

						default:
							if( readSentenceString != NULL &&
							admin_->isSystemStartingUp() )
								return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found an unknown word in sentence \"", readSentenceString, "\" at position ", wordOrderNr, " with grammar parameter ", currentReadItem_->grammarParameter, " and word parameter ", wordParameter );
							else
								return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found an unknown word at position ", wordOrderNr, " with grammar parameter ", currentReadItem_->grammarParameter, " and word parameter ", wordParameter );
						}
					}
				}
			while( !commonVariables_->hasShownWarning &&
			!admin_->hasRequestedRestart() &&
			currentReadItem_ != NULL &&
			( currentReadItem_ = currentReadItem_->nextReadItem() ) != NULL );

			if( selectionListNr != NO_LIST_NR )
				{
				if( admin_->checkForDuplicateSelection() != RESULT_OK )
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check on a duplicate selection" );
				}
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I failed to get the first read item" );

		return commonVariables_->result;
		}

	ResultType findGrammarPathInCurrentLanguage( unsigned short grammarLevel, GrammarItem *parseGrammarItem )
		{
		ReadResultType readResult;
		bool isOption;
		bool isChoice;
		bool isWaitingForNewStart;
		bool isWaitingForChoiceEnd;
		unsigned short previousWordOrderNr;
		unsigned short startWordOrderNr;
		unsigned short choiceStartWordOrderNr = NO_ORDER_NR;
		GrammarItem *definitionParseGrammarItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findGrammarPathInCurrentLanguage";

		if( grammarLevel < MAX_GRAMMAR_LEVEL )
			{
			if( parseGrammarItem != NULL )
				{
				if( admin_->readList != NULL )
					{
					if( grammarLevel == NO_GRAMMAR_LEVEL )
						currentParseWordOrderNr_ = NO_ORDER_NR;

					startWordOrderNr = currentParseWordOrderNr_;

					do	{
						isOption = false;
						isChoice = false;
						isWaitingForNewStart = true;
						isWaitingForChoiceEnd = false;
						currentParseWordOrderNr_ = startWordOrderNr;
						previousWordOrderNr = startWordOrderNr;
						definitionParseGrammarItem = parseGrammarItem;

						do	{
							if( isWaitingForNewStart &&
							parseGrammarItem->isNewStart() )	// Skip first grammar definition item, if not is a data item
								isWaitingForNewStart = false;

							if( !isWaitingForNewStart &&
							!isWaitingForChoiceEnd )
								{
								previousWordOrderNr = currentParseWordOrderNr_;

								if( parseGrammarItem->isOptionStart() )
									isOption = true;

								if( parseGrammarItem->isChoiceStart() )
									{
									isChoice = true;
									choiceStartWordOrderNr = currentParseWordOrderNr_;
									}

								if( parseGrammarItem->isDefinitionStart() )
									{
									if( ( readResult = admin_->readList->selectMatchingWordType( currentParseWordOrderNr_, definitionParseGrammarItem->grammarParameter(), definitionParseGrammarItem->grammarWordTypeNr() ) ).result == RESULT_OK )
										{
										if( readResult.hasFoundMatchingWordType )
											currentParseWordOrderNr_++;
										}
									else
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to select a matching word type" );
									}
								else
									{
									if( grammarLevel + 1 < MAX_GRAMMAR_LEVEL )
										{
										if( parseGrammarItem->definitionGrammarItem != NULL )
											{
											if( findGrammarPathInCurrentLanguage( ( grammarLevel + 1 ), parseGrammarItem->definitionGrammarItem ) == RESULT_OK )
												{
												if( currentParseWordOrderNr_ == previousWordOrderNr )	// Unsuccessful
													{
													if( isOption )
														isWaitingForNewStart = true;

													if( isChoice )
														{
														if( !parseGrammarItem->isChoiceEnd )
															isWaitingForNewStart = true;

														currentParseWordOrderNr_ = choiceStartWordOrderNr;
														}
													}
												}
											else
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find the grammar path at grammar word \"", parseGrammarItem->grammarString(), "\"" );
											}
										else
											return myWord_->startErrorInItem( functionNameString, moduleNameString_, "Grammar word \"", parseGrammarItem->grammarString(), "\" isn't defined in the grammar file" );
										}
									else
										return myWord_->startErrorInItem( functionNameString, moduleNameString_, "There is probably an endless loop in the grammar definitions, because the grammar level reached: #", grammarLevel );
									}
								}

							if( commonVariables_->result == RESULT_OK )
								{
								if( parseGrammarItem->isOptionEnd )
									isOption = false;

								if( parseGrammarItem->isChoiceEnd )
									{
									isChoice = false;
									isWaitingForChoiceEnd = false;
									}

								parseGrammarItem = parseGrammarItem->nextGrammarItem();

								if( isChoice &&
								!isWaitingForChoiceEnd &&
								parseGrammarItem != NULL &&
								parseGrammarItem->isNewStart() &&
								currentParseWordOrderNr_ > previousWordOrderNr )
									isWaitingForChoiceEnd = true;
								}
							}
						while( commonVariables_->result == RESULT_OK &&

						( isWaitingForNewStart ||
						isWaitingForChoiceEnd ||
						currentParseWordOrderNr_ > previousWordOrderNr ) &&

						parseGrammarItem != NULL &&
						definitionParseGrammarItem->activeSentenceNr() == parseGrammarItem->activeSentenceNr() );

						if( !isWaitingForNewStart &&
						currentParseWordOrderNr_ > startWordOrderNr &&
						currentParseWordOrderNr_ == previousWordOrderNr )
							currentParseWordOrderNr_ = startWordOrderNr;
						}
					while( commonVariables_->result == RESULT_OK &&
					currentParseWordOrderNr_ == startWordOrderNr &&
					definitionParseGrammarItem != NULL &&
					( parseGrammarItem = definitionParseGrammarItem->nextDefinitionGrammarItem ) != NULL );

					if( commonVariables_->result == RESULT_OK &&
					definitionParseGrammarItem != NULL &&
					definitionParseGrammarItem->isGrammarDefinition() &&

					( previousWordOrderNr > startWordOrderNr ||
					currentParseWordOrderNr_ > startWordOrderNr ) )
						{
						if( admin_->readList->setGrammarParameter( ( currentParseWordOrderNr_ > startWordOrderNr ), startWordOrderNr, ( currentParseWordOrderNr_ > startWordOrderNr ? currentParseWordOrderNr_ : previousWordOrderNr ), definitionParseGrammarItem ) != RESULT_OK )
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to set the grammar parameter of the read words between the positions ", startWordOrderNr, " and ", currentParseWordOrderNr_ );
						}
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The read list isn't created yet" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given parse grammar item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given grammar level is too high: #", grammarLevel );

		return commonVariables_->result;
		}

	ResultType processSentence( char *readSentenceString )
		{
		ReadResultType readResult;
		bool hasFoundFullPath;
		bool hasFoundMoreInterpretations;
		bool hasCreatedAllReadWords = false;
		unsigned short currentLanguageNr = commonVariables_->currentGrammarLanguageNr;
		unsigned short originalLanguageNr = commonVariables_->currentGrammarLanguageNr;
		unsigned int nLanguages = myWord_->numberOfActiveGrammarLanguages();
		GrammarItem *startOfGrammarItem;
		char errorString[MAX_ERROR_STRING_LENGTH];
		char functionNameString[FUNCTION_NAME_LENGTH] = "processSentence";

		if( nLanguages > 0 )
			{
			if( nLanguages >= commonVariables_->currentGrammarLanguageNr )
				{
				do	{
					admin_->deleteReadList();

					if( admin_->deleteUnusedInterpretations( true ) == RESULT_OK )
						{
						if( currentLanguageNr != commonVariables_->currentGrammarLanguageNr )	// Need to switch language
							{
							if( admin_->assignGrammarAndInterfaceLanguage( currentLanguageNr ) != RESULT_OK )
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to assign the grammar and interface language" );
							}

						if( commonVariables_->currentGrammarLanguageWordItem != NULL )
							{
							if( commonVariables_->currentGrammarLanguageWordItem->needToCheckGrammar() )
								{
								if( commonVariables_->currentGrammarLanguageWordItem->checkGrammar() != RESULT_OK )
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check the grammar" );
								}

							if( admin_->cleanupDeletedItems() == RESULT_OK )
								{
								hasFoundMoreInterpretations = false;
								startOfGrammarItem = commonVariables_->currentGrammarLanguageWordItem->startOfGrammarItem();

									// Create read words from a given sentence
									if( ( readResult = admin_->createReadWords( readSentenceString ) ).result == RESULT_OK )
										hasCreatedAllReadWords = readResult.hasCreatedAllReadWords;
									else
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create the read words" );

								if( admin_->readList != NULL )
									{
									hasFoundFullPath = false;
									hasFoundMoreInterpretations = false;
									admin_->readList->initForParsingReadWords();

									if( hasCreatedAllReadWords )
										{
										do	{
											if( findGrammarPathInCurrentLanguage( NO_GRAMMAR_LEVEL, startOfGrammarItem ) == RESULT_OK )
												{
												hasFoundFullPath = ( currentParseWordOrderNr_ == admin_->readList->lastCreatedWordOrderNr() );

												if( !hasFoundFullPath )
													{
													if( ( readResult = admin_->readList->findMoreInterpretations() ).result == RESULT_OK )
														hasFoundMoreInterpretations = readResult.hasFoundMoreInterpretations;
													else
														return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find more interpretations" );
													}
												}
											else
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find the grammar path for a sentence with grammar language \"", myWord_->grammarLanguageNameString( currentLanguageNr ), "\"" );
											}
										while( !hasFoundFullPath &&
										hasFoundMoreInterpretations );
										}

									if( admin_->deleteUnusedInterpretations( !hasFoundFullPath ) == RESULT_OK )
										{
										if( hasFoundFullPath )	// Successful interpretation of sentence
											{
											if( parseSentence( readSentenceString ) != RESULT_OK )
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to parse the sentence" );
											}

										if( !hasFoundFullPath )
											{
											if( nLanguages <= 1 )
												currentLanguageNr++;							// The only language
											else
												{
												if( currentLanguageNr == originalLanguageNr )	// Failed for current language
													currentLanguageNr = 1;						// Try all languages
												else
													currentLanguageNr++;

												if( currentLanguageNr == originalLanguageNr )	// Skip current language (already tested)
													currentLanguageNr++;
												}
											}

										if( deleteRollbackInfo_ )
											{
											if( admin_->deleteRollbackInfo() != RESULT_OK )
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete the rollback info" );
											}
										}
									else
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete the unused interpretations of the read words" );
									}
								else
									return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The read list isn't created yet" );
								}
							else
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to cleanup the deleted items" );
							}
						else
							return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The current grammar language word item is undefined" );
						}
					else
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete unused interpretations" );
					}
				while( !hasFoundFullPath &&
				currentLanguageNr <= nLanguages );

				if( !hasFoundFullPath )	// Failed to interpret sentence
					{
					if( commonVariables_->currentGrammarLanguageNr != originalLanguageNr )
						{
						if( admin_->assignGrammarAndInterfaceLanguage( originalLanguageNr ) != RESULT_OK )	// Restore the original language
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to assign the grammar and interface language after an interpretation failure" );
						}

					if( currentParseWordOrderNr_ == NO_ORDER_NR )
						{
						if( admin_->isSystemStartingUp() )
							return myWord_->startSystemErrorInItem( functionNameString, moduleNameString_, "I don't understand this sentence:\n1) Please make sure you enter a sentence within my limited grammar definition\n2) and don't forget to add a colon (or other punctuation mark) at the end of each sentence" );
						else
							{
							if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WARNING, INTERFACE_SENTENCE_WARNING_NOT_CONFORM_GRAMMAR ) != RESULT_OK )
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface warning" );
							}
						}
					else
						{
						if( admin_->isSystemStartingUp() )
							{
							sprintf( errorString, "I don't understand the sentence from the word at position %u", currentParseWordOrderNr_ );
							return myWord_->startSystemErrorInItem( functionNameString, moduleNameString_, errorString );
							}
						else
							{
							if( commonVariables_->presentation->writeInterfaceText( PRESENTATION_PROMPT_WARNING, INTERFACE_SENTENCE_WARNING_DONT_UNDERSTAND_FROM_WORD_POSITION_START, (unsigned int)currentParseWordOrderNr_, INTERFACE_SENTENCE_WARNING_AT_POSITION_END ) != RESULT_OK )
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface warning" );
							}
						}
					}
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The current grammar language number exceeds the number of languages" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I couldn't find any grammar language" );

		return commonVariables_->result;
		}

	ResultType addReadSpecification( bool isAction, bool isNewStart, unsigned short selectionLevel, unsigned short selectionListNr )
		{
		CollectionResultType collectionResult;
		bool isConditional = ( isConditional_ || selectionListNr != NO_LIST_NR );
		bool initializeVariables = true;
		unsigned short imperativeParameter = NO_IMPERATIVE_PARAMETER;
		unsigned short specificationWordParameter = NO_WORD_PARAMETER;
		ReadItem *currentGeneralizationReadItem = startGeneralizationWordReadItem_;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addReadSpecification";

		if( currentGeneralizationReadItem != NULL )
			{
			if( endGeneralizationWordReadItem_ != NULL )
				{
				admin_->initializeAdminAssumptionVariables();
				admin_->initializeAdminConclusionVariables();
				admin_->initializeAdminSpecificationVariables();

				do	{
					switch( currentGeneralizationReadItem->grammarParameter )
						{
						case GRAMMAR_IMPERATIVE:
							imperativeParameter = currentGeneralizationReadItem->wordParameter();
							// Don't insert a break statement

						case GRAMMAR_GENERALIZATION_WORD:
							if( ( collectionResult = admin_->addUserSpecifications( initializeVariables, isAction, isAssignment_, isConditional, isDeactiveAssignment_, isArchivedAssignment_, isExclusive_, isNewStart, isPossessive_, isSpecificationGeneralization_, prepositionParameter_, questionParameter_, selectionLevel, selectionListNr, imperativeParameter, specificationWordParameter, specificationCollectionNr_, generalizationContextNr_, specificationContextNr_, relationContextNr_, currentGeneralizationReadItem, startSpecificationWordReadItem_, endSpecificationWordReadItem_, startRelationWordReadItem_, endRelationWordReadItem_ ) ).result == RESULT_OK )
								{
								if( collectionResult.needToRedoSpecificationCollection )
									{
									if( ( collectionResult = admin_->addUserSpecifications( initializeVariables, isAction, isAssignment_, isConditional, isDeactiveAssignment_, isArchivedAssignment_, isExclusive_, isNewStart, isPossessive_, isSpecificationGeneralization_, prepositionParameter_, questionParameter_, selectionLevel, selectionListNr, imperativeParameter, specificationWordParameter, specificationCollectionNr_, generalizationContextNr_, specificationContextNr_, relationContextNr_, currentGeneralizationReadItem, startSpecificationWordReadItem_, endSpecificationWordReadItem_, startRelationWordReadItem_, endRelationWordReadItem_ ) ).result != RESULT_OK )
										return myWord_->addErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I failed to add the read user specifications" );
									}

								initializeVariables = false;
								}
							else
								return myWord_->addErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I failed to add the read user specifications" );
						}
					}
				while( !commonVariables_->hasShownWarning &&
				currentGeneralizationReadItem != endGeneralizationWordReadItem_ &&
				( currentGeneralizationReadItem = currentGeneralizationReadItem->nextReadItem() ) != NULL );
				}
			else
				return myWord_->startErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "The end generalization read item is undefined" );
			}
		else
			return myWord_->startErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "The start generalization read item is undefined" );

		return commonVariables_->result;
		}

	ResultType readSpecification( bool isAction, bool isNewStart, unsigned short selectionLevel, unsigned short selectionListNr, char *readSentenceString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "readSpecification";
		if( scanSpecification( readSentenceString ) == RESULT_OK )
			{
			if( addReadSpecification( isAction, isNewStart, selectionLevel, selectionListNr ) != RESULT_OK )
				return myWord_->addErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I failed to add the read specification" );
			}
		else
			return myWord_->addErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I failed to scan the generalization-specification" );

		return commonVariables_->result;
		}

	ResultType readImperative( bool isAction, bool isNewStart, unsigned short selectionLevel, unsigned short selectionListNr, char *readSentenceString )
		{
		unsigned short imperativeParameter = NO_IMPERATIVE_PARAMETER;
		unsigned short specificationWordParameter = NO_WORD_PARAMETER;
		ReadItem *firstReadItem;
		ReadItem *imperativeReadItem;
		ReadItem *specificationReadItem;
		WordItem *imperativeWordItem = NULL;
		char functionNameString[FUNCTION_NAME_LENGTH] = "readImperative";

		areReadItemsStillValid_ = true;

		if( currentReadItem_ != NULL )
			{
			startGeneralizationWordReadItem_ = NULL;
			endGeneralizationWordReadItem_ = NULL;

			if( scanSpecification( readSentenceString ) == RESULT_OK )
				{
				if( ( imperativeReadItem = startGeneralizationWordReadItem_ ) != NULL &&
				endGeneralizationWordReadItem_ != NULL )
					{
					do	{
						if( imperativeReadItem->isReadWordVerb() )
							{
							imperativeParameter = imperativeReadItem->wordParameter();
							imperativeWordItem = imperativeReadItem->readWordItem();
							}
						}
					while( ( imperativeReadItem = imperativeReadItem->nextReadItem() ) != NULL );

					if( ( specificationReadItem = startSpecificationWordReadItem_ ) == NULL )	// Only imperative word
						{
						if( admin_->executeImperative( true, NO_LIST_NR, startGeneralizationWordReadItem_->wordParameter(), specificationWordParameter, WORD_TYPE_UNDEFINED, MAX_PROGRESS, startGeneralizationWordReadItem_->readString, startGeneralizationWordReadItem_->readWordItem(), NULL, startRelationWordReadItem_, endRelationWordReadItem_, NULL, NULL ) != RESULT_OK )
							{
							if( startGeneralizationWordReadItem_ == NULL )
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to execute the single imperative" );
							else
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to execute the single imperative at position ", startGeneralizationWordReadItem_->wordOrderNr() );
							}
						}
					else	// Imperative word has specifications
						{
						if( endSpecificationWordReadItem_ != NULL )
							{
							if( addReadSpecification( isAction, isNewStart, selectionLevel, selectionListNr ) == RESULT_OK )
								{
								if( !commonVariables_->hasShownWarning &&
								selectionListNr == NO_LIST_NR )
									{
									if( ( firstReadItem = admin_->firstActiveReadItem() ) != NULL )
										{
										do	{
											if( specificationReadItem->isReadWordNoun() ||
											specificationReadItem->isUserDefined() )
												{
												if( specificationReadItem->isNounFile() ||				// Make distinction between reading a normal file or a test file
												specificationReadItem->isNounJustificationReport() )	// Make distinction between showing a word or justification report
													specificationWordParameter = specificationReadItem->wordParameter();
												else
													{
													if( admin_->executeImperative( true, NO_LIST_NR, imperativeParameter, ( specificationWordParameter == NO_WORD_PARAMETER ? specificationReadItem->wordParameter() : specificationWordParameter ), specificationReadItem->wordTypeNr(), MAX_PROGRESS, specificationReadItem->readString, imperativeWordItem, specificationReadItem->readWordItem(), startRelationWordReadItem_, endRelationWordReadItem_, NULL, NULL ) != RESULT_OK )
														return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to execute an imperative with specifications" );
													}
												}

											if( firstReadItem != admin_->firstActiveReadItem() )
												areReadItemsStillValid_ = false;
											}
										while( areReadItemsStillValid_ &&
										!admin_->hasRequestedRestart() &&
										!commonVariables_->hasShownWarning &&

										( !specificationReadItem->isVirtualListPreposition() ||
										specificationWordParameter > NO_WORD_PARAMETER ) &&		// Loop shouldn't end when virtual list prepositions are used to e.g. show justification reports

										specificationReadItem != endSpecificationWordReadItem_ &&
										( specificationReadItem = specificationReadItem->nextReadItem() ) != NULL );
										}
									else
										return myWord_->startErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I couldn't find the first read item" );
									}
								}
							else
								{
								if( startGeneralizationWordReadItem_ == NULL ||
								endGeneralizationWordReadItem_ == NULL )
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add the generalization part of the read specification" );
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add the generalization part of the read specification between the positions ", startGeneralizationWordReadItem_->wordOrderNr(), " and ", endGeneralizationWordReadItem_->wordOrderNr() );
								}
							}
						else
							return myWord_->startErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "The end specification read item is undefined" );
						}
					}
				else
					return myWord_->startErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I couldn't find the imperative" );
				}
			else
				return myWord_->addErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I failed to scan the generalization-specification" );
			}
		else
			return myWord_->startErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "The current read item is undefined" );

		return commonVariables_->result;
		}


	public:
	// Constructor

	AdminReadSentence( AdminItem *admin, WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		areReadItemsStillValid_ = false;
		deleteRollbackInfo_ = true;
		showConclusions_ = false;

		isAssignment_ = false;
		isConditional_ = false;
		isExclusive_ = false;
		isDeactiveAssignment_ = false;
		isArchivedAssignment_ = false;
		isPossessive_ = false;
		isSpecificationGeneralization_ = false;
		isLinkedGeneralizationConjunction_ = false;

		prepositionParameter_ = NO_PREPOSITION_PARAMETER;
		questionParameter_ = NO_QUESTION_PARAMETER;

		generalizationContextNr_ = NO_CONTEXT_NR;
		specificationContextNr_ = NO_CONTEXT_NR;
		relationContextNr_ = NO_CONTEXT_NR;

		currentReadItem_ = NULL;
		startGeneralizationWordReadItem_ = NULL;
		endGeneralizationWordReadItem_ = NULL;
		startSpecificationWordReadItem_ = NULL;
		endSpecificationWordReadItem_ = NULL;
		startRelationWordReadItem_ = NULL;
		endRelationWordReadItem_ = NULL;

		admin_ = admin;
		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "AdminReadSentence" );

		if( commonVariables_ != NULL )
			{
		if( admin_ != NULL )
			{
			if( myWord_ == NULL )
				strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given admin is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	void dontShowConclusions()
		{
		showConclusions_ = false;
		}

	void dontDeletedRollbackInfo()
		{
		deleteRollbackInfo_ = false;
		}

	bool areReadItemsStillValid()
		{
		return areReadItemsStillValid_;
		}

	bool isPossessivePronounStructure()
		{
		ReadItem *readAheadWordItem = currentReadItem_;

		while( readAheadWordItem != NULL &&
		!readAheadWordItem->isReadWordPossessiveDeterminer() )
			readAheadWordItem = readAheadWordItem->nextReadItem();

		return ( readAheadWordItem != NULL );
		}

	bool isUserSentencePossessive()
		{
		return isPossessive_;
		}

	ResultType processReadSentence( char *readSentenceString )
		{
		unsigned int startSentenceNr = commonVariables_->currentSentenceNr;
		char functionNameString[FUNCTION_NAME_LENGTH] = "processReadSentence";

		showConclusions_ = true;
		deleteRollbackInfo_ = true;

		commonVariables_->hasShownWarning = false;
		commonVariables_->hasFoundAnswerToQuestion = false;
		commonVariables_->isFirstAnswerToQuestion = true;
		commonVariables_->isQuestionAlreadyAnswered = false;
		commonVariables_->isSpecificationConfirmedByUser = false;
		commonVariables_->isUserQuestion = false;

		commonVariables_->lastShownMoreSpecificSpecificationItem = NULL;

		if( readSentenceString != NULL )
			{
			if( processSentence( readSentenceString ) == RESULT_OK )
				{
				if( showConclusions_ &&
				!admin_->hasRequestedRestart() &&
				!commonVariables_->hasShownWarning &&
				startSentenceNr == commonVariables_->currentSentenceNr )
					{
					clearLastCheckedAssumptionLevelItemNrInAllWords();

					if( admin_->integrityCheck( ( questionParameter_ > NO_QUESTION_PARAMETER ), readSentenceString ) == RESULT_OK )
						{
						if( admin_->hasFoundChange() &&
						!commonVariables_->hasShownWarning )	// Passed integrity check
							{
								// Show self-generated conclusions of the last sentence
							if( admin_->writeSelfGeneratedInfo( true, false, false ) == RESULT_OK )
								{
								// Show self-generated assumptions of the last sentence
								if( admin_->writeSelfGeneratedInfo( false, true, false ) == RESULT_OK )
									{
									// Show self-generated questions of the last sentence
									if( admin_->writeSelfGeneratedInfo( false, false, true ) != RESULT_OK )
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write the self-generated questions" );
									}
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write the self-generated assumptions" );
								}
							else
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write the self-generated conclusions" );
							}

						if( !commonVariables_->hasShownWarning &&

						( admin_->hasFoundChange() ||
						commonVariables_->isUserQuestion ) )
							{
							if( admin_->answerQuestions() != RESULT_OK )
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to answer questions" );
							}
						}
					else
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to perform an integrity check on sentence \"", readSentenceString, "\"" );
					}
				}
			else
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to process sentence: \"", readSentenceString, "\"" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given read sentence string is undefined" );

		return commonVariables_->result;
		}
	};

/*************************************************************************
 *
 *	"You have turned my mourning into joyful dancing.
 *	You have taken away my clothes of mourning and
 *	clothed me with joy,
 *	that I might sing praises to you and not be silent.
 *	O Lord my God, I will give you thanks forever!" (Psalm 30:11-12)
 *
 *************************************************************************/
