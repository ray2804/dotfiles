/* License/copyright: Dual licences, read copyright.txt in the package*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>
#include <unistd.h>

#include "utils.h"
#include "definitions.h"
#include "languages.h"
#include "keywords.h"
#include "printing.h"

/*---------- Global variables --------*/
extern int debug;
extern int verbose;
extern char lang[];
extern char alphabet[];
extern char numeral[];
extern char separator[];
extern char eos[];
extern char special[];
extern char file_keyw[];
extern long int size_line;
extern int linewidth;

/*------------- functions ------------*/

long int excludedfromfile(char *path,char *excludedword,int filenum,char *lang,long int n){
/*load file containing exluded or basic words (such as articles...)*/
FILE *fp;
char filename[SIZE_WORD];
char ch;
int i; //cntword

  if (filenum==1) sprintf(filename,"%sexcluded.%s.word",path,lang);
  if (filenum==2) sprintf(filename,"%sbasic.%s.word",path,lang);
 
  if ((fp=fopen(filename,"r")) == NULL) {
    ERRPOS
    fprintf(stderr,"\nError:Unable to open %s \n",filename);
    return -1;
  }
  excludedword[0]='\n';

  i=1;
  while ((ch=fgetc(fp)) != EOF) {
    /*if comment read a full line eol terminated*/
    if (ch=='#') {
      while (((ch=fgetc(fp)) != EOF) && (ch != '\n')) {}
    } 
    else
    {
      /*change semicolon and slash in eol*/
      if ((ch==';') || (ch=='/')) ch='\n';
      /*prevent duplicate \n*/
      if ((ch == '\n') && (ch == excludedword[i-1])) {}
      else excludedword[i++]=ch;
      if (i==n) {
        excludedword[i]='\0';
		    ERRPOS
        fprintf(stderr,"\nOverflow in excludedfromfile\n");
        fclose(fp);
        return -1;
      }
    }
  }
  if (excludedword[i-1] != '\n') excludedword[i++]='\n';
  excludedword[i]='\0';
  fclose(fp);
  return i;
}

int savesinglekeyword(char *result,int nb,int width,char *excludedword,char *title,int rec) {
/* 
   - Save the single keywords for the classifier need in mode I
   keywords are filtered to keep the most relevant
   words in title get a highest weight
   a file is created in the same format as the dictionnary
   - Display keywords list
   
   To improve: replace basic.word filter with their frequency
*/
  int i,val,max,cnt,lgline,nbw,lg;
  char *word,*wordchk,*token_title;
  char *str_ptr;
  FILE *fp1;
  char previous_ch,ch;
  char validchar[SHORT_STR]; //table of valid chars
  float weight;
  int nbkw=0,nbpkw=0;
  int lg_listofwords; //avoid overflow
  char listofwords[MEDIUM_STR]="";
  
  if (linewidth) clever_print(0,""); //reset static var in fct
  
  strcpy(validchar,alphabet);
  strcat(validchar," .");
  
  if ((word = (char*)malloc(size_line)) == NULL) errmalloc("savesinglekeyword"); 
  if ((wordchk = (char*)malloc(size_line)) == NULL) errmalloc("savesinglekeyword"); 
  if ((token_title = (char*)malloc(size_line)) == NULL) errmalloc("savesinglekeyword"); 

  if (title) {
    /*Extract words in title*/
    nbw=lg=lgline=0;
    word[lg++]='\n';
    int ok=1; 
    *token_title ='\0';
    while (ok) { //loop to scan char one by one
      ch=*(title++); //read char/char until the end-of-string
      if (ch == '\0') break; //end-of-string so exit loop
      if ((int)ch < 32) ch=' '; //no crtl char
      if ((int)ch > 126) ch=' '; //no crtl char
        else ch=tolower(ch); //because works only on lowercase
    
      /*replace delimiter*/
      if (strchr(separator,ch) != NULL) ch=' ';    
      /*replace end of sentence*/
      if (strchr(eos,ch) != NULL) ch=' ';
      if (ch == '.') ch=' ';
      /*replace invalide char*/
      if (strchr(validchar,ch) == NULL) ch='_';
      /*store char*/
      switch (ch) {
      case ' ': //the word is extracted
        if (ch != previous_ch) {
          word[lg++]='\n'; //separator between word
          word[lg]='\0'; //end-of-string
	        /* no too common word such as article... no too short word */
          if ((lg>3) && (strstr(excludedword,word) == NULL) && (strstr(token_title,word) == NULL)) {
            nbw++; //count word
            lgline+=lg+1; //used to check overflow
            if (lgline > size_line) {
			  ERRPOS
			  fprintf(stderr," memory overflow\n"); 
			  exit(EXIT_FAILURE);
			}
	        word[lg-1]='\0';
            strcat(token_title,word); //concatenate word
          }
          lg=0; //ready for another word
	      word[lg++]='\n';
        }
        break;
      case '_': break; //do nothing
      default:
        word[lg++]=ch; //concatenate char
      }
      previous_ch=ch; /*Avoid doublon*/
    }
    strcat(token_title,"\n"); //finish the line
  }
  
  if (debug) fprintf(stderr,"\nTokenized title:<%s>\n",token_title);
  
  printing("<List of keywords>\n",1,999,rec);
 
  /* Open the file  */
  fp1=fopen(file_keyw,"w");
  if (fp1==NULL){
    ERRPOS
    fprintf(stderr,"Unable to write %s ->Exit!\n",file_keyw);
    exit(EXIT_FAILURE);
  }

  /* write the header
  (int)(0.15*nb*width) gives an exegerated line length
  (+5% extra) 10% of keywords are kept */
  fprintf(fp1,"#Single keywords generated by texlexan from the text\n");
  fprintf(fp1,"#<LINE_LG:%i>\n",(int)(0.15*nb*width));
  fprintf(fp1,"1 skws:/");

  cnt=0;
  max=0;
  lgline=0;
  for(i=0;i<nb*width;i+=width) {
    /*extract keywords found and their occurence*/
    
    strcpy(word,result+i);
    if ((str_ptr=strpbrk(word,":")) != NULL) *str_ptr=0; //str_ptr points at the end of the value
    val=atoi(word); //val just before ':'
    if (val == 0) {
	    ERRPOS
	    fprintf(stderr,"in printsorted:atoi\n");
	  }
    else {
      /* str_ptr+1 points on the word (just after the ':' replaced with '\0' ) 
      excludedword are common words not very significant so we skip them
      --- FILTER WORD ---
      */
      if ((strlen(str_ptr+1) > 2) && (arenumbers(str_ptr+1) == 0)) {
        strcpy(wordchk,"\n"); //wordchk is used to filter word
        strcat(wordchk,str_ptr+1);
        strcat(wordchk,"\n");
        if (strstr(excludedword,wordchk) == NULL) { //do no proceed excluded/basic words
          if (max == 0) max=val; //max contains the first and highest freq (because result is sorted)
          cnt++; //nb of keywords recorded
	        /* 
	        This is a recipe to compute weight, alchemistry like
	        relative freq by the length of the word 
	        */
	        weight=((float)(val*strlen(str_ptr+1))/(float)(max));
	        /*round the weight*/
	        if (weight > 8.5) val=9;
	        else if (weight > 7.5) val=8;
	        else if (weight > 6.5) val=7;
          else if (weight > 5.5) val=6;
          else if (weight > 4.5) val=5;
          else if (weight > 3.5) val=4;
          else if (weight > 2.5) val=3;
          else if (weight > 1.5) val=2;
          else if (weight > 0.5) val=1;
          else val=0;
          if (strstr(token_title,wordchk) != NULL) val=9; //word in title gets the highest score
          if (val>0) { //only significant keyword
            strcpy(word,str_ptr+1);
            if (debug) fprintf(stderr,"<%s>",word);
            lgline+=fprintf(fp1,"%i\\%s/",val,word); //write the keyword in a file
            nbkw++; //count recorded keywords
            if (rec) {
              /*print words separated with a semicolon*/
              chgtosingular(word,lang);
              strcat(word,";");
              if (strstr(listofwords,word) == NULL) {
                lg=strlen(word);
                if (lg_listofwords+lg < MEDIUM_STR) {
                  strcat(listofwords,word);
                  lg_listofwords+=lg;
                }    
                if (linewidth) printing(clever_print(linewidth,word),1,999,rec);
                else printing(word,1,999,rec); //unformated line
                nbpkw++; //count printed keywords
              }
            }
            if (lgline > 0.1*nb*width) break; //line to long
          }
        }
      }
    }
  }
  fprintf(fp1,"\n"); //finish the line with an eol
  fprintf(fp1,"#<END>\n");
  if (fclose(fp1) != 0) {
    ERRPOS
    fprintf(stderr," in printsorted:fclose fp1\n");
  }
  if (rec) {
    if (verbose) printf("\n %i recorded keywords (singular & plural)",nbkw);
    sprintf(word,"\n<Extracted %i keywords>\n",nbpkw);
    printing(word,1,999,rec);
    printing("<End of the list of keywords>\n",1,999,rec);
  }
  /*release memory*/
  free(word); free(wordchk); free(token_title);
  if (debug) fprintf(stderr,"\nkeywords done.\n");
  return cnt; //done - no pb
}
