/*
 *	Class:			AdminItem
 *	Parent class:	WordItem
 *	Grand parent:	Item
 *	Purpose:		To process tasks at administration level
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

// Admin Item header

#ifndef ADMINITEM
#define ADMINITEM 1

#include "WordItem.h"
#include "ContextResultType.cpp"
#include "FileResultType.cpp"

// Class declarations needed by some compilers, like Code::Blocks
class AdminAssumption;
class AdminAuthorization;
class AdminCleanup;
class AdminCollection;
class AdminConclusion;
class AdminContext;
class AdminGrammar;
class AdminImperative;
class AdminJustification;
class AdminLanguage;
class AdminQuery;
class AdminRead;
class AdminReadCreateWords;
class AdminReadSentence;
class AdminSelection;
class AdminSolve;
class AdminSpecification;
class AdminWrite;
class FileList;
class List;
class ReadList;
class ScoreList;
class SelectionList;
class WordItem;
class WordList;

class AdminItem : private WordItem
	{
	friend class AdminAssumption;
	friend class AdminAuthorization;
	friend class AdminCleanup;
	friend class AdminCollection;
	friend class AdminConclusion;
	friend class AdminGrammar;
	friend class AdminImperative;
	friend class AdminLanguage;
	friend class AdminQuery;
	friend class AdminRead;
	friend class AdminReadCreateWords;
	friend class AdminReadSentence;
	friend class AdminSelection;
	friend class AdminSolve;
	friend class AdminSpecification;
	friend class AdminWrite;

	// Private constructible variables

	bool isSystemStartingUp_;

	AdminAssumption *adminAssumption_;
	AdminAuthorization *adminAuthorization_;
	AdminCleanup *adminCleanup_;
	AdminCollection *adminCollection_;
	AdminConclusion *adminConclusion_;
	AdminContext *adminContext_;
	AdminGrammar *adminGrammar_;
	AdminImperative *adminImperative_;
	AdminJustification *adminJustification_;
	AdminLanguage *adminLanguage_;
	AdminQuery *adminQuery_;
	AdminRead *adminRead_;
	AdminReadCreateWords *adminReadCreateWords_;
	AdminReadSentence *adminReadSentence_;
	AdminSelection *adminSelection_;
	AdminSolve *adminSolve_;
	AdminSpecification *adminSpecification_;
	AdminWrite *adminWrite_;


	// Private functions

	ResultType startup();

	// Private read functions

	ResultType readStartupFile();


	protected:
	// Protected constructible variables

	FileList *fileList;
	ReadList *readList;
	ScoreList *scoreList;
	WordList *wordList;
	SelectionList *conditionList;
	SelectionList *actionList;
	SelectionList *alternativeList;

	List *adminList[NUMBER_OF_ADMIN_LISTS];


	// Protected common functions

	bool isSystemStartingUp();
	bool isGeneralizationReasoningWordType( bool includeNoun, unsigned short generalizationWordTypeNr );

	char adminListChar( unsigned short adminListNr );


	// Protected assignment functions

	ResultType assignSelectionSpecification( SelectionItem *assignmentSelectionItem );
	ResultType assignSpecification( WordItem *generalizationWordItem, WordItem *specificationWordItem );

	SpecificationResultType assignSpecificationWithAuthorization( bool isAmbiguousRelationContext, bool isAssignedOrClear, bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, bool isSelfGenerated, unsigned short prepositionParameter, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int originalSentenceNr, unsigned int activeSentenceNr, unsigned int deactiveSentenceNr, unsigned int archiveSentenceNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem, char *specificationString );


	// Protected assumption functions

	void initializeAdminAssumptionVariables();

	ResultType addSuggestiveQuestionAssumption( bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, SpecificationItem *specificSpecificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem );
	ResultType findGeneralizationAssumptionBySpecification( bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int generalizationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem );
	ResultType findGeneralizationAssumptionByGeneralization( bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, unsigned short specificQuestionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int generalizationContextNr, unsigned int relationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem );
	ResultType findExclusiveSpecificationSubstitutionAssumption( bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem );

	ResultType addAssumption( bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, unsigned short justificationTypeNr, unsigned short prepositionParamater, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, SpecificationItem *definitionSpecificationItem, SpecificationItem *specificSpecificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem );


	// Protected authorization functions

	unsigned int myFirstSentenceNr();

	ResultType login( WordItem *specificationWordItem );
	ResultType authorizeWord( WordItem *authorizationWordItem );

	char *currentUserName();


	// Protected cleanup functions

	void clearDontIncrementCurrentSentenceNr();

	bool dontIncrementCurrentSentenceNr();
	bool wasUndoOrRedo();

	unsigned int highestSentenceNr();

	ResultType checkForChanges();
	ResultType cleanupDeletedItems();
	ResultType currentItemNr();

	ResultType deleteRollbackInfo();
	ResultType deleteAllTemporaryLists();
	ResultType deleteUnusedInterpretations( bool deleteAllActiveWordTypes );
	ResultType deleteSentences( bool isAvailableForRollback, unsigned int lowestSentenceNr );

	ResultType undoLastSentence();
	ResultType redoLastUndoneSentence();


	// Protected collection functions

	CollectionResultType collectSpecificationStrings( bool isExclusive, bool isExclusiveGeneralization, bool isQuestion, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, WordItem *generalizationWordItem, char *previousSpecificationString, char *currentSpecificationString );
	CollectionResultType collectSpecificationWords( bool isExclusive, bool isExclusiveGeneralization, bool isQuestion, bool isSpecificationGeneralization, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, WordItem *compoundGeneralizationWordItem, WordItem *generalizationWordItem, WordItem *previousSpecificationWordItem, WordItem *currentSpecificationWordItem );

	ResultType collectGeneralizationWordWithPreviousOne( bool isExclusive, bool isExclusiveGeneralization, bool isPossessive, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short questionParameter, unsigned int relationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem );
	ResultType collectRelationWords( bool isExclusive, unsigned short relationWordTypeNr, unsigned short specificationWordTypeNr, WordItem *previousRelationWordItem, WordItem *currentRelationWordItem, WordItem *specificationWordItem );


	// Protected conclusion functions

	void initializeAdminConclusionVariables();

	ResultType addSpecificationGeneralizationConclusion( unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, SpecificationItem *definitionSpecificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem );
	ResultType findPossessiveReversibleConclusion( bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int specificationContextNr, unsigned int relationPronounContextNr, unsigned int relationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem );
	ResultType findSpecificationSubstitutionConclusionOrQuestion( bool isAssumption, bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, bool isUserSentence, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem );

	SpecificationResultType findCompoundSpecificationSubstitutionConclusion( bool isNegative, bool isPossessive, unsigned short specificationWordTypeNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem );


	// Protected context functions

	unsigned int highestContextNr();

	ContextResultType addPronounContext( unsigned short contextWordTypeNr, WordItem *contextWordItem );
	ContextResultType getRelationContextNr( bool isExclusive, bool isNegative, bool isPossessive, bool isUserSentence, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int nContextRelations, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem, ReadItem *startRelationReadItem );


	// Protected grammar functions

	bool hasFoundChange();

	ResultType addGrammar( char *grammarString );

	WordItem *predefinedAdjectiveBusyWordItem();
	WordItem *predefinedAdjectiveDoneWordItem();
	WordItem *predefinedAdjectiveInvertedWordItem();

	WordItem *predefinedNounInterfaceLanguageWordItem();
	WordItem *predefinedNounPasswordWordItem();
	WordItem *predefinedNounSolveLevelWordItem();
	WordItem *predefinedNounSolveMethodWordItem();
	WordItem *predefinedNounSolveStrategyWordItem();
	WordItem *predefinedVerbLoginWordItem();


	// Protected imperative functions

	ResultType executeImperative( bool initializeVariables, unsigned short executionListNr, unsigned short imperativeParameter, unsigned short specificationWordParameter, unsigned short specificationWordTypeNr, unsigned long endSolveProgress, char *executionString, WordItem *generalizationWordItem, WordItem *specificationWordItem, ReadItem *startRelationWordReadItem, ReadItem *endRelationWordReadItem, SelectionItem *executionSelectionItem, SelectionItem *actionSelectionItem );


	// Protected justification functions

	ResultType writeJustificationSpecification( char *justificationSentenceString, SpecificationItem *justificationSpecificationItem );


	// Protected language functions

	ResultType authorizeLanguageWord( WordItem *authorizationWordItem );

	ResultType createGrammarLanguage( char *languageNameString );
	ResultType createInterfaceLanguage( char *languageNameString );

	ResultType createLanguageSpecification( WordItem *languageWordItem, WordItem *languageNounWordItem );

	ResultType assignGrammarAndInterfaceLanguage( unsigned short newLanguageNr );
	ResultType assignGrammarAndInterfaceLanguage( char *languageNameString );


	// Protected query functions

	void initializeQueryStringPosition();

	ResultType writeTextWithPossibleQueryCommands( unsigned short promptTypeNr, char *textString );
	ResultType executeQuery( bool suppressMessage, bool returnToPosition, bool writeQueryResult, unsigned short promptTypeNr, char *queryString );


	// Protected read functions

	ResultType readExamplesFile( char *examplesFileNameString );

	ResultType readAndExecute();
	ResultType getUserInput( bool isPassword, bool isQuestion, bool isText, char *promptInputString, char *readString );

	FileResultType readInfoFile( bool reportErrorIfFileDoesNotExist, char *infoFileNameString );


	// Protected read create words functions

	void deleteReadList();

	bool createImperativeSentence();
	bool hasPassedGrammarIntegrityCheck();

	ReadResultType createReadWord( unsigned short wordOrderNr, unsigned short wordTypeNr, char *textString, WordItem *readWordItem );
	ReadResultType createReadWords( char *grammarString );
	ReadResultType getWordInfo( bool skipDoubleQuotes, size_t startWordPosition, char *wordString );

	WordResultType createWord( unsigned short previousWordDefiniteArticleParameter, unsigned short previousWordIndefiniteArticleParameter, unsigned short wordTypeNr, unsigned short wordParameter, size_t wordLength, char *wordString );

	ReadItem *firstActiveReadItem();
	ReadItem *firstDeactiveReadItem();


	// Protected read sentence functions

	void dontShowConclusions();
	void dontDeletedRollbackInfo();

	bool areReadItemsStillValid();
	bool isPossessivePronounStructure();

	ResultType processReadSentence( char *readString );


	// Protected selection functions

	ResultType checkForDuplicateSelection();

	ResultType createSelectionTextPart( bool isAction, bool isNewStart, unsigned short selectionLevel, unsigned short selectionListNr, unsigned short imperativeParameter, char *specificationString );
	ResultType createSelectionPart( bool isAction, bool isAssignedOrClear, bool isDeactive, bool isArchived, bool isFirstComparisonPart, bool isNewStart, bool isNegative, bool isPossessive, bool isValueSpecification, unsigned short selectionLevel, unsigned short selectionListNr, unsigned short imperativeParameter, unsigned short prepositionParameter, unsigned short specificationWordParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int nContextRelations, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString );

	ResultType executeSelections();
	ResultType executeSelection( unsigned long endSolveProgress, SelectionItem *actionSelectionItem );


	// Protected solve functions

	void clearCurrentSolveProgress();
	void deleteScoreList();

	ResultType canWordBeSolved( WordItem *solveWordItem );
	ResultType findPossibilityToSolveWord( bool isAddScores, bool isInverted, bool duplicatesAllowed, bool prepareSort, unsigned short solveStrategyParameter, WordItem *solveWordItem );
	ResultType solveWord( unsigned long endSolveProgress, WordItem *solveWordItem, SelectionItem *actionSelectionItem );

	SelectionResultType checkCondition( SelectionItem *conditionSelectionItem );


	// Protected specification functions

	void initializeLinkedWord();
	void initializeAdminSpecificationVariables();

	bool isUserSentencePossessive();

	CollectionResultType addUserSpecifications( bool initializeVariables, bool isAction, bool isAssignment, bool isConditional, bool isDeactive, bool isArchived, bool isExclusive, bool isNewStart, bool isPossessive, bool isSpecificationGeneralization, unsigned short prepositionParameter, unsigned short questionParameter, unsigned short selectionLevel, unsigned short selectionListNr, unsigned short imperativeParameter, unsigned short specificationWordParameter, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationPronounContextNr, ReadItem *generalizationReadItem, ReadItem *startSpecificationReadItem, ReadItem *endSpecificationReadItem, ReadItem *startRelationReadItem, ReadItem *endRelationWordReadItem );

	SpecificationResultType addSpecification( bool isAssignment, bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, bool isSelfGenerated, bool isSpecificationGeneralization, bool isValueSpecification, unsigned short prepositionParameter, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString );
	SpecificationResultType addSpecificationWithAuthorization( bool isAssignment, bool isConditional, bool isDeactiveAssignment, bool isArchivedAssignment, bool isExclusive, bool isNegative, bool isPossessive, bool isSelection, bool isSpecificationGeneralization, bool isValueSpecification, unsigned short prepositionParameter, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString );

	WordItem *userSentenceGeneralizationWordItem();


	// Protected write functions

	void initializeAdminWriteVariables();

	ResultType answerQuestions();
	ResultType integrityCheck( bool isQuestion, char *integrityCheckSentenceString );

	ResultType writeJustificationReport( WordItem *justificationWordItem );
	ResultType writeSelfGeneratedInfo( bool writeSelfGeneratedConclusions, bool writeSelfGeneratedAssumptions, bool writeSelfGeneratedQuestions );
	ResultType writeInfoAboutWord( bool writeCurrentSentenceOnly, bool writeUserSpecifications, bool writeSelfGeneratedConclusions, bool writeSelfGeneratedAssumptions, bool writeUserQuestions, bool writeSelfGeneratedQuestions, bool writeSpecificationInfo, bool writeRelatedInfo, char *integrityCheckSentenceString, WordItem *writeWordItem );


	// Public functions
	public:
	// Constructor

	AdminItem();
	~AdminItem();

	bool hasRequestedRestart();

	ResultType interact();
	};

#endif

/*************************************************************************
 *
 *	"I will praise the Lord at all times.
 *	I will constantly speak his praises." (Psalm 34:1)
 *
 *************************************************************************/
