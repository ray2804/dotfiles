package gui_airborne::linux;
use base qw(gui_airborne);
use strict;

sub make_control{}
1;
