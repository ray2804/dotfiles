-- phpMyAdmin SQL Dump
-- version 2.7.0-pl1
-- http://www.phpmyadmin.net
-- 
-- Host: pr-db2
-- Generation Time: Jun 04, 2006 at 07:57 AM
-- Server version: 4.1.12
-- PHP Version: 4.3.9
-- 
-- Docsum Tables
-- 
-- 
-- Database: `d167349_docsum`
-- 
DROP DATABASE `d167349_docsum`;
CREATE DATABASE `d167349_docsum` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE d167349_docsum;

-- --------------------------------------------------------

-- 
-- Table structure for table `AUDIT_USER_TOPIC`
-- 
-- Creation: Jun 03, 2006 at 06:58 AM
-- Last update: Jun 03, 2006 at 01:58 PM
-- Last check: Jun 03, 2006 at 06:58 AM
-- 

DROP TABLE IF EXISTS `AUDIT_USER_TOPIC`;
CREATE TABLE IF NOT EXISTS `AUDIT_USER_TOPIC` (
  `TOPIC_ID` int(10) unsigned NOT NULL auto_increment,
  `TOPIC` text NOT NULL,
  `TOPIC_COUNT` int(10) unsigned NOT NULL default '1',
  PRIMARY KEY  (`TOPIC_ID`),
  FULLTEXT KEY `TOPIC` (`TOPIC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 PACK_KEYS=0 COMMENT='Tracks the user topic queries' AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

-- 
-- Table structure for table `CONTENTS`
-- 
-- Creation: May 17, 2006 at 08:30 PM
-- Last update: May 24, 2006 at 08:04 PM
-- Last check: May 21, 2006 at 06:54 AM
-- 

DROP TABLE IF EXISTS `CONTENTS`;
CREATE TABLE IF NOT EXISTS `CONTENTS` (
  `CONTENT_ID` int(10) unsigned NOT NULL auto_increment,
  `FILE_ID` int(10) unsigned NOT NULL default '0',
  `CONTENT` text NOT NULL,
  PRIMARY KEY  (`CONTENT_ID`),
  FULLTEXT KEY `CONTENT` (`CONTENT`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=927 ;

-- --------------------------------------------------------

-- 
-- Table structure for table `METADATA`
-- 
-- Creation: May 21, 2006 at 06:51 AM
-- Last update: May 24, 2006 at 08:04 PM
-- 

DROP TABLE IF EXISTS `METADATA`;
CREATE TABLE IF NOT EXISTS `METADATA` (
  `FILE_ID` int(10) unsigned NOT NULL auto_increment,
  `CHECKSUM` varchar(32) NOT NULL default '',
  `PATH` text NOT NULL,
  `KEYWORDS` text NOT NULL,
  PRIMARY KEY  (`FILE_ID`),
  UNIQUE KEY `CHECKSUM` (`CHECKSUM`),
  FULLTEXT KEY `KEYWORDS` (`KEYWORDS`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;
