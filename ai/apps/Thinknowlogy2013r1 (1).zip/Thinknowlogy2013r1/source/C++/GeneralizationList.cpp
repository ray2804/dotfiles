/*
 *	Class:			GeneralizationList
 *	Parent class:	List
 *	Purpose:		To store generalization items
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "GeneralizationItem.cpp"
#include "List.h"

class GeneralizationList : private List
	{
	friend class WordItem;


	// Private deconstructor functions

	void deleteGeneralizationList( GeneralizationItem *searchItem )
		{
		GeneralizationItem *deleteItem;

		while( searchItem != NULL )
			{
			deleteItem = searchItem;
			searchItem = searchItem->nextGeneralizationItem();
			delete deleteItem;
			}
		}


	public:
	// Constructor

	GeneralizationList( WordItem *myWord, CommonVariables *commonVariables )
		{
		initializeListVariables( WORD_GENERALIZATION_LIST_SYMBOL, "GeneralizationList", myWord, commonVariables );
		}

	// Deconstructor

	~GeneralizationList()
		{
		deleteGeneralizationList( firstActiveGeneralizationItem() );
		deleteGeneralizationList( (GeneralizationItem *)firstDeactiveItem() );
		deleteGeneralizationList( (GeneralizationItem *)firstArchivedItem() );
		deleteGeneralizationList( (GeneralizationItem *)firstDeletedItem() );
		}


	// Protected functions

	GeneralizationResultType findGeneralizationItem( bool isRelation, unsigned short questionParameter, unsigned short generalizationWordTypeNr, WordItem *generalizationWordItem )
		{
		GeneralizationResultType generalizationResult;
		GeneralizationItem *searchItem = firstActiveGeneralizationItem();
		char functionNameString[FUNCTION_NAME_LENGTH] = "findGeneralizationItem";

		if( generalizationWordItem != NULL )
			{
			while( searchItem != NULL &&
			!generalizationResult.hasFoundGeneralization )
				{
				if( searchItem->isRelation() == isRelation &&
				searchItem->questionParameter() == questionParameter &&

				( searchItem->generalizationWordTypeNr() == generalizationWordTypeNr ||

				( searchItem->isGeneralizationSingularNoun() &&
				generalizationWordTypeNr == WORD_TYPE_NOUN_PLURAL ) ||

				( searchItem->isGeneralizationPluralNoun() &&
				generalizationWordTypeNr == WORD_TYPE_NOUN_SINGULAR ) ) &&

				searchItem->generalizationWordItem() == generalizationWordItem )
					generalizationResult.hasFoundGeneralization = true;
				else
					searchItem = searchItem->nextGeneralizationItem();
				}
			}
		else
			startError( functionNameString, NULL, "The given generalization word item is undefined" );

		generalizationResult.result = commonVariables()->result;
		return generalizationResult;
		}

	ResultType checkWordItemForUsage( WordItem *unusedWordItem )
		{
		GeneralizationItem *searchItem = firstActiveGeneralizationItem();
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkWordItemForUsage";

		if( unusedWordItem != NULL )
			{
			while( searchItem != NULL )
				{
				if( searchItem->generalizationWordItem() == unusedWordItem )
					return startError( functionNameString, NULL, "The collected word item is still in use" );

				searchItem = searchItem->nextGeneralizationItem();
				}
			}
		else
			return startError( functionNameString, NULL, "The given unused word item is undefined" );

		return commonVariables()->result;
		}

	ResultType createGeneralizationItem( bool isRelation, unsigned short questionParameter, unsigned short specificationWordTypeNr, unsigned short generalizationWordTypeNr, WordItem *generalizationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "createGeneralizationItem";
		if( generalizationWordTypeNr > WORD_TYPE_UNDEFINED &&
		generalizationWordTypeNr < NUMBER_OF_WORD_TYPES )
			{
			if( commonVariables()->currentItemNr < MAX_ITEM_NR )
				{
				if( addItemToActiveList( (Item *)( new GeneralizationItem( isRelation, questionParameter, specificationWordTypeNr, generalizationWordTypeNr, generalizationWordItem, this, myWord(), commonVariables() ) ) ) != RESULT_OK )
					return addError( functionNameString, NULL, "I failed to add an active generalization item" );
				}
			else
				return startError( functionNameString, NULL, "The current item number is undefined" );
			}
		else
			return startError( functionNameString, NULL, "The given generalization word type number is undefined or out of bounds" );

		return commonVariables()->result;
		}

	GeneralizationItem *firstActiveGeneralizationItem()
		{
		return (GeneralizationItem *)firstActiveItem();
		}

	GeneralizationItem *firstActiveGeneralizationItem( bool isRelation )
		{
		GeneralizationItem *firstGeneralizationItem = firstActiveGeneralizationItem();

		return ( firstGeneralizationItem == NULL ? NULL : firstGeneralizationItem->getGeneralizationItem( true, isRelation ) );
		}
	};

/*************************************************************************
 *
 *	"Praise the Lord, for the Lord is good;
 *	celebrate his lovely name with music." (Psalm 135:3)
 *
 *************************************************************************/
