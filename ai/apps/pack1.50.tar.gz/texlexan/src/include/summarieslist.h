/* License/copyright: At the end of this file or read copyright.txt */

/*---------- Declarations --------------*/
int extract_dates(char *optarg,long *startdate,long *enddate);
int extract_summaries(char *file_input,char *file_output,long startdate,long enddate);
int split_dates_targets(char *optarg,char *between_dates,char *list_targets);
