/* License/copyright: At the end of this file or read copyright.txt */

/*---------- Declarations --------------*/
long int excludedfromfile(char *path,char *excludedword,int filenum,char *lang,long int n);
int exclusion(char *excludedword,char *word);

