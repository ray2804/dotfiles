/*
 *	Class:			AdminWrite
 *	Supports class:	AdminItem
 *	Purpose:		To write selected specifications as sentences
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "AdminItem.h"
#include "GeneralizationItem.cpp"
#include "Presentation.cpp"
#include "ReadItem.cpp"
#include "SpecificationItem.cpp"

class AdminWrite
	{
	// Private constructible variables

	bool hasFoundAnyWordPassingGrammarIntegrityCheck_;

	bool isFirstSelfGeneratedAssumption_;
	bool isFirstSelfGeneratedConclusion_;
	bool isFirstSelfGeneratedQuestion_;
	bool isFirstUserQuestion_;
	bool isFirstUserSpecifications_;

	CommonVariables *commonVariables_;
	AdminItem *admin_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	bool hasAllWordsPassed()
		{
		ReadItem *currentReadItem;

		if( ( currentReadItem = admin_->firstActiveReadItem() ) == NULL )
			return false;
		else
			{
			do	{
				if( currentReadItem->readWordTypeString() != NULL &&	// Skip hidden word types
				!currentReadItem->isWordPassingGrammarIntegrityCheck )
					return false;
				}
			while( ( currentReadItem = currentReadItem->nextReadItem() ) != NULL );
			}

		return true;
		}

	ResultType writeSpecification( bool isAssignment, bool isDeactive, bool isArchived, bool writeCurrentSentenceOnly, bool writeJustification, bool writeUserSpecifications, bool writeSelfGeneratedConclusions, bool writeSelfGeneratedAssumptions, bool writeUserQuestions, bool writeSelfGeneratedQuestions, char *integrityCheckSentenceString, WordItem *writeWordItem )
		{
		SpecificationItem *currentSpecificationItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeSpecification";

		if( writeWordItem != NULL )
			{
			if( ( currentSpecificationItem = writeWordItem->firstSelectedSpecification( isAssignment, ( isAssignment && isDeactive ), ( isAssignment && isArchived ), ( writeUserQuestions || writeSelfGeneratedQuestions ) ) ) != NULL )
				{
				do	{
					// Filter self-generated specifications
					if( ( ( writeSelfGeneratedConclusions &&
					currentSpecificationItem->isSelfGeneratedConclusion() ) ||

					( writeSelfGeneratedAssumptions &&
					currentSpecificationItem->isSelfGeneratedAssumption() ) ||

					( writeSelfGeneratedQuestions &&
					currentSpecificationItem->isSelfGeneratedQuestion() ) ||

					// Filter user-entered specifications
					( writeUserSpecifications &&
					currentSpecificationItem->isUserSpecification() ) ||

					( writeUserQuestions &&
					currentSpecificationItem->isUserQuestion() ) ) &&

					// Filter on current or updated sentences
					( !admin_->hasFoundChange() ||		// Nothing has changed. Will result in notification: "I know".
					!writeCurrentSentenceOnly ||
					currentSpecificationItem->hasNewInformation() ) )
						{
						if( writeWordItem->writeSelectedSpecification( false, false, writeCurrentSentenceOnly, false, NO_ANSWER_PARAMETER, currentSpecificationItem ) == RESULT_OK )
							{
							if( strlen( commonVariables_->writeSentenceString ) > 0 )
								{
								if( integrityCheckSentenceString == NULL )
									{
									if( ( writeSelfGeneratedConclusions &&
									isFirstSelfGeneratedConclusion_ ) ||

									( writeSelfGeneratedAssumptions &&
									isFirstSelfGeneratedAssumption_ ) ||

									( writeSelfGeneratedQuestions &&
									isFirstSelfGeneratedQuestion_ ) ||

									( writeUserSpecifications &&
									isFirstUserSpecifications_ ) ||

									( writeUserQuestions &&
									isFirstUserQuestion_ ) )
										{
										if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_NOTIFICATION, ( currentSpecificationItem->isSelfGenerated() ? ( writeSelfGeneratedConclusions ? INTERFACE_LISTING_MY_CONCLUSIONS : ( writeSelfGeneratedAssumptions ? INTERFACE_LISTING_MY_ASSUMPTIONS : INTERFACE_LISTING_MY_QUESTIONS ) ) : ( writeUserSpecifications ? ( currentSpecificationItem->userNr() == commonVariables_->currentUserNr ? INTERFACE_LISTING_YOUR_INFORMATION : INTERFACE_LISTING_MY_INFORMATION ) : INTERFACE_LISTING_YOUR_QUESTIONS ) ) ) == RESULT_OK )
											{
											if( writeSelfGeneratedConclusions )
												isFirstSelfGeneratedConclusion_ = false;
											else
												{
												if( writeSelfGeneratedAssumptions )
													isFirstSelfGeneratedAssumption_ = false;
												else
													{
													if( writeSelfGeneratedQuestions )
														isFirstSelfGeneratedQuestion_ = false;
													else
														{
														if( writeUserSpecifications )
															isFirstUserSpecifications_ = false;
														else
															{
															if( writeUserQuestions )
																isFirstUserQuestion_ = false;
															}
														}
													}
												}
											}
										else
											return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write my conclusions header" );
										}

									if( writeJustification &&
									currentSpecificationItem->isSelfGenerated() )
										{
										if( admin_->writeJustificationSpecification( commonVariables_->writeSentenceString, currentSpecificationItem ) != RESULT_OK )
											return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write a justification line" );
										}
									else
										{
										if( commonVariables_->presentation->writeDiacriticalText( PRESENTATION_PROMPT_WRITE, commonVariables_->writeSentenceString ) != RESULT_OK )
											return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write a sentence" );
										}
									}
								else
									{
									if( markWordsPassingGrammarIntegrityCheck() != RESULT_OK )
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to mark the words that are passing the integrity check" );
									}
								}
							}
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write a selected specification" );
						}
					}
				while( ( integrityCheckSentenceString == NULL ||
				!admin_->hasPassedGrammarIntegrityCheck() ) &&

				( currentSpecificationItem = currentSpecificationItem->nextSelectedSpecificationItem( false ) ) != NULL );
				}
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given write word item is undefined" );

		return commonVariables_->result;
		}

	ResultType writeSelfGeneratedInfo( bool writeCurrentSentenceOnly, bool writeJustification, bool writeSelfGeneratedConclusions, bool writeSelfGeneratedAssumptions, bool writeSelfGeneratedQuestions, WordItem *writeWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeSelfGeneratedInfo";
		if( writeSpecification( false, false, false, writeCurrentSentenceOnly, writeJustification, false, writeSelfGeneratedConclusions, writeSelfGeneratedAssumptions, false, writeSelfGeneratedQuestions, NULL, writeWordItem ) == RESULT_OK )
			{
			if( writeSpecification( true, false, false, writeCurrentSentenceOnly, writeJustification, false, writeSelfGeneratedConclusions, writeSelfGeneratedAssumptions, false, writeSelfGeneratedQuestions, NULL, writeWordItem ) == RESULT_OK )
				{
				if( writeSpecification( true, true, false, writeCurrentSentenceOnly, writeJustification, false, writeSelfGeneratedConclusions, writeSelfGeneratedAssumptions, false, writeSelfGeneratedQuestions, NULL, writeWordItem ) == RESULT_OK )
					{
					if( writeSpecification( true, false, true, writeCurrentSentenceOnly, writeJustification, false, writeSelfGeneratedConclusions, writeSelfGeneratedAssumptions, false, writeSelfGeneratedQuestions, NULL, writeWordItem ) != RESULT_OK )
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write self-generated archive assignments" );
					}
				else
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write self-generated past-tense assignments" );
				}
			else
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write self-generated current-tense assignments" );
			}
		else
			return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write self-generated specifications" );

		return commonVariables_->result;
		}

	ResultType writeUserInfo( bool writeCurrentSentenceOnly, bool writeUserSpecifications, bool writeUserQuestions, char *integrityCheckSentenceString, WordItem *writeWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeUserInfo";
		// Respond with a user-entered specification or assignment
		if( writeUserSpecifications )
			{
			if( writeSpecification( false, false, false, writeCurrentSentenceOnly, false, writeUserSpecifications, false, false, false, false, integrityCheckSentenceString, writeWordItem ) == RESULT_OK )
				{
				if( writeSpecification( true, false, false, writeCurrentSentenceOnly, false, writeUserSpecifications, false, false, false, false, integrityCheckSentenceString, writeWordItem ) == RESULT_OK )
					{
					if( writeSpecification( true, true, false, writeCurrentSentenceOnly, false, writeUserSpecifications, false, false, false, false, integrityCheckSentenceString, writeWordItem ) == RESULT_OK )
						{
						if( writeSpecification( true, false, true, writeCurrentSentenceOnly, false, writeUserSpecifications, false, false, false, false, integrityCheckSentenceString, writeWordItem ) != RESULT_OK )
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write user-entered archive assignments" );
						}
					else
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write user-entered past-tense assignments" );
					}
				else
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write user-entered current-tense assignments" );
				}
			else
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write user-entered specifications" );
			}

		// Respond with a user question
		if( writeUserQuestions )
			{
			if( writeSpecification( false, false, false, writeCurrentSentenceOnly, false, false, false, false, writeUserQuestions, false, integrityCheckSentenceString, writeWordItem ) == RESULT_OK )
				{
				if( writeSpecification( true, false, false, writeCurrentSentenceOnly, false, false, false, false, writeUserQuestions, false, integrityCheckSentenceString, writeWordItem ) == RESULT_OK )
					{
					if( writeSpecification( true, true, false, writeCurrentSentenceOnly, false, false, false, false, writeUserQuestions, false, integrityCheckSentenceString, writeWordItem ) == RESULT_OK )
						{
						if( writeSpecification( true, false, true, writeCurrentSentenceOnly, false, false, false, false, writeUserQuestions, false, integrityCheckSentenceString, writeWordItem ) != RESULT_OK )
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write user questions with archive assignments" );
						}
					else
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write user questions with past-tense assignments" );
					}
				else
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write user questions with current-tense assignments" );
				}
			else
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write user questions without assignments" );
			}

		return commonVariables_->result;
		}

	ResultType writeSelectedSpecificationInfo( WordItem *writeWordItem )
		{
		GeneralizationItem *currentGeneralizationItem;
		WordItem *currentGeneralizationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeSpecificationInfo";

		if( ( currentGeneralizationItem = writeWordItem->firstActiveGeneralizationItemOfSpecification() ) != NULL )
			{
			do	{
				if( ( currentGeneralizationWordItem = currentGeneralizationItem->generalizationWordItem() ) != NULL )
					{
					// Respond with active specifications
					if( currentGeneralizationWordItem->writeSelectedSpecificationInfo( false, false, false, false, writeWordItem ) == RESULT_OK )
						{
						// Respond with active specification questions
						if( currentGeneralizationWordItem->writeSelectedSpecificationInfo( false, false, false, true, writeWordItem ) == RESULT_OK )
							{
							// Respond with active assignments
							if( currentGeneralizationWordItem->writeSelectedSpecificationInfo( true, false, false, false, writeWordItem ) == RESULT_OK )
								{
								// Respond with active assignment questions
								if( currentGeneralizationWordItem->writeSelectedSpecificationInfo( true, false, false, true, writeWordItem ) == RESULT_OK )
									{
									// Respond with deactive assignments
									if( currentGeneralizationWordItem->writeSelectedSpecificationInfo( true, true, false, false, writeWordItem ) == RESULT_OK )
										{
										// Respond with deactive assignment questions
										if( currentGeneralizationWordItem->writeSelectedSpecificationInfo( true, true, false, true, writeWordItem ) == RESULT_OK )
											{
											// Respond with archive assignments
											if( currentGeneralizationWordItem->writeSelectedSpecificationInfo( true, false, true, false, writeWordItem ) == RESULT_OK )
												{
												// Respond with archive assignment questions
												if( currentGeneralizationWordItem->writeSelectedSpecificationInfo( true, false, true, true, writeWordItem ) != RESULT_OK )
													return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write archive assignment questions" );
												}
											else
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write archive assignments" );
											}
										else
											return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write deactive assignment questions" );
										}
									else
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write deactive assignments" );
									}
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write active assignment questions" );
								}
							else
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write active assignments" );
							}
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write active specification questions" );
						}
					else
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write active specifications" );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found an undefined generalization word" );
				}
			while( ( currentGeneralizationItem = currentGeneralizationItem->nextGeneralizationItemOfSpecification() ) != NULL );
			}

		return commonVariables_->result;
		}

	ResultType writeSelectedRelationInfo( WordItem *writeWordItem )
		{
		GeneralizationItem *currentGeneralizationItem;
		WordItem *currentGeneralizationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeRelatedInfo";

		if( ( currentGeneralizationItem = writeWordItem->firstActiveGeneralizationItemOfRelation() ) != NULL )
			{
			do	{
				if( ( currentGeneralizationWordItem = currentGeneralizationItem->generalizationWordItem() ) != NULL )
					{
					if( currentGeneralizationItem->isRelation() )
						{
						// Respond with active related specifications
						if( currentGeneralizationWordItem->writeSelectedRelationInfo( false, false, false, false, writeWordItem ) == RESULT_OK )
							{
							// Respond with active related specification questions
							if( currentGeneralizationWordItem->writeSelectedRelationInfo( false, false, false, true, writeWordItem ) == RESULT_OK )
								{
								// Respond with active related assignments
								if( currentGeneralizationWordItem->writeSelectedRelationInfo( true, false, false, false, writeWordItem ) == RESULT_OK )
									{
									// Respond with active related assignment questions
									if( currentGeneralizationWordItem->writeSelectedRelationInfo( true, false, false, true, writeWordItem ) == RESULT_OK )
										{
										// Respond with deactive related assignments
										if( currentGeneralizationWordItem->writeSelectedRelationInfo( true, true, false, false, writeWordItem ) == RESULT_OK )
											{
											// Respond with deactive related assignment questions
											if( currentGeneralizationWordItem->writeSelectedRelationInfo( true, true, false, true, writeWordItem ) == RESULT_OK )
												{
												// Respond with archive related assignments
												if( currentGeneralizationWordItem->writeSelectedRelationInfo( true, false, true, false, writeWordItem ) == RESULT_OK )
													{
													// Respond with archive related assignment questions
													if( currentGeneralizationWordItem->writeSelectedRelationInfo( true, false, true, true, writeWordItem ) != RESULT_OK )
														return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write archive related assignment questions" );
													}
												else
													return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write archive related assignment" );
												}
											else
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write deactive related assignment questions" );
											}
										else
											return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write active related assignments" );
										}
									else
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write active related assignment assignments" );
									}
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write active related assignments" );
								}
							else
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write active related specification questions" );
							}
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write active related specifications" );
						}
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found an undefined generalization word" );
				}
			while( ( currentGeneralizationItem = currentGeneralizationItem->nextGeneralizationItemOfRelation() ) != NULL );
			}

		return commonVariables_->result;
		}

	ResultType markWordsPassingGrammarIntegrityCheck()
		{
		ReadResultType readResult;
		size_t writeSentenceStringLength;
		size_t wordPosition = 0;
		char *readWordTypeString;
		ReadItem *currentReadItem;
		ReadItem *skipReadItem = NULL;
		char functionNameString[FUNCTION_NAME_LENGTH] = "markWordsPassingGrammarIntegrityCheck";

		if( ( currentReadItem = admin_->firstActiveReadItem() ) != NULL )
			{
			if( ( writeSentenceStringLength = strlen( commonVariables_->writeSentenceString ) ) > 0 )
				{
				do	{
					do	{
						if( ( readResult = admin_->getWordInfo( false, wordPosition, commonVariables_->writeSentenceString ) ).result == RESULT_OK )
							{
							if( readResult.wordLength > 0 &&
							( readWordTypeString = currentReadItem->readWordTypeString() ) != NULL )	// Skip hidden word types
								{
								if( strlen( readWordTypeString ) == readResult.wordLength &&
								strncmp( &commonVariables_->writeSentenceString[wordPosition], readWordTypeString, readResult.wordLength ) == 0 )
									{
									hasFoundAnyWordPassingGrammarIntegrityCheck_ = true;
									currentReadItem->isWordPassingGrammarIntegrityCheck = true;
									}
								else
									{
									// Skip generalization conjunction
									if( currentReadItem->isGeneralizationSpecification() ||

									// Skip linked conjunction
									currentReadItem->isLinkedGeneralizationConjunction() ||

									// Skip grammar conjunction
									currentReadItem->isSentenceConjunction() ||

									// Skip text until it is implemented
									currentReadItem->isReadWordText() )
										currentReadItem->isWordPassingGrammarIntegrityCheck = true;	// Skip until implemented
									else
										{
										if( skipReadItem == NULL )
											skipReadItem = currentReadItem;
										}
									}
								}
							}
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get the length of the current grammar word" );
						}
					while( readResult.wordLength > 0 &&
					( currentReadItem = currentReadItem->nextReadItem() ) != NULL );

					if( skipReadItem != NULL &&
					currentReadItem == NULL )
						currentReadItem = skipReadItem;

					wordPosition = readResult.nextWordPosition;
					}
				while( currentReadItem != NULL &&
				readResult.nextWordPosition < writeSentenceStringLength );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The write sentence string is empty" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I couldn't find any read words" );

		return commonVariables_->result;
		}


	public:
	// Constructor

	AdminWrite( AdminItem *admin, WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		hasFoundAnyWordPassingGrammarIntegrityCheck_ = false;

		isFirstSelfGeneratedAssumption_ = true;
		isFirstSelfGeneratedConclusion_ = true;
		isFirstSelfGeneratedQuestion_ = true;
		isFirstUserQuestion_ = true;
		isFirstUserSpecifications_ = true;

		admin_ = admin;
		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "AdminWrite" );

		if( commonVariables_ != NULL )
			{
		if( admin_ != NULL )
			{
			if( myWord_ == NULL )
				strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given admin is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	void initializeAdminWriteVariables()
		{
		isFirstSelfGeneratedAssumption_ = true;
		isFirstSelfGeneratedConclusion_ = true;
		isFirstSelfGeneratedQuestion_ = true;
		isFirstUserQuestion_ = true;
		isFirstUserSpecifications_ = true;
		}

	ResultType answerQuestions()
		{
		WordItem *currentWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "answerQuestions";

		if( commonVariables_->isQuestionAlreadyAnswered )
			{
			if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_NOTIFICATION, INTERFACE_QUESTION_IS_ALREADY_ANSWERED ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface notification" );
			}

		// Do in all words for an answer
		if( ( currentWordItem = commonVariables_->firstWordItem ) != NULL )
			{
			do	{
				if( currentWordItem->findAnswerToNewUserQuestion() != RESULT_OK )
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find an answer to new questions of the user about word \"", currentWordItem->anyWordTypeString(), "\"" );
				}
			while( ( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The first word item is undefined" );

		if( commonVariables_->isUserQuestion &&
		!commonVariables_->hasFoundAnswerToQuestion &&
		!commonVariables_->isQuestionAlreadyAnswered )
			{
			if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_NOTIFICATION, INTERFACE_QUESTION_I_LL_ANSWER_AS_SOON_AS_I_HAVE_ENOUGH_INFORMATION ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface notification" );
			}

		return commonVariables_->result;
		}

	ResultType integrityCheck( bool isQuestion, char *integrityCheckSentenceString )
		{
		ReadItem *currentReadItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "integrityCheck";

		hasFoundAnyWordPassingGrammarIntegrityCheck_ = false;

		if( admin_->checkForChanges() == RESULT_OK )
			{
			if( admin_->hasFoundChange() &&		// Skip direct text and known knowledge
			( currentReadItem = admin_->firstActiveReadItem() ) != NULL )
				{
				do	{	// Select all generalizations in a sentence
					if( currentReadItem->isGeneralizationWord() )
						{
						if( writeInfoAboutWord( true, false, !isQuestion, false, false, isQuestion, false, false, false, integrityCheckSentenceString, currentReadItem->readWordItem() ) != RESULT_OK )
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write info about word \"", currentReadItem->readWordItem()->anyWordTypeString(), "\"" );
						}
					}
				// Skip selections until writing of selection is implemented
				while( !currentReadItem->isSelection() &&

				// Skip imperatives until writing of imperatives is implemented
				!currentReadItem->isImperative() &&
				( currentReadItem = currentReadItem->nextReadItem() ) != NULL );

				if( currentReadItem == NULL &&		// Sentence isn't skipped (selections and imperatives)
				!hasAllWordsPassed() )
					{
					if( admin_->isSystemStartingUp() &&
					integrityCheckSentenceString != NULL )
						{
						if( commonVariables_->presentation->writeInterfaceText( PRESENTATION_PROMPT_WARNING, INTERFACE_SENTENCE_ERROR_GRAMMAR_INTEGRITY_STORE_OR_RETRIEVE, EMPTY_STRING, INTERFACE_SENTENCE_ERROR_GRAMMAR_INTEGRITY_SENTENCE, integrityCheckSentenceString, INTERFACE_SENTENCE_ERROR_GRAMMAR_INTEGRITY_SENTENCE_END ) != RESULT_OK )
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface warning" );
						}
					else
						{
						if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WARNING, INTERFACE_SENTENCE_ERROR_GRAMMAR_INTEGRITY_STORE_OR_RETRIEVE, EMPTY_STRING, INTERFACE_SENTENCE_ERROR_GRAMMAR_INTEGRITY_THIS_SENTENCE ) != RESULT_OK )
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface warning" );
						}

					if( hasFoundAnyWordPassingGrammarIntegrityCheck_ &&
					strlen( commonVariables_->writeSentenceString ) > 0 )
						{
						if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WARNING, INTERFACE_SENTENCE_ERROR_GRAMMAR_INTEGRITY_I_RETRIEVED_FROM_MY_SYSTEM, commonVariables_->writeSentenceString, INTERFACE_SENTENCE_ERROR_GRAMMAR_INTEGRITY_SENTENCE_END ) != RESULT_OK )
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface warning" );
						}

					if( admin_->isSystemStartingUp() &&
					commonVariables_->hasShownWarning )
						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "An integrity error occurred during startup" );
					}
				}
			}
		else
			return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check for changes" );

		return commonVariables_->result;
		}

	ResultType writeSelfGeneratedInfo( bool writeSelfGeneratedConclusions, bool writeSelfGeneratedAssumptions, bool writeSelfGeneratedQuestions )
		{
		WordItem *currentWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeSelfGeneratedInfo";
		isFirstSelfGeneratedAssumption_ = true;
		isFirstSelfGeneratedConclusion_ = true;
		isFirstSelfGeneratedQuestion_ = true;

		// Do in all words for self-generated info
		if( ( currentWordItem = commonVariables_->firstWordItem ) != NULL )
			{
			do	{
				if( writeInfoAboutWord( true, false, false, writeSelfGeneratedConclusions, writeSelfGeneratedAssumptions, false, writeSelfGeneratedQuestions, false, false, NULL, currentWordItem ) != RESULT_OK )
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write info about word \"", currentWordItem->anyWordTypeString(), "\"" );
				}
			while( ( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The first word item is undefined" );

		return commonVariables_->result;
		}

	ResultType writeSelfGeneratedInfo( bool writeCurrentSentenceOnly, bool writeJustification, bool writeSelfGeneratedConclusions, bool writeSelfGeneratedAssumptions, bool writeSelfGeneratedQuestions, char *integrityCheckSentenceString, WordItem *writeWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeSelfGeneratedInfo";
		// Respond with a self-generated conclusions
		if( integrityCheckSentenceString == NULL )	// Don't perform integrity check for self-generated info
			{
			if( writeSelfGeneratedConclusions )		// Self-generated conclusions
				{
				if( writeSelfGeneratedInfo( writeCurrentSentenceOnly, writeJustification, true, false, false, writeWordItem ) != RESULT_OK )
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write self-generated conclusions" );
				}
			}

		// Respond with a self-generated assumptions
		if( writeSelfGeneratedAssumptions )
			{
			if( writeSelfGeneratedInfo( writeCurrentSentenceOnly, writeJustification, false, true, false, writeWordItem ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write self-generated assumptions" );
			}

		// Respond with a self-generated questions
		if( writeSelfGeneratedQuestions )
			{
			if( writeSelfGeneratedInfo( writeCurrentSentenceOnly, writeJustification, false, false, true, writeWordItem ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write self-generated questions" );
			}

		return commonVariables_->result;
		}

	ResultType writeInfoAboutWord( bool writeCurrentSentenceOnly, bool writeJustification, bool writeUserSpecifications, bool writeSelfGeneratedConclusions, bool writeSelfGeneratedAssumptions, bool writeUserQuestions, bool writeSelfGeneratedQuestions, bool writeSpecificationInfo, bool writeRelatedInfo, char *integrityCheckSentenceString, WordItem *writeWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeInfoAboutWord";
		if( writeUserQuestions ||
		writeUserSpecifications )
			{
			if( writeUserInfo( writeCurrentSentenceOnly, writeUserSpecifications, writeUserQuestions, integrityCheckSentenceString, writeWordItem ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write the user generated info" );
			}

		if( integrityCheckSentenceString == NULL &&		// Don't perform integrity check for self-generated conclusions

		( writeSelfGeneratedConclusions ||
		writeSelfGeneratedAssumptions ||
		writeSelfGeneratedQuestions ) )
			{
			if( writeSelfGeneratedInfo( writeCurrentSentenceOnly, writeJustification, writeSelfGeneratedConclusions, writeSelfGeneratedAssumptions, writeSelfGeneratedQuestions, NULL, writeWordItem ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write the self-generated info" );
			}

		// Respond with other specification info
		if( integrityCheckSentenceString == NULL &&		// Don't perform integrity check for other specification info
		writeSpecificationInfo )
			{
			if( writeSelectedSpecificationInfo( writeWordItem ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write selected specification info" );
			}

		// Respond with related info
		if( integrityCheckSentenceString == NULL &&		// Don't perform integrity check for related info
		writeRelatedInfo )
			{
			if( writeSelectedRelationInfo( writeWordItem ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write selected related info" );
			}

		return commonVariables_->result;
		}
	};

/*************************************************************************
 *
 *	"Give thanks to the Lord, for he is good!
 *	His faithful love endures forever." (Psalm 107:1)
 *
 *************************************************************************/
