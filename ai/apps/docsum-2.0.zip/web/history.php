<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<?php
	
	/* Load the functions file */
	include_once 'objects.php';
	
	if (isset($_GET["delete"])) {
		$fileid = urldecode($_GET["delete"]);
		if(!ereg("[0-9]+", $fileid)) $fileid = -1;
	} else {
		$fileid = -1;
	}
	
	$page = "history";
	include_once 'head.php';
	
	$linkGen = new LinkGenerator($main_page);
	$cmdGen = new CommandGenerator();
	$cmdExe = new CommandExecuter();
	$pgGen = new PageGenerator($main_page);
	
	//echo $main_page;
	
	echo $header_html;
	echo $linkGen->i_link().' | '. $linkGen->a_link();
	echo "<center><a href=\"$main_page\">$logo_html</a></center>";
	
	if($fileid >=0){
		echo '<h3 class="indented"><font style="color:red;">file delete results</font></h3>';
		echo '<p class="indented">';
		$cmd = $cmdGen->d_file($fileid);
		$output = $cmdExe->py_exe($cmd);
		foreach($output as $line) echo "$line</br>";
		echo '</p>';
	}
	
	echo '<h3 class="indented">history</h3>';
	echo '<p class="indented">this provides some recent data about how docsum is being used. specifically,
	the tracking information below shows the files being used to create summary documents, and recent/frequent 
	summary queries. hopefully, this information will eventually provide useful information to improve this
	applications.</p>';
	
	echo '<h3 class="indented">topic links</h3>';
	echo '<p class="indented">you can sample some recent or frequent summaries by clicking the links
	in the topic tables below.</p>';
	
	echo '<h3 class="indented">delete warning</h3>';
	echo '<p class="indented">please be aware that the delete action will not be confirmed. 
	once the link is clicked, the file content will be become inactive in the database.</p>';
	
	$pgGen->historyTopicLists($cmdGen,$cmdExe);
?>	
	<br><center>
	<a href="." onclick="showFiles('active');return false;">show active files</a> | <a href="." onclick="showFiles('inactive');return false;">show inactive files</a> | <a href="." onclick="showFiles('hide');return false;">hide files</a>
	</center>
	<div id="history"></div>
	
<?php 	echo $foot_html;	?>
