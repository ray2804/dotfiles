#! /usr/bin/env python
# -*- coding: UTF-8 -*-
###
#
# This file is the legal property of Jean-Pierre Redonnet
# <redonnetbrouk@aol.com>
# Copyright (c) 2008-2009 Jean-Pierre Redonnet
#
# This program 'texlexan.py'(the GUI of texlexan) is a free softwares;
# you can redistribute it and/or modify it under the terms of the GNU
# General Public License version 3 as published by the Free Software
# Foundation.
#
# texlexan.py is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# long with texlexan.py.If not, see <http://www.gnu.org/licenses/>.
#
###
import pygtk
pygtk.require('2.0')
import gtk,gobject
import sys,os,shutil,string,time,urllib
import urlparse
import webbrowser
from time import localtime,strftime,strptime,mktime,clock

Prog_name='TLSearch'
version='GUI 0.02'
date_version='Dec 14 2009'

class App:
   pass

#----------- Display info in a small window -------------
def message(title,message):
   dia = gtk.Dialog(title,
        None,  #the toplevel wgt of your app
        gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT,  #binary flags or'ed together
        (gtk.STOCK_OK, gtk.RESPONSE_CLOSE))
   dia.vbox.pack_start(gtk.Label('\n'+message+'\n'))
   dia.show_all()
   result = dia.run()
   dia.destroy()
   return

#---------- start thesearch engine: sis in command line -----------------
def valid(w):
    global result
    print "\nStart the CLI Engines...cross your fingers!"
    console_encoding = 'UTF-8'
    prog_sis=prg_path
    #suppress space
    text=entry1.get_text().strip();
    if len(text)==0:
       return
    if check3.get_active():
       text=text.replace('  ',' ')
       text=text.replace(' ',',')
    textbis='"'+text.encode(console_encoding)+'"'
    #Prepare the cmde line for texlexan
    if check1.get_active(): prog_sis+=' -e0' #strict
    else: prog_sis+=' -e1' #one error accepted
    if (check2.get_active()):prog_sis+=' -w' #weak stemming
    if (check4.get_active()==False):prog_sis+=' -c' #no case sensitive
    if check5.get_active(): prog_sis+=' -s1' #relevant sentences
    else: prog_sis+=' -s2' #whole summary
    prog_sis+=' -l -f '+archive_path+' '+textbis
    result=result_path+'/result.html'
    os.system(prog_sis+'>'+result)
    webbrowser.open(result)
    return True

#---------------- Manage the main window ----------------------
#clear the text window
def erase(w):
   entry1.set_text("")
   return
   
#short help
def help(w):
   dia = gtk.Dialog('Help',
   None,  #the toplevel wgt of your app
   gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT,  #binary flags or'ed together
   ('_More info', 77,gtk.STOCK_CLOSE, gtk.RESPONSE_CLOSE))
   dia.vbox.pack_start(gtk.Label(
      '\nJP Redonnet\nVers. '+version+' - '+date_version+'\n'+Prog_name+' - Basic\n\n'+
      'Search inside the whole summaries archived.\n'+
      'Show the result (summaries) with your web browser.\n'+
      'Provide the link to the original documment.'))
   dia.show_all()
   result = dia.run()
   dia.destroy()
   if result == 77:
      webbrowser.open("http://texlexan.sourceforge.net/")
      gtk.RESPONSE_CLOSE
   return     

def quit(w):
   try: os.remove(result)
   except: None
   gtk.main_quit()

#### program starts here ! ####
home_user_path=os.path.expanduser('~')  #home directory
texlexan_path=home_user_path+'/texlexan_cfg/' #contain the config file
result_path=home_user_path+'/texlexan_result/' #summaries files
archive_path=home_user_path+'/texlexan_archive/' #archives downloaded files
prg_path=home_user_path+'/texlexan_prog' #contain the main prog
width_col='70' #default abstracts have 70 chars per line
lang_char='Latin-1' #output of texlexan (latin1) is converted in unicode
memory_alloc=10 #how many block of mem to alloc
result=''

# if config path does'nt exist exit
if not os.path.isdir(texlexan_path):
    message("Error!",texlexan_path+" doesn't exist.\nPlease, run TexLexAn first.")
    exit()

#read config file 
version_n='0'
text_path=''
try: f=open(texlexan_path+'texlexan.cfg','r')
except:
    message('Error','impossible to open '+texlexan_path+'texlexan.cfg')
    exit()
for line in f:
    if line[:3]=='vn:': version_n=string.strip(line[3:-1])
    #if line[:3]=='sp:': prg_path=string.strip(line[3:-1])
    if line[:3]=='rp:': result_path=string.strip(line[3:-1])
    if line[:3]=='ap:': archive_path=string.strip(line[3:-1])
    if line[:3]=='cs:': char_set=string.upper(string.strip(line[3:-1]))
    if line[:3]=='ln:': language=string.strip(line[3:-1])
    if line[:3]=='te:': terminal_e=string.strip(line[3:-1])
    if line[:3]=='wc:': width_col=string.atoi(string.strip(line[3:-1]))
    if line[:3]=='LC:': lang_char=string.strip(line[3:-1])
    if line[:3]=='ma:': memory_alloc=string.atoi(string.strip(line[3:-1]))
f.close()

if version_n<>'2':
    message('Error','Config file is not compatible\n I an continuing with default values\n Please read change.txt')
    exit

if text_path=='': text_path=home_user_path

#Check if main prog 'sis' exist
prg_path=prg_path+"/sis"
if not os.path.isfile(prg_path):
    message("Error!!!",prg_path+" doesn't exist?\nSorry, I can't continue.")
    exit()
    
#Check if the archived files folder exist
if not os.path.isdir(archive_path):
    message("Info",archive_path+" doesn't exist!")

# *** The main window ***
# This window is used to enter the file name of the text to analyze 
# and the options to send to texlexan in command line

w = gtk.Window()
w.set_keep_above(True)
w.set_title(Prog_name+' '+version)
w.set_default_size(100, 100)
w.drag_dest_set(0, [], 0)
h0box = gtk.HBox(False, 0)
h1box = gtk.HBox(False, 0)
h2box = gtk.HBox(False, 0)
h3box = gtk.HBox(False, 0)
vbox = gtk.VBox(False, 0)
hbox = gtk.HBox(False, 0)
h1box = gtk.HBox(False, 0)
w.add(vbox)
#entry target words for sentiment
entry1 = gtk.Entry()
h1box.pack_start(entry1, True, True, 0)
frame0 = gtk.Frame('Searched word')
frame0.add(h1box)
vbox.add(frame0)
#checkbox
check1 = gtk.CheckButton("Strict")
vbox.pack_start(check1, False, False, 0)
check1.set_active(False)
check2 = gtk.CheckButton("Stemming")
vbox.pack_start(check2, False, False, 0)
check2.set_active(False)
check3 = gtk.CheckButton("Separate words")
vbox.pack_start(check3, False, False, 0)
check3.set_active(False)
check4 = gtk.CheckButton("Case sensitive")
vbox.pack_start(check4, False, False, 0)
check4.set_active(False)
check5 = gtk.CheckButton("Relevant sentences")
vbox.pack_start(check5, False, False, 0)
check5.set_active(False)
#buttons
button1 = gtk.Button("_Ok",gtk.STOCK_OK)
hbox.pack_start(button1, False, False, 0)
button2 = gtk.Button("_Clear",gtk.STOCK_CLEAR)
hbox.pack_start(button2, False, False, 0)
button3 = gtk.Button("_Help",gtk.STOCK_HELP)
hbox.pack_start(button3, False, False, 0)
button4 = gtk.Button("_Close",gtk.STOCK_QUIT)
hbox.pack_start(button4, False, False, 0)
vbox.add(hbox)
#connections
button1.connect("clicked",valid)   
button2.connect("clicked",erase)
button3.connect("clicked",help)
button4.connect("clicked",quit)
w.show_all()

   
gtk.main()


#gui frontend for the text analyzer: texlexan
#JP Redonnet, redonnetbrouk@aol.com
#Well, not very fancy but it works!
