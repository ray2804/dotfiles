/*
 *	Class:			AdminSolve
 *	Supports class:	AdminItem
 *	Purpose:		Trying to solve (= to assign) words according to the
					given selections
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "AdminItem.h"
#include "Presentation.cpp"
#include "ScoreList.h"
#include "SelectionList.h"
#include "SpecificationItem.cpp"
#include "WordList.cpp"

class AdminSolve
	{
	// Private constructible variables

	bool canWordBeSolved_;
	bool hasFoundPossibility_;
	bool hasFoundScoringAssignment_;
	bool isConditionSatisfied_;

	unsigned short solveLevel_;

	unsigned long oldSatisfiedScore_;
	unsigned long newSatisfiedScore_;
	unsigned long oldDissatisfiedScore_;
	unsigned long newDissatisfiedScore_;
	unsigned long oldNotBlockingScore_;
	unsigned long newNotBlockingScore_;
	unsigned long oldBlockingScore_;
	unsigned long newBlockingScore_;

	unsigned long currentSolveProgress_;

	SelectionItem *currentExecutionSelectionItem_;

	SpecificationItem *comparisonAssignmentItem_;
	SpecificationItem *firstComparisonAssignmentItem_;
	SpecificationItem *secondComparisonAssignmentItem_;

	CommonVariables *commonVariables_;
	AdminItem *admin_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	void clearAllWordSolveChecksInAllWords()
		{
		WordItem *currentWordItem;

		if( ( currentWordItem = commonVariables_->firstWordItem ) != NULL )		// Do in all words
			{
			do	currentWordItem->isWordCheckedForSolving = false;
			while( ( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}
		}

	bool isNumeralString( char *checkString )
		{
		size_t stringLength;
		size_t position = 0;

		if( checkString != NULL &&
		( stringLength = strlen( checkString ) ) > 0 )
			{
			while( position < stringLength &&
			isdigit( checkString[position] ) )
				position++;

			return ( position == stringLength );
			}

		return false;
		}

	ResultType getComparisonAssignment( bool isNumeralRelation, WordItem *specificationWordItem, WordItem *relationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "getComparisonAssignment";
		comparisonAssignmentItem_ = NULL;

		if( specificationWordItem != NULL )
			{
			if( isNumeralRelation )
				comparisonAssignmentItem_ = specificationWordItem->firstActiveNumeralAssignment();
			else
				{
				if( relationWordItem == NULL )
					comparisonAssignmentItem_ = specificationWordItem->firstActiveStringAssignment();
				else
					{
					if( specificationWordItem->isNounHead() )
						comparisonAssignmentItem_ = relationWordItem->lastActiveAssignmentButNotAQuestion();
					else
						{
						if( specificationWordItem->isNounTail() )
							comparisonAssignmentItem_ = relationWordItem->firstActiveAssignmentButNotAQuestion();
						else
							{
							if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WARNING, INTERFACE_IMPERATIVE_WARNING_I_DONT_KNOW_HOW_TO_EXECUTE_IMPERATIVE_VERB_START, specificationWordItem->anyWordTypeString(), INTERFACE_IMPERATIVE_WARNING_I_DONT_KNOW_HOW_TO_EXECUTE_IMPERATIVE_VERB_END ) != RESULT_OK )
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface warning" );
							}
						}
					}
				}
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word item is undefined" );

		return commonVariables_->result;
		}

	ResultType deleteAssignmentLevelInAllWords()
		{
		WordItem *currentWordItem;

		if( ( currentWordItem = commonVariables_->firstWordItem ) != NULL )		// Do in all words
			{
			do	currentWordItem->deleteAssignmentLevelInWord();
			while( ( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}

		return commonVariables_->result;
		}

	ResultType backTrackConditionScorePaths( bool isAddScores, bool isInverted, bool duplicatesAllowed, bool prepareSort, unsigned short executionLevel, unsigned short solveStrategyParameter, unsigned int conditionSentenceNr )
		{
		bool isNewStart;
		bool isWaitingForNewLevel;
		bool isWaitingForNewStart;
		bool hasFoundScore = false;
		unsigned short selectionLevel;
		unsigned short handledSelectionLevel;
		unsigned short previousSelectionLevel;
		unsigned short unhandledSelectionLevel;
		SelectionItem *conditionSelectionItem;
		SelectionItem *previousConditionSelectionItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "backTrackConditionScorePaths";

		if( admin_->conditionList != NULL )
			{
			admin_->conditionList->clearConditionChecksForSolving( MAX_LEVEL, conditionSentenceNr );

			do	{
				isWaitingForNewLevel = false;
				isWaitingForNewStart = false;
				handledSelectionLevel = MAX_LEVEL;
				previousSelectionLevel = NO_SELECTION_LEVEL;
				unhandledSelectionLevel = MAX_LEVEL;
				previousConditionSelectionItem = NULL;

				if( ( conditionSelectionItem = admin_->conditionList->firstConditionSelectionItem( conditionSentenceNr ) ) != NULL )
					{
					if( isAddScores )
						{
						oldSatisfiedScore_ = NO_SCORE;
						newSatisfiedScore_ = NO_SCORE;
						oldDissatisfiedScore_ = NO_SCORE;
						newDissatisfiedScore_ = NO_SCORE;
						oldNotBlockingScore_ = NO_SCORE;
						newNotBlockingScore_ = NO_SCORE;
						oldBlockingScore_ = NO_SCORE;
						newBlockingScore_ = NO_SCORE;
						}

					do	{
						isNewStart = conditionSelectionItem->isNewStart();
						selectionLevel = conditionSelectionItem->selectionLevel();

						if( conditionSelectionItem->isConditionCheckedForSolving )
							isWaitingForNewStart = true;
						else
							{
							if( isNewStart &&
							previousConditionSelectionItem != NULL )											// Not first start item
								{
								isWaitingForNewStart = false;

								if( selectionLevel == previousSelectionLevel )			// Second brance on the same level
									{
									if( !isWaitingForNewLevel )
										{
										if( handledSelectionLevel == MAX_LEVEL )
											{
											handledSelectionLevel = selectionLevel;

											if( previousConditionSelectionItem->isConditionCheckedForSolving )	// This is a new brance
												conditionSelectionItem->isConditionCheckedForSolving = true;
											else						// The previous brance was a new brance and this one is unhandled
												{
												isWaitingForNewLevel = true;
												unhandledSelectionLevel = selectionLevel;
												previousConditionSelectionItem->isConditionCheckedForSolving = true;
												}
											}
										else
											{
											isWaitingForNewLevel = true;

											if( unhandledSelectionLevel == MAX_LEVEL )	// This brance isn't handled yet
												unhandledSelectionLevel = selectionLevel;
											}
										}
									}
								else									// New start on a new level
									isWaitingForNewLevel = false;
								}

							if( !isWaitingForNewLevel &&
							!isWaitingForNewStart )
								{
								if( calculateScorePaths( isInverted, duplicatesAllowed, prepareSort, solveStrategyParameter, conditionSelectionItem ) != RESULT_OK )
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to calculate the score paths" );
								}
							}

						previousSelectionLevel = selectionLevel;

						if( isNewStart )
							previousConditionSelectionItem = conditionSelectionItem;
						}
					while( ( conditionSelectionItem = conditionSelectionItem->nextConditionItem( executionLevel, conditionSentenceNr ) ) != NULL );

					if( conditionSelectionItem != NULL ||
					previousSelectionLevel == executionLevel )
						{
						// All brances on same level are done and there are brances on a higher level unhandled,
						// so start again with the handled brances (by clearing their checks) until all paths are handled
						if( unhandledSelectionLevel < MAX_LEVEL &&
						handledSelectionLevel < unhandledSelectionLevel )
							admin_->conditionList->clearConditionChecksForSolving( unhandledSelectionLevel, conditionSentenceNr );

						if( isAddScores )
							{
							if( admin_->scoreList == NULL ||
							( oldSatisfiedScore_ == NO_SCORE &&
							newSatisfiedScore_ == NO_SCORE &&
							oldDissatisfiedScore_ == NO_SCORE &&
							newDissatisfiedScore_ == NO_SCORE &&
							oldNotBlockingScore_ == NO_SCORE &&
							newNotBlockingScore_ == NO_SCORE &&
							oldBlockingScore_ == NO_SCORE &&
							newBlockingScore_ == NO_SCORE ) )
								hasFoundScore = false;
							else
								{
								if( admin_->scoreList->checkScores( isInverted, solveStrategyParameter, oldSatisfiedScore_, newSatisfiedScore_, oldDissatisfiedScore_, newDissatisfiedScore_, oldNotBlockingScore_, newNotBlockingScore_, oldBlockingScore_, newBlockingScore_ ) == RESULT_OK )
									hasFoundScore = admin_->scoreList->hasFoundScore();
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check the scores" );
								}

							if( !hasFoundScore &&
							duplicatesAllowed &&
							commonVariables_->currentAssignmentLevel > NO_ASSIGNMENT_LEVEL )
								{
								if( createScore( ( commonVariables_->currentAssignmentLevel > NO_ASSIGNMENT_LEVEL ), oldSatisfiedScore_, newSatisfiedScore_, oldDissatisfiedScore_, newDissatisfiedScore_, oldNotBlockingScore_, newNotBlockingScore_, oldBlockingScore_, newBlockingScore_, NULL ) != RESULT_OK )
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create an empty solve score" );
								}
							}
						}
					else
						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I couldn't reach the given execution level ", executionLevel, ". The highest reached level was ", handledSelectionLevel );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I couldn't get the first item of the condition with sentence number ", conditionSentenceNr );
				}
			while( unhandledSelectionLevel < MAX_LEVEL );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The condition list isn't created yet" );

		return commonVariables_->result;
		}

	ResultType canWordBeSolved( bool isAction, WordItem *solveWordItem )
		{
		SelectionResultType selectionResult;
		SelectionItem *originalExecutionSelectionItem = currentExecutionSelectionItem_;
		WordItem *specificationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "canWordBeSolved";

		canWordBeSolved_ = false;

		if( isAction )
			{
			if( admin_->actionList != NULL )
				{
				if( ( selectionResult = admin_->actionList->findFirstExecutionItem( solveWordItem ) ).result == RESULT_OK )
					currentExecutionSelectionItem_ = selectionResult.firstExecutionItem;
				else
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find the first action execution selection item with solve word \"", solveWordItem->anyWordTypeString(), "\"" );
				}
			}
		else
			{
			if( admin_->alternativeList != NULL )
				{
				if( ( selectionResult = admin_->alternativeList->findFirstExecutionItem( solveWordItem ) ).result == RESULT_OK )
					currentExecutionSelectionItem_ = selectionResult.firstExecutionItem;
				else
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find the first alternative execution selection item with solve word \"", solveWordItem->anyWordTypeString(), "\"" );
				}
			}

		if( currentExecutionSelectionItem_ != NULL )
			{
			do	{
				if( ( specificationWordItem = currentExecutionSelectionItem_->specificationWordItem() ) != NULL )
					{
					if( specificationWordItem->firstActiveAssignmentButNotAQuestion() == NULL )
						{
						if( currentExecutionSelectionItem_->isValueSpecification() )
							{
							if( canWordBeSolved( specificationWordItem ) != RESULT_OK )
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find out if value specification word \"", specificationWordItem->anyWordTypeString(), "\" can be solved" );
							}
						else
							{
							if( !currentExecutionSelectionItem_->isNegative() )
								canWordBeSolved_ = true;
							}
						}
					else	// Word has active assignments
						canWordBeSolved_ = true;

					if( currentExecutionSelectionItem_->findNextExecutionSelectionItem( solveWordItem ) == RESULT_OK )
						currentExecutionSelectionItem_ = currentExecutionSelectionItem_->nextExecutionItem();
					else
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find the next execution selection item with solve word \"", solveWordItem->anyWordTypeString(), "\"" );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The specification word of the current execution selection item is undefined" );
				}
			while( !canWordBeSolved_ &&
			currentExecutionSelectionItem_ != NULL );
			}

		currentExecutionSelectionItem_ = originalExecutionSelectionItem;

		return commonVariables_->result;
		}

	ResultType checkComparison( SelectionItem *conditionSelectionItem )
		{
		bool isNegative;
		bool isNumeralRelation;
		int comparisonResult = 0;
		int firstNumeral = 0;
		int secondNumeral = 0;
		char *firstString = NULL;
		char *secondString = NULL;
		WordItem *generalizationWordItem;
		WordItem *specificationWordItem;
		WordItem *firstSpecificationWordItem;
		WordItem *secondSpecificationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkComparison";

		isConditionSatisfied_ = false;

		if( conditionSelectionItem != NULL )
			{
			if( ( generalizationWordItem = conditionSelectionItem->generalizationWordItem() ) != NULL )
				{
				if( ( specificationWordItem = conditionSelectionItem->specificationWordItem() ) != NULL )
					{
					isNegative = conditionSelectionItem->isNegative();

					if( conditionSelectionItem->isFirstComparisonPart() )			// First part
						{
						if( getComparisonAssignment( false, specificationWordItem, conditionSelectionItem->relationWordItem() ) == RESULT_OK )
							{
							isConditionSatisfied_ = true;	// Allow the second part of the comparison to be checked

							firstComparisonAssignmentItem_ = comparisonAssignmentItem_;
							secondComparisonAssignmentItem_ = NULL;
							}
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed get the first comparison assignment" );
						}
					else
						{
						isNumeralRelation = conditionSelectionItem->isNumeralRelation();

						if( !isNumeralRelation &&
						conditionSelectionItem->specificationString() == NULL )		// Second part
							{
							if( getComparisonAssignment( false, specificationWordItem, conditionSelectionItem->relationWordItem() ) == RESULT_OK )
								{
								secondComparisonAssignmentItem_ = comparisonAssignmentItem_;

								firstSpecificationWordItem = ( firstComparisonAssignmentItem_ == NULL ? NULL : firstComparisonAssignmentItem_->specificationWordItem() );
								secondSpecificationWordItem = ( secondComparisonAssignmentItem_ == NULL ? NULL : secondComparisonAssignmentItem_->specificationWordItem() );

								firstString = ( firstSpecificationWordItem == NULL ? NULL : firstSpecificationWordItem->anyWordTypeString() );
								secondString = ( secondSpecificationWordItem == NULL ? NULL : secondSpecificationWordItem->anyWordTypeString() );
								}
							else
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed get a comparison assignment" );
							}
						else	// Numeral or specification string
							{
							if( getComparisonAssignment( isNumeralRelation, specificationWordItem, conditionSelectionItem->relationWordItem() ) == RESULT_OK )
								{
								firstString = ( comparisonAssignmentItem_ == NULL ? NULL : ( isNumeralRelation ? ( comparisonAssignmentItem_->specificationWordItem() == NULL ? NULL : comparisonAssignmentItem_->specificationWordItem()->anyWordTypeString() ) : comparisonAssignmentItem_->specificationString() ) );
								secondString = ( isNumeralRelation ? ( conditionSelectionItem->relationWordItem() == NULL ? NULL : conditionSelectionItem->relationWordItem()->anyWordTypeString() ) : conditionSelectionItem->specificationString() );
								}
							else
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed get the first comparison assignment" );
							}

						if( firstString == NULL ||
						secondString == NULL )
							comparisonResult = ( firstString == NULL && secondString == NULL ? 0 : ( firstString == NULL ? -1 : 1 ) );
						else
							{
							if( isNumeralString( firstString ) &&
							isNumeralString( secondString ) )
								{
								sscanf( firstString, "%d", &firstNumeral );
								sscanf( secondString, "%d", &secondNumeral );

								comparisonResult = ( firstNumeral == secondNumeral ? 0 : ( firstNumeral < secondNumeral ? -1 : 1 ) );
								}
							else
								comparisonResult = strcmp( firstString, secondString );
							}

						if( generalizationWordItem->isAdjectiveComparisonLess() )
							isConditionSatisfied_ = ( comparisonResult < 0 ? !isNegative : isNegative );
						else
							{
							if( generalizationWordItem->isAdjectiveComparisonEqual() )
								isConditionSatisfied_ = ( comparisonResult == 0 ? !isNegative : isNegative );
							else
								{
								if( generalizationWordItem->isAdjectiveComparisonMore() )
									isConditionSatisfied_ = ( comparisonResult > 0 ? !isNegative : isNegative );
								else
									return myWord_->startErrorInItem( functionNameString, moduleNameString_, "Word \"", generalizationWordItem->anyWordTypeString(), "\" isn't comparison word" );
								}
							}
						}
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The specification word of the given condition selection item is undefined" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The generalization word of the given condition selection item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given condition selection item is undefined" );

		return commonVariables_->result;
		}

	ResultType checkForOddOrEven( SelectionItem *conditionSelectionItem )
		{
		bool isPossessive;
		bool isNegative;
		unsigned int nAssignments;
		unsigned int relationContextNr;
		WordItem *generalizationWordItem;
		WordItem *specificationWordItem;
		WordItem *relationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkForOddOrEven";

		isConditionSatisfied_ = false;

		if( conditionSelectionItem != NULL )
			{
			if( ( generalizationWordItem = conditionSelectionItem->generalizationWordItem() ) != NULL )
				{
				if( ( specificationWordItem = conditionSelectionItem->specificationWordItem() ) != NULL )
					{
					isPossessive = conditionSelectionItem->isPossessive();
					isNegative = conditionSelectionItem->isNegative();
					relationContextNr = conditionSelectionItem->relationContextNr();

					if( ( relationWordItem = myWord_->contextWordInAllWords( isPossessive, relationContextNr, specificationWordItem, NULL ) ) != NULL )
						{
						if( specificationWordItem->isNounNumber() )
							{
							nAssignments = relationWordItem->numberOfActiveAssignments();

							if( generalizationWordItem->isAdjectiveOdd() )
								isConditionSatisfied_ = ( nAssignments % 2 == 1 ? !isNegative : isNegative );
							else
								{
								if( generalizationWordItem->isAdjectiveEven() )
									isConditionSatisfied_ = ( nAssignments % 2 == 0 ? !isNegative : isNegative );
								else
									return myWord_->startErrorInItem( functionNameString, moduleNameString_, "Word \"", generalizationWordItem->anyWordTypeString(), "\" isn't about odd or even" );
								}
							}
						else
							{
							if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WARNING, INTERFACE_IMPERATIVE_WARNING_I_DONT_KNOW_HOW_TO_EXECUTE_IMPERATIVE_VERB_START, relationWordItem->anyWordTypeString(), INTERFACE_IMPERATIVE_WARNING_I_DONT_KNOW_HOW_TO_EXECUTE_IMPERATIVE_VERB_END ) != RESULT_OK )
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface warning" );
							}
						}
					else
						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I couldn't find the relation word" );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The specification word of the given condition selection item is undefined" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The generalization word of the given condition selection item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given condition selection item is undefined" );

		return commonVariables_->result;
		}

	ResultType createScore( bool isChecked, unsigned long oldSatisfiedScore, unsigned long newSatisfiedScore, unsigned long oldDissatisfiedScore, unsigned long newDissatisfiedScore, unsigned long oldNotBlockingScore, unsigned long newNotBlockingScore, unsigned long oldBlockingScore, unsigned long newBlockingScore, SelectionItem *referenceSelectionItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "createScore";
		if( admin_->scoreList == NULL )
			{
			// Create list
			if( ( admin_->scoreList = new ScoreList( myWord_, commonVariables_ ) ) != NULL )
				{
				commonVariables_->adminScoreList = admin_->scoreList;
				admin_->adminList[ADMIN_SCORE_LIST] = admin_->scoreList;
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I failed to create the admin solve score list" );
			}

		if( admin_->scoreList->createScoreItem( isChecked, oldSatisfiedScore, newSatisfiedScore, oldDissatisfiedScore, newDissatisfiedScore, oldNotBlockingScore, newNotBlockingScore, oldBlockingScore, newBlockingScore, referenceSelectionItem ) != RESULT_OK )
			return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create a score item" );

		return commonVariables_->result;
		}

	ResultType findScoringAssignment( bool isBlocking, WordItem *generalizationWordItem )
		{
		SpecificationItem *currentAssignmentItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findScoringAssignment";

		hasFoundScoringAssignment_ = false;

		if( generalizationWordItem != NULL )
			{
			if( ( currentAssignmentItem = generalizationWordItem->firstActiveAssignmentButNotAQuestion() ) != NULL )
				{
				do	{
					if( !currentAssignmentItem->isNegative() )
						{
						hasFoundScoringAssignment_ = true;

						if( isBlocking )
							{
							if( currentAssignmentItem->isOlderSentence() )
								oldBlockingScore_++;
							else
								newBlockingScore_++;
							}
						else
							{
							if( currentAssignmentItem->isOlderSentence() )
								oldNotBlockingScore_++;
							else
								newNotBlockingScore_++;
							}
						}
					}
				while( !hasFoundScoringAssignment_ &&
				( currentAssignmentItem = currentAssignmentItem->nextAssignmentItemButNotAQuestion() ) != NULL );
				}
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		return commonVariables_->result;
		}

	ResultType findScoringAssignment( bool isPossessive, bool isSatisfiedScore, unsigned int relationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem )
		{
		SpecificationItem *currentAssignmentItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findScoringAssignment";

		hasFoundScoringAssignment_ = false;

		if( generalizationWordItem != NULL )
			{
			if( specificationWordItem != NULL )
				{
				if( ( currentAssignmentItem = generalizationWordItem->firstActiveAssignmentButNotAQuestion() ) != NULL )
					{
					do	{
						if( currentAssignmentItem->isRelatedSpecification( false, isPossessive, relationContextNr, specificationWordItem ) )
							{
							hasFoundScoringAssignment_ = true;

							if( isSatisfiedScore )
								{
								if( currentAssignmentItem->isOlderSentence() )
									oldSatisfiedScore_++;
								else
									newSatisfiedScore_++;
								}
							else
								{
								if( currentAssignmentItem->isOlderSentence() )
									oldDissatisfiedScore_++;
								else
									newDissatisfiedScore_++;
								}
							}
						}
					while( !hasFoundScoringAssignment_ &&
					( currentAssignmentItem = currentAssignmentItem->nextAssignmentItemButNotAQuestion() ) != NULL );
					}
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		return commonVariables_->result;
		}

	ResultType checkConditionByValue( bool isNegative, bool isPossessive, unsigned int generalizationContextNr, unsigned int specificationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem )
		{
		bool isSatisfiedScore;
		SpecificationItem *foundAssignmentItem;
		SpecificationItem *currentSpecificationItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkConditionByValue";

		isConditionSatisfied_ = true;

		if( specificationWordItem != NULL )
			{
			if( ( currentSpecificationItem = specificationWordItem->firstSpecificationButNotAQuestion() ) != NULL )
				{
				do	{
					foundAssignmentItem = specificationWordItem->firstAssignment( true, false, false, false, isPossessive, NO_QUESTION_PARAMETER, generalizationContextNr, specificationContextNr, currentSpecificationItem->relationContextNr(), currentSpecificationItem->specificationWordItem(), currentSpecificationItem->specificationString() );
					isSatisfiedScore = ( isNegative == ( foundAssignmentItem == NULL || foundAssignmentItem->isNegative() ) );

					if( findScoringAssignment( isPossessive, isSatisfiedScore, currentSpecificationItem->relationContextNr(), generalizationWordItem, currentSpecificationItem->specificationWordItem() ) == RESULT_OK )
						{
						if( hasFoundScoringAssignment_ != isSatisfiedScore )
							isConditionSatisfied_ = false;
						}
					else
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a scoring assignment" );
					}
				while( ( currentSpecificationItem = currentSpecificationItem->nextSpecificationItemButNotAQuestion() ) != NULL );
				}
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word item is undefined" );

		return commonVariables_->result;
		}

	ResultType calculateScorePaths( bool isInverted, bool duplicatesAllowed, bool prepareSort, unsigned short solveStrategyParameter, SelectionItem *referenceSelectionItem )
		{
		bool addLocalScores;
		bool originalfoundpossibility;
		bool hasFoundScore = false;
		unsigned long localOldSatisfiedScore;
		unsigned long localNewSatisfiedScore;
		unsigned long localOldDissatisfiedScore;
		unsigned long localNewDissatisfiedScore;
		unsigned long localOldNotBlockingScore;
		unsigned long localNewNotBlockingScore;
		unsigned long localOldBlockingScore;
		unsigned long localNewBlockingScore;
		unsigned long oldSatisfiedScore = oldSatisfiedScore_;
		unsigned long newSatisfiedScore = newSatisfiedScore_;
		unsigned long oldDissatisfiedScore = oldDissatisfiedScore_;
		unsigned long newDissatisfiedScore = newDissatisfiedScore_;
		unsigned long oldNotBlockingScore = oldNotBlockingScore_;
		unsigned long newNotBlockingScore = newNotBlockingScore_;
		unsigned long oldBlockingScore = oldBlockingScore_;
		unsigned long newBlockingScore = newBlockingScore_;
		WordItem *generalizationWordItem;
		WordItem *specificationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "calculateScorePaths";

		if( referenceSelectionItem != NULL )
			{
			if( ( generalizationWordItem = referenceSelectionItem->generalizationWordItem() ) != NULL )
				{
				oldSatisfiedScore_ = NO_SCORE;
				newSatisfiedScore_ = NO_SCORE;
				oldDissatisfiedScore_ = NO_SCORE;
				newDissatisfiedScore_ = NO_SCORE;
				oldNotBlockingScore_ = NO_SCORE;
				newNotBlockingScore_ = NO_SCORE;
				oldBlockingScore_ = NO_SCORE;
				newBlockingScore_ = NO_SCORE;

				if( checkCondition( referenceSelectionItem ).result == RESULT_OK )
					{
					addLocalScores = true;

					localOldSatisfiedScore = oldSatisfiedScore_;
					localNewSatisfiedScore = newSatisfiedScore_;
					localOldDissatisfiedScore = oldDissatisfiedScore_;
					localNewDissatisfiedScore = newDissatisfiedScore_;
					localOldNotBlockingScore = oldNotBlockingScore_;
					localNewNotBlockingScore = newNotBlockingScore_;
					localOldBlockingScore = oldBlockingScore_;
					localNewBlockingScore = newBlockingScore_;

					oldSatisfiedScore_ = oldSatisfiedScore;
					newSatisfiedScore_ = newSatisfiedScore;
					oldDissatisfiedScore_ = oldDissatisfiedScore;
					newDissatisfiedScore_ = newDissatisfiedScore;
					oldNotBlockingScore_ = oldNotBlockingScore;
					newNotBlockingScore_ = newNotBlockingScore;
					oldBlockingScore_ = oldBlockingScore;
					newBlockingScore_ = newBlockingScore;

					if( !isConditionSatisfied_ &&
					!generalizationWordItem->isWordCheckedForSolving )
						{
						if( referenceSelectionItem->isAssignedOrClear() )
							{
							if( !referenceSelectionItem->isNegative() )
								{
								if( generalizationWordItem->firstActiveAssignmentButNotAQuestion() == NULL )		// Word has no active assignments
									{
									originalfoundpossibility = hasFoundPossibility_;

									if( admin_->findPossibilityToSolveWord( false, isInverted, duplicatesAllowed, prepareSort, solveStrategyParameter, generalizationWordItem ) == RESULT_OK )
										{
										if( hasFoundPossibility_ )
											addLocalScores = false;
										else
											hasFoundPossibility_ = originalfoundpossibility;
										}
									else
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a possibility to solve condition word \"", generalizationWordItem->anyWordTypeString(), "\"" );
									}
								}
							}
						else
							{
							if( ( specificationWordItem = referenceSelectionItem->specificationWordItem() ) != NULL )
								{
								if( !referenceSelectionItem->isNegative() &&
								!specificationWordItem->isWordCheckedForSolving &&
								generalizationWordItem->firstActiveAssignmentButNotAQuestion() == NULL )		// Word has no active assignments
									{
									if( canWordBeSolved( specificationWordItem ) == RESULT_OK )
										{
										if( canWordBeSolved_ )
											{
											originalfoundpossibility = hasFoundPossibility_;

											if( admin_->findPossibilityToSolveWord( false, isInverted, duplicatesAllowed, prepareSort, solveStrategyParameter, generalizationWordItem ) == RESULT_OK )
												{
												if( hasFoundPossibility_ )
													addLocalScores = false;
												else
													hasFoundPossibility_ = originalfoundpossibility;
												}
											else
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a possibility to solve condition word \"", generalizationWordItem->anyWordTypeString(), "\"" );
											}
										else
											{
											if( duplicatesAllowed ||
											admin_->scoreList == NULL )
												hasFoundScore = false;
											else
												{
												if( admin_->scoreList->findScore( prepareSort, referenceSelectionItem ) == RESULT_OK )
													hasFoundScore = admin_->scoreList->hasFoundScore();
												else
													return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a score item" );
												}

											if( !hasFoundScore )
												{
												if( createScore( ( commonVariables_->currentAssignmentLevel > NO_ASSIGNMENT_LEVEL ), NO_SCORE, NO_SCORE, NO_SCORE, NO_SCORE, NO_SCORE, NO_SCORE, NO_SCORE, NO_SCORE, referenceSelectionItem ) == RESULT_OK )
													hasFoundPossibility_ = true;
												else
													return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create an empty solve score" );
												}
											}
										}
									else
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find out if specification word \"", specificationWordItem->anyWordTypeString(), "\" can be solved" );
									}
								}
							else
								return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The specification word of the given score item is undefined" );
							}
						}

					if( !commonVariables_->hasShownWarning &&
					addLocalScores )
						{
						oldSatisfiedScore_ += localOldSatisfiedScore;
						newSatisfiedScore_ += localNewSatisfiedScore;
						oldDissatisfiedScore_ += localOldDissatisfiedScore;
						newDissatisfiedScore_ += localNewDissatisfiedScore;
						oldNotBlockingScore_ += localOldNotBlockingScore;
						newNotBlockingScore_ += localNewNotBlockingScore;
						oldBlockingScore_ += localOldBlockingScore;
						newBlockingScore_ += localNewBlockingScore;
						}
					}
				else
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check the condition of the item with sentence number ", referenceSelectionItem->activeSentenceNr(), " and item number ", referenceSelectionItem->itemNr() );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The generalization word of the given score item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given reference selection item is undefined" );

		return commonVariables_->result;
		}


	public:
	// Constructor

	AdminSolve( AdminItem *admin, WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		canWordBeSolved_ = false;
		hasFoundPossibility_ = false;
		hasFoundScoringAssignment_ = false;
		isConditionSatisfied_ = false;

		solveLevel_ = NO_SOLVE_LEVEL;

		oldSatisfiedScore_ = NO_SCORE;
		newSatisfiedScore_ = NO_SCORE;
		oldDissatisfiedScore_ = NO_SCORE;
		newDissatisfiedScore_ = NO_SCORE;
		oldNotBlockingScore_ = NO_SCORE;
		newNotBlockingScore_ = NO_SCORE;
		oldBlockingScore_ = NO_SCORE;
		newBlockingScore_ = NO_SCORE;

		currentSolveProgress_ = 0;

		currentExecutionSelectionItem_ = NULL;
		comparisonAssignmentItem_ = NULL;
		firstComparisonAssignmentItem_ = NULL;
		secondComparisonAssignmentItem_ = NULL;

		admin_ = admin;
		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "AdminSolve" );

		if( commonVariables_ != NULL )
			{
		if( admin_ != NULL )
			{
			if( myWord_ == NULL )
				strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given admin is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	void clearCurrentSolveProgress()
		{
		currentSolveProgress_ = 0;
		}

	ResultType canWordBeSolved( WordItem *solveWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "canWordBeSolved";
		if( canWordBeSolved( true, solveWordItem ) == RESULT_OK )
			{
			if( !canWordBeSolved_ &&
			!commonVariables_->hasShownWarning )
				{
				if( canWordBeSolved( false, solveWordItem ) != RESULT_OK )
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find out if a word can be solved by an alternative action" );
				}
			}
		else
			return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find out if a word can be solved by an action" );

		return commonVariables_->result;
		}

	ResultType solveWord( unsigned long endSolveProgress, WordItem *solveWordItem, SelectionItem *actionSelectionItem )
		{
		SelectionResultType selectionResult;
		SpecificationResultType specificationResult;
		bool isInverted = false;
		unsigned int nPossibilities;
		unsigned int possibilityNumber = 0;
		unsigned long solveProgressStep;
		unsigned long tempEndSolveProgress;
		ScoreItem *possibilityItem;
		SpecificationItem *foundSpecificationItem;
		WordItem *predefinedNounSolveLevelWordItem;
		WordItem *predefinedNounSolveMethodWordItem;
		WordItem *predefinedNounSolveStrategyWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "solveWord";

		if( solveWordItem != NULL )
			{
			if( ( predefinedNounSolveMethodWordItem = admin_->predefinedNounSolveMethodWordItem() ) != NULL )
				{
				if( ( predefinedNounSolveStrategyWordItem = admin_->predefinedNounSolveStrategyWordItem() ) != NULL )
					{
					if( currentSolveProgress_ == 0 )
						{
						if( ( predefinedNounSolveLevelWordItem = admin_->predefinedNounSolveLevelWordItem() ) == NULL )
							solveLevel_ = NO_SOLVE_LEVEL;
						else
							{
							if( ( specificationResult = predefinedNounSolveLevelWordItem->getAssignmentOrderNr( WORD_TYPE_ADJECTIVE ) ).result == RESULT_OK )
								solveLevel_ = specificationResult.assignmentOrderNr;
							else
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get the solve level" );
							}
						}

					if( solveWordItem->firstActiveAssignmentButNotAQuestion() == NULL )		// Word has no active assignments
						{
						if( commonVariables_->currentAssignmentLevel <= solveLevel_ )
							{
							if( admin_->assignSpecification( predefinedNounSolveMethodWordItem, admin_->predefinedAdjectiveBusyWordItem() ) == RESULT_OK )
								{
								if( commonVariables_->currentAssignmentLevel == NO_ASSIGNMENT_LEVEL )
									{
									clearAllWordSolveChecksInAllWords();

									if( admin_->scoreList != NULL )
										{
										if( admin_->scoreList->deleteScores() != RESULT_OK )	// Make sure no scores are left at the start
											return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete the admin score list" );
										}
									}

								foundSpecificationItem = predefinedNounSolveMethodWordItem->firstAssignment( true, false, false, false, false, (unsigned short)NO_QUESTION_PARAMETER, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_CONTEXT_NR, admin_->predefinedAdjectiveInvertedWordItem(), NULL );
								isInverted = ( foundSpecificationItem != NULL );

								if( ( specificationResult = predefinedNounSolveStrategyWordItem->getAssignmentWordParameter() ).result == RESULT_OK )
									{
									if( findPossibilityToSolveWord( true, isInverted, ( commonVariables_->currentAssignmentLevel == solveLevel_ ), ( commonVariables_->currentAssignmentLevel + 1 < solveLevel_ ), specificationResult.assignmentParameter, solveWordItem ) == RESULT_OK )
										{
										if( hasFoundPossibility_ )
											{
											if( commonVariables_->currentAssignmentLevel < solveLevel_ )
												{
												if( admin_->scoreList != NULL )
													{
													nPossibilities = admin_->scoreList->numberOfPossibilities();
													solveProgressStep = ( ( endSolveProgress - currentSolveProgress_ ) / nPossibilities );

													if( solveLevel_ > 1 )
														commonVariables_->presentation->startProgress( currentSolveProgress_, MAX_PROGRESS, INTERFACE_CONSOLE_I_AM_EXECUTING_SELECTIONS_START, solveLevel_, INTERFACE_CONSOLE_I_AM_EXECUTING_SELECTIONS_END );

													if( admin_->wordList != NULL )
														{
														if( ( possibilityItem = admin_->scoreList->firstPossibility() ) != NULL )
															{
															do	{
																if( commonVariables_->currentAssignmentLevel == NO_ASSIGNMENT_LEVEL )	// Copy solve action of NO_ASSIGNMENT_LEVEL to higher levels
																	actionSelectionItem = possibilityItem->scoreReference();

																if( admin_->wordList->createNewAssignmentLevelInWordList() == RESULT_OK )
																	{
																	commonVariables_->currentAssignmentLevel++;

																	if( admin_->assignSelectionSpecification( possibilityItem->scoreReference() ) == RESULT_OK )
																		{
																		tempEndSolveProgress = currentSolveProgress_ + solveProgressStep;

																		if( admin_->executeSelection( ( currentSolveProgress_ + solveProgressStep / 2L ), actionSelectionItem ) == RESULT_OK )
																			{
																			if( solveWordItem->firstActiveAssignmentButNotAQuestion() != NULL )		// Word has active assignments
																				{
																				foundSpecificationItem = predefinedNounSolveMethodWordItem->firstAssignment( true, false, false, false, false, (unsigned short)NO_QUESTION_PARAMETER, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_CONTEXT_NR, admin_->predefinedAdjectiveInvertedWordItem(), NULL );
																				isInverted = ( foundSpecificationItem != NULL );

																				if( !isInverted &&
																				commonVariables_->currentAssignmentLevel < solveLevel_ )
																					{
																					if( admin_->scoreList->deleteScores() == RESULT_OK )
																						solveLevel_ = commonVariables_->currentAssignmentLevel;		// Don't solve any deeper when there is a winning score
																					else
																						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete the scores with an assignment level higher than ", commonVariables_->currentAssignmentLevel );
																					}

																				// Create winning or losing score
																				if( createScore( false, NO_SCORE, ( isInverted ? NO_SCORE : WINNING_SCORE ), NO_SCORE, ( isInverted ? WINNING_SCORE : NO_SCORE ), NO_SCORE, NO_SCORE, NO_SCORE, NO_SCORE, actionSelectionItem ) == RESULT_OK )
																					{
																					currentSolveProgress_ = tempEndSolveProgress;

																					if( solveLevel_ > 1 )
																						commonVariables_->presentation->showProgress( currentSolveProgress_ );
																					}
																				else
																					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create a winning or losing score of solve word \"", solveWordItem->anyWordTypeString(), "\" at assignment level ", commonVariables_->currentAssignmentLevel );
																				}
																			else
																				{
																				if( solveWord( tempEndSolveProgress, solveWordItem, actionSelectionItem ) == RESULT_OK )
																					{
																					if( commonVariables_->currentAssignmentLevel == 1 )
																						admin_->scoreList->changeAction( actionSelectionItem );
																					}
																				else
																					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to solve word \"", solveWordItem->anyWordTypeString(), "\" at assignment level ", commonVariables_->currentAssignmentLevel );
																				}

																			if( deleteAssignmentLevelInAllWords() == RESULT_OK )
																				{
																				commonVariables_->currentAssignmentLevel--;
																				possibilityItem = possibilityItem->nextPossibilityItem();

																				if( ++possibilityNumber <= nPossibilities )
																					{
																					if( possibilityItem != NULL &&
																					possibilityNumber == nPossibilities )
																						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found more possibility items than number of possibilities" );
																					}
																				else
																					{
																					if( possibilityItem == NULL )
																						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I couldn't get the next possibility item before the number of possibilities is reached" );
																					}
																				}
																			else
																				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete the assignments of level ", commonVariables_->currentAssignmentLevel );
																			}
																		else
																			return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to execute a selection during the solving of word \"", solveWordItem->anyWordTypeString(), "\" at assignment level ", commonVariables_->currentAssignmentLevel );
																		}
																	else
																		return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to assign a selection specifcation at assignment level: ", commonVariables_->currentAssignmentLevel );
																	}
																else
																	return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create a new assignment level: ", commonVariables_->currentAssignmentLevel );
																}
															while( possibilityItem != NULL );

															if( admin_->scoreList != NULL &&

															( nPossibilities > 1 ||
															commonVariables_->currentAssignmentLevel > NO_ASSIGNMENT_LEVEL ) )	// Higher level has possibilities
																{
																if( admin_->scoreList->deleteScores() != RESULT_OK )
																	return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete the scores with assignment level ", commonVariables_->currentAssignmentLevel );
																}
															}
														else
															return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I failed to get the first possibility item at assignment level ", commonVariables_->currentAssignmentLevel );
														}
													else
														return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The word list isn't created yet" );
													}
												else
													return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The solve scores list isn't created yet at assignment level ", commonVariables_->currentAssignmentLevel );
												}
											else
												{
												currentSolveProgress_ = endSolveProgress;

												if( solveLevel_ > 1 )
													commonVariables_->presentation->showProgress( currentSolveProgress_ );
												}

											if( commonVariables_->currentAssignmentLevel == NO_ASSIGNMENT_LEVEL )
												{
												commonVariables_->presentation->clearProgress();

												if( admin_->scoreList != NULL )
													{
													if( ( specificationResult = predefinedNounSolveStrategyWordItem->getAssignmentWordParameter() ).result == RESULT_OK )
														{
														if( ( selectionResult = admin_->scoreList->getBestAction( specificationResult.assignmentParameter ) ).result == RESULT_OK )
															{
															if( ( actionSelectionItem = selectionResult.bestActionItem ) != NULL )
																{
																if( admin_->assignSelectionSpecification( actionSelectionItem ) == RESULT_OK )
																	{
																	if( admin_->assignSpecification( predefinedNounSolveMethodWordItem, admin_->predefinedAdjectiveDoneWordItem() ) != RESULT_OK )
																		return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to assign the done flag to the solve method at assignment level ", commonVariables_->currentAssignmentLevel );
																	}
																else
																	return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to assign a selection specification at assignment level ", commonVariables_->currentAssignmentLevel );
																}
															else
																return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I couldn't get the best action selection item" );
															}
														else
															return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get the best action of solve word \"", solveWordItem->anyWordTypeString(), "\" at assignment level ", commonVariables_->currentAssignmentLevel );
														}
													else
														return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get the solve strategy at assignment level ", commonVariables_->currentAssignmentLevel );
													}
												else
													return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The solve scores list isn't created yet" );
												}
											}
										else
											{
											if( commonVariables_->currentAssignmentLevel == NO_ASSIGNMENT_LEVEL )
												{
												if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WARNING, INTERFACE_IMPERATIVE_WARNING_I_COULD_FIND_SOLVE_INFO_START, solveWordItem->anyWordTypeString(), INTERFACE_IMPERATIVE_WARNING_I_COULD_FIND_SOLVE_INFO_END ) != RESULT_OK )
													return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface warning" );
												}
											}
										}
									else
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a possibility to solve word \"", solveWordItem->anyWordTypeString(), "\" at assignment level ", commonVariables_->currentAssignmentLevel );
									}
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get the solve strategy at assignment level ", commonVariables_->currentAssignmentLevel );
								}
							else
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to assign the busy flag to the solve method at assignment level ", commonVariables_->currentAssignmentLevel );
							}
						else
							return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given assignment level of ", commonVariables_->currentAssignmentLevel, " is higher than the given solve level ", solveLevel_ );
						}
					else
						{
						if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WARNING, INTERFACE_IMPERATIVE_WARNING_WORD_ALREADY_SOLVED_START, solveWordItem->anyWordTypeString(), INTERFACE_IMPERATIVE_WARNING_WORD_ALREADY_SOLVED_END ) != RESULT_OK )
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface warning" );
						}
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The predefined solve strategy noun word item is undefined" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The predefined solve-method noun word item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given solve word is undefined" );

		return commonVariables_->result;
		}

	ResultType findPossibilityToSolveWord( bool isAddScores, bool isInverted, bool duplicatesAllowed, bool prepareSort, unsigned short solveStrategyParameter, WordItem *solveWordItem )
		{
		SelectionResultType selectionResult;
		SelectionItem *originalExecutionSelectionItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findPossibilityToSolveWord";

		hasFoundPossibility_ = false;

		if( solveWordItem != NULL )
			{
			if( !solveWordItem->isWordCheckedForSolving )
				{
				if( canWordBeSolved( true, solveWordItem ) == RESULT_OK )
					{
					solveWordItem->isWordCheckedForSolving = true;

					if( canWordBeSolved_ &&
					admin_->actionList != NULL )
						{
						originalExecutionSelectionItem = currentExecutionSelectionItem_;

						if( ( selectionResult = admin_->actionList->findFirstExecutionItem( solveWordItem ) ).result == RESULT_OK )
							{
							if( ( currentExecutionSelectionItem_ = selectionResult.firstExecutionItem ) != NULL )
								{
								do	{
									if( backTrackConditionScorePaths( isAddScores, isInverted, duplicatesAllowed, prepareSort, currentExecutionSelectionItem_->selectionLevel(), solveStrategyParameter, currentExecutionSelectionItem_->activeSentenceNr() ) == RESULT_OK )
										{
										if( currentExecutionSelectionItem_->findNextExecutionSelectionItem( solveWordItem ) == RESULT_OK )
											currentExecutionSelectionItem_ = currentExecutionSelectionItem_->nextExecutionItem();
										else
											return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find the next action selection item with solve word \"", solveWordItem->anyWordTypeString(), "\"" );
										}
									else
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to back-track the condition score paths for the action with sentence number ", currentExecutionSelectionItem_->activeSentenceNr() );
									}
								while( currentExecutionSelectionItem_ != NULL );
								}

							currentExecutionSelectionItem_ = originalExecutionSelectionItem;
							}
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find the first action selection item with solve word \"", solveWordItem->anyWordTypeString(), "\"" );
						}

					if( !commonVariables_->hasShownWarning )
						{
						if( canWordBeSolved( false, solveWordItem ) == RESULT_OK )
							{
							if( canWordBeSolved_ &&
							admin_->alternativeList != NULL )
								{
								originalExecutionSelectionItem = currentExecutionSelectionItem_;

								if( ( selectionResult = admin_->alternativeList->findFirstExecutionItem( solveWordItem ) ).result == RESULT_OK )
									{
									if( ( currentExecutionSelectionItem_ = selectionResult.firstExecutionItem ) != NULL )
										{
										do	{
											if( backTrackConditionScorePaths( isAddScores, isInverted, duplicatesAllowed, prepareSort, currentExecutionSelectionItem_->selectionLevel(), solveStrategyParameter, currentExecutionSelectionItem_->activeSentenceNr() ) == RESULT_OK )
												{
												if( currentExecutionSelectionItem_->findNextExecutionSelectionItem( solveWordItem ) == RESULT_OK )
													currentExecutionSelectionItem_ = currentExecutionSelectionItem_->nextExecutionItem();
												else
													return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find the next alternative item with solve word \"", solveWordItem->anyWordTypeString(), "\"" );
												}
											else
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to back-track the condition score paths for the alternative with sentence number ", currentExecutionSelectionItem_->activeSentenceNr() );
											}
										while( currentExecutionSelectionItem_ != NULL );
										}

									currentExecutionSelectionItem_ = originalExecutionSelectionItem;
									}
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find the first alternative item with solve word \"", solveWordItem->anyWordTypeString(), "\"" );
								}

							solveWordItem->isWordCheckedForSolving = false;
							}
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find out if the given word \"", solveWordItem->anyWordTypeString(), "\" can be solved by alternative" );
						}
					}
				else
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find out if the given word \"", solveWordItem->anyWordTypeString(), "\" can be solved by action" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given solve word \"", solveWordItem->anyWordTypeString(), "\" is already checked" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given solve word is undefined" );

		return commonVariables_->result;
		}

	SelectionResultType checkCondition( SelectionItem *conditionSelectionItem )
		{
		SelectionResultType selectionResult;
		bool isPossessive;
		bool isNegative;
		WordItem *generalizationWordItem;
		WordItem *specificationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkCondition";

		isConditionSatisfied_ = false;

		if( conditionSelectionItem != NULL )
			{
			if( ( generalizationWordItem = conditionSelectionItem->generalizationWordItem() ) != NULL )
				{
				if( ( specificationWordItem = conditionSelectionItem->specificationWordItem() ) != NULL )
					{
					isPossessive = conditionSelectionItem->isPossessive();
					isNegative = conditionSelectionItem->isNegative();

					if( conditionSelectionItem->isAssignedOrClear() )
						{
						if( specificationWordItem->isAdjectiveClear() )
							{
							if( findScoringAssignment( !isNegative, generalizationWordItem ) == RESULT_OK )
								isConditionSatisfied_ = ( hasFoundScoringAssignment_ ? isNegative : !isNegative );
							else
								myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a scoring assignment" );
							}
						else	// Is Assigned
							{
							if( findScoringAssignment( isNegative, generalizationWordItem ) == RESULT_OK )
								isConditionSatisfied_ = ( hasFoundScoringAssignment_ ? !isNegative : isNegative );
							else
								myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a scoring assignment" );
							}
						}
					else
						{
						if( generalizationWordItem->isAdjectiveComparison() )
							{
							if( checkComparison( conditionSelectionItem ) != RESULT_OK )
								myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check a comparison" );
							}
						else
							{
							if( generalizationWordItem->isAdjectiveOddOrEven() )
								{
								if( checkForOddOrEven( conditionSelectionItem ) != RESULT_OK )
									myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check for odd or even" );
								}
							else
								{
								if( conditionSelectionItem->isValueSpecification() )
									{
									if( checkConditionByValue( isNegative, isPossessive, conditionSelectionItem->generalizationContextNr(), conditionSelectionItem->specificationContextNr(), generalizationWordItem, specificationWordItem ) != RESULT_OK )
										myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check the condition of a specification by value" );
									}
								else
									{
									if( findScoringAssignment( isPossessive, !isNegative, conditionSelectionItem->relationContextNr(), generalizationWordItem, specificationWordItem ) == RESULT_OK )
										{
										if( hasFoundScoringAssignment_ != isNegative )
											isConditionSatisfied_ = true;
										}
									else
										myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a scoring assignment" );
									}
								}
							}
						}
					}
				else
					myWord_->startErrorInItem( functionNameString, moduleNameString_, "The specification word of the given condition selection item is undefined" );
				}
			else
				myWord_->startErrorInItem( functionNameString, moduleNameString_, "The generalization word of the given condition selection item is undefined" );
			}
		else
			myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given condition selection item is undefined" );

		selectionResult.isConditionSatisfied = isConditionSatisfied_;
		selectionResult.result = commonVariables_->result;
		return selectionResult;
		}
	};

/*************************************************************************
 *
 *	"Give thanks to the God of gods.
 *	His faithful love endures forever." (Psalm 136:2)
 *
 *************************************************************************/
