/*
 *	Class:			WordTypeItem
 *	Parent class:	Item
 *	Purpose:		To store the word-types of a word
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#ifndef WORDTYPEITEM
#define WORDTYPEITEM 1
#include <ctype.h>
#include <limits.h>
#include "WordItem.h"

class WordTypeItem : private Item
	{
	friend class AdminCleanup;
	friend class AdminReadCreateWords;
	friend class WordItem;
	friend class WordType;
	friend class WordTypeList;

	// Private loadable variables

	bool isPropernamePrecededByDefiniteArticle_;

	unsigned short definiteArticleParameter_;
	unsigned short indefiniteArticleParameter_;
	unsigned short wordTypeNr_;
	unsigned short wordTypeLanguageNr_;


	// Private constructible variables

	unsigned short writeLevel_;

	char *wordTypeString_;

	void *hideKey_;


	protected:
	// Constructor

	WordTypeItem( bool isPropernamePrecededByDefiniteArticle, unsigned short definiteArticleParameter, unsigned short indefiniteArticleParameter, unsigned short wordTypeLanguageNr, unsigned short wordTypeNr, size_t wordTypeStringLength, char *_wordTypeString, List *myList, WordItem *myWord, CommonVariables *commonVariables )
		{
		initializeItemVariables( NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, "WordTypeItem", myList, myWord, commonVariables );

		// Private loadable variables

		isPropernamePrecededByDefiniteArticle_ = isPropernamePrecededByDefiniteArticle;

		definiteArticleParameter_ = definiteArticleParameter;
		indefiniteArticleParameter_ = indefiniteArticleParameter;
		wordTypeNr_ = wordTypeNr;
		wordTypeLanguageNr_ = wordTypeLanguageNr;

		// Private constructible variables

		writeLevel_ = NO_WRITE_LEVEL;

		hideKey_ = NULL;
		wordTypeString_ = NULL;

		if( _wordTypeString != NULL )
			{
			if( strlen( _wordTypeString ) > 0 )
				{
				if( wordTypeStringLength > 0 )
					{
					if( wordTypeStringLength < MAX_READ_WRITE_STRING_LENGTH &&
					strlen( _wordTypeString ) < MAX_READ_WRITE_STRING_LENGTH )
						{
						if( ( wordTypeString_ = new char[wordTypeStringLength + 1] ) != NULL )
							{
							strncpy( wordTypeString_, _wordTypeString, wordTypeStringLength );
							wordTypeString_[wordTypeStringLength] = NULL_CHAR;

							if( isupper( _wordTypeString[0] ) &&
							wordTypeNr != WORD_TYPE_LETTER_CAPITAL &&
							wordTypeNr != WORD_TYPE_PROPER_NAME )
								wordTypeString_[0] = (char)tolower( wordTypeString_[0] );
							}
						else
							startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, NULL, "I failed to create the word type string" );
						}
					else
						startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, NULL, "The given word type is too long" );
					}
				else
					startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, NULL, "The given word type string length is undefined" );
				}
			else
				startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, NULL, "The given word type string is empty" );
			}
		else
			startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, NULL, "The given word type string is undefined" );
		}

	~WordTypeItem()
		{
		if( wordTypeString_ != NULL )
			delete wordTypeString_;
		}


	// Protected virtual functions

	virtual void showString( bool returnQueryToPosition )
		{
		char statusString[2] = SPACE_STRING;
		statusString[0] = statusChar();

		if( itemString() != NULL )
			{
			if( commonVariables()->hasFoundQuery )
				strcat( commonVariables()->queryString, ( returnQueryToPosition ? NEW_LINE_STRING : QUERY_SEPARATOR_SPACE_STRING ) );

			if( !isActiveItem() )	// Show status when not active
				strcat( commonVariables()->queryString, statusString );

			commonVariables()->hasFoundQuery = true;
			strcat( commonVariables()->queryString, itemString() );
			}
		}

	virtual bool hasFoundParameter( unsigned int queryParameter )
		{
		return ( definiteArticleParameter_ == NO_DEFINITE_ARTICLE_PARAMETER ||
				indefiniteArticleParameter_ == NO_INDEFINITE_ARTICLE_PARAMETER ||
				wordTypeLanguageNr_ == queryParameter ||
				writeLevel_ == queryParameter ||

				( queryParameter == MAX_QUERY_PARAMETER &&

				( definiteArticleParameter_ > NO_DEFINITE_ARTICLE_PARAMETER ||
				definiteArticleParameter_ > NO_INDEFINITE_ARTICLE_PARAMETER ||
				wordTypeLanguageNr_ > 0 ||
				writeLevel_ > NO_WRITE_LEVEL ) ) );
		}

	virtual bool hasFoundWordType( unsigned short queryWordTypeNr )
		{
		return ( wordTypeNr_ == queryWordTypeNr );
		}

	virtual bool isSorted( Item *nextSortItem )
		{
		return ( nextSortItem == NULL ||
				// Ascending wordTypeLanguageNr
				wordTypeLanguageNr_ < ( (WordTypeItem *)nextSortItem )->wordTypeLanguageNr_ );
		}

	virtual char *itemString()
		{
		return ( hideKey_ == NULL ? wordTypeString_ : NULL );
		}

	virtual char *toString( unsigned short queryWordTypeNr )
		{
		char *wordString;
		char *wordTypeString = myWord()->wordTypeName( wordTypeNr_ );
		char *grammarLanguageNameStringString = myWord()->grammarLanguageNameString( wordTypeLanguageNr_ );

		Item::toString( queryWordTypeNr );

		if( hideKey_ != NULL )
			{
			strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
			strcat( commonVariables()->queryString, "isHidden" );
			}

		if( isPropernamePrecededByDefiniteArticle_ )
			{
			strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
			strcat( commonVariables()->queryString, "isPropernamePrecededByDefiniteArticle" );
			}

		if( definiteArticleParameter_ > NO_DEFINITE_ARTICLE_PARAMETER )
			{
			sprintf( tempString, "%cdefiniteArticleParameter:%u", QUERY_SEPARATOR_CHAR, definiteArticleParameter_ );
			strcat( commonVariables()->queryString, tempString );
			}

		if( indefiniteArticleParameter_ > NO_INDEFINITE_ARTICLE_PARAMETER )
			{
			sprintf( tempString, "%cindefiniteArticleParameter:%u", QUERY_SEPARATOR_CHAR, indefiniteArticleParameter_ );
			strcat( commonVariables()->queryString, tempString );
			}

		if( wordTypeString == NULL )
			sprintf( tempString, "%cwordType:%c%u", QUERY_SEPARATOR_CHAR, QUERY_WORD_TYPE_CHAR, wordTypeNr_ );
		else
			sprintf( tempString, "%cwordType:%s%c%u", QUERY_SEPARATOR_CHAR, wordTypeString, QUERY_WORD_TYPE_CHAR, wordTypeNr_ );

		strcat( commonVariables()->queryString, tempString );

		if( wordTypeLanguageNr_ > 0 )
			{
			if( grammarLanguageNameStringString == NULL )
				sprintf( tempString, "%cgrammarLanguage:%u", QUERY_SEPARATOR_CHAR, wordTypeLanguageNr_ );
			else
				sprintf( tempString, "%cgrammarLanguage:%s", QUERY_SEPARATOR_CHAR, grammarLanguageNameStringString );

			strcat( commonVariables()->queryString, tempString );
			}

		if( ( wordString = itemString() ) != NULL )
			{
			sprintf( tempString, "%cwordString:%c%s%c", QUERY_SEPARATOR_CHAR, QUERY_STRING_START_CHAR, wordString, QUERY_STRING_END_CHAR );
			strcat( commonVariables()->queryString, tempString );
			}

		return commonVariables()->queryString;
		}


	// Protected functions

	void clearWriteLevel( unsigned short currentWriteLevel )
		{
		if( writeLevel_ > currentWriteLevel )
			writeLevel_ = NO_WRITE_LEVEL;
		}

	bool hasUndefinedDefiniteArticle()
		{
		return ( definiteArticleParameter_ == NO_DEFINITE_ARTICLE_PARAMETER );
		}

	bool hasUndefinedIndefiniteArticle()
		{
		return ( indefiniteArticleParameter_ == NO_INDEFINITE_ARTICLE_PARAMETER );
		}

	bool isCorrectDefiniteArticle( unsigned short definiteArticleParameter )
		{
		return ( definiteArticleParameter_ == NO_DEFINITE_ARTICLE_PARAMETER ||
				definiteArticleParameter_ == definiteArticleParameter );
		}

	bool isCorrectIndefiniteArticle( unsigned short indefiniteArticleParameter )
		{
		bool isStartingWithVowel = isStringStartingWithVowel( itemString() );

		return ( indefiniteArticleParameter_ == indefiniteArticleParameter ||

				// If undefined, fall back to a simple rule
				( indefiniteArticleParameter_ == NO_INDEFINITE_ARTICLE_PARAMETER &&

				// 'an'
				( ( isStartingWithVowel &&
				indefiniteArticleParameter == WORD_PARAMETER_ARTICLE_INDEFINITE_1 ) ||

				// 'a'
				( !isStartingWithVowel &&
				indefiniteArticleParameter == WORD_PARAMETER_ARTICLE_INDEFINITE_2 ) ) ) );
		}

	bool isPropernamePrecededByDefiniteArticle( unsigned short definiteArticleParameter )
		{
		return ( isPropernamePrecededByDefiniteArticle_ &&
				isCorrectDefiniteArticle( definiteArticleParameter ) );
		}

	bool isCorrectHiddenWordType( char *compareString, void *hideKey )
		{
		if( hideKey_ == hideKey &&
		compareString != NULL &&
		strcmp( wordTypeString_, compareString ) == 0 )
			return true;

		return false;
		}

	bool isWordTypeAdjective()
		{
		return ( wordTypeNr_ == WORD_TYPE_ADJECTIVE );
		}

	bool isWordTypeArticle()
		{
		return ( wordTypeNr_ == WORD_TYPE_ARTICLE );
		}

	bool isWordTypeConjunction()
		{
		return ( wordTypeNr_ == WORD_TYPE_CONJUNCTION );
		}

	bool isWordTypeDefiniteArticle()
		{
		return ( wordTypeNr_ == WORD_TYPE_ARTICLE &&	// Filter on articles, because nouns also have a definiteArticleParameter

				( definiteArticleParameter_ == WORD_PARAMETER_ARTICLE_DEFINITE_1 ||
				definiteArticleParameter_ == WORD_PARAMETER_ARTICLE_DEFINITE_2 ) );
		}

	bool isWordTypeIndefiniteArticle()
		{
		return ( wordTypeNr_ == WORD_TYPE_ARTICLE &&	// Filter on articles, because nouns also have an indefiniteArticleParameter

				( indefiniteArticleParameter_ == WORD_PARAMETER_ARTICLE_INDEFINITE_1 ||
				indefiniteArticleParameter_ == WORD_PARAMETER_ARTICLE_INDEFINITE_2 ) );
		}

	bool isWordTypeSingularNoun()
		{
		return ( wordTypeNr_ == WORD_TYPE_NOUN_SINGULAR );
		}

	bool isWordTypePluralNoun()
		{
		return ( wordTypeNr_ == WORD_TYPE_NOUN_PLURAL );
		}

	bool isWordTypePossessiveDeterminer()
		{
		return ( wordTypeNr_ == WORD_TYPE_POSSESSIVE_DETERMINER_SINGULAR ||
				wordTypeNr_ == WORD_TYPE_POSSESSIVE_DETERMINER_PLURAL );
		}

	bool isWordTypePossessivePronoun()
		{
		return ( wordTypeNr_ == WORD_TYPE_POSSESSIVE_PRONOUN_SINGULAR ||
				wordTypeNr_ == WORD_TYPE_POSSESSIVE_PRONOUN_PLURAL );
		}

	bool isWordTypeSymbol()
		{
		return ( wordTypeNr_ == WORD_TYPE_SYMBOL );
		}

	bool isWordTypeLetter()
		{
		return ( wordTypeNr_ == WORD_TYPE_LETTER_SMALL ||
				wordTypeNr_ == WORD_TYPE_LETTER_CAPITAL );
		}

	bool isWordTypeNumeral()
		{
		return ( wordTypeNr_ == WORD_TYPE_NUMERAL );
		}

	bool isWordTypeVerb()
		{
		return ( wordTypeNr_ == WORD_TYPE_VERB_SINGULAR ||
				wordTypeNr_ == WORD_TYPE_VERB_PLURAL );
		}

	bool isWordAlreadyWritten()
		{
		return ( writeLevel_ > NO_WRITE_LEVEL );
		}

	unsigned short definiteArticleParameter()
		{
		return definiteArticleParameter_;
		}

	unsigned short indefiniteArticleParameter()
		{
		return indefiniteArticleParameter_;
		}

	unsigned short wordTypeNr()
		{
		return wordTypeNr_;
		}

	unsigned short wordTypeLanguageNr()
		{
		return wordTypeLanguageNr_;
		}

	ResultType setDefiniteArticleParameter( unsigned short definiteArticleParameter )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "setDefiniteArticleParameter";
		if( definiteArticleParameter == WORD_PARAMETER_ARTICLE_DEFINITE_1 ||
		definiteArticleParameter == WORD_PARAMETER_ARTICLE_DEFINITE_2 )
			{
			if( definiteArticleParameter_ == NO_DEFINITE_ARTICLE_PARAMETER )
				{
				if( isWordTypeSingularNoun() )
					definiteArticleParameter_ = definiteArticleParameter;
				else
					return startErrorInItem( functionNameString, NULL, itemString(), "I am not a singular noun" );
				}
			else
				return startErrorInItem( functionNameString, NULL, itemString(), "The current definite article paramater is already defined" );
			}
		else
			return startErrorInItem( functionNameString, NULL, itemString(), "The given definite article paramater is no definite article paramater" );

		return commonVariables()->result;
		}

	ResultType setIndefiniteArticleParameter( unsigned short indefiniteArticleParameter )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "setIndefiniteArticleParameter";
		if( indefiniteArticleParameter == WORD_PARAMETER_ARTICLE_INDEFINITE_1 ||
		indefiniteArticleParameter == WORD_PARAMETER_ARTICLE_INDEFINITE_2 )
			{
			if( indefiniteArticleParameter_ == NO_INDEFINITE_ARTICLE_PARAMETER )
				{
				if( isWordTypeSingularNoun() )
					indefiniteArticleParameter_ = indefiniteArticleParameter;
				else
					return startErrorInItem( functionNameString, NULL, itemString(), "I am not a singular noun" );
				}
			else
				return startErrorInItem( functionNameString, NULL, itemString(), "The current indefinite article paramater is already defined" );
			}
		else
			return startErrorInItem( functionNameString, NULL, itemString(), "The given indefinite article paramater is no indefinite article paramater" );

		return commonVariables()->result;
		}

	ResultType markWordTypeAsWritten()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "markWordTypeAsWritten";
		if( commonVariables()->currentWriteLevel < MAX_LEVEL )
			{
			if( writeLevel_ == NO_WRITE_LEVEL )
				writeLevel_ = ++commonVariables()->currentWriteLevel;
			else
				return startErrorInItem( functionNameString, NULL, itemString(), "My write level is already assigned" );
			}
		else
			return startSystemErrorInItem( functionNameString, NULL, itemString(), "Current write word level overflow" );

		return commonVariables()->result;
		}

	ResultType hideWordType( void *hideKey )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "hideWordType";
		if( hideKey_ == NULL )
			hideKey_ = hideKey;
		else
			return startErrorInItem( functionNameString, NULL, itemString(), "This word type is already hidden" );

		return commonVariables()->result;
		}

	ResultType createNewWordTypeString( char *newWordTypeString )
		{
		size_t newWordTypeStringLength;
		char functionNameString[FUNCTION_NAME_LENGTH] = "createNewWordTypeString";
		if( newWordTypeString != NULL )
			{
			if( ( newWordTypeStringLength = strlen( newWordTypeString ) ) > 0 )
				{
				if( newWordTypeStringLength < MAX_READ_WRITE_STRING_LENGTH )
					{
					if( wordTypeString_ != NULL )
						delete wordTypeString_;

					if( ( wordTypeString_ = new char[newWordTypeStringLength + 1] ) != NULL )
						strcpy( wordTypeString_, newWordTypeString );
					else
						return startErrorInItem( functionNameString, NULL, itemString(), "I failed to create the word type string" );
					}
				else
					return startErrorInItem( functionNameString, NULL, itemString(), "The given word type is too long" );
				}
			else
				return startErrorInItem( functionNameString, NULL, itemString(), "The given new word type string is empty" );
			}
		else
			return startErrorInItem( functionNameString, NULL, itemString(), "The given new word type string is undefined" );

		return commonVariables()->result;
		}

	WordTypeItem *nextWordTypeItem()
		{
		return (WordTypeItem *)nextItem;
		}

	WordTypeItem *nextCurrentLanguageWordTypeItem()
		{
		WordTypeItem *nextCurrentLanguageWordTypeItem = nextWordTypeItem();

		return ( nextCurrentLanguageWordTypeItem != NULL &&
				nextCurrentLanguageWordTypeItem->wordTypeLanguageNr() == commonVariables()->currentGrammarLanguageNr ? nextCurrentLanguageWordTypeItem : NULL );
		}

	WordTypeItem *nextWordTypeItem( unsigned short wordTypeNr )
		{
		WordTypeItem *searchItem = nextCurrentLanguageWordTypeItem();

		while( searchItem != NULL )
			{
			if( wordTypeNr == WORD_TYPE_UNDEFINED ||
			searchItem->wordTypeNr_ == wordTypeNr )
				return searchItem;

			searchItem = searchItem->nextCurrentLanguageWordTypeItem();
			}

		return NULL;
		}
	};
#endif

/*************************************************************************
 *
 *	"The Lord gives his people strength.
 *	The Lord blesses them with peace." (Psalm 29:11)
 *
 *************************************************************************/
