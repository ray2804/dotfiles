#! /usr/bin/env python
# -*- coding: UTF-8 -*-
###
#
# This file is the legal property of Jean-Pierre Redonnet
# <redonnetbrouk@aol.com>
# Copyright (c) 2008-2009 Jean-Pierre Redonnet
#
# This program 'texlexan.py'(the GUI of texlexan) is a free softwares;
# you can redistribute it and/or modify it under the terms of the GNU
# General Public License version 3 as published by the Free Software
# Foundation.
#
# texlexan.py is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# long with texlexan.py.If not, see <http://www.gnu.org/licenses/>.
#
###
import pygtk
pygtk.require('2.0')
import gtk,gobject
import sys,os,shutil,string
import webbrowser

Prog_name='TLStart'
version='GUI 0.02'
date_version='Jan 17 2010'

class App:
   pass

#----------- Display info in a small window -------------
def message(title,message):
   dia = gtk.Dialog(title,
        None,  #the toplevel wgt of your app
        gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT,  #binary flags or'ed together
        (gtk.STOCK_OK, gtk.RESPONSE_CLOSE))
   dia.vbox.pack_start(gtk.Label('\n'+message+'\n'))
   dia.show_all()
   result = dia.run()
   dia.destroy()
   return

#---------- start thesearch engine: sis in command line -----------------
def texlexan_small(w):
    os.system(prg1_path+' -s')
    return True
   
def texlexan_full(w):
    os.system(prg1_path+' -f')
    return True

def texlexan_relevant(w):
    os.system(prg1_path+' -t')
    return True

def sis(w):
    os.system(prg2_path)
    return True

def help(w):
    webbrowser.open("http://texlexan.sourceforge.net/")
    return True



#---------------- Manage the main window ----------------------
   
def quit(w):
   try: os.remove(result)
   except: None
   gtk.main_quit()

#### program starts here ! ####
home_user_path=os.path.expanduser('~')  #home directory
texlexan_path=home_user_path+'/texlexan_cfg/' #contain the config file
prg1_path=home_user_path+'/texlexan_prog/texlexan.py'#contain the main prog
prg2_path=home_user_path+'/texlexan_prog/tlsearch.py' #contain the main prog

# if config path does'nt exist exit
if not os.path.isdir(texlexan_path):
    message("Error!",texlexan_path+" doesn't exist.\nI will use default paths.")
else:
   #read config file 
   try: f=open(texlexan_path+'texlexan.cfg','r')
   except:
      message('Error','impossible to open '+texlexan_path+'texlexan.cfg')
      exit()
   for line in f:
      if line[:3]=='pp:': prg_1_path=string.strip(line[3:-1])
      if line[:3]=='sp:': prg_2_path=string.strip(line[3:-1])
   f.close()
 
# *** The main window ***
w = gtk.Window()
w.set_keep_above(False)
w.set_title(Prog_name+' '+version)
w.set_default_size(100, 100)
vbox = gtk.VBox(False, 0)
hbox = gtk.HBox(False, 0)
w.add(vbox)
#buttons
button1 = gtk.Button("<<< _Analyzer Classifier Sumarizer small >>>",None)
vbox.pack_start(button1, False, False, 0)
button2 = gtk.Button("<<< Analyzer _Classifier Sumarizer full >>>",None)
vbox.pack_start(button2, False, False, 0)
button3 = gtk.Button("<<< _Relevant informations >>>",None)
vbox.pack_start(button3, False, False, 0)
button4 = gtk.Button("<<< _Search archives >>>",None)
vbox.pack_start(button4, False, False, 0)
button5 = gtk.Button("<<< _Help >>>",None)
vbox.pack_start(button5, False, False, 0)
button6 = gtk.Button("<<< _Close >>>",gtk.STOCK_QUIT)
vbox.pack_start(button6, False, False, 0)
#connections
button1.connect("clicked",texlexan_small)
button2.connect("clicked",texlexan_full)
button3.connect("clicked",texlexan_relevant)
button4.connect("clicked",sis)
button5.connect("clicked",help)
button6.connect("clicked",quit)
w.show_all()
   
gtk.main()
