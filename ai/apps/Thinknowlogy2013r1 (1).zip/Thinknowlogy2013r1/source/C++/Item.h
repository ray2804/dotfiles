/*
 *	Class:		Item
 *	Purpose:	Base class for the knowledge structure
 *	Version:	Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

// Item header

#ifndef ITEM
#define ITEM 1

#include "CommonVariables.cpp"

// Class declarations needed by some compilers, like Code::Blocks
class List;
class WordItem;

class Item
	{
	friend class FileItem;
	friend class List;
	friend class ListCleanup;
	friend class ListQuery;
	friend class ReadItem;
	friend class SelectionList;
	friend class SpecificationItem;
	friend class WordItem;


	// Private constructible variables

	unsigned short userNr_;

	unsigned int originalSentenceNr_;
	unsigned int creationSentenceNr_;

	unsigned int activeSentenceNr_;
	unsigned int deactiveSentenceNr_;
	unsigned int archiveSentenceNr_;
	unsigned int deleteSentenceNr_;

	unsigned int itemNr_;

	char statusChar_;

	char classNameString_[FUNCTION_NAME_LENGTH];
	char superClassNameString_[FUNCTION_NAME_LENGTH];


	// Private loadable variables

	List *myList_;
	WordItem *myWord_;

	CommonVariables *commonVariables_;


	// Private functions

	char *myWordTypeString( unsigned short queryWordTypeNr );


	protected:
	// Protected constructible variables

	bool isAvailableForRollback;
	bool isSelectedByQuery;
	bool wasActiveBeforeArchiving;

	Item *previousItem;
	Item *nextItem;

	char tempString[MAX_READ_WRITE_STRING_LENGTH];


	// Constructor

	Item();


	// Protected error functions

	ResultType addErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString );
	ResultType addErrorInItem( const char *functionNameString, const char *moduleNameString, char *instanceNameString, const char *errorString );

	ResultType addErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, unsigned int number1 );
	ResultType addErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, unsigned int number1, const char *errorString2, unsigned int number2 );
	ResultType addErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3, unsigned int number1 );
	ResultType addErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3 );
	ResultType addErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3, const char *errorString4, const char *errorString5 );

	ResultType addErrorInItem( char listChar, const char *functionNameString, const char *moduleNameString, const char *errorString );
	ResultType addErrorInItem( char listChar, const char *functionNameString, const char *moduleNameString, char *instanceNameString, const char *errorString );

	ResultType addErrorInItem( char listChar, const char *functionNameString, const char *moduleNameString, const char *errorString1, unsigned int number1 );
	ResultType addErrorInItem( char listChar, const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3 );
	ResultType addErrorInItem( char listChar, const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3, const char *errorString4, const char *errorString5 );

	ResultType startErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString );
	ResultType startErrorInItem( const char *functionNameString, const char *moduleNameString, char *instanceNameString, const char *errorString );

	ResultType startErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, unsigned int number1 );
	ResultType startErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, unsigned int number1, const char *errorString2, unsigned int number2 );
	ResultType startErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, unsigned int number1, const char *errorString2, unsigned int number2, const char *errorString3, unsigned int number3 );
	ResultType startErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, char char1, const char *errorString2 );
	ResultType startErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, char char1, const char *errorString2, char char2, const char *errorString3 );
	ResultType startErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3 );
	ResultType startErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3, const char *errorString4, const char *errorString5 );
	ResultType startErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3, const char *errorString4, const char *errorString5, const char *errorString6, const char *errorString7 );
	ResultType startErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3, unsigned int number1, const char *errorString4, unsigned int number2, const char *errorString5, unsigned int number3 );

	ResultType startErrorInItem( char listChar, const char *functionNameString, const char *moduleNameString, const char *errorString );
	ResultType startErrorInItem( char listChar, const char *functionNameString, const char *moduleNameString, char *instanceNameString, const char *errorString );

	ResultType startErrorInItem( char listChar, const char *functionNameString, const char *moduleNameString, const char *errorString1, unsigned int number1 );
	ResultType startErrorInItem( char listChar, const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3 );
	ResultType startErrorInItem( char listChar, const char *functionNameString, const char *moduleNameString, const char *errorString1, unsigned int number1, const char *errorString2, unsigned int number2 );

	ResultType startSystemErrorInItem( const char *functionNameString, const char *moduleNameString, const char *errorString );
	ResultType startSystemErrorInItem( const char *functionNameString, const char *moduleNameString, char *instanceNameString, const char *errorString );


	// Protected virtual functions

	virtual void showString( bool returnQueryToPosition );
	virtual void showWordReferences( bool returnQueryToPosition );
	virtual void showWords( bool returnQueryToPosition, unsigned short queryWordTypeNr );

	virtual bool hasFoundParameter( unsigned int queryParameter );
	virtual bool hasFoundReferenceItemById( unsigned int querySentenceNr, unsigned int queryItemNr );
	virtual bool hasFoundWordType( unsigned short queryWordTypeNr );

	virtual bool isSorted( Item *nextSortItem );

	virtual ResultType checkForUsage();
	virtual ResultType findMatchingWordReferenceString( char *queryString );

	virtual char *itemString();
	virtual char *extraItemString();
	virtual char *toString( unsigned short queryWordTypeNr );


	// Protected common functions

	void setActiveStatus();
	void setDeactiveStatus();
	void setArchivedStatus();
	void setDeletedStatus();

	void setActiveSentenceNr();
	void setDeactiveSentenceNr();
	void setArchivedSentenceNr();
	void setDeletedSentenceNr();

	void clearArchivedSentenceNr();

	void initializeItemVariables( const char *classNameString, WordItem *myWord, CommonVariables *commonVariables );	// Strictly to init AdminItem
	void initializeItemVariables( unsigned int originalSentenceNr, unsigned int activeSentenceNr, unsigned int deactiveSentenceNr, unsigned int archiveSentenceNr, const char *classNameString, List *myList, WordItem *myWord, CommonVariables *commonVariables );

	bool hasActiveSentenceNr();
	bool hasDeactiveSentenceNr();
	bool hasArchivedSentenceNr();

	bool hasCurrentCreationSentenceNr();

	bool hasCurrentActiveSentenceNr();
	bool hasCurrentDeactiveSentenceNr();
	bool hasCurrentArchivedSentenceNr();
	bool hasCurrentDeletedSentenceNr();

	bool isOlderSentence();

	bool isActiveItem();
	bool isDeactiveItem();
	bool isArchivedItem();
	bool isDeletedItem();

	bool isMoreRecent( Item *checkItem );
	bool isStringStartingWithVowel( char *textString );

	unsigned short userNr();

	unsigned int activeSentenceNr();
	unsigned int deactiveSentenceNr();
	unsigned int originalSentenceNr();
	unsigned int creationSentenceNr();

	unsigned int archiveSentenceNr();
	unsigned int deleteSentenceNr();

	unsigned int itemNr();

	ResultType decrementActiveSentenceNr();
	ResultType decrementDeactiveSentenceNr();
	ResultType decrementOriginalSentenceNr();
	ResultType decrementCreationSentenceNr();
	ResultType decrementArchivedSentenceNr();

	ResultType decrementCreationItemNr( unsigned int decrementOffset );

	char statusChar();

	List *myList();

	WordItem *myWord();

	CommonVariables *commonVariables();
	};
#endif

/*************************************************************************
 *
 *	"I will boast only in the Lord;
 *	let all who are helpless take heart." (Psalm 34:2)
 *
 *************************************************************************/
