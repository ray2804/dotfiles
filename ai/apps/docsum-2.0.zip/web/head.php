<?php 
	/* Current working directory */
	//$cwd = getcwd();
	
	/* version */
	$version = "2.0";
	
	/* This project's unix name, sourceforge only */
	$unixname = "docsum";
	
	$main_page = "index.php";
	
	/* Project page URL */
	$pj_url = "http://sourceforge.net/projects/$unixname";
	
	/* Project web home page */
	$hm_url = "http://$unixname.sourceforge.net";
	
	/* Application URL */
	#app_url = "http://$unixname.sourceforge.net/$unixname/phpsrc/$docsum_page";
	
	/* Application location on disk */
	//$app_loc = "/home/groups/d/do/docsum/htdocs/docsum";
	//global $app_loc;
	//$app_loc  = "/home/terry/docsum";
	
	/* File storage location */
	//$file_store =  '/tmp/persistent/docsum';
	
	/* Project admin e-mail */
	$email = 'tepietrondi@yahoo.com';	
	
	/* Project Author */
	$author = "Terrence Pietrondi";
	
	/* Logo URL */
	$logo = 'docsum-graphic.png';
	
	/* Logo HTML for pages */
	$logo_html = "<img src=\"$logo\" border=\"0\" alt=\"Docsum Logo\" />";
	
	/* Header html for pages */
	$header_html = "<head>
	<title>SourceForge.net Project: $unixname $page</title>
	<meta NAME=\"author\" CONTENT=\"$author\">
	<link rel=\"stylesheet\" type=\"text/css\" href=\"docsum.css\" />
	<script type=\"text/javascript\" src=\"docsum.js\"></script> 
	</head>";
	
	$foot_html = "<br>
<center><a href=\"about.php\">about docsum</a> | <a href=\"mailto:$email\">feedback/questions</a></center>
<br><center><a href=\"http://sourceforge.net\"><img src=\"http://sflogo.sourceforge.net/sflogo.php?group_id=167349&amp;type=2\" width=\"125\" height=\"37\" border=\"0\" alt=\"SourceForge.net Logo\" /></a>
<br>version $version</center>
</body>
</html>";
?>
