This directory contains a template of the directory structure expected
when compiling KPML. To use an alternative directory for binaries, set
the binary root parameter (common-lisp-user::*kpml-binaries-root*) to
the selected directory prior to installing KPML and make a copy of
this template structure there (e.g., by copying and then changing the 
name).

