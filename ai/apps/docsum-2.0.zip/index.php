<?php
// Get the information needed from the path to create the new URL
//$cwd = getcwd();
$unixname = "docsum";//substr($cwd, 18, (strpos($cwd,"/",19)-18));
$url = "./web/";
                                                                                
// Send the HTTP Location header... should work for most browsers
header("Location: $url");
                                                                                
// If we get this far the Location header wasn't processed...
// Send a simple page with a link on it to the summary page
?>
                                                                                
<html>
<head><title><?php echo("SourceForge.net Project: $unixname"); ?></title></head>
<body>
<?php echo"You probably meant to go <a HREF=$url>here</a>.";?>
</body>
</html>
