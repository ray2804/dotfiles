package gui_window::doc_cls::average;
use base qw(gui_window::doc_cls);

1;