READ THIS before clicking on anything in this directory!
=========

This directory contains assorted scripts and lisp fragments for
creating standalone images and saved state versions of KPML.

In general one needs to edit only the path information in these
scripts for them to work appropriately. Most, if not all, of
these are for Lispworks, as Franz is more restrictive about
who you can make images for and how much they want to charge
you for it.

The scripts are provided AS IS, without guarantee (i.e., even
less than usual). You should probably be generally familiar
with the process of making images and standalones under
Lispworks before playing with these. You should also
have been able to install KPML from the sources up to and
including the loading of resources and generation of examples--
otherwise whatever went wrong then will go wrong again when
the script is run, but without much possibility of you
being able to find out what it is that is failing.

The *.bat files start up Lispworks and run the corresponding
Lisp file for possibly compiling, loading and freezing the
KPML image required. They are quite good when everything
works since they reduce the work of making images to
a mouseclick. The created images are saved to D:\Images
unless you change this bit of the *lisp* file used 
by a script. Naturally they can also be changed so that
grammars in various stages of development are similarly
'frozen' into the image created.

John Bateman
Bremen, September 2002

