/*
 *	Class:			SpecificationItem
 *	Purpose:		To store info about the specification structure
 *					of a word
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#ifndef SPECIFICATIONITEM
#define SPECIFICATIONITEM 1
#include <limits.h>
#include "List.h"
#include "JustificationItem.h"
#include "WordItem.h"

class SpecificationItem : private Item
	{
	friend class AdminAssumption;
	friend class AdminAuthorization;
	friend class AdminCollection;
	friend class AdminConclusion;
	friend class AdminContext;
	friend class AdminImperative;
	friend class AdminJustification;
	friend class AdminLanguage;
	friend class AdminSolve;
	friend class AdminSpecification;
	friend class AdminWrite;
	friend class JustificationItem;
	friend class JustificationList;
	friend class SpecificationList;
	friend class WordAssignment;
	friend class WordCollection;
	friend class WordItem;
	friend class WordQuestion;
	friend class WordSpecification;
	friend class WordWrite;
	friend class WordWriteSentence;
	friend class WordWriteWords;

	// Private constructible variables

	unsigned short nAssignmentLevelRecalculations_;

	// Private loadable variables

	bool isAnsweredQuestion_;
	bool isConcludedAssumption_;
	bool isConditional_;
	bool isExclusive_;
	bool isNegative_;
	bool isPossessive_;
	bool isSpecificationGeneralization_;
	bool isValueSpecification_;

	unsigned short assignmentLevel_;
	unsigned short assumptionLevel_;
	unsigned short grammarLanguageNr_;
	unsigned short prepositionParameter_;
	unsigned short questionParameter_;

	unsigned short generalizationWordTypeNr_;
	unsigned short specificationWordTypeNr_;

	unsigned int generalizationCollectionNr_;
	unsigned int specificationCollectionNr_;

	unsigned int generalizationContextNr_;
	unsigned int specificationContextNr_;
	unsigned int relationContextNr_;

	unsigned int nContextRelations_;

	JustificationItem *specificationJustificationItem_;

	WordItem *specificationWordItem_;

	char *specificationString_;


	// Private constructible variables

	unsigned short specificationStringWriteLevel_;

	unsigned int lastCheckedAssumptionLevelItemNr_;


	// Private question functions

	SpecificationItem *newUserQuestion( bool includeThisItem )
		{
		SpecificationItem *searchItem = ( includeThisItem ? this : nextSelectedSpecificationItem( false ) );

		while( searchItem != NULL )
			{
			if( !searchItem->isAnsweredQuestion() &&
			!searchItem->isOlderSentence() &&
			searchItem->isUserQuestion() )
				return searchItem;

			searchItem = searchItem->nextSelectedSpecificationItem( false );
			}

		return searchItem;
		}


	// Private specification functions

	SpecificationResultType calculateAssumptionLevel( bool needsRecalculation )
		{
		SpecificationResultType specificationResult;
		unsigned short highestAssumptionLevel;
		unsigned short lowestAssumptionLevel = MAX_LEVEL;
		unsigned int tempAssumptionLevel;
		unsigned int nJustificationRelationWords;
		unsigned int nSpecificationRelationWords;
		JustificationItem *currentJustificationItem;
		JustificationItem *nextJustificationItem = specificationJustificationItem_;
		char functionNameString[FUNCTION_NAME_LENGTH] = "calculateAssumptionLevel";

		if( ( needsRecalculation ||
		assumptionLevel_ == NO_ASSUMPTION_LEVEL ) &&

		isSelfGeneratedAssumption() )
			{
			if( ++nAssignmentLevelRecalculations_ < MAX_ASSUMPTION_LEVEL_RECALCULATIONS )
				{
				nSpecificationRelationWords = myWord()->nContextWords( isPossessive_, relationContextNr_, specificationWordItem_ );

				do	{
					nJustificationRelationWords = 0;
					highestAssumptionLevel = NO_ASSUMPTION_LEVEL;
					currentJustificationItem = nextJustificationItem;

					if( currentJustificationItem != NULL )
						{
						do	{
							nJustificationRelationWords += currentJustificationItem->nJustificationContextRelations( relationContextNr_, nSpecificationRelationWords );

							if( currentJustificationItem->isAssumption() )
								{
								if( ( specificationResult = currentJustificationItem->getCombinedAssumptionLevel() ).result == RESULT_OK )
									{
									if( ( tempAssumptionLevel = ( specificationResult.combinedAssumptionLevel + currentJustificationItem->assumptionGrade() ) ) > highestAssumptionLevel )
										{
										if( tempAssumptionLevel < MAX_LEVEL )
											highestAssumptionLevel = (unsigned short)tempAssumptionLevel;
										else
											startSystemErrorInItem( functionNameString, NULL, NULL, "Assumption level overflow" );
										}
									}
								else
									addErrorInItem( functionNameString, NULL, NULL, "I failed to get the combined assumption level" );
								}
							}
						while( commonVariables()->result == RESULT_OK &&
						( currentJustificationItem = currentJustificationItem->nextJustificationItemWithSameTypeAndOrderNr() ) != NULL );
						}

					if( commonVariables()->result == RESULT_OK &&
					highestAssumptionLevel < lowestAssumptionLevel &&

					( nJustificationRelationWords == nSpecificationRelationWords ||

					( assumptionLevel_ == NO_ASSUMPTION_LEVEL &&
					lastCheckedAssumptionLevelItemNr_ == commonVariables_->currentItemNr ) ) )	// To avoid looping: calculation A, calculation B, calculation A, etc.
						lowestAssumptionLevel = highestAssumptionLevel;
					}
				while( commonVariables()->result == RESULT_OK &&
				( nextJustificationItem = nextJustificationItem->nextJustificationItemWithDifferentTypeOrOrderNr( specificationJustificationItem_ ) ) != NULL );

				if( commonVariables()->result == RESULT_OK )
					{
					if( lowestAssumptionLevel < MAX_LEVEL )
						{
						nAssignmentLevelRecalculations_ = 0;
						assumptionLevel_ = lowestAssumptionLevel;
						}

					lastCheckedAssumptionLevelItemNr_ = commonVariables_->currentItemNr;
					}
				}
			else
				startErrorInItem( functionNameString, NULL, "I think there is an endless loop in the assumption level calculation of my specification, because the number of iterations is: ", nAssignmentLevelRecalculations_ );
			}

		specificationResult.assumptionLevel = assumptionLevel_;
		specificationResult.result = commonVariables()->result;
		return specificationResult;
		}


	protected:
	// Protected constructible variables

	SpecificationItem *replacingSpecificationItem;


	// Constructor

	SpecificationItem( bool isAnsweredQuestion, bool isConditional, bool _isConcludedAssumption, bool isExclusive, bool isNegative, bool isPossessive, bool isSpecificationGeneralization, bool isValueSpecification, unsigned short assignmentLevel, unsigned short assumptionLevel, unsigned short grammarLanguageNr, unsigned short prepositionParameter, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int originalSentenceNr, unsigned int activeSentenceNr, unsigned int deactiveSentenceNr, unsigned int archiveSentenceNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *specificationWordItem, char *specificationString, List *myList, WordItem *myWord, CommonVariables *commonVariables )
		{
		size_t specificationStringLength;

		initializeItemVariables( originalSentenceNr, activeSentenceNr, deactiveSentenceNr, archiveSentenceNr, "SpecificationItem", myList, myWord, commonVariables );

		// Private constructible variables

		nAssignmentLevelRecalculations_ = 0;

		// Private loadable variables

		isAnsweredQuestion_ = isAnsweredQuestion;
		isConcludedAssumption_ = _isConcludedAssumption;
		isConditional_ = isConditional;
		isExclusive_ = isExclusive;
		isNegative_ = isNegative;
		isPossessive_ = isPossessive;
		isSpecificationGeneralization_ = isSpecificationGeneralization;
		isValueSpecification_ = isValueSpecification;

		assignmentLevel_ = assignmentLevel;
		assumptionLevel_ = assumptionLevel;
		grammarLanguageNr_ = grammarLanguageNr;
		prepositionParameter_ = prepositionParameter;
		questionParameter_ = questionParameter;

		generalizationWordTypeNr_ = generalizationWordTypeNr;
		specificationWordTypeNr_ = specificationWordTypeNr;

		generalizationCollectionNr_ = generalizationCollectionNr;
		specificationCollectionNr_ = specificationCollectionNr;

		generalizationContextNr_ = generalizationContextNr;
		specificationContextNr_ = specificationContextNr;
		relationContextNr_ = relationContextNr;

		nContextRelations_ = nContextRelations;

		specificationJustificationItem_ = specificationJustificationItem;

		specificationWordItem_ = specificationWordItem;

		specificationString_ = NULL;

		if( specificationString != NULL )
			{
			if( ( specificationStringLength = strlen( specificationString ) ) < MAX_READ_WRITE_STRING_LENGTH )
				{
				if( ( specificationString_ = new char[specificationStringLength + 1] ) != NULL )
					strcpy( specificationString_, specificationString );
				else
					startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, NULL, "I failed to create a specification string" );
				}
			else
				startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, NULL, "The given specification string is too long" );
			}

		// Private constructible variables

		specificationStringWriteLevel_ = NO_WRITE_LEVEL;

		lastCheckedAssumptionLevelItemNr_ = NO_ITEM_NR;

		// Protected constructible variables

		replacingSpecificationItem = NULL;
		}

	~SpecificationItem()
		{
		if( specificationString_ != NULL )
			delete specificationString_;
		}


	// Protected virtual functions

	virtual void showString( bool returnQueryToPosition )
		{
		char statusString[2] = SPACE_STRING;
		statusString[0] = statusChar();

		if( specificationString_ != NULL )
			{
			if( commonVariables()->hasFoundQuery )
				strcat( commonVariables()->queryString, ( returnQueryToPosition ? NEW_LINE_STRING : QUERY_SEPARATOR_SPACE_STRING ) );

			if( !isActiveItem() )	// Show status when not active
				strcat( commonVariables()->queryString, statusString );

			commonVariables()->hasFoundQuery = true;
			strcat( commonVariables()->queryString, specificationString_ );
			}
		}

	virtual void showWordReferences( bool returnQueryToPosition )
		{
		char *wordString;
		char statusString[2] = SPACE_STRING;
		statusString[0] = statusChar();

//Java
		if( specificationWordItem_ != NULL &&
		( wordString = specificationWordItem_->wordTypeString( true, NO_ORDER_NR, specificationWordTypeNr_ ) ) != NULL )
			{
			if( commonVariables()->hasFoundQuery )
				strcat( commonVariables()->queryString, ( returnQueryToPosition ? NEW_LINE_STRING : QUERY_SEPARATOR_SPACE_STRING ) );

			if( !isActiveItem() )	// Show status when not active
				strcat( commonVariables()->queryString, statusString );

			commonVariables()->hasFoundQuery = true;
			strcat( commonVariables()->queryString, wordString );
			}
		}

	virtual bool hasFoundParameter( unsigned int queryParameter )
		{
		return ( grammarLanguageNr_ == queryParameter ||
				prepositionParameter_ == queryParameter ||
				questionParameter_ == queryParameter ||
				generalizationCollectionNr_ == queryParameter ||
				specificationCollectionNr_ == queryParameter ||
				generalizationContextNr_ == queryParameter ||
				specificationContextNr_ == queryParameter ||
				relationContextNr_ == queryParameter ||
				nContextRelations_ == queryParameter ||

				( queryParameter == MAX_QUERY_PARAMETER &&

				( grammarLanguageNr_ > NO_LANGUAGE_NR ||
				prepositionParameter_ > NO_PREPOSITION_PARAMETER ||
				questionParameter_ > NO_QUESTION_PARAMETER ||
				generalizationCollectionNr_ > NO_COLLECTION_NR ||
				specificationCollectionNr_ > NO_COLLECTION_NR ||
				generalizationContextNr_ > NO_CONTEXT_NR ||
				specificationContextNr_ > NO_CONTEXT_NR ||
				relationContextNr_ > NO_CONTEXT_NR ||
				nContextRelations_ > 0 ) ) );
		}

	virtual bool hasFoundReferenceItemById( unsigned int querySentenceNr, unsigned int queryItemNr )
		{
		return ( ( specificationJustificationItem_ == NULL ? false :
					( querySentenceNr == NO_SENTENCE_NR ? true : specificationJustificationItem_->creationSentenceNr() == querySentenceNr ) &&
					( queryItemNr == NO_ITEM_NR ? true : specificationJustificationItem_->itemNr() == queryItemNr ) ) ||

				( specificationWordItem_ == NULL ? false :
					( querySentenceNr == NO_SENTENCE_NR ? true : specificationWordItem_->creationSentenceNr() == querySentenceNr ) &&
					( queryItemNr == NO_ITEM_NR ? true : specificationWordItem_->itemNr() == queryItemNr ) ) ||

				( replacingSpecificationItem == NULL ? false :
					( querySentenceNr == NO_SENTENCE_NR ? true : replacingSpecificationItem->creationSentenceNr() == querySentenceNr ) &&
					( queryItemNr == NO_ITEM_NR ? true : replacingSpecificationItem->itemNr() == queryItemNr ) ) );
		}

	virtual bool hasFoundWordType( unsigned short queryWordTypeNr )
		{
		return ( generalizationWordTypeNr_ == queryWordTypeNr ||
				specificationWordTypeNr_ == queryWordTypeNr	);
		}

	virtual bool isSorted( Item *nextSortItem )
		{
		return ( nextSortItem == NULL ||
				// 1) Assignment needs descending assignmentLevel
				assignmentLevel_ > ( (SpecificationItem *)nextSortItem )->assignmentLevel_ ||

				// 2) Question and specification needs descending creationSentenceNr
				( assignmentLevel_ == ( (SpecificationItem *)nextSortItem )->assignmentLevel_ &&
				creationSentenceNr() > nextSortItem->creationSentenceNr() ) );
		}

	virtual ResultType checkForUsage()
		{
		return myWord()->checkSpecificationForUsageOfInvolvedWords( this );
		}

	virtual ResultType findMatchingWordReferenceString( char *queryString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "findMatchingWordReferenceString";
		commonVariables()->hasFoundMatchingStrings = false;

		if( specificationWordItem_ != NULL )
			{
			if( specificationWordItem_->findMatchingWordReferenceString( queryString ) != RESULT_OK )
				return addErrorInItem( functionNameString, NULL, NULL, "I failed to find a matching word reference string for the specification word" );
			}

		return commonVariables()->result;
		}

	virtual char *toString( unsigned short queryWordTypeNr )
		{
		char *wordString;
		char *languageNameString = myWord()->grammarLanguageNameString( grammarLanguageNr_ );
		char *generalizationWordTypeString = myWord()->wordTypeName( generalizationWordTypeNr_ );
		char *specificationWordTypeString = myWord()->wordTypeName( specificationWordTypeNr_ );

		Item::toString( queryWordTypeNr );

		if( isAnsweredQuestion_ )
			{
			strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
			strcat( commonVariables()->queryString, "isAnsweredQuestion" );
			}

		if( isConditional_ )
			{
			strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
			strcat( commonVariables()->queryString, "isConditional" );
			}

		if( isConcludedAssumption_ )
			{
			strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
			strcat( commonVariables()->queryString, "isConcludedAssumption" );
			}

		if( isExclusive_ )
			{
			strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
			strcat( commonVariables()->queryString, "isExclusive" );
			}

		if( isNegative_ )
			{
			strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
			strcat( commonVariables()->queryString, "isNegative" );
			}

		if( isPossessive_ )
			{
			strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
			strcat( commonVariables()->queryString, "isPossessive" );
			}

		if( isSpecificationGeneralization_ )
			{
			strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
			strcat( commonVariables()->queryString, "isSpecificationGeneralization" );
			}

		if( isValueSpecification_ )
			{
			strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
			strcat( commonVariables()->queryString, "isValueSpecification" );
			}

		if( assignmentLevel_ > NO_ASSIGNMENT_LEVEL )
			{
			sprintf( tempString, "%cassignmentLevel:%u", QUERY_SEPARATOR_CHAR, assignmentLevel_ );
			strcat( commonVariables()->queryString, tempString );
			}

		if( assumptionLevel_ > NO_ASSUMPTION_LEVEL )
			{
			sprintf( tempString, "%cassumptionLevel:%u", QUERY_SEPARATOR_CHAR, assumptionLevel_ );
			strcat( commonVariables()->queryString, tempString );
			}

		if( grammarLanguageNr_ > NO_LANGUAGE_NR )
			{
			if( languageNameString == NULL )
				sprintf( tempString, "%cgrammarLanguageNr:%u", QUERY_SEPARATOR_CHAR, grammarLanguageNr_ );
			else
				sprintf( tempString, "%cgrammarLanguage:%s", QUERY_SEPARATOR_CHAR, languageNameString );

			strcat( commonVariables()->queryString, tempString );
			}

		if( specificationStringWriteLevel_ > NO_WRITE_LEVEL )
			{
			sprintf( tempString, "%cspecificationStringWriteLevel:%u", QUERY_SEPARATOR_CHAR, specificationStringWriteLevel_ );
			strcat( commonVariables()->queryString, tempString );
			}

		if( prepositionParameter_ > NO_PREPOSITION_PARAMETER )
			{
			sprintf( tempString, "%cprepositionParameter:%u", QUERY_SEPARATOR_CHAR, prepositionParameter_ );
			strcat( commonVariables()->queryString, tempString );
			}

		if( questionParameter_ > NO_QUESTION_PARAMETER )
			{
			sprintf( tempString, "%cquestionParameter:%u", QUERY_SEPARATOR_CHAR, questionParameter_ );
			strcat( commonVariables()->queryString, tempString );
			}
/*
		if( lastCheckedAssumptionLevelItemNr_ > NO_ITEM_NR )
			{
			sprintf( tempString, "%clastCheckedAssumptionLevelItemNr:%u", QUERY_SEPARATOR_CHAR, lastCheckedAssumptionLevelItemNr_ );
			strcat( commonVariables()->queryString, tempString );
			}
*/
		if( generalizationCollectionNr_ > NO_COLLECTION_NR )
			{
			sprintf( tempString, "%cgeneralizationCollectionNr:%u", QUERY_SEPARATOR_CHAR, generalizationCollectionNr_ );
			strcat( commonVariables()->queryString, tempString );
			}

		if( generalizationWordTypeString == NULL )
			sprintf( tempString, "%cgeneralizationWordType:%c%u", QUERY_SEPARATOR_CHAR, QUERY_WORD_TYPE_CHAR, generalizationWordTypeNr_ );
		else
			sprintf( tempString, "%cgeneralizationWordType:%s%c%u", QUERY_SEPARATOR_CHAR, generalizationWordTypeString, QUERY_WORD_TYPE_CHAR, generalizationWordTypeNr_ );

		strcat( commonVariables()->queryString, tempString );

		if( generalizationContextNr_ > NO_CONTEXT_NR )
			{
			sprintf( tempString, "%cgeneralizationContextNr:%u", QUERY_SEPARATOR_CHAR, generalizationContextNr_ );
			strcat( commonVariables()->queryString, tempString );
			}

		if( specificationCollectionNr_ > NO_COLLECTION_NR )
			{
			sprintf( tempString, "%cspecificationCollectionNr:%u", QUERY_SEPARATOR_CHAR, specificationCollectionNr_ );
			strcat( commonVariables()->queryString, tempString );
			}

		if( specificationWordTypeString == NULL )
			sprintf( tempString, "%cspecificationWordType:%c%u", QUERY_SEPARATOR_CHAR, QUERY_WORD_TYPE_CHAR, specificationWordTypeNr_ );
		else
			sprintf( tempString, "%cspecificationWordType:%s%c%u", QUERY_SEPARATOR_CHAR, specificationWordTypeString, QUERY_WORD_TYPE_CHAR, specificationWordTypeNr_ );

		strcat( commonVariables()->queryString, tempString );

		if( specificationContextNr_ > NO_CONTEXT_NR )
			{
			sprintf( tempString, "%cspecificationContextNr:%u", QUERY_SEPARATOR_CHAR, specificationContextNr_ );
			strcat( commonVariables()->queryString, tempString );
			}

		if( specificationWordItem_ != NULL )
			{
			sprintf( tempString, "%cspecificationWord%c%u%c%u%c", QUERY_SEPARATOR_CHAR, QUERY_REF_ITEM_START_CHAR, specificationWordItem_->creationSentenceNr(), QUERY_SEPARATOR_CHAR, specificationWordItem_->itemNr(), QUERY_REF_ITEM_END_CHAR );
			strcat( commonVariables()->queryString, tempString );

			if( ( wordString = specificationWordItem_->wordTypeString( true, NO_ORDER_NR, specificationWordTypeNr_ ) ) != NULL )
				{
				sprintf( tempString, "%c%s%c", QUERY_WORD_REFERENCE_START_CHAR, wordString, QUERY_WORD_REFERENCE_END_CHAR );
				strcat( commonVariables()->queryString, tempString );
				}
			}

		if( relationContextNr_ > NO_CONTEXT_NR )
			{
			sprintf( tempString, "%crelationContextNr:%u", QUERY_SEPARATOR_CHAR, relationContextNr_ );
			strcat( commonVariables()->queryString, tempString );
			}

		if( nContextRelations_ > NO_CONTEXT_NR )
			{
			sprintf( tempString, "%cnContextRelations:%u", QUERY_SEPARATOR_CHAR, nContextRelations_ );
			strcat( commonVariables()->queryString, tempString );
			}

		if( specificationJustificationItem_ != NULL )
			{
			sprintf( tempString, "%cspecificationJustificationItem%c%u%c%u%c", QUERY_SEPARATOR_CHAR, QUERY_REF_ITEM_START_CHAR, specificationJustificationItem_->creationSentenceNr(), QUERY_SEPARATOR_CHAR, specificationJustificationItem_->itemNr(), QUERY_REF_ITEM_END_CHAR );
			strcat( commonVariables()->queryString, tempString );
			}

		if( replacingSpecificationItem != NULL )
			{
			sprintf( tempString, "%creplacingSpecificationItem%c%u%c%u%c", QUERY_SEPARATOR_CHAR, QUERY_REF_ITEM_START_CHAR, replacingSpecificationItem->creationSentenceNr(), QUERY_SEPARATOR_CHAR, replacingSpecificationItem->itemNr(), QUERY_REF_ITEM_END_CHAR );
			strcat( commonVariables()->queryString, tempString );
			}

		if( specificationString_ != NULL )
			{
			sprintf( tempString, "%cspecificationString:%c%s%c", QUERY_SEPARATOR_CHAR, QUERY_STRING_START_CHAR, specificationString_, QUERY_STRING_END_CHAR );
			strcat( commonVariables()->queryString, tempString );
			}

		return commonVariables()->queryString;
		}


	// Protected assignment functions

	bool isAssignment()
		{
		return ( myList()->isAssignmentList() );
		}

	bool isActiveAssignment()
		{
		return ( isAssignment() &&
				isActiveItem() );
		}

	bool isDeactiveAssignment()
		{
		return ( isAssignment() &&
				isDeactiveItem() );
		}

	bool isArchivedAssignment()
		{
		return ( isAssignment() &&
				isArchivedItem() );
		}

	unsigned short assignmentLevel()
		{
		return assignmentLevel_;
		}

	unsigned short assumptionLevel()
		{
		return assumptionLevel_;
		}

	unsigned short grammarLanguageNr()
		{
		return grammarLanguageNr_;
		}

	SpecificationItem *getAssignmentItem( bool isIncludingAnsweredQuestions, bool includeThisItem )
		{
		SpecificationItem *searchItem = ( includeThisItem ? ( assignmentLevel_ == commonVariables()->currentAssignmentLevel ? this : NULL ) : nextAssignmentItemWithCurrentLevel() );

		while( searchItem != NULL )
			{
			// Skip replaced assignments
			if( ( searchItem->replacingSpecificationItem == NULL ||
			// Skip replaced specifications that are undone
			searchItem->replacingSpecificationItem->creationSentenceNr() > commonVariables_->currentSentenceNr ) &&

			// Skip answered questions
			( isIncludingAnsweredQuestions ||
			!searchItem->isAnsweredQuestion() ) )
				return searchItem;

			searchItem = searchItem->nextAssignmentItemWithCurrentLevel();
			}

		return NULL;
		}

	SpecificationItem *getAssignmentItem( bool isIncludingAnsweredQuestions, bool includeThisItem, bool isQuestion )
		{
		SpecificationItem *searchItem = ( includeThisItem ? ( assignmentLevel_ == commonVariables()->currentAssignmentLevel ? this : NULL ) : nextAssignmentItemWithCurrentLevel() );

		while( searchItem != NULL )
			{
			// Skip replaced assignments
			if( ( searchItem->replacingSpecificationItem == NULL ||
			// Skip replaced specifications that are undone
			searchItem->replacingSpecificationItem->creationSentenceNr() > commonVariables_->currentSentenceNr ) &&

			// Skip answered questions
			( isIncludingAnsweredQuestions ||
			!searchItem->isAnsweredQuestion() ) &&

			searchItem->isQuestion() == isQuestion )
				return searchItem;

			searchItem = searchItem->nextAssignmentItemWithCurrentLevel();
			}

		return NULL;
		}

	SpecificationItem *getAssignmentItem( bool isIncludingAnsweredQuestions, bool includeThisItem, unsigned short questionParameter )
		{
		SpecificationItem *searchItem = ( includeThisItem ? ( assignmentLevel_ == commonVariables()->currentAssignmentLevel ? this : NULL ) : nextAssignmentItemWithCurrentLevel() );

		while( searchItem != NULL )
			{
			// Skip replaced assignments
			if( ( searchItem->replacingSpecificationItem == NULL ||
			// Skip replaced specifications that are undone
			searchItem->replacingSpecificationItem->creationSentenceNr() > commonVariables_->currentSentenceNr ) &&

			// Skip answered questions
			( isIncludingAnsweredQuestions ||
			!searchItem->isAnsweredQuestion() ) &&

			searchItem->questionParameter() == questionParameter )
				return searchItem;

			searchItem = searchItem->nextAssignmentItemWithCurrentLevel();
			}

		return NULL;
		}

	SpecificationItem *nextAssignmentItemWithCurrentLevel()
		{
		SpecificationItem *nextAssignmentItem = (SpecificationItem *)nextItem;

		if( nextAssignmentItem != NULL &&
		nextAssignmentItem->assignmentLevel() == commonVariables()->currentAssignmentLevel )
			return nextAssignmentItem;

		return NULL;
		}

	SpecificationItem *nextAssignmentItemButNotAQuestion()
		{
		return getAssignmentItem( false, false, false );
		}


	// Protected question functions

	bool isAnsweredQuestion()
		{
		return isAnsweredQuestion_;
		}

	bool isConcludedAssumption()
		{
		return isConcludedAssumption_;
		}

	bool isQuestion()
		{
		return ( questionParameter_ > NO_QUESTION_PARAMETER );
		}

	bool isSelfGeneratedQuestion()
		{
		JustificationItem *searchItem = specificationJustificationItem_;

		if( questionParameter_ > NO_QUESTION_PARAMETER )
			{
			while( searchItem != NULL )
				{
				if( searchItem->isQuestion() )
					return true;

				searchItem = searchItem->attachedJustificationItem();
				}
			}

		return false;
		}

	bool isUserQuestion()
		{
		return ( questionParameter_ > NO_QUESTION_PARAMETER &&
				specificationJustificationItem_ == NULL );
		}

	unsigned short questionParameter()
		{
		return questionParameter_;
		}

	SpecificationItem *firstNewUserQuestion()
		{
		return newUserQuestion( true );
		}

	SpecificationItem *nextNewUserQuestion()
		{
		return newUserQuestion( false );
		}


	// Protected specification functions

	void clearLastCheckedAssumptionLevelItemNr()
		{
		lastCheckedAssumptionLevelItemNr_ = NO_ITEM_NR;
		}

	void clearSpecificationStringWriteLevel( unsigned short currentWriteLevel )
		{
		if( specificationStringWriteLevel_ > currentWriteLevel )
			specificationStringWriteLevel_ = NO_WRITE_LEVEL;
		}

	void markAsConcludedAssumption()
		{
		isConcludedAssumption_ = true;
		assumptionLevel_ = NO_ASSUMPTION_LEVEL;
		}

	bool hasNewInformation()
		{
		return ( !isOlderSentence() ||

				( ( isConcludedAssumption_ ||
				isSelfGeneratedAssumption() ) &&

				assumptionLevel_ == NO_ASSUMPTION_LEVEL &&
				specificationJustificationItem_->hasNewInformation() ) ||	// Has new justification item

				( ( isAssignment() ||
				!hasExclusiveRelationCollection() ) &&

				( hasCurrentDeactiveSentenceNr() ||
				hasCurrentArchivedSentenceNr() ||
				myWord()->isContextCurrentlyUpdatedInAllWords( isPossessive_, relationContextNr_, specificationWordItem_ ) ) ) );
		}

	bool hasOnlyExclusiveSpecificationSubstitutionAssumptionsWithoutDefinition()
		{
		return ( specificationJustificationItem_ != NULL &&
				specificationJustificationItem_->hasOnlyExclusiveSpecificationSubstitutionAssumptionsWithoutDefinition() );
		}

	bool hasGeneralizationCollection()
		{
		return ( generalizationCollectionNr_ > NO_COLLECTION_NR );
		}

	bool hasExclusiveGeneralizationCollection()
		{
		return ( isExclusive_ &&
				generalizationCollectionNr_ > NO_COLLECTION_NR );
		}

	bool hasSpecificationCollection()
		{
		return ( specificationCollectionNr_ > NO_COLLECTION_NR );
		}

	bool hasSpecificationCompoundCollection()
		{
		return ( specificationCollectionNr_ > NO_COLLECTION_NR &&
				specificationWordItem_ != NULL &&
				specificationWordItem_->isCompoundCollection( specificationCollectionNr_ ) );
		}

	bool hasRelationCollection()
		{
		return ( relationCollectionNr() > NO_COLLECTION_NR );
		}

	bool hasExclusiveRelationCollection()
		{
		return ( isExclusive_ &&
				hasRelationCollection() );
		}

	bool hasGeneralizationContext()
		{
		return ( generalizationContextNr_ > NO_CONTEXT_NR );
		}

	bool hasFoundSpecificationJustification( JustificationItem *specificationJustificationItem )
		{
		JustificationItem *searchItem = specificationJustificationItem_;

		if( specificationJustificationItem != NULL )
			{
			while( searchItem != NULL )
				{
				if( searchItem == specificationJustificationItem )
					return true;

				searchItem = searchItem->attachedJustificationItem();
				}
			}

		return false;
		}

	bool hasSpecificationContext()
		{
		return ( specificationContextNr_ > NO_CONTEXT_NR );
		}

	bool hasRelationContext()
		{
		return ( relationContextNr_ > NO_CONTEXT_NR );
		}

	bool isConditional()
		{
		return isConditional_;
		}

	bool isExclusive()
		{
		return isExclusive_;
		}

	bool isNegative()
		{
		return isNegative_;
		}

	bool isPossessive()
		{
		return isPossessive_;
		}

	bool isPrepositionFor()
		{
		return ( prepositionParameter_ == WORD_PARAMETER_PREPOSITION_FOR );
		}

	bool isPrepositionFrom()
		{
		return ( prepositionParameter_ == WORD_PARAMETER_PREPOSITION_FROM );
		}

	bool isPrepositionIn()
		{
		return ( prepositionParameter_ == WORD_PARAMETER_PREPOSITION_IN );
		}

	bool isPrepositionOf()
		{
		return ( prepositionParameter_ == WORD_PARAMETER_PREPOSITION_OF );
		}

	bool isPrepositionTo()
		{
		return ( prepositionParameter_ == WORD_PARAMETER_PREPOSITION_TO );
		}

	bool isMatchingGeneralizationContextNr( bool isAllowingEmptyContextResult, unsigned int generalizationContextNr )
		{
		if( ( !isExclusive_ &&
		generalizationContextNr == NO_CONTEXT_NR ) ||			// Empty subset

		generalizationContextNr_ == generalizationContextNr ||	// Same set

		( isAllowingEmptyContextResult &&
		generalizationContextNr_ == NO_CONTEXT_NR ) )
			return true;

		return myWord()->isContextSubsetInAllWords( generalizationContextNr_, generalizationContextNr );
		}

	bool isMatchingSpecificationContextNr( bool isAllowingEmptyContextResult, unsigned int specificationContextNr )
		{
		if( specificationContextNr == NO_CONTEXT_NR ||			// Empty subset
		specificationContextNr_ == specificationContextNr ||	// Same set

		( isAllowingEmptyContextResult &&
		specificationContextNr_ == NO_CONTEXT_NR ) )
			return true;

		return myWord()->isContextSubsetInAllWords( specificationContextNr_, specificationContextNr );
		}

	bool isMatchingRelationContextNr( bool isAllowingEmptyContextResult, unsigned int relationContextNr )
		{
		if( relationContextNr == NO_CONTEXT_NR ||		// Empty subset
		relationContextNr_ == relationContextNr ||		// Same set

		( isAllowingEmptyContextResult &&
		relationContextNr_ == NO_CONTEXT_NR ) )
			return true;

		return myWord()->isContextSubsetInAllWords( relationContextNr_, relationContextNr );
		}

	bool isMyJustificationAnAssumption()
		{
		return ( specificationJustificationItem_ != NULL &&
				specificationJustificationItem_->isAssumption() );
		}

	bool isSelfGeneratedAssumption()
		{
		JustificationItem *searchItem = specificationJustificationItem_;

		if( !isConcludedAssumption_ )
			{
			while( searchItem != NULL )
				{
				if( searchItem->isAssumption() )
					return true;

				searchItem = searchItem->attachedJustificationItem();
				}
			}

		return false;
		}

	bool isSelfGeneratedConclusion()
		{
		return ( isSelfGenerated() &&
				!isSelfGeneratedAssumption() );
		}

	bool isUserSpecification()
		{
		return ( questionParameter_ == NO_QUESTION_PARAMETER &&
				specificationJustificationItem_ == NULL );
		}

	bool isSelfGenerated()
		{
		return ( specificationJustificationItem_ != NULL );
		}

	bool isSelfGeneratedPossessiveReversibleConclusion()
		{
		return ( specificationJustificationItem_ != NULL &&
				specificationJustificationItem_->isPossessiveReversibleConclusion() );
		}

	bool isSpecificationGeneralization()
		{
		return isSpecificationGeneralization_;
		}

	bool isSpecificationStringAlreadyWritten()
		{
		return ( specificationStringWriteLevel_ > NO_WRITE_LEVEL );
		}

	bool isValueSpecification()
		{
		return isValueSpecification_;
		}

	bool isGeneralizationNoun()
		{
		return ( generalizationWordTypeNr_ == WORD_TYPE_NOUN_SINGULAR ||
				generalizationWordTypeNr_ == WORD_TYPE_NOUN_PLURAL );
		}

	bool isSpecificationNoun()
		{
		return ( specificationWordTypeNr_ == WORD_TYPE_NOUN_SINGULAR ||
				specificationWordTypeNr_ == WORD_TYPE_NOUN_PLURAL );
		}

	bool isSpecificationNumeral()
		{
		return ( specificationWordTypeNr_ == WORD_TYPE_NUMERAL );
		}

	bool isGeneralizationPropername()
		{
		return ( generalizationWordTypeNr_ == WORD_TYPE_PROPER_NAME );
		}

	bool isSpecificationPropername()
		{
		return ( specificationWordTypeNr_ == WORD_TYPE_PROPER_NAME );
		}

	bool isRelationPropername()
		{
		return ( relationWordTypeNr() == WORD_TYPE_PROPER_NAME );
		}

	bool isSpecificationCompoundCollection()
		{
		return ( specificationWordItem_ != NULL &&
				specificationWordItem_->isCompoundCollection( specificationCollectionNr_ ) );
		}

	bool isRelatedQuestion( bool isExclusive, unsigned int specificationCollectionNr, unsigned int subsetRelationContextNr )
		{
		return ( isExclusive_ == isExclusive &&
				specificationCollectionNr_ == specificationCollectionNr &&
				isMatchingRelationContextNr( true, subsetRelationContextNr ) );
		}

	bool isRelatedSpecification( unsigned int generalizationContextNr, unsigned int specificationContextNr )
		{
		return ( isMatchingGeneralizationContextNr( true, generalizationContextNr ) &&
				isMatchingSpecificationContextNr( true, specificationContextNr ) );
		}

	bool isRelatedSpecification( bool isNegative, bool isPossessive, unsigned short generalizationWordTypeNr )
		{
		return ( isNegative_ == isNegative &&
				isPossessive_ == isPossessive &&
				generalizationWordTypeNr_ == generalizationWordTypeNr );
		}

	bool isRelatedSpecification( bool isExclusive, bool isNegative, bool isPossessive, WordItem *specificationWordItem )
		{
		return ( isExclusive_ == isExclusive &&
				isNegative_ == isNegative &&
				isPossessive_ == isPossessive &&
				relationContextNr_ > NO_CONTEXT_NR &&
				specificationWordItem != NULL &&
				specificationWordItem_ == specificationWordItem );
		}

	bool isRelatedSpecification( bool isNegative, bool isPossessive, unsigned int relationContextNr, WordItem *specificationWordItem )
		{
		return ( isNegative_ == isNegative &&
				isPossessive_ == isPossessive &&
				specificationWordItem != NULL &&
				specificationWordItem_ == specificationWordItem &&
				isMatchingRelationContextNr( true, relationContextNr ) );
		}

	bool isRelatedSpecification( bool isPossessive, bool _isSelfGenerated, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int compoundSpecificationCollectionNr, WordItem *specificationWordItem )
		{
		return ( isPossessive_ == isPossessive &&
				isSelfGenerated() == _isSelfGenerated &&
				generalizationCollectionNr_ == generalizationCollectionNr &&

				( specificationCollectionNr_ == specificationCollectionNr ||

				( compoundSpecificationCollectionNr > NO_COLLECTION_NR &&
				specificationCollectionNr_ == compoundSpecificationCollectionNr ) ) &&

				( hasSpecificationCollection() ||
				specificationWordItem_ == specificationWordItem ) );
		}

	bool isRelatedSpecification( bool checkRelationContext, bool ignoreExclusive, bool isExclusive, bool isPossessive, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr )
		{
		return ( ( ignoreExclusive ||
				isExclusive_ == isExclusive ) &&

				isPossessive_ == isPossessive &&
				specificationCollectionNr_ == specificationCollectionNr &&
				generalizationContextNr_ == generalizationContextNr &&		// Don't find a matching contexts when exclusive is tested
				specificationContextNr_ == specificationContextNr &&

				( !checkRelationContext ||
				relationContextNr_ == relationContextNr ) );
		}

	bool isRelatedSpecification( bool isNegative, bool isPossessive, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int relationContextNr )
		{
		return ( isNegative_ == isNegative &&
				isPossessive_ == isPossessive &&
				hasSpecificationCollection() &&
				generalizationCollectionNr_ == generalizationCollectionNr &&
				specificationCollectionNr_ == specificationCollectionNr &&
				isMatchingRelationContextNr( true, relationContextNr ) );
		}

	bool isRelatedSpecification( bool isExclusive, bool isPossessive, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr )
		{
		return ( isExclusive_ == isExclusive &&
				isPossessive_ == isPossessive &&
				hasSpecificationCollection() &&
				generalizationCollectionNr_ == generalizationCollectionNr &&
				specificationCollectionNr_ == specificationCollectionNr &&
				generalizationContextNr_ == generalizationContextNr &&		// Don't find a matching contexts when exclusive is tested
				specificationContextNr_ == specificationContextNr &&
				relationContextNr_ == relationContextNr );
		}

	bool isRelatedSpecification( bool isExclusive, bool isPossessive, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem )
		{
		return ( isExclusive_ == isExclusive &&
				isPossessive_ == isPossessive &&
				generalizationCollectionNr_ == generalizationCollectionNr &&
				specificationCollectionNr_ == specificationCollectionNr &&
				specificationWordItem != NULL &&
				specificationWordItem_ == specificationWordItem &&
				generalizationContextNr_ == generalizationContextNr &&		// Don't find a matching contexts when exclusive is tested
				specificationContextNr_ == specificationContextNr &&
				relationContextNr_ == relationContextNr );
		}

	bool hasFoundJustificationOfSameType( unsigned short justificationTypeNr, SpecificationItem *definitionSpecificationItem, SpecificationItem *specificSpecificationItem )
		{
		unsigned int definitionSpecificationCollectionNr = ( definitionSpecificationItem == NULL ? NO_COLLECTION_NR : definitionSpecificationItem->specificationCollectionNr() );
		unsigned int specificSpecificationCollectionNr = ( specificSpecificationItem == NULL ? NO_COLLECTION_NR : specificSpecificationItem->specificationCollectionNr() );
		JustificationItem *searchItem = specificationJustificationItem_;

		while( searchItem != NULL )
			{
			if( searchItem->justificationTypeNr() == justificationTypeNr &&

			( !searchItem->hasDefinitionSpecification() ||
			!searchItem->hasSpecificSpecification() ||

			( searchItem->definitionSpecificationItem()->specificationCollectionNr() == definitionSpecificationCollectionNr &&
			searchItem->specificSpecificationItem()->specificationCollectionNr() == specificSpecificationCollectionNr ) ) )
				return true;

			searchItem = searchItem->attachedJustificationItem();
			}

		return false;
		}

	unsigned short prepositionParameter()
		{
		return prepositionParameter_;
		}

	unsigned short generalizationWordTypeNr()
		{
		return generalizationWordTypeNr_;
		}

	unsigned short specificationWordTypeNr()
		{
		return specificationWordTypeNr_;
		}

	unsigned short relationWordTypeNr()
		{
		return myWord()->contextWordTypeNrInAllWords( relationContextNr_ );
		}

	unsigned short highestAttachedJustificationOrderNr( unsigned short justificationTypeNr )
		{
		unsigned short highestOrderNr = NO_ORDER_NR;
		JustificationItem *searchItem = specificationJustificationItem_;

		while( searchItem != NULL )
			{
			if( searchItem->orderNr > highestOrderNr &&
			searchItem->justificationTypeNr() == justificationTypeNr )
				highestOrderNr = searchItem->orderNr;

			searchItem = searchItem->attachedJustificationItem();
			}

		return highestOrderNr;
		}

	unsigned int generalizationCollectionNr()
		{
		return generalizationCollectionNr_;
		}

	unsigned int specificationCollectionNr()
		{
		return specificationCollectionNr_;
		}

	unsigned int relationCollectionNr()
		{
		return myWord()->collectionNrInAllWords( relationContextNr_ );
		}

	unsigned int generalizationContextNr()
		{
		return generalizationContextNr_;
		}

	unsigned int specificationContextNr()
		{
		return specificationContextNr_;
		}

	unsigned int relationContextNr()
		{
		return relationContextNr_;
		}

	unsigned int nContextRelations()
		{
		return nContextRelations_;
		}

	ResultType changeJustificationItem( JustificationItem *replacingJustificationItem )
		{
		JustificationItem *searchItem = specificationJustificationItem_;
		char functionNameString[FUNCTION_NAME_LENGTH] = "changeJustificationItem";

		if( replacingJustificationItem != NULL )
			{
			if( replacingJustificationItem->isActiveItem() )
				{
				if( hasCurrentCreationSentenceNr() )
					{
					while( searchItem != NULL )
						{
						if( searchItem == replacingJustificationItem )
							return startErrorInItem( functionNameString, NULL, NULL, "The given replacing justification item is already one of my attached justification items" );

						searchItem = searchItem->attachedJustificationItem();
						}

					specificationJustificationItem_ = replacingJustificationItem;
					}
				else
					return startErrorInItem( functionNameString, NULL, NULL, "It isn't allowed to change an older item afterwards" );
				}
			else
				return startErrorInItem( functionNameString, NULL, NULL, "The given replacing justification item isn't active" );
			}
		else
			return startErrorInItem( functionNameString, NULL, NULL, "The given replacing justification item is undefined" );

		return commonVariables()->result;
		}

	ResultType collectSpecificationItem( bool isCollectGeneralization, bool isCollectSpecification, bool isExclusiveGeneralization, unsigned int collectionNr )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "collectSpecificationItem";
		if( isCollectGeneralization ||
		isCollectSpecification )
			{
			if( collectionNr > NO_COLLECTION_NR )
				{
				if( hasCurrentCreationSentenceNr() )
					{
					if( isCollectGeneralization )
						{
						if( !hasGeneralizationCollection() )
							{
							if( isExclusiveGeneralization )
								isExclusive_ = true;

							generalizationCollectionNr_ = collectionNr;
							}
						else
							return startErrorInItem( functionNameString, NULL, NULL, "The generalization is already collected" );
						}

					if( isCollectSpecification )
						{
						if( !hasSpecificationCollection() )
							specificationCollectionNr_ = collectionNr;
						else
							return startErrorInItem( functionNameString, NULL, NULL, "The specification is already collected" );
						}
					}
				else
					return startErrorInItem( functionNameString, NULL, NULL, "It isn't allowed to change an older item afterwards" );
				}
			else
				return startErrorInItem( functionNameString, NULL, NULL, "The given collection number is undefined" );
			}
		else
			return startErrorInItem( functionNameString, NULL, NULL, "Nothing to do. All given collection indicators are undefined" );

		return commonVariables()->result;
		}

	ResultType markSpecificationStringAsWritten()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "markSpecificationStringAsWritten";
		if( commonVariables()->currentWriteLevel < MAX_LEVEL )
			{
			if( specificationStringWriteLevel_ == NO_WRITE_LEVEL )
				specificationStringWriteLevel_ = ++commonVariables()->currentWriteLevel;
			else
				return startErrorInItem( functionNameString, NULL, itemString(), "My write level is already assigned" );
			}
		else
			return startSystemErrorInItem( functionNameString, NULL, itemString(), "Current write word level overflow" );

		return commonVariables()->result;
		}

	SpecificationResultType checkArticleForNextUnwrittenSpecificationNounWord( bool isDefiniteArticle, unsigned short definiteArticleParameter )
		{
		SpecificationResultType specificationResult;
		WordResultType wordResult;
		bool isIncludingAnsweredQuestions = isAnsweredQuestion();
		SpecificationItem *currentSpecificationItem;
		WordItem *currentSpecificationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkArticleForNextUnwrittenSpecificationNounWord";

		if( isSpecificationNoun() )
			{
			if( ( currentSpecificationItem = myWord()->firstSelectedSpecification( isIncludingAnsweredQuestions, isAssignment(), isDeactiveAssignment(), isArchivedAssignment(), questionParameter_ ) ) != NULL )
				{
				do	{
					if( currentSpecificationItem->isRelatedSpecification( isExclusive_, isPossessive_, generalizationCollectionNr_, specificationCollectionNr_, generalizationContextNr_, specificationContextNr_, relationContextNr_ ) &&
					( currentSpecificationWordItem = currentSpecificationItem->specificationWordItem() ) != NULL )
						{
						if( ( wordResult = currentSpecificationWordItem->checkWordTypeForBeenWritten( specificationWordTypeNr_ ) ).result == RESULT_OK )
							{
							if( !wordResult.isWordAlreadyWritten )
								wordResult.foundWordItem = currentSpecificationWordItem;
							}
						else
							addErrorInItem( functionNameString, NULL, NULL, "I failed to check a specification word for being written" );
						}
					else	// No more specifications
						wordResult.foundWordItem = specificationWordItem_;
					}
				while( commonVariables()->result == RESULT_OK &&
				wordResult.foundWordItem == NULL &&
				( currentSpecificationItem = currentSpecificationItem->nextSpecificationItemWithSameQuestionParameter( isIncludingAnsweredQuestions ) ) != NULL );
				}

			specificationResult.isCorrectArticle = ( wordResult.foundWordItem == NULL ? true : ( isDefiniteArticle ? wordResult.foundWordItem->isCorrectDefiniteArticle( definiteArticleParameter, specificationWordTypeNr_ ) : wordResult.foundWordItem->isCorrectIndefiniteArticle( definiteArticleParameter, specificationWordTypeNr_ ) ) );
			}

		specificationResult.result = commonVariables_->result;
		return specificationResult;
		}

	SpecificationResultType checkArticleForNextUnwrittenRelationPropernamePrecededByDefiniteArticle( unsigned short definiteArticleParameter )
		{
		SpecificationResultType specificationResult;
		WordResultType wordResult;
		WordItem *currentRelationWordItem = NULL;		// Start to search first word in function contextWordInAllWords
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkArticleForNextUnwrittenRelationPropernamePrecededByDefiniteArticle";

		if( isRelationPropername() )
			{
			do	{
				if( ( currentRelationWordItem = relationWordItem( currentRelationWordItem ) ) != NULL )
					{
					if( ( wordResult = currentRelationWordItem->checkWordTypeForBeenWritten( WORD_TYPE_PROPER_NAME ) ).result == RESULT_OK )
						{
						if( !wordResult.isWordAlreadyWritten )
							wordResult.foundWordItem = currentRelationWordItem;
						}
					else
						addErrorInItem( functionNameString, NULL, NULL, "I failed to check a relation propername word for being written" );
					}
				}
			while( commonVariables()->result == RESULT_OK &&
			wordResult.foundWordItem == NULL &&
			currentRelationWordItem != NULL );

			specificationResult.isCorrectArticle = ( currentRelationWordItem != NULL &&
													currentRelationWordItem->isPropernamePrecededByDefiniteArticle( definiteArticleParameter ) );
			}

		specificationResult.result = commonVariables_->result;
		return specificationResult;
		}

	SpecificationResultType getAssumptionLevel()
		{
		return calculateAssumptionLevel( false );
		}

	SpecificationResultType recalculateAssumptionLevel()
		{
		nAssignmentLevelRecalculations_ = 0;
		return calculateAssumptionLevel( true );
		}

	JustificationItem *specificationJustificationItem()
		{
		return specificationJustificationItem_;
		}

	JustificationItem *foundDefinitionSpecificationJustificationItem( SpecificationItem *definitionSpecificationItem )
		{
		JustificationItem *searchItem = specificationJustificationItem_;

		if( definitionSpecificationItem != NULL )
			{
			while( searchItem != NULL )
				{
				if( searchItem->definitionSpecificationItem() == definitionSpecificationItem )
					return searchItem;

				searchItem = searchItem->attachedJustificationItem();
				}
			}

		return NULL;
		}

	JustificationItem *foundSpecificSpecificationJustificationItem( WordItem *generalizationWordItem )
		{
		SpecificationItem *specificSpecificationItem;
		JustificationItem *searchItem = specificationJustificationItem_;

		if( generalizationWordItem != NULL &&
		specificationCollectionNr_ > NO_COLLECTION_NR )
			{
			while( searchItem != NULL )
				{
				if( searchItem->isOppositePossessiveConditionalSpecificationAssumption() &&
				( specificSpecificationItem = searchItem->specificSpecificationItem() ) != NULL )
					{
					if( specificSpecificationItem->isPossessive() == isPossessive_ &&
					specificSpecificationItem->specificationCollectionNr() == specificationCollectionNr_ &&
					specificSpecificationItem->specificationWordItem() != specificationWordItem_ &&
					specificSpecificationItem->generalizationWordItem() == generalizationWordItem )
						return searchItem;
					}

				searchItem = searchItem->attachedJustificationItem();
				}
			}

		return NULL;
		}

	SpecificationItem *nextSpecificationItem()
		{
		return (SpecificationItem *)nextItem ;
		}

	SpecificationItem *nextAssignmentOrSpecificationItem()
		{
		return ( isAssignment() ? nextAssignmentItemWithCurrentLevel() : nextSpecificationItem() );
		}

	SpecificationItem *updatedSpecificationItem()
		{
		SpecificationItem *updatedSpecificationItem;
		SpecificationItem *searchItem = this;

		while( ( updatedSpecificationItem = searchItem->replacingSpecificationItem ) != NULL )
			searchItem = updatedSpecificationItem;

		return searchItem;
		}

	SpecificationItem *getSpecificationItem( bool isIncludingAnsweredQuestions, bool includeThisItem, bool isQuestion )
		{
		SpecificationItem *searchItem = ( includeThisItem ? this : nextSpecificationItem() );

		while( searchItem != NULL )
			{
			// Skip replaced specifications
			if( ( searchItem->replacingSpecificationItem == NULL ||
			// Skip replaced specifications that are undone
			searchItem->replacingSpecificationItem->creationSentenceNr() > commonVariables_->currentSentenceNr ) &&

			// Skip answered questions
			( isIncludingAnsweredQuestions ||
			!searchItem->isAnsweredQuestion() ) &&

			searchItem->isQuestion() == isQuestion )
				return searchItem;

			searchItem = searchItem->nextSpecificationItem();
			}

		return NULL;
		}

	SpecificationItem *getSpecificationItem( bool isIncludingAnsweredQuestions, bool includeThisItem, unsigned short questionParameter )
		{
		SpecificationItem *searchItem = ( includeThisItem ? this : nextSpecificationItem() );

		while( searchItem != NULL )
			{
			// Skip replaced specifications
			if( ( searchItem->replacingSpecificationItem == NULL ||
			// Skip replaced specifications that are undone
			searchItem->replacingSpecificationItem->creationSentenceNr() > commonVariables_->currentSentenceNr ) &&

			// Skip answered questions
			( isIncludingAnsweredQuestions ||
			!searchItem->isAnsweredQuestion() ) &&

			searchItem->questionParameter() == questionParameter )
				return searchItem;

			searchItem = searchItem->nextSpecificationItem();
			}

		return NULL;
		}

	SpecificationItem *nextSelectedSpecificationItem( bool isIncludingAnsweredQuestions )
		{
		return ( isAssignment() ? getAssignmentItem( isIncludingAnsweredQuestions, false, isQuestion() ) : getSpecificationItem( isIncludingAnsweredQuestions, false, isQuestion() ) );
		}

	SpecificationItem *nextSpecificationItemButNotAQuestion()
		{
		return ( isAssignment() ? getAssignmentItem( false, false, false ) : getSpecificationItem( false, false, false ) );
		}

	SpecificationItem *nextSpecificationItemWithSameQuestionParameter( bool isIncludingAnsweredQuestions )
		{
		return ( isAssignment() ? getAssignmentItem( isIncludingAnsweredQuestions, false, questionParameter_ ) : getSpecificationItem( isIncludingAnsweredQuestions, false, questionParameter_ ) );
		}

	WordItem *generalizationWordItem()
		{
		return myWord();
		}

	WordItem *specificationWordItem()
		{
		return specificationWordItem_;
		}

	WordItem *relationWordItem()
		{
		return relationWordItem( NULL );
		}

	WordItem *relationWordItem( WordItem *previousWordItem )
		{
		return myWord()->contextWordInAllWords( isPossessive_, relationContextNr_, specificationWordItem_, previousWordItem );
		}

	char *specificationString()
		{
		return specificationString_;
		}

	char *activeGeneralizationWordTypeString()
		{
		return myWord()->activeWordTypeString( generalizationWordTypeNr_ );
		}
	};
#endif

/*************************************************************************
 *
 *	"All he does is just and good,
 *	and all his commandments are trustworthy." (Psalm 111:7)
 *
 *************************************************************************/
