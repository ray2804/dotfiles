/*
 *	Class:			AdminJustification
 *	Supports class:	AdminItem
 *	Purpose:		To write justification reports for the
 *					self-generated knowledge
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "Presentation.cpp"
#include "SpecificationItem.cpp"

class AdminJustification
	{
	// Private constructible variables

	WordItem *previousSpecificGeneralizationWordItem_;

	CommonVariables *commonVariables_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	ResultType writeJustificationSpecification( bool showDefinitionSpecification, bool showSpecificSpecification, JustificationItem *specificationJustificationItem )
		{
		SpecificationItem *definitionSpecificationItem;
		SpecificationItem *anotherDefinitionSpecificationItem;
		SpecificationItem *specificSpecificationItem;
		WordItem *generalizationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeJustificationSpecification";

		if( specificationJustificationItem != NULL )
			{
			if( showDefinitionSpecification &&
			( definitionSpecificationItem = specificationJustificationItem->definitionSpecificationItem() ) != NULL )
				{
				if( ( generalizationWordItem = definitionSpecificationItem->generalizationWordItem() ) != NULL )
					{
					if( generalizationWordItem->writeJustificationSpecification( definitionSpecificationItem ) != RESULT_OK )
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write a definition justification specification" );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The definition specification item of the given specification justification item has no generalization word" );
				}

			if( ( anotherDefinitionSpecificationItem = specificationJustificationItem->anotherDefinitionSpecificationItem() ) != NULL )
				{
				if( ( generalizationWordItem = anotherDefinitionSpecificationItem->generalizationWordItem() ) != NULL )
					{
					if( generalizationWordItem->writeJustificationSpecification( anotherDefinitionSpecificationItem ) != RESULT_OK )
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write another definition justification specification" );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The another definition specification item of the given specification justification item has no generalization word" );
				}

			if( ( specificSpecificationItem = specificationJustificationItem->specificSpecificationItem() ) != NULL )
				{
				if( showDefinitionSpecification ||
				showSpecificSpecification )
					{
					if( ( generalizationWordItem = specificSpecificationItem->generalizationWordItem() ) != NULL )
						{
						if( generalizationWordItem->writeJustificationSpecification( specificSpecificationItem ) != RESULT_OK )
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write a specific justification specification" );
						}
					else
						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The specific specification item of the given specification justification item has no generalization word" );
					}
				}
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification justification item is undefined" );

		return commonVariables_->result;
		}

	ResultType writeJustificationSpecifications( bool showDefinitionSpecification, JustificationItem *firstJustificationItem )
		{
		JustificationItem *currentJustificationItem;
		SpecificationItem *specificSpecificationItem;
		WordItem *specificGeneralizationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeJustificationSpecifications";

		if( firstJustificationItem != NULL )
			{
			currentJustificationItem = firstJustificationItem;

			do	{
				specificSpecificationItem = currentJustificationItem->specificSpecificationItem();
				specificGeneralizationWordItem = ( specificSpecificationItem == NULL ? NULL : specificSpecificationItem->generalizationWordItem() );

				if( writeJustificationSpecification( showDefinitionSpecification, ( specificSpecificationItem->hasRelationContext() || specificGeneralizationWordItem != previousSpecificGeneralizationWordItem_ ), currentJustificationItem ) == RESULT_OK )
					{
					if( specificSpecificationItem != NULL )
						{
						showDefinitionSpecification = false;
						previousSpecificGeneralizationWordItem_ = specificGeneralizationWordItem;
						}
					}
				else
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write the current justification specification" );
				}
			while( ( currentJustificationItem = currentJustificationItem->nextJustificationItemWithSameTypeAndOrderNr() ) != NULL );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given first justification item is undefined" );

		return commonVariables_->result;
		}

	ResultType writeJustificationType( bool isFirstJustificationType, char *justificationSentenceString, JustificationItem *specificationJustificationItem, SpecificationItem *selfGeneratedSpecificationItem )
		{
		bool isAnsweredQuestion;
		bool isExclusive;
		bool isPossessive;
		unsigned int generalizationCollectionNr;
		unsigned int specificationCollectionNr;
		unsigned int generalizationContextNr;
		unsigned int specificationContextNr;
		unsigned int relationContextNr;
		SpecificationItem *currentSpecificationItem;
		WordItem *generalizationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeJustificationType";

		previousSpecificGeneralizationWordItem_ = NULL;

		if( justificationSentenceString != NULL )
			{
			if( specificationJustificationItem != NULL )
				{
				if( selfGeneratedSpecificationItem != NULL )
					{
					if( ( generalizationWordItem = selfGeneratedSpecificationItem->generalizationWordItem() ) != NULL )
						{
						if( isFirstJustificationType )
							{
							if( commonVariables_->presentation->writeDiacriticalText( PRESENTATION_PROMPT_WRITE, justificationSentenceString ) != RESULT_OK )
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write the justification sentence" );
							}

						if( commonVariables_->presentation->writeInterfaceText( false, !isFirstJustificationType, PRESENTATION_PROMPT_NOTIFICATION, ( isFirstJustificationType ? INTERFACE_LISTING_JUSTIFICATION_BECAUSE : INTERFACE_LISTING_JUSTIFICATION_AND ) ) == RESULT_OK )
							{
							if( writeJustificationSpecifications( true, specificationJustificationItem ) == RESULT_OK )
								{
								isAnsweredQuestion = selfGeneratedSpecificationItem->isAnsweredQuestion();

								if( ( currentSpecificationItem = generalizationWordItem->firstSelectedSpecification( isAnsweredQuestion, selfGeneratedSpecificationItem->isAssignment(), selfGeneratedSpecificationItem->isDeactiveAssignment(), selfGeneratedSpecificationItem->isArchivedAssignment(), selfGeneratedSpecificationItem->questionParameter() ) ) != NULL )
									{
									isExclusive = selfGeneratedSpecificationItem->isExclusive();
									isPossessive = selfGeneratedSpecificationItem->isPossessive();
									generalizationCollectionNr = selfGeneratedSpecificationItem->generalizationCollectionNr();
									specificationCollectionNr = selfGeneratedSpecificationItem->specificationCollectionNr();
									generalizationContextNr = selfGeneratedSpecificationItem->generalizationContextNr();
									specificationContextNr = selfGeneratedSpecificationItem->specificationContextNr();
									relationContextNr = selfGeneratedSpecificationItem->relationContextNr();

									do	{
										if( currentSpecificationItem->isSelfGenerated() &&
										currentSpecificationItem != selfGeneratedSpecificationItem &&
										currentSpecificationItem->isRelatedSpecification( isExclusive, isPossessive, generalizationCollectionNr, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr ) )
											{
											if( writeJustificationSpecifications( false, currentSpecificationItem->specificationJustificationItem() ) != RESULT_OK )
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write the current justification specifications" );
											}
										}
									while( ( currentSpecificationItem = currentSpecificationItem->nextSpecificationItemWithSameQuestionParameter( isAnsweredQuestion ) ) != NULL );
									}
								}
							else
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write the justification specifications" );
							}
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write the justification start string" );
						}
					else
						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word of the self-generated specification item is undefined" );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given self-generated specification item is undefined" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification justification is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given justification sentence string is undefined" );

		return commonVariables_->result;
		}


	public:
	// Constructor

	AdminJustification( WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		previousSpecificGeneralizationWordItem_ = NULL;

		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "AdminJustification" );

		if( commonVariables_ != NULL )
			{
		if( myWord_ == NULL )
			strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	ResultType writeJustificationSpecification( char *justificationSentenceString, SpecificationItem *selfGeneratedSpecificationItem )
		{
		bool isFirstJustificationType = true;
		JustificationItem *firstJustificationItem;
		JustificationItem *currentJustificationItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeJustificationSpecification";

		if( selfGeneratedSpecificationItem != NULL )
			{
			if( ( firstJustificationItem = selfGeneratedSpecificationItem->specificationJustificationItem() ) != NULL )
				{
				currentJustificationItem = firstJustificationItem;

				do	{
					if( writeJustificationType( isFirstJustificationType, justificationSentenceString, currentJustificationItem, selfGeneratedSpecificationItem ) == RESULT_OK )
						isFirstJustificationType = false;
					else
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write a justification type of a specification" );
					}
				while( ( currentJustificationItem = currentJustificationItem->nextJustificationItemWithDifferentTypeOrOrderNr( firstJustificationItem ) ) != NULL );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The specification justification of the given self-generated specification item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given self-generated specification item is undefined" );

		return commonVariables_->result;
		}
	};

/*************************************************************************
 *
 *	"Oh, the joys of those who trust the Lord,
 *	who have no confidence of the proud
 *	or in those who worship idols." (Psalm 40:4)
 *
 *************************************************************************/
