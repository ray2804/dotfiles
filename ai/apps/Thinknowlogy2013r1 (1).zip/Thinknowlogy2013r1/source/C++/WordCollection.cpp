/*
 *	Class:			WordCollection
 *	Supports class:	WordItem
 *	Purpose:		To create collection structures
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "CollectionList.cpp"
#include "GeneralizationItem.cpp"
#include "Presentation.cpp"
#include "SpecificationItem.cpp"

class WordCollection
	{
	// Private constructible variables

	bool hasCreatedCollection_;

	WordItem *foundCollectionWordItem_;
	WordItem *foundGeneralizationWordItem_;

	CommonVariables *commonVariables_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	ResultType addCollectionByExclusiveSpecification( bool isExclusive, unsigned short collectionWordTypeNr, WordItem *generalizationWordItem, WordItem *collectionWordItem )
		{
		CollectionResultType collectionResult;
		unsigned int collectionNr;
		SpecificationItem *currentSpecificationItem;
		WordItem *currentSpecificationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addCollectionByExclusiveSpecification";

		hasCreatedCollection_ = false;

		if( generalizationWordItem != NULL )
			{
			if( collectionWordItem != NULL )
				{
				if( myWord_->isNoun() )
					{
					if( collectionWordItem->isNoun() )
						{
						if( ( currentSpecificationItem = myWord_->firstSpecificationButNotAQuestion() ) != NULL )
							{
							do	{
								if( currentSpecificationItem->isExclusive() &&
								( currentSpecificationWordItem = currentSpecificationItem->specificationWordItem() ) == generalizationWordItem )
									{
									if( foundCollectionWordItem_ == NULL )
										{
										foundCollectionWordItem_ = collectionWordItem;
										foundGeneralizationWordItem_ = currentSpecificationWordItem;
										}
									else
										{
										if( ( collectionResult = foundCollectionWordItem_->findCollection( false, collectionWordItem, myWord_ ) ).result == RESULT_OK )
											{
											if( !collectionResult.isCollected )
												{
												if( ( collectionNr = myWord_->highestCollectionNrInAllWords() ) < MAX_COLLECTION_NR )
													{
													if( foundCollectionWordItem_->addCollection( isExclusive, false, collectionWordTypeNr, WORD_TYPE_UNDEFINED, ++collectionNr, collectionWordItem, myWord_, NULL, NULL ) == RESULT_OK )
														{
														if( collectionWordItem->addCollection( isExclusive, false, collectionWordTypeNr, WORD_TYPE_UNDEFINED, collectionNr, foundCollectionWordItem_, myWord_, NULL, NULL ) == RESULT_OK )
															{
															hasCreatedCollection_ = true;
															foundCollectionWordItem_ = NULL;
															}
														else
															return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to collect word \"", currentSpecificationWordItem->anyWordTypeString(), "\" with word \"", collectionWordItem->anyWordTypeString(), "\"" );
														}
													else
														return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to collect word \"", currentSpecificationWordItem->anyWordTypeString(), "\" with word \"", collectionWordItem->anyWordTypeString(), "\"" );
													}
												else
													return myWord_->startSystemErrorInWord( functionNameString, moduleNameString_, "Collection number overflow" );
												}

											}
										else
											return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find out if word \"", collectionWordItem->anyWordTypeString(), "\" is collected with word \"", foundCollectionWordItem_->anyWordTypeString(), "\"" );
										}
									}
								}
							while( !hasCreatedCollection_ &&
							( currentSpecificationItem = currentSpecificationItem->nextSpecificationItemButNotAQuestion() ) != NULL );
							}
						}
					else
						return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given collected word isn't a noun" );
					}
				else
					return myWord_->startErrorInWord( functionNameString, moduleNameString_, "I am not a noun" );
				}
			else
				return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given collected word item is undefined" );
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		return commonVariables_->result;
		}


	public:
	// Constructor

	WordCollection( WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		hasCreatedCollection_ = false;

		foundCollectionWordItem_ = NULL;
		foundGeneralizationWordItem_ = NULL;

		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "WordCollection" );

		if( commonVariables_ != NULL )
			{
		if( myWord_ == NULL )
			strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInWord( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	CollectionResultType addCollectionByGeneralization( bool isExclusive, bool isExclusiveGeneralization, bool isQuestion, bool tryGeneralizations, unsigned short collectionWordTypeNr, WordItem *generalizationWordItem, WordItem *collectionWordItem )
		{
		CollectionResultType collectionResult;
		GeneralizationItem *currentGeneralizationItem;
		WordItem *currentGeneralizationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addCollectionByGeneralization";

		if( collectionWordItem != NULL )
			{
			if( addCollectionByExclusiveSpecification( isExclusive, collectionWordTypeNr, generalizationWordItem, collectionWordItem ) == RESULT_OK )
				{
				if( tryGeneralizations &&
				!hasCreatedCollection_ &&
				foundGeneralizationWordItem_ == NULL &&
				( currentGeneralizationItem = myWord_->firstActiveGeneralizationItem() ) != NULL )
					{
					do	{
						if( ( currentGeneralizationWordItem = currentGeneralizationItem->generalizationWordItem() ) != NULL )
							{
							if( currentGeneralizationWordItem->isNoun() &&
							currentGeneralizationWordItem != collectionWordItem )
								{
								if( ( collectionResult = currentGeneralizationWordItem->addCollectionByGeneralization( isExclusive, isExclusiveGeneralization, isQuestion, false, collectionWordTypeNr, generalizationWordItem, collectionWordItem ) ).result == RESULT_OK )
									{
									if( collectionResult.foundGeneralizationWordItem != NULL )
										{
										// Collect by generalization
										if( collectionResult.foundGeneralizationWordItem->collectGeneralizationAndSpecifications( isExclusiveGeneralization, false, isQuestion, collectionWordItem->collectionNr( collectionWordTypeNr, currentGeneralizationWordItem ) ) != RESULT_OK )
											myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to collect specifications in word \"", collectionResult.foundGeneralizationWordItem->anyWordTypeString(), "\"" );
										}
									}
								else
									myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to add a collection by generalization in word \"", currentGeneralizationWordItem->anyWordTypeString(), "\"" );
								}
							}
						else
							myWord_->startErrorInWord( functionNameString, moduleNameString_, "I found an undefined generalization word" );
						}
					while( commonVariables_->result == RESULT_OK &&
					collectionResult.foundGeneralizationWordItem == NULL &&
					( currentGeneralizationItem = currentGeneralizationItem->nextGeneralizationItem() ) != NULL );
					}
				}
			else
				myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to add a specification collection by exclusive specification" );
			}
		else
			myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given collection word item is undefined" );

		collectionResult.foundGeneralizationWordItem = foundGeneralizationWordItem_;
		collectionResult.result = commonVariables_->result;
		return collectionResult;
		}

	ResultType addCollection( bool isExclusive, bool isSpecificationGeneralization, unsigned short collectionWordTypeNr, unsigned short commonWordTypeNr, unsigned int collectionNr, WordItem *collectionWordItem, WordItem *commonWordItem, WordItem *compoundGeneralizationWordItem, char *collectionString )
		{
		bool isDuplicateCollection = false;
		unsigned short collectionOrderNr;
		unsigned int foundCollectionNr = NO_COLLECTION_NR;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addCollection";

		foundCollectionWordItem_ = NULL;

		if( !myWord_->iAmAdmin() )
			{
			if( collectionNr > NO_COLLECTION_NR )
				{
				if( collectionString == NULL )
					{
					if( collectionWordItem != NULL )
						{
						if( commonWordItem != NULL )
							{
							if( collectionWordItem != myWord_ )
								{
								if( commonWordItem != myWord_ )
									{
									if( myWord_->activeWordTypeItem( true, collectionWordTypeNr ) != NULL )
										{
										if( ( foundCollectionNr = myWord_->collectionNr( collectionWordTypeNr, commonWordItem, compoundGeneralizationWordItem ) ) > NO_COLLECTION_NR )
											{
											if( foundCollectionNr != collectionNr )
												{
												if( isSpecificationGeneralization )
													isDuplicateCollection = true;
												else
													{
													// Detected semantic ambiguity of the specification word
													if( commonVariables_->presentation->writeInterfaceText( PRESENTATION_PROMPT_NOTIFICATION, INTERFACE_SENTENCE_NOTIFICATION_AMBIGUOUS_DUE_TO_SPECIFICATION_START, commonWordItem->wordTypeString( true, NO_ORDER_NR, commonWordTypeNr ), INTERFACE_SENTENCE_NOTIFICATION_AMBIGUOUS_DUE_TO_SPECIFICATION_WORD, myWord_->wordTypeString( true, NO_ORDER_NR, collectionWordTypeNr ), INTERFACE_SENTENCE_NOTIFICATION_AMBIGUOUS_DUE_TO_SPECIFICATION_END ) != RESULT_OK )
														return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write an interface notification about ambiguity" );
													}
												}
											}
										}
									else
										return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The requested word type with number doesn't exist: ", collectionWordTypeNr );
									}
								else
									return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given common word is the same as me" );
								}
							else
								return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given collected word is the same as me" );
							}
						else
							return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given common word is undefined" );
						}
					else
						return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given collected word is undefined" );
					}

				if( !isDuplicateCollection )
					{
					if( !myWord_->hasFoundCollection( collectionNr, collectionWordItem, commonWordItem, compoundGeneralizationWordItem ) )
						{
						if( ( collectionOrderNr = myWord_->highestCollectionOrderNrInAllWords( collectionNr ) ) < MAX_ORDER_NR - 1 )
							{
							if( myWord_->collectionList == NULL )
								{
								// Create list
								if( ( myWord_->collectionList = new CollectionList( myWord_, commonVariables_ ) ) != NULL )
									myWord_->wordList[WORD_COLLECTION_LIST] = myWord_->collectionList;
								else
									return myWord_->startErrorInWord( functionNameString, moduleNameString_, "I failed to create a collection list" );
								}

							return myWord_->collectionList->createCollectionItem( isExclusive, ++collectionOrderNr, collectionWordTypeNr, commonWordTypeNr, collectionNr, collectionWordItem, commonWordItem, compoundGeneralizationWordItem, collectionString );
							}
						else
							return myWord_->startSystemErrorInWord( functionNameString, moduleNameString_, "Collection order number overflow" );
						}
					else
						return myWord_->startErrorInWord( functionNameString, moduleNameString_, "This collection already exists" );
					}
				}
			else
				return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given collection number is undefined" );
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The admin does not have collections" );

		return commonVariables_->result;
		}
	};

/*************************************************************************
 *
 *	"They do not fear bad news;
 *	they confidently trust the Lord to take care of them.
 *	They are confident and fearless
 *	and can face their foes triumphantly." (Psalm 112:7-8)
 *
 *************************************************************************/
