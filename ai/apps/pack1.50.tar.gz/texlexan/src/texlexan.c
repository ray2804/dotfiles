/* 
  License/copyright: At the end of this file 
  or read copyright.txt included in the package
*/

/* 
  This is the main function, it does:

- External variables are defined here
- Read cmde line arguments
- Allocate mem for text,onlyonceword,longline,excludedword,
    result,best_result and pos_sentence
- filter chars and words of the text file
- Compute readeability
- Compute words repetition
- Search for sentiments
- Search for plagiarism
- Search for group of keywords
- Search for single keywords
- Decide of the abstract mode to do
- Desallocate mem of text,onlyonceword,result,longline
    excludedword,best_result and pos_sentence
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>
#include <unistd.h>
#include <time.h>

#include "utils.h"
#include "help.h"
#include "definitions.h"
#include "languages.h"
#include "analyses.h"
#include "abstracts.h"
#include "keywords.h"
#include "printing.h"
#include "smartdecision.h"
#include "sentiment.h"
#include "summarieslist.h"

/*---------- Global variables --------*/
int debug=0; //no debug default mode
int verbose=0; //verbose minimal
char lang[TINY_STR]="auto"; //abreviated
char en_negation_verbs[]="\nhasn\nhaven\nhad\nisn\naren\ndon\ndoesn\ndidn\nwasn\nweren\ncouldn\nshouldn\nwouldn\n"; //can't is exclude because wedon't drop n'
char namecity[]="/las/vegas/los/angeles/damas/paris/bahamas/hamas/tunis/"; //keep 's' at the end
char invariable[2][1000]={"/yes/was/has/his/gas/thus/this/is/us/bus/tennis/",
                    "/eux/cieux/mieux/vieux/hiboux/choux/houx/cariboux/sioux/os/dos/temps/corps/"}; //keep s
char alphabet[]="abcdefghijklmnopqrstuvwxyz";
char numeral[]="0123456789";
char separator[]="/-+*<>=(){}[]\t\r\n";
char coma=',';
char eos[]=":?!;";
char special[]="@'";
char file_input[SIZE_WORD]="";
char file_output[SIZE_WORD]="";
char file_abstract1[SIZE_WORD]="";
char file_abstract2[SIZE_WORD]="";
char file_abstract3[SIZE_WORD]="";
char file_abstract4[SIZE_WORD]="";
char file_abstract5[SIZE_WORD]="";
char file_abstract6[SIZE_WORD]="";
char file_bilan_abstr[SIZE_WORD]="";
char path_dictionary[SIZE_WORD]="";
char path_output_files[SIZE_WORD]="";
char file_dictionary[SIZE_WORD]="keyworder";
char file_builddico[SIZE_WORD]="";
char file_keyw[SIZE_WORD]="";
/*Default size of variables*/
long int size_best_result=SIZE_WORD*100; //!!!limitation 100 lines to stores
long int size_text=400000; //~40000 words !!!limitation
long int size_onlyonceword=200000; //~20000 words !!!limitation

long int size_line=SIZE_LINE; //size of each line read in dico !!!limitation
int size_class_name=SIZE_WORD; //size of each class_name
int size_nb_class=500; //number of class !!!limitation

int size_excludedword=100000; //size of word list excluded/basic !!!limitation
long int size_trash=1000000; //used after realloc
int linewidth=0; //line lenght, default no limit (set \n to splite line printed)

int abstract_utf8=0;

int count_silent_bug=0; //somme bugs are hidden but may false the results
/*-------------- Main start here -------------*/
int main(int argc, char **argv)
{
  /*Local variables of main*/
  time_t now,now_again;
  struct tm *tm;
  double duration_job;
  char date[100];
  char filename[SIZE_WORD]; //text to analyze
  char file_original[SIZE_WORD]; //text initial to analyze
  char file_temporary_input[SIZE_WORD]; //text to analyze after conversion to ansi 7bits
  char file_iso[SIZE_WORD]; //text after conversion iso8859
  char ch,previous_ch; //text is read char / char
  int prevch_upper=0; //flag 1 if previous char is uppercase, for abreviations M. U.S.A.
  FILE *fp,*fp1;
  char *str_ptr,*str_ptr_next,*str_ptr1,*str_ptr2; //chain pointers
  char *wtarget;
  char *text; //dynamic allocated buffer stores the simplified text
  char *onlyonceword; //dynamic allocated words list
  char *result; //dynamic allocated results list
  char *best_result; //dynamic allocated best results, a cumul of classification results
  char *longline; //dynamic alloc line to print
  char *trash; //used to be sure there is still some memory
  unsigned long long hash1_val=0; //signature of the text 64bits
  unsigned long long hash2_val=0; //signature of the text 64bits
  char hash_str[256]; //store the text signature large enough
  long int *pos_sentence; //store the pos of each sentences in the ansi7b converted text file
  char word[SIZE_WORD],wordchk[SIZE_WORD+2]; //store single word and grp of words
  char validchar[255]; //table of valid chars
  char *excludedword; //first list of excluded words - next list common words
  int  result_overflow; //cnt overflow in result
  int singlekeywords_found=0; //flag set=1 when keyterm of 1 word are found
  char text_title[SIZE_WORD]=""; //title found in html text

  long int size_result; //calculated, SIZE_WORD*nboow (nb of only once words)
  int en_negation_flag=0; //english negation n't to convert
  /*nbw w except excluded, nbtw w except without woyel, nboow words differents
  nbl nb lines, nbts sum sylab */
  long int nbnewline; //cnt newline, used to evaluate the spacing
  long int  nbw,nbtw; //cnt of words, total of words
  long int nboow; //nb of different words
  long int nbl; //nb of lines
  long int pos_char; //pos char in the raw text (temp file)
  long int nbeos; //count nb of eos added to 'text'
  long int nbs,nbts,nbtc; //cnt syllables, total of syllables,total comas
  long int basicword; //nb of basic words
  long int nbkw,setnbkw; //cnt & pt a word in text , cnt nb of words to group
  long int nbkey; //cnt nb subresult added to result = nb of repetition or keygrp or keyword
  long int nb_best_result=0; //cnt nb best_result added to best_result
  long int set_nb_best_result=10; //nb of best_result to keep for each grp of n-grams
  long int nbw_abstract; //nb words in the abstract
  long int i,j,jprev,k; //cnt used in loops (k cnts nb of occurence)
  long int length; //lg of onlyonce or text used in loops
  long int lgtext; //cnt size (nb of chars) of text (prevent overflow)
  long int lgonlyonceword; //cnt size (nb of chars) of onlyonceword (prevent overflow)
  int lg; //word length
  int  nlang=0; //language code
  int isofile=0; //flag=1 if text iso8859 is available*
  int nb_summaries_extracted=0; //when classification.lst is analyzed only
  
  /*defaults arg*/
  int lgmin=1; //word length, accept 1 char...SIZE_WORD chars
  int builddico=0,wait_key=0; //flag 0/1
  int dosinglekeyword=1; //do keyterms of single word
  int showkeywords=0; //do not print all the keyterms list
  int showfilteredkeywords=0; //do not print the filtered keyterms list
  int doplagia=1; //check plagia
  int strict_plagia=1,checkrepeating=1,showwordrepeated=0; //flag 0/1
  int doemotion=1; //do emotion
  int rec=1; //display result but do not record
  int threshold_plagia=1;
  int repeatdistance=5; //5 words
  int histogram=0; //no histogram
  int abstract_mode=-1; //abstract, mode auto
  int abstract_rate=10; //10% of the text
  int brief_class=1; //do not detail classes found for each N-grams
  int min=1;        //freq mini
  int levenstein=0; //no levenstein
  int maxsetnbkw=3; //nb words in group (start from N+1)
  float taux=0.1; //cutoff keep result highest*taux
  int memoryalloc=1; //default memory size
  char format[TINY_STR]="text"; //check text format:html,xml...
  char convert[TINY_STR]="auto"; //check text char (utf8 or ansi)
  char text_class_added[SIZE_WORD]=""; //class name when builddic
  int batch_mode=0;
  int k_cst=1; //coef applied to the constants of keyworder.lan.dicN
  /* vars for the list of summaries analyze*/
  int listofsummaries=0; //1 if list of summaries to analyse
  long startdate=0; //analyse the list of summaries from startdate
  long enddate=0; //analyse the list of summaries to endate
  char between_dates[SIZE_WORD],list_targets[SIZE_WORD]; //raw from optarg
  
  /*end defaults arg*/
     
  char onEOS=1; //add end of sentence marker in text
  char exclus[SIZE_WORD]="";
  int nbs3=0;
  int syllablesstat[]={0,0,0,0,0,0,0,0,0,0,0}; //1...11 syllables
    
  /*used in sentence analyze routine*/
  char *line; //line limited at 'size_line' chars
  char *skip_ptr[1000]; //allow to skip 1000 sentences
  int *class_sum,*class_diff; //'size_nb_class' classes
  char **classname; //'size_nb_class*size_class_name' chars
  long int gross_sum;
  int cont,val,d,do_sentence;
  char class_probable[SIZE_WORD]; //store the most probable class
  int class_probable_score; //store the score of the most probable class
  int mode_ar=1; //define method to determine the class_probable
  char target[SIZE_WORD]; //class target for the abstract by cue
  int made_abstract=0; //flag at 1 if an abstract is produced
  /*End local variables of main*/

  /*get & format time*/
  time(&now);
  tm=localtime(&now);
  strftime(date,sizeof date,"%A %B %d, %Y, %OH:%M",tm);
  
  /*initialise random numbers*/
  srand (time (NULL));
    
  /* get options from the cmd line */
  int oc;
  int nbopt=0; 
  while ((oc=getopt(argc,argv,":a:A:bBc:C:d:D:e:E:f:F:g:hi:kKl:L:m:M:n:o:p:q:r:RsS:t:u:v:VwW:z:")) != -1){
    nbopt++;
    switch(oc) {
      case 'a':
        abstract_rate=atoi(optarg);
        if ((abstract_rate == 0) || (abstract_rate > 99)) {
          ERRPOS
          fprintf(stderr,"Argument required must be between 1 and 99\n");
          exit(EXIT_FAILURE);
        }
        break;	 	
      case 'A':
        if ((*optarg=='a') || (*optarg=='A')) abstract_mode=-1;
        else if ((*optarg=='b') || (*optarg=='B')) abstract_mode=-2;
	      else {
       	    if ((atoi(optarg) < 0) || (atoi(optarg) > 15)) {
              help("\nError argument: -A 0...7\n");
            }
          abstract_mode=atoi(optarg);
        }
        break;	 	    
      case 'b':
        /*training immediately after*/
        batch_mode=0;
        builddico=1;
        dosinglekeyword=1; //key_term of 1 word
        min=1; //freq min = 1 occurence
        lgmin=2; //word length min > 2 char
        taux=0.01; //results from max_freq to 0.01*max_freq
        maxsetnbkw=2; //1,2,3 words in keywords
        strcpy(exclus,"F"); //excluded words from excluded.lan.word file
        showkeywords=0; //do not print keywords list
        break;
	    case 'B':
	      /*no immediate training*/
	      batch_mode=1;
        builddico=1;
	      dosinglekeyword=1; //key_term of 1 word
        min=1; //freq min = 1 occurence
        lgmin=1; //word length min > 1 char
        taux=0.01; //results from max_freq to 0.01*max_freq
        maxsetnbkw=2; //1,2,3 words in keywords
        strcpy(exclus,""); //no exclusion
	      showkeywords=0; //do not print keywords list		
		    break;	
      case 'c':
		/* chars encoding */
        if (strstr(optarg,"A_utf8") || strstr(optarg,"A_UTF8")) abstract_utf8=1;
		else strcpy(convert,optarg);
        break;
      case 'C':
		/* to update a class */
        strcpy(text_class_added,optarg);
        break;	
      case 'd':
        debug=atoi(optarg);
        break;
      case 'D': 
	    /* Analyze the list of summaries
		 * Extract language, chars encoding, dates and targets 
		 * -D locale=lang.encoding,date1,date2,target=... */
		if (strlen(optarg) > SIZE_WORD) {
			fprintf(stderr,"Check the option -D \"locale=lang.encoding,date1,date2,target=...,...\"\n");
			ERRPOS; 
			exit(EXIT_FAILURE);
		}
		split_dates_targets(optarg,between_dates,list_targets);
        extract_dates(between_dates,&startdate,&enddate);
		listofsummaries=1;
        break;		
      case 'e':
		/* Excluded words */
        strcpy(exclus,optarg);
        break;
	  case 'E':
		/* Emotion-Sentiment analysis */
		if (*optarg=='0' && strlen(optarg)==1) doemotion=0;
		else if (*optarg=='1' && strlen(optarg)==1) doemotion=1;
		else if (*optarg=='2' && strlen(optarg)==1) doemotion=2;
		else if (strlen(optarg) > 1) {
			wtarget=strdup(optarg);
			doemotion=1;
		}
        break;	
      case 'f':
		/* dictionaries path */
        strcpy(path_dictionary,optarg);
        /*check is path is valid*/
        if (testdir(path_dictionary) == 0) {
			ERRPOS
			fprintf(stderr,"Unable to access to %s\n",path_dictionary);
			exit(EXIT_FAILURE);
        }
        break;
      case 'F':
		/* output file path */
        strcpy(path_output_files,optarg);
        /*check is path is valid*/
        if (testdir(path_output_files) == 0) {
			ERRPOS
			fprintf(stderr,"Unable to access to %s\n",path_output_files);
			exit(EXIT_FAILURE);
        }
        break;
      case 'g':
		/* keep words with length > lgmin */
        lgmin=atoi(optarg);
        break;
      case 'h':
        help("");
        break;
      case 'i':
		/* input file path+name */
        strcpy(file_input,optarg);
        break;
      case 'k':
        showkeywords=1;
        break;
      case 'K':
        showfilteredkeywords=1;
        break;
      case 'l':
        /* language abrev. or auto */
        strcpy(lang,optarg);
        strtolower(lang);
        break;
      case 'L':
        levenstein=atoi(optarg);
        break;
      case 'm':
		/* minimal occurence of terms */
        min=atoi(optarg);
        break;
      case 'M':
		/* Means classes */
        if (atoi(optarg)>1) brief_class=1;
		else brief_class=0;
        break;
      case 'n':
        maxsetnbkw=atoi(optarg);
        break;
      case 'o':
        strcpy(file_output,optarg);
        break;
      case 'p':
        if ((*optarg < '0') || (*optarg > '3')) {
	        help("\nError argument: -p 0...3\n");
        }
        rec=atoi(optarg);
        break;
      case 'q':
        /* coef can be applied to the constants */
        k_cst=atoi(optarg);
        break;
      case 'r':
        repeatdistance=atoi(optarg);
        if (repeatdistance == 0) checkrepeating=0;
        break;
      case 'R':  
        showwordrepeated=1;
        break;
      case 's':
        dosinglekeyword=0;
        break;
      case 'S':
        threshold_plagia=atoi(optarg);
        if (threshold_plagia == 0) doplagia=0;
        else if (threshold_plagia > 0) strict_plagia=0;
        else {
	       fprintf(stderr,"Error: arg S takes 0 or 1\n"); 
	       exit(EXIT_FAILURE);
        }
        break;
      case 't':
        taux=((float)atoi(optarg))/100;       
        break;
      case 'u':
        histogram=atoi(optarg);
        break; 
      case 'v':
        if ((*optarg < '0') || (*optarg > '2')) {
          help("\nError argument: -v 0...2\n");
        }
        verbose=atoi(optarg);
        break; 
      case 'V':
        printf("\n%s ver. %s - %s - %s\n",PROG_NAME,COMPACT_VERSION,AUTOR,DATE_VERSION);          
        return(1); 
      case 'w':
        wait_key=1;
        break; 
      case 'W':
        linewidth=atoi(optarg);
        break; 
      case 'z':
        memoryalloc=atoi(optarg);
        break;   
      case ':':
        fprintf(stderr,"%s: option `-%c' requires an argument\n",argv[0],optopt);
        exit(EXIT_FAILURE);
        break;
      case '?':
      default:
        fprintf(stderr,"%s: option `-%c' is invalid: ignored\n",argv[0],optopt);
        exit(EXIT_FAILURE);
        break;
    }
  }
  if (nbopt == 0) help("\nError - argument required\n");
  
  if (verbose) printf("\n\n-=-=-=-=-=-=-=-=-=-=-%s-=-=-=-=-=-=-=-=-=-=-\nver. %s - %s - %s\n\n",PROG_NAME,COMPACT_VERSION,AUTOR,DATE_VERSION);  
 
  if (memoryalloc > 1) {
    size_best_result*=memoryalloc;
    size_text*=memoryalloc;
    size_onlyonceword*=memoryalloc;
    size_excludedword*=memoryalloc;
    size_class_name*=memoryalloc;
    size_nb_class*=memoryalloc;
  }
   
  /* dynamic allocation */
  text = (char*)malloc(size_text);
  onlyonceword = (char*)malloc(size_onlyonceword);
  longline = (char*)malloc(SIZE_LONGLINE+1);
  excludedword = (char*)malloc(size_excludedword);
  best_result = (char*)malloc(size_best_result);
  pos_sentence = (long int*)malloc(4*NB_SENTENCES*memoryalloc);
  if ((text==NULL) || (onlyonceword==NULL) || (longline==NULL) || (excludedword==NULL) || (best_result==NULL) || (pos_sentence==NULL)) errmalloc("main");
  
  /* check the input file (doc to analyse) */
  if (*file_input == '\0') { //nothing?
    ERRPOS
    fprintf(stderr,"Missing input file name -> Exit!\n");
    exit(EXIT_FAILURE);
  } 
  else if (strcmp(file_input,"PIPE") == 0) { //pipe?
      sprintf(file_input,"%sPIPE.txt",path_output_files);
	  /* file_input is the outpout file of readandsave !!! */
      readandsave(file_input);
  }
  else if ( listofsummaries ) { //list of summaries to analyse?
	  sprintf(file_output,"%slistsummaries.txt",path_output_files);
	  nb_summaries_extracted=extract_summaries(file_input,file_output,startdate,enddate);
	  if ( nb_summaries_extracted == 0 ) {
        printf("\nAny summary extracted -> Exit!\n");
        exit(EXIT_FAILURE);
	  } else printf("Number of summaries extracted: %i\n",nb_summaries_extracted);  
	  
	  /* file_output will be the file_input of the next routnes */
	  strcpy(file_input,file_output); 
  }
  
  printf("File analyzed: %s Date: %s\n",file_input,date);  
  strcpy(file_original,file_input);

  /*abstract file names*/
  strcpy(file_abstract1,path_output_files);
  strcat(file_abstract1,"abstract1.txt");
  strcpy(file_abstract2,path_output_files);
  strcat(file_abstract2,"abstract2.txt");
  strcpy(file_abstract3,path_output_files);
  strcat(file_abstract3,"abstract3.txt");
  strcpy(file_abstract4,path_output_files);
  strcat(file_abstract4,"abstract4.txt");
  strcpy(file_abstract5,path_output_files);
  strcat(file_abstract5,"abstract5.txt");
  strcpy(file_abstract6,path_output_files);
  strcat(file_abstract6,"abstract6.txt");
  
  strcpy(file_bilan_abstr,path_dictionary);
  strcat(file_bilan_abstr,"abstracts.data");
  
  /*output file name*/
  if (*file_output == '\0') {    //no output name provided then create one
    strcpy(file_output,path_output_files);
    strcat(file_output,"keyworder.out");
  } //else if ((rec & 2) != 2) rec=rec & 2;
  
  /*temporary iso8859 converted input file*/
  strcpy(file_iso,path_output_files);
  strcat(file_iso,"iso8859.temp");

  if ((rec & 2) == 2) {
    /* Open the file  */
    fp=fopen(file_output,"w");
    if (fp==NULL){
	  ERRPOS
      fprintf(stderr,"Unable to create %s ->Exit!\n",file_output);
      exit(EXIT_FAILURE);
    }
    printf("Result file %s\n",file_output);
    fprintf(fp,"< File analyzed %s >\n< Date %s >\n",file_input,date);
    if (fclose(fp) != 0) {
	  ERRPOS
	  fprintf(stderr,"Error:fclose fp");
	}
  }
 
  /* Detect and display the text format:
   * - search first if <html> document 
   * - search next the char coding (plain ansi, utf8, utf16) */
  if (strcmp(convert,"auto")==0) {
    if (testhtml(file_input)) { printf("Format is html - "); strcpy(format,"html"); }   
    if (testansi7(file_input)) { printf("Charset is ANSI 7bits.\n\n"); strcpy(convert,"ansi"); }
      else if (testutf8(file_input)) { printf("Charset is UTF8.\n"); strcpy(convert,"utf8"); }
        else if (testutf16(file_input)) { printf("Charset is UTF16.\n"); strcpy(convert,"utf16"); }
          else { printf("Charset is supposed iso.\n\n"); strcpy(convert,"iso"); }
  }
  
  /*the path of the 'filtered single keywords' dictionary made*/
  strcpy(file_keyw,path_output_files);
  strcat(file_keyw,"singlekeys.temp");

  /*
    Procede to the conversion:
	- start with conversion html -> iso8859 & ansi7b
	- next convert utf8 ->  iso8859 & ansi7b
    text_ansi7.temp contains text after conversion to ANSI
    iso8859.temp contains text after conversion to iso 8859-1/15
    isofile flag is set at 1
  */
  
  /* text.temp contains text after conversion html to text*/
  if (strcmp(format,"html")==0) {
    sprintf(file_temporary_input,"%stext.temp",path_output_files);
    printf("Conversion html->text, %s\n\n",htmltotext(file_input,file_temporary_input,text_title));
    /*now we will work on the temporary file (charset converted)*/
    strcpy(file_input,file_temporary_input); //now we will work on the temporary html converted  
  }

  sprintf(file_temporary_input,"%stext_ansi7.temp",path_output_files);
  if (strcmp(convert,"utf8")==0) { printf("Conversion UTF8->ANSI(7)+ISO 8859, %i err\n",utf8toansi7b(file_input,file_temporary_input,file_iso)); isofile=1;}
    else if (strcmp(convert,"iso")==0) printf("Conversion ISO 8859->ANSI(7), %i err\n",isotoansi7b(file_input,file_temporary_input));
      else printf("Remove ctr-char ANSI(7), %i err\n",plainansi7b(file_input,file_temporary_input));
  /*we will work on the temporary file (charset converted)*/
  strcpy(file_input,file_temporary_input);


  /* Detect and display the main language of the text */
  if (strcmp(lang,"auto")==0) {
    strcpy(lang,testlanguage(path_dictionary,file_input));
    printf("Language detected: %s\n\n",lang);
    if (strcmp(lang,"err") == 0) {
	  ERRPOS
	  fprintf(stderr,"Language returned 'err'");
	  exit(EXIT_FAILURE); //better to exit
	}
  } 
  else 
    printf("Language forced: %s\n\n",lang);
   

  /* 
     Header of the builddico file 
	 Append mode: for batch training
	 Write mode: if a learned is used next
  */  
  if (builddico) {
    /*the path of builddico*/
    /* Open file - record header - close file */
    if (batch_mode) {
	    /*for batch training*/
	    strcpy(file_builddico,path_dictionary);
      strcat(file_builddico,"keyworder.build");
	    fp=fopen(file_builddico,"a");
	  }
	    else
	  {
	    /*for immediate training*/
	    strcpy(file_builddico,path_output_files);
      strcat(file_builddico,"keyworder.build");
	    fp=fopen(file_builddico,"w");
	  }
    if (fp==NULL){
	    ERRPOS
      fprintf(stderr,"Unable to open %s ->Check file permission.\n ->Exit!\n",file_builddico);
      exit(EXIT_FAILURE);
    }
    fprintf(fp,"< Begin analyze >\n");
    fprintf(fp,"< File analyzed:%s >\n",file_original);
    fprintf(fp,"< Text class:%s >\n",text_class_added);
    fprintf(fp,"< Language:%s >\n",lang);
    fprintf(fp,"< Parameters Version:%s Lang:%s Charset:%s Min:%i Lgmin:%i Taux:%f Exclude:%s >\n",COMPACT_VERSION,lang,convert,min,lgmin,taux,exclus);
    if (fclose(fp) != 0) {
	    ERRPOS
	    fprintf(stderr,"Error: fclose fp");
	    count_silent_bug++;
	  }
  }
  
  /* 
     Words exclusion depending of the language
     Can be a file or group of words defined in the prog
  */
  if (strpbrk(exclus,"file") || strpbrk(exclus,"F")) {
    if (excludedfromfile(path_dictionary,excludedword,1,lang,size_excludedword) < 0) {
      ERRPOS
      fprintf(stderr,"Error: Openning excludedword file!\n\n");
      count_silent_bug++;
	  }
  } else {
    if (strcmp(lang,"fr")==0) {
      nlang=0;
      if (strpbrk(exclus,"article") || strpbrk(exclus,"A")) strcat(excludedword,"\nun\nune\ndes\nle\nla\nles\n");
      if (strpbrk(exclus,"preposition") || strpbrk(exclus,"P")) strcat(excludedword,"\nde\ndu\nau\naux\nen\ndans\navec\npour\n");
      if (strpbrk(exclus,"conjunction") || strpbrk(exclus,"C")) strcat(excludedword,"\net\nou\n");
      if (strpbrk(exclus,"verb") || strpbrk(exclus,"V")) strcat(excludedword,"\nai\nas\na\navons\navez\nont\navais\navait\navions\naviez\navaient\nsuis\nes\nest\nsommes\netes\nsont\netais\netait\netions\netiez\netaient\n");
    }
    else if (strcmp(lang,"en")==0) {
     nlang=1;
     if (strpbrk(exclus,"article") || strpbrk(exclus,"A")) strcat(excludedword,"\na\nan\nthe\nsome\n");
     if (strpbrk(exclus,"preposition") || strpbrk(exclus,"P")) strcat(excludedword,"\nof\nat\nto\nfor\nin\non\nby\nwith\nas\n");
     if (strpbrk(exclus,"conjunction") || strpbrk(exclus,"C")) strcat(excludedword,"\nand\nor\n");
     if (strpbrk(exclus,"verb") || strpbrk(exclus,"V")) strcat(excludedword,"\nam\nis\nare\nwas\nwere\nhas\nhave\nhad\n");
    }
  }
  
  /*
    onlyonceword and text contains the filtered and tokinezed text
    each words are separated with an eol '\n'
    but: - onlyonceword is a list of words present in the text (same 
         words are not repeated)
         - text keeps the stucture of the native text
    
    !!! This routine tokenizes the text, 
	* it is a very important job to analyze correctly the text.

      - Read the text file (ansi7 converted)
      - Filter chars
	  - convert word followed by an apostrophe (language dependent)
      - Filter words
      - Detect basic abreviations
      - Detect end of sentence (EOS)
      - Build a table with the position of each sentence
      - Count the number of words
      - Count the number of sentences
      - Evaluate the number of syllables in each word
      - Do a table of nb of words / nb of syllables
      - Concatenate words in text
      - Create and update onlyonceword
      
    Futur possibilities to experiment:
      - create a hash table (will speed up repetition routine 
      and keywords routines)
  */
  
  strcpy(onlyonceword,"\n"); /*First char in text is eol needed for word search*/
  strcpy(text,"\n"); /*First char in text is eol needed for word search*/
  lgonlyonceword=lgtext=1; /*because '\n'is in pos 0 */
  nbl=nbw=nbtw=nbts=nbtc=nboow=0; /*nb lines, nb words, total words, total syllables, total comas, total only once words*/
  ch=previous_ch=' ';
  hash1_val=hash2_val=0; //will be the signature of the text
  lg=0;
  nbeos=0; 
  basicword=0;
  nbnewline=0;
  pos_sentence[nbeos++]=pos_char=0; //top of the raw text
  strcpy(validchar,alphabet);
  strcat(validchar,numeral);
  strcat(validchar,special);
  strcat(validchar," .");
  
  /* Open the text (temp file) to analyze */
  fp=fopen(file_input,"r");
  if (fp==NULL){
    ERRPOS
    fprintf(stderr,"Unable to open %s ->Exit!\n",file_input);
    exit(EXIT_FAILURE);
  }
  
  if (debug) fprintf(stderr,"\nSTART GET WORD ROUTINE\n"); //check pb
  int ok=1;  
  /* The main loop: tokenize the text, 
   * read and proceed char one by one */
  while (ok) {
    prevch_upper=0;
    ch=fgetc(fp);
    pos_char++; //position char in the text
    if (ch == EOF) break; //eof so exit loop
	/* Count newline */
	if ((int)ch < 13) nbnewline++;
    /* Filter only alphanumeric */
    if ((int)ch < 32) ch=' '; //no crtl char
    else if ((int)ch > 126) ch=' '; //no special char
    else if (isupper(ch)) {
      prevch_upper=1; //useful to detect single char abreviation
      ch=tolower(ch); //because works only on lowercase
    } 

    /* count & replace coma */
    if (ch==coma) {
        ch=' ';
        nbtc++;
    }
    /*replace delimiter*/
    if (strchr(separator,ch) != NULL) ch=' ';
	
    /*try to detect some abreviations*/
    if (ch=='.') {
      if (lg==1) ch='\0';//abreviation: M. m. U.S.A. u.s.a. U.F.O. u.f.o.
      else if (lg==2) {
        if (strncmp("cf",word,2)==0) ch=' ';
      }
      else if (lg==3) {
        if (strncmp("syn",word,3)==0) ch=' ';
      }
    }
    
    /* PB with dot for www.truc.html */
    
    /*replace end of sentence*/
    if (strchr(eos,ch) != NULL) ch='.';

    /*replace invalide char*/    
    if ((ch != EOF) && (strchr(validchar,ch) == NULL)) ch='_';
    
    /*store char*/
    switch (ch) {
    case ' ': 
      if (ch != previous_ch) {
        word[lg++]='\n';
        word[lg]=0;
        strcpy(wordchk,"\n");
        strcat(wordchk,word);
        nbs=syllablescount(word,1);
        nbts+=nbs;
        if (nbs < 10) syllablesstat[nbs]++; else syllablesstat[10]++;
        if (nbs > 0) nbtw++; /*word without vowel is excluded*/
        /* no too common word such as article... no too short word */
        if (strstr(excludedword,wordchk) != NULL) {basicword++;}
	      else if (lg > lgmin && arenumbers(word) == 0) {
          nbw++;
          lgtext+=lg+1;
          if (lgtext > size_text) {
		        ERRPOS
		        fprintf(stderr,"Error:Text, memory overflow"); 
			      exit(EXIT_FAILURE);
		      }
          strcat(text,word); /*word1 CR word2 CR ...*/
          if (strstr(onlyonceword,wordchk) == NULL) {
            nboow++;
            lgonlyonceword+=lg+1;
            if (lgonlyonceword > size_onlyonceword) {
			        ERRPOS
			        fprintf(stderr,"Error:Onlyonceword, memory overflow"); 
			        exit(EXIT_FAILURE);
			      }
            strcat(onlyonceword,word);
          }
        }
        lg=0; //reset lenght of word
      }
      break;
	case '\'': //apostroph plays an important role in English and French
	  if (ch != previous_ch) {
		  if (strcmp(lang,"fr") == 0) {
			word[lg++]='e';
		  }
		  else if (strcmp(lang,"en") == 0) {
			  if (lg > 1) {
				  word[lg]='\n';
				  word[lg+1]=0;
				  strcpy(wordchk,"\n");
				  strcat(wordchk,word);
				  if (strstr("\ncan\n",wordchk)!=NULL) {
					  en_negation_flag=1;
				  } 
				  else if (strstr(en_negation_verbs,wordchk)!=NULL) {
					en_negation_flag=1;
					lg--;
				  }
				 else en_negation_flag=0;
			  }
		   }
		word[lg++]='\n';
        word[lg]=0;
        strcpy(wordchk,"\n");
        strcat(wordchk,word);
        nbs=syllablescount(word,1);
        nbts+=nbs;
        if (nbs < 10) syllablesstat[nbs]++; else syllablesstat[10]++;
        if (nbs > 0) nbtw++; /*word without vowel is excluded*/
        /* no too common word such as article... no too short word */
        if (strstr(excludedword,wordchk) != NULL) {basicword++;}
	      else if (lg > lgmin && arenumbers(word) == 0) {
          nbw++;
          lgtext+=lg+1;
          if (lgtext > size_text) {
		        ERRPOS
		        fprintf(stderr,"Error:Text, memory overflow"); 
			      exit(EXIT_FAILURE);
		   }
          strcat(text,word); /*word1 CR word2 CR ...*/
          if (strstr(onlyonceword,wordchk) == NULL) {
            nboow++;
            lgonlyonceword+=lg+1;
            if (lgonlyonceword > size_onlyonceword) {
			        ERRPOS
			        fprintf(stderr,"Error:Onlyonceword, memory overflow"); 
			        exit(EXIT_FAILURE);
			      }
            strcat(onlyonceword,word);
          }
        }
        lg=0; //reset lenght of word
		
		if (en_negation_flag) {
			/* english negation: ...n't => not */
			en_negation_flag=0;	
			lgtext+=4;
			if (lgtext > size_text) {
				ERRPOS
				fprintf(stderr,"Error:Text, memory overflow"); 
				  exit(EXIT_FAILURE);
			}
			strcat(text,"not\n"); /*word1 CR word2 CR ...*/	
		}
      }
	  break;
    case '"':
      if (ch != previous_ch) {
        word[lg++]='\n';
        word[lg]=0;
        strcpy(wordchk,"\n");
        strcat(wordchk,word);
        nbs=syllablescount(word,1);
        nbts+=nbs;
        if (nbs < 10) syllablesstat[nbs]++; else syllablesstat[10]++;
        if (nbs > 0) nbtw++; /*things without vowel are excluded*/
        if (strstr(excludedword,wordchk) != NULL)  {basicword++;}
	    else if (lg > lgmin && arenumbers(word) == 0) {
          nbw++;
          lgtext+=lg+1;
          if (lgtext > size_text) {
		    ERRPOS
		    fprintf(stderr,"Error:Text, memory overflow"); 
			exit(EXIT_FAILURE);
		  }
          strcat(text,word);
          if (strstr(onlyonceword,wordchk) == NULL) {
            nboow++;
            lgonlyonceword+=lg+1;
            if (lgonlyonceword > size_onlyonceword) {
			  ERRPOS
			  fprintf(stderr,"Error:Onlyonceword, memory overflow"); 
			  exit(EXIT_FAILURE);
			}
            strcat(onlyonceword,word);
          }
        }
        lg=0;
      }
      break;
    case '.': /* Suposed End of sentence */
      /* pb with abreviation M. Ex.  */
      if (ch != previous_ch){
        nbl++; //cnt nb of lines
        word[lg++]='\n';
        word[lg]=0;
        strcpy(wordchk,"\n");
        strcat(wordchk,word);
        nbs=syllablescount(word,1);
        nbts+=nbs;
        if (nbs < 10) syllablesstat[nbs]++; else syllablesstat[10]++;
        if (nbs > 0) nbtw++; /*things without vowel are excluded*/
        if (strstr(excludedword,wordchk) != NULL) {basicword++;}
	    else if (lg > lgmin && arenumbers(word) == 0) {
          nbw++;
          lgtext+=lg+1;
          if (lgtext > size_text) {
		    ERRPOS
		    fprintf(stderr,"Error:Text, memory overflow"); 
			exit(EXIT_FAILURE);
		  }
          strcat(text,word);
          if (onEOS) {
	    strcat(text,"EOS\n"); //add EOS marker to the text
	    pos_sentence[nbeos++]=pos_char; //store position end of sentence
	  }
          if (strstr(onlyonceword,wordchk) == NULL) {
            nboow++;
            lgonlyonceword+=lg+1;
            if (lgonlyonceword > size_onlyonceword) {
			  ERRPOS
			  fprintf(stderr,"Error:Onlyonceword, memory overflow"); 
			  exit(EXIT_FAILURE);
			}
            strcat(onlyonceword,word);
          }
        }
        lg=0;
      }
      break;
    case '_': break;
    case EOF: break;
    default:
	  /*Rebuild the word*/
      if ( lg < SIZE_WORD )
        word[lg++]=ch;
      else if (verbose) 
        ERRPOS;
	  /* compute the hash value */
	  hash1_val = (hash1_val<<4)^(hash1_val>>28)^(int)ch; //rotating hash
	  hash2_val = (33*hash2_val)+(int)ch; //Bernstein hash
    } /* end of switch */
    previous_ch=ch; /*Avoid doublon*/
  } /* end of while */ 
  /* mix hash_value*/
  hash1_val = hash1_val ^ (hash1_val>>10) ^ (hash1_val>>20);
  sprintf(hash_str,"%llx%llx",hash1_val,hash2_val);
  
  /* tokenization is done */
  if (fclose(fp) != 0) {
    ERRPOS
    fprintf(stderr,"Error: fclose fp");
    count_silent_bug++;
  }
  if (debug) fprintf(stderr,"\nEND GET WORD ROUTINE\n"); //check pb
  if (debug>3) fprintf(stderr,"\nText:\n%s \n\nOnlyonce\n%s\n\n",text,onlyonceword);
  
  /*If nb of words with 10 or more syllables are > words with 1 & 2 syllables there is pb!*/
  if (syllablesstat[10]>(syllablesstat[1]+syllablesstat[2])) {
    ERRPOS
    fprintf(stderr,"Warning: Charset conversion pb?\n");
    count_silent_bug++;
  }

  /* Dynamic Alloc Memory to result */
  size_result=(nboow+1)*size_class_name; //may result a too large amount of memory allocated
  if (debug) fprintf(stderr,"\nSize result %li bytes\n",size_result);
  if ((result = (char*)malloc(size_result)) == NULL) errmalloc("for result in main()");

  /* Some usefull info to build the dico */  
  if (builddico) {
    /* Open the file  */
    fp=fopen(file_builddico,"a");
    if (fp==NULL){
      printf("Unable to open %s ->Exit!\n",file_builddico);
      exit(EXIT_FAILURE);
    }
    if (strpbrk(exclus,"file") || strpbrk(exclus,"F")) {
	  fprintf(fp,"< Excluded words:From file >\n");
	} else fprintf(fp,"< Excluded words:%s >\n",exclus);
    fprintf(fp,"< Number of words:%li >\n",nbtw);
    fprintf(fp,"< Different words:%li >\n",nboow);
    fprintf(fp,"< Number of lines:%li >\n",nbl); //nb sentences
	fprintf(fp,"< Number of CR   :%li >\n",nbnewline);
    if (fclose(fp) != 0) {
	  ERRPOS
	  fprintf(stderr,"Error: fclose fp");
	  count_silent_bug++;
	}
  }
  
  
  /*                      <Some statistics>
  Number of words, syllables 
  */ 
  if (abstract_mode != -2) { //no if only summary
    sprintf(longline,"Number of words=\t\t\t %li\nNumber of sentences=\t\t %li\n",nbtw,nbl);
    printing(longline,1,999,rec);
	sprintf(longline,"Average word/sentence=\t %.1f\n",((float)nbtw/(float)nbl));
    printing(longline,1,999,rec);
	sprintf(longline,"Sentences/new line=\t\t %.1f\n",((float)nbl/(float)nbnewline));
    printing(longline,1,999,rec);
    sprintf(longline,"Number of syllables=\t\t %li\nAverage syllable/word=\t\t %.1f\n\n",nbts,((float)nbts/(float)nbtw));
    printing(longline,1,999,rec);
    for(i=1;i<10;i++) {
      sprintf(longline,"Words with %li syllables=\t %i\n",i,syllablesstat[i]);
      printing(longline,1,999,rec);
    }
    sprintf(longline,"More than 9 syllables=\t\t %i\n",syllablesstat[10]);
    printing(longline,1,999,rec);
  }
  /*reading time*/
  sprintf(longline,"\nEstim. reading time=\t %.1f mn\n\n",
            readingtime(path_dictionary,lang,nbts,nbtw,nbtc,nbl));
  printing(longline,1,999,rec);
  /*readability*/
  if (abstract_mode != -2) { //no if only summary
    for(i=3;i<10;i++) nbs3+=syllablesstat[i];
    if (strcmp(lang,"fr")==0) {
      sprintf(longline,"Flesh Readability Fr=\t %.1f\nScore: 100-90 Easy(Cartoon) / 70-60 Normal(Rewriting) / 30-0 Hard(Scientific)\n",209-1.15*((float)nbtw/(float)nbl)-68*((float)nbts/(float)nbtw));
      printing(longline,1,999,rec);
      sprintf(longline,"Grunning fog index=\t %.1f\nGrunning fox index evaluates text readablility (age of the reader)\n\n",0.4*((float)nbtw/(float)nbl)+100*((float)nbs3/(float)nbtw));
      printing(longline,1,999,rec);
    }
    else if (strcmp(lang,"en")==0) {
      sprintf(longline,"Flesh Readability En=\t %.1f\nScore: 100-90 Easy(Cartoon) / 70-60 Normal(Rewriting) / 30-0 Hard(Scientific)\n",206.835-1.015*((float)nbtw/(float)nbl)-84.6*((float)nbts/(float)nbtw));
      printing(longline,1,999,rec);
      sprintf(longline,"Grunning fog index=\t %.1f\nGrunning fox index evaluates text readability (age of the reader)\n\n",0.4*((float)nbtw/(float)nbl)+100*((float)nbs3/(float)nbtw));
      printing(longline,1,999,rec);
    }
  }

  /*Now load var excludedword with a list of basic/common words*/
  if (excludedfromfile(path_dictionary,excludedword,2,lang,size_excludedword) < 0) {
    if (verbose) printf("\nNo 'basic.lan.word' file found - I am going to use the list of excluded words\n");
    if (excludedfromfile(path_dictionary,excludedword,1,lang,size_excludedword) < 0) 
      if (verbose) printf("\nNo 'excluded.lan.word' file found - Use only internal excluded words list.\n");
    if (strcmp(lang,"fr")==0) {
      if (verbose) printf("\nLoad internal French words list.\n");
      if (strpbrk(exclus,"article") || strpbrk(exclus,"A")) strcat(excludedword,"\nun\nune\ndes\nle\nla\nles\n");
      if (strpbrk(exclus,"preposition") || strpbrk(exclus,"P")) strcat(excludedword,"\nde\ndu\nau\naux\nen\ndans\navec\npour\n");
      if (strpbrk(exclus,"conjunction") || strpbrk(exclus,"C")) strcat(excludedword,"\net\nou\n");
      if (strpbrk(exclus,"verb") || strpbrk(exclus,"V")) strcat(excludedword,"\nai\nas\na\navons\navez\nont\navais\navait\navions\naviez\navaient\nsuis\nes\nest\nsommes\netes\nsont\netais\netait\netions\netiez\netaient\n");
    }
    else if (strcmp(lang,"en")==0) {
     if (verbose) printf("\nLoad internal English words list.\n");
     if (strpbrk(exclus,"article") || strpbrk(exclus,"A")) strcat(excludedword,"\na\nan\nthe\nsome\n");
     if (strpbrk(exclus,"preposition") || strpbrk(exclus,"P")) strcat(excludedword,"\nof\nat\nto\nfor\nin\non\nby\nwith\nas\n");
     if (strpbrk(exclus,"conjunction") || strpbrk(exclus,"C")) strcat(excludedword,"\nand\nor\n");
     if (strpbrk(exclus,"verb") || strpbrk(exclus,"V")) strcat(excludedword,"\nam\nis\nare\nwas\nwere\nhas\nhave\nhad\n");
    }
  }
  if (debug>3) fprintf(stderr,"list of excluded words:%s",excludedword);
  
  /*                      <Repetition analyze>
  Check word repeated in continuous sentences (repetition routine)
  */
  if (checkrepeating) {
    if (debug) fprintf(stderr,"\nSTART REPETITION ROUTINE\n"); //check pb
    nbkey=k=result_overflow=0;
    length=strlen(text);
    for(i=0;i<length;i++) {
      if (text[i]=='\n') {
        for(j=0;i+j+1<length;j++) {
          if (text[j+i+1] != '\n') word[j]=text[j+i+1];
          else {
            word[j]=0;
            if (strcmp(word,"EOS") != 0) {
              strcpy(wordchk,"\n");
              strcat(wordchk,word);
              strcat(wordchk,"\n");
              if (strstr(excludedword,wordchk) != NULL) basicword++;
              str_ptr=text+j+i+1;
              k=0;
              if ((str_ptr_next=strstr(str_ptr,wordchk)) != NULL) {
                while ((str_ptr=strstr(str_ptr,"EOS")) != NULL) {
                  str_ptr+=4;
                  if (str_ptr >= str_ptr_next-1) break;
                  k++; //cnt repetition same word
                }
                if (k<repeatdistance) {
                  if (showwordrepeated) {
                    if (strlen(word)>SIZE_WORD) word[SIZE_WORD]=0; /*max 'SIZE_WORD' chars*/
                    if (nbkey*SIZE_WORD > size_result) {
                      size_result=(long int)(nbkey+1)*SIZE_WORD;
                      if ((result=(char*)realloc(result,size_result))==NULL) errmalloc("in repetition routine");
                        else if (debug) fprintf(stderr,"Info: More memory is allocated , result=%li\n",size_result);
                      if ((trash=(char*)malloc(size_trash))==NULL) errmalloc("in repetition routine - memory too low?");
                      free(trash);
                    }
                    if (nbkey*SIZE_WORD < size_result) sprintf(result+nbkey*SIZE_WORD,"%4li:%s",k,word); /*Store subresult*/
                      else result_overflow++; 
                  }
                  nbkey++; //count subresult added to result = nb of words repeated
                }
                k=0;
                /*str_ptr=str_ptr_next+strlen(wordchk);*/ /*to the end of the word found*/
              }
            }
            i=i+j;          
            break;
          }
        }
      }
    }
    if (debug) fprintf(stderr,"\nEND REPETITION ROUTINE\n"); //check pb
    sprintf(longline,"Repeated words= %li and rate=%.1f%%  Basic words= %li and rate=%.1f%%\n\n",nbkey,(100*(float)nbkey/(float)nbtw),basicword,(100*(float)basicword/(float)nbtw));
    printing(longline,1,999,rec);
    if (showwordrepeated) {
      if (result_overflow) {
	    ERRPOS
	    fprintf(stderr,"Error:Result var overflow in repetition routine!\n\n");
	  }
      for(i=0;i<nbkey;i++) printf("<%s>",result+i*SIZE_WORD);
    }
  }
  
/*                   < Sentiment > */  
  if (debug) fprintf(stderr,"\nSTART SENTIMENT ROUTINE\n"); //check pb
  if (doemotion) {
	printing("\n<Sentiments>\n",1,999,rec);
	sprintf(filename,"%s%s.%s.dicE",path_dictionary,file_dictionary,lang);
    if (filesize(filename) > 0) 
		emotion_extract(
			filename,result,size_result,text,pos_sentence,
			0,wtarget,doemotion,rec);
	printing("<End Sentiment>\n",1,999,rec);
  }

  
/*                   < plagiarism search >
  Search nb occurence of the same sentences (sentence routine)
  The weighting is similar to weightresult(...) but I included in the routine
  below because sentence can be large and oblige to allocate a lot of memory to result.
*/
  if (debug) fprintf(stderr,"\nSTART PLAGIARISM ROUTINE\n"); //check pb
  if (doplagia) {
    sprintf(filename,"%s%s.%s.dicS",path_dictionary,file_dictionary,lang);
    if (filesize(filename) > 0) {
      printing("\n<Similar sentences - Plagiarism>\n",1,999,rec);
      /*dynamic alloc*/
      if ((line = (char*)malloc(size_line)) == NULL) errmalloc("Sentence Analyze");
      if ((classname = (char**)malloc(size_nb_class*sizeof(char*))) == NULL) errmalloc("Sentence Analyze");
      for (k=0;k<size_nb_class;k++) if ((classname[k] = (char*)malloc(size_class_name)) == NULL) errmalloc("Sentence Analyze");
      if ((class_sum = (int*)malloc(size_nb_class*sizeof(int))) == NULL) errmalloc("Sentence Analyze");
      if ((class_diff = (int*)malloc(size_nb_class*sizeof(int))) == NULL) errmalloc("Sentence Analyze");
      
      for(i=0;i<size_nb_class;i++) { class_sum[i]=0; class_diff[i]=0; } //set to zero tables of cumuled weight & occurence

      fp1=fopen(filename,"r");
      if (fp1==NULL){
	    ERRPOS
        fprintf(stderr,"Unable to reopen %s ->Exit!\n",filename);
        exit(EXIT_FAILURE);
      }

      /*build the classname array*/  
      fseek(fp1,0,SEEK_SET);
      for(i=0;i<size_nb_class;i++) {
        line[size_line-2]='\0';
        if (fgets(line,size_line,fp1) == NULL) break; //!!!pb if line>size_line
        if (line[size_line-2] != '\0') {
		  ERRPOS
		  fprintf(stderr,"Pb size_line too small\n");
		  count_silent_bug++;
		}
        if (line[0] != '#') {
          if ((str_ptr2=strpbrk(line,":/")) != NULL) *str_ptr2='\0';
          else {
		    ERRPOS
		    fprintf(stderr,"':/' not found!\n");
		  }
          if (strlen(line) < size_class_name) strcpy(word,line);
          else {
		    ERRPOS
		    fprintf(stderr,"Label too long in weightresult:<%s>\n",line);
		  }
          if ((str_ptr2=strpbrk(line," ")) != NULL) *str_ptr2='\0';
          if ((j=atoi(line))!=0) strcpy(classname[j],word);
          else {
		    ERRPOS
		    fprintf(stderr,"atoi(line):<%s>\n",line);
		    count_silent_bug++;
		  }
        }
      }
      /*Below: extract each sentence in the text, check & count if repeated in the text
      then check if in the dictionary keyworder.lan.dicoS (of famous sentences)*/
      i=j=0;
      gross_sum=0;
      nbkey=result_overflow=0;
      str_ptr=text;
      length=strlen(text);
      while ((str_ptr_next=strstr(str_ptr,"EOS")) != '\0') { //point to the end of the sentence
        do_sentence=1; //set flag
        for (i=0;i<j;i++) if (str_ptr==skip_ptr[i]) { //skip same sentence repeated
	  do_sentence=0; 
	  break;
	}
	if (str_ptr_next-str_ptr < 5) { //skip if too few chars
	  do_sentence=0;
	  break;
	}
	i=0;
	for (str_ptr1=str_ptr;str_ptr1<str_ptr_next;str_ptr1++) if (*str_ptr1=='\n') i++;
	if (i<5) { //skip if less than 4 words in the sentence
	  do_sentence=0; 
	  break;
	}
	if (str_ptr_next-str_ptr > SIZE_LONGLINE) { //because longline size is fixed
	  do_sentence=0;
	  ERRPOS
	  fprintf(stderr,"Sentence too long!\n");
	  count_silent_bug++;
	}  
        if (do_sentence) {
          strncpy(longline,str_ptr,str_ptr_next-str_ptr);
          longline[str_ptr_next-str_ptr]='\0';
          str_ptr1=str_ptr_next+3; //pt the next sentence
          /*cnt repetition of same sentence inside text*/
          k=1; //counter          
          while ((str_ptr1=strstr(str_ptr1,longline)) != '\0') {            
	    if (j<100) {skip_ptr[j++]=str_ptr1; k++;}
	    else {
		  ERRPOS
		  fprintf(stderr,"Skip_prt table is full\n");
		}
	    str_ptr1+=str_ptr_next-str_ptr;
	    if (str_ptr1 > text+length) {
		 ERRPOS
		 fprintf(stderr," In sentence analyze:str_ptr1\n");
		 count_silent_bug++;
		  break;
		}
	  }
	  /*set delimiter & replace CR with space*/
	  longline[str_ptr_next-str_ptr-1]='/'; //last delimited
	  longline[0]='\\'; //first delimiter
	  str_ptr=longline;
	  while ((str_ptr=strchr(str_ptr,'\n')) != '\0') *str_ptr=' '; //replace CR
	  
	  /*Read each line of the dico*/
	  fseek(fp1,0,SEEK_SET); //read from the beginning
	  cont=1;
          while(cont==1) {
            line[size_line-2]= '\0';
            if (fgets(line,size_line,fp1) == NULL) cont=0; //!!!pb if line>size_line
            else if (line[0] != '#') {  //comments are skipped
              if (line[size_line-2] != '\0') {
			    ERRPOS
			    fprintf(stderr,"pb size_line too small\n");
			    count_silent_bug++;
			  }	
	      if (strict_plagia) {
                /*Search for the full sentence in the line (strict match)*/
	        if ((str_ptr1=strstr(strstr(line,":/"),longline)) !=NULL) {
                  /*convert single digit val*/
                  val=chartoi(*(str_ptr1-1)); //str_ptr1-1 points le val (1 char)
                  if ((str_ptr2=strchr(line,' ')) != NULL) *str_ptr2=0; //index class_
                  class_sum[atoi(line)]+=val*k; //weight x nb occurence
                  class_diff[atoi(line)]++; //nb sentences <>
                  gross_sum+=val*k;
		  sprintf(result,"<Class:%s Weight:%li Occur:%li Sentence:%s>",classname[atoi(line)],val*k,k,longline);
		  printing(result,1,2000,rec);
              } }
	      else {
	        /*Search for an approx match in the line*/
		/*levenshtein is too slow here*/
		d=strlen(longline)*threshold_plagia/100;
		str_ptr1=line;
		while ((str_ptr1=strchr(str_ptr1,'\\')) !=NULL) {
		  while ((str_ptr2=strchr(str_ptr1,'/')) !=NULL) {
		    *(str_ptr2+1)='\0';
		    /*do not take the best but just enough close (<d)*/
		    if ((val=levenshtein_distance(longline,str_ptr1)) < d) {
		      /*convert single digit val*/
                      val=chartoi(*(str_ptr1-2)); //str_ptr1-2 points le val (1 char)
                      if ((str_ptr2=strchr(line,' ')) != NULL) *str_ptr2=0; //index class_
                      class_sum[atoi(line)]+=val*k; //weight x nb occurence
                      class_diff[atoi(line)]++; //nb sentences <>
                      gross_sum+=val*k;
		      sprintf(result,"<Class:%s Weight:%li Occur:%li Sentence:%s>",classname[atoi(line)],val*k,k,longline);
		      printing(result,1,2000,rec);
		      goto jump; //ok for the next sentence
		    }
		    str_ptr1=str_ptr2+1;
        } } } } } }
	jump:;
        str_ptr=str_ptr_next+3; //continue to the next sentence
      }
      fclose(fp1); 
      
      if (gross_sum == 0) printing("None found\n",1,999,rec); //no plagia
      else {
        /*Print results   !!!rmq: size of field = size_class_name */ 
        j=0;
        for(i=0;i<size_nb_class;i++) if (class_diff[i]>0) {
          if (j*size_class_name > size_result) {
		    ERRPOS
		    fprintf(stderr,"Result, memory  overflow"); 
			exit(EXIT_FAILURE);
		  }
          sprintf(result+j*size_class_name,"Perc:%3li%% Freq:%7i Diff:%5i class: %s\n",100*class_sum[i]/gross_sum,class_sum[i],class_diff[i],classname[i]);
          j++;
        }
        printing("\n<Classified sentences>\n",1,999,rec);
        printing(result,j,size_class_name,rec);
      }
      printing("\n\n",1,999,rec);
      /*release memory allocated*/
      free(line);
      for (k=0;k<size_nb_class;k++) free(classname[k]);
      free(classname);
      free(class_sum);
      free(class_diff);     
    } 
    else {
      sprintf(longline,"No file %s\n",filename); 
      printing(longline,1,999,rec);
    }
  }    // End of the plagiarism routine
    
  /*                  <group of keywords analyze>
  Search nb occurence for group of keywords (group keywords routine)
                             2...n-grams
  walk word by word ex. we love sweet life => /we love/,/love sweet/,/sweet life/ 
  grp of words are stored in word[SIZE_WORD] and wordchk[SIZE_WORD] 
  => SIZE_WORD is the main limitation of nb of words in grp
  word separator '\n' is replaced with '-' before storing in result
  */
  for(setnbkw=maxsetnbkw;setnbkw>0;setnbkw--) {
    if (debug) fprintf(stderr,"\nSTART GRP WORD ROUTINE\n"); //check pb
    sprintf(filename,"%s%s.%s.dic%li",path_dictionary,file_dictionary,lang,setnbkw+1);
    if (filesize(filename) > 0 || builddico) { //no wast of time if dicoN does not exist
      nbkey=jprev=result_overflow=0;
      length=strlen(onlyonceword);    
      for(i=0;i<length;i++) 
        if (onlyonceword[i]=='\n') {  //position at the beginning of the word
          nbkw=0;
          for(j=0;i+j+1<length;j++) { //go char by char
            if (j < SIZE_WORD) word[j]=onlyonceword[j+i+1]; //copy char by char
              else {
			    ERRPOS
			    fprintf(stderr," Words group > SIZE_WORD (%i chars)\n",SIZE_WORD); //limit
			    count_silent_bug++;
			  }
            if (onlyonceword[j+i+1] == '\n') {   //position at the end of the word
              nbkw++;
              if (nbkw==1) jprev=j; //will continue at the end of the first word
            }
            if (nbkw > setnbkw) {  //nb of words in group is ok to run a searching
              word[j]=0;
              strcpy(wordchk,"\n");
              strcat(wordchk,word);
              strcat(wordchk,"\n");
              k=0; //counter
              str_ptr=text;  //will search in the text
              while ((str_ptr=strstr(str_ptr,wordchk)) != NULL) {
                k++;   //cnt same grp found
                str_ptr+=strlen(wordchk); /*to the end of the word found*/
              }
              while ((str_ptr=strpbrk(word,"\n")) != NULL) *str_ptr='-';
              if (k>0) {              
                if (nbkey*SIZE_WORD > size_result) {
                  size_result=(long int)(nbkey+1)*SIZE_WORD;
                  if ((result=(char*)realloc(result,size_result))==NULL) errmalloc("in group keyw routine");
                    else if (debug) fprintf(stderr,"Info:More memory allocated , result=%li\n",size_result);
                  if ((trash=(char*)malloc(size_trash))==NULL) errmalloc("in group keyw- memory too low?");
                  free(trash);
                }
                if (nbkey*SIZE_WORD < size_result) sprintf(result+nbkey*SIZE_WORD,"%4li:%s",k,word); //Store subresult here
                  else result_overflow++; 
                nbkey++;   //cnt nb of subresults (occurence+keyword grp) added to result = nb of keygrp found
              }
              i=i+jprev;
              break;
            }
          }
        }
        if (debug) fprintf(stderr,"\nEND GRP WORD ROUTINE\n"); //check pb
        sprintf(longline,"\n\n< Group of %li words: >\n",setnbkw+1);
        if (result_overflow) {
		  ERRPOS
		  fprintf(stderr," Result var overflow in group keyw routine!\n\n");
		  count_silent_bug++;
		}  
        if (showkeywords) printing(longline,1,999,rec);
        if (nbkey>0) {
	      // showkeywords==0 do not print keywords list
          printsorted(result,nbkey,SIZE_WORD,min,taux,setnbkw+1,(rec*showkeywords),builddico);
          sprintf(longline,"\n< Nb of keywords=%li >\n",nbkey);
        } else printf(longline,"None\n");
        if (showkeywords) printing(longline,1,999,rec);
      
        /*Below weight group of keywords*/
        if (nbkey > 0) {          
          if (filesize(filename) > 0) {
			/* size_class_name */
            nbkey=weightresult(filename,result,size_result,nbkey,SIZE_WORD,levenstein,k_cst);
            if (nbkey > 0) {
              /*  !!!rmq: after weightresult, size of field = size_class_name */ 
              qsort(result,nbkey,size_class_name,str_cmp);
              if (abstract_mode != -2 && !brief_class) { //if not only abstract
				/* print the list of classes found */
                sprintf(longline,"\n<Classified groupe of %li keywords>\n",setnbkw+1); 
                printing(longline,1,999,rec);
                printing(result,nbkey,size_class_name,rec);
                printing("\n\n",1,999,rec); 
              }
              /*store the set_nb_best_result (or less) classes with the highest score in 'best_result' 
	            nb_best_result*size_class_name is pointing the position in best result*/
	            if ((nb_best_result+set_nb_best_result)*size_class_name < size_best_result) 
				{
					for (i=0;i<nbkey;i++)
					{
						if (i == set_nb_best_result) break;
						strcpy(best_result+nb_best_result*size_class_name,result+i*size_class_name);
						nb_best_result++; //count the nb of best result added
					}
				}
                else result_overflow++;
            } //endif nbkey
            else if (verbose) {
              sprintf(longline,"No group of %li keywords found\n",setnbkw+1);
              printing(longline,1,999,rec);
            }
          } 
          else {
            sprintf(longline,"No file %s\n",filename); 
            printing(longline,1,999,rec);
          }
        }
    }
  }  // End of the 2...n-grams occurence search
    
  /*                   <single keywords analyze>
  Search nb occurence for each keyword (single keyword routine)
  */
  if (debug) fprintf(stderr,"\nSTART SGL WORD ROUTINE\n"); //check pb
  if (dosinglekeyword) {
    nbkey=result_overflow=0;
    length=strlen(onlyonceword);
    for(i=0;i<length;i++) {
      if (onlyonceword[i]=='\n') {
        for(j=0;i+j+1<length;j++) {
          if (onlyonceword[j+i+1] != '\n') word[j]=onlyonceword[j+i+1];
          else {
            word[j]=0;
            strcpy(wordchk,"\n");
            strcat(wordchk,word);
            strcat(wordchk,"\n");
            k=0; //counter
            str_ptr=text;
            while ((str_ptr=strstr(str_ptr,wordchk)) != NULL) {
              k++;  //cnt same word found
              str_ptr+=strlen(wordchk); //to the end of the word found
            }
            if (strlen(word) > SIZE_WORD) word[SIZE_WORD]=0; //max 'SIZE_WORD' chars
            if (nbkey*SIZE_WORD > size_result) {  //realloc more memory for result
              size_result=(long int)(nbkey+1)*SIZE_WORD; //nb size of result for realloc
              if ((result=(char*)realloc(result,size_result))==NULL) errmalloc("in single keyw routine");
                else if (debug) fprintf(stderr,"Info:More memory allocated , result=%li\n",size_result);
              if ((trash=(char*)malloc(size_trash))==NULL) errmalloc("in single keyw routine - memory too low?");
              free(trash);
            }
	          /* nbkey*SIZE_WORD is an index */
            if (nbkey*SIZE_WORD < size_result) sprintf(result+nbkey*SIZE_WORD,"%4li:%s",k,word); //Store subresult here
              else result_overflow++; 
            i=i+j;
            nbkey++; //cnt nb subresult (occurence+keyword) added to result = nb of keyword found
            break;
          }
        }
      }
    } 
    
    if (debug) fprintf(stderr,"\nEND SGL WORD ROUTINE\n"); //check pb
    if (nbkey > 0) { //if word fount and stored in result
      if (result_overflow) {
	    ERRPOS
	    fprintf(stderr," Result var overflow in single keyw routine!\n\n");
	    count_silent_bug++;
	  }
      /* printsorted does several important things:
         - sort the result, the highest occurence to the lowest.
	 - filter the result before printing:
	     keeps occurence > mini and occurence > ratio * highest*occurence
	 - write the result in keyworder.build (for the learning)
	 Note: result is return sorted
      */
      printsorted(result,nbkey,SIZE_WORD,min,taux,1,(rec*showkeywords),builddico); //showkeywords==0 => no keywords print
      sprintf(longline,"\n< Nb of significant words=%li and nb of keywords=%li >\n",nbw,nbkey);
      if (showkeywords) printing(longline,1,999,rec);
      /* store single keyword for the classifier mode IV
      keywords are filtered to keep the most relevant
      a file is created in the same format as dictionnary
      */
      savesinglekeyword(result,nbkey,SIZE_WORD,excludedword,text_title,(showfilteredkeywords*rec));
      /* prepare the name of the dictionary: filename */
      sprintf(filename,"%s%s.%s.dic%i",path_dictionary,file_dictionary,lang,1);
      if (filesize(filename) > 0) {
        /* classify the text from the words found (bag of words method)
	      weightresult returns the number of class found */     
	      if (debug) fprintf(stderr,"\nStart Weightresult\n");
        nbkey=weightresult(filename,result,size_result,nbkey,SIZE_WORD,levenstein,k_cst);
        if (debug) fprintf(stderr,"\nEnd Weightresult\n");
        if (nbkey > 0) { //if class found
          /*  !!!rmq: after weightresult, size of field = size_class_name */ 
          if (debug) {
            fprintf(stderr,"\nStart Qsort\nResult before sorting:\n");
            for (i=0;i<nbkey;i++) fprintf(stderr,"R:%s\n",result+i*size_class_name);
          }
          if (nbkey > 1) qsort(result,nbkey,size_class_name,str_cmp);
          if (debug) fprintf(stderr,"\nEnd Qsort\n");
          if (abstract_mode != -2 && !brief_class) { //if not only abstracts
			/* print the list of classes found */
            printing("\n<Classified single keywords>\n",1,999,rec);
            printing(result,nbkey,size_class_name,rec);
          }
          /* If the distibution is wide the risk of wrong classification is important */
	        
			/*store the set_nb_best_result (or less) classes with the highest score in 'best_result' 
	        nb_best_result*SIZE_WORD is pointing the position in best result*/
			if ((nb_best_result+set_nb_best_result)*size_class_name < size_best_result) 
			{
				for (i=0;i<nbkey;i++)
				{
					if (i == set_nb_best_result) break;
					strcpy(best_result+nb_best_result*size_class_name,result+i*size_class_name);
					nb_best_result++; //count the nb of best result added
				}
			}
			else result_overflow++;
			singlekeywords_found=1;
        } //endif nbkey
        else {
	        printing("No single word class found\n",1,999,rec);
	        singlekeywords_found=0;
	      }
      }
      else {
        sprintf(longline,"No file %s\n",filename); 
        printing(longline,1,999,rec);
	      singlekeywords_found=0;
      }
    }  
  }  // End of the simple keyword (1-gram) search routine

  /*Determine the most relevant/probable class*/
  if (nb_best_result) { //if there's some results to analyse
	if (debug) fprintf(stderr,"\nSRCH 'class_probable' with analyze_result()\n"); //check pb
	/* =>mode possible 1 (grade) or 2 (s1) or 3 or 4,
	* mode 3 choose the best of S1 or grade 
	* mode 4 list compiled and sorted grades */
	if ( listofsummaries ) {
		mode_ar=4;
		class_probable_score = analyze_result(class_probable,result,best_result,nb_best_result,size_class_name,mode_ar);
	}
    else {
		mode_ar=4; //3 remplaced with 4
		class_probable_score = analyze_result(class_probable,result,best_result,nb_best_result,size_class_name,mode_ar);
	}
  }	
  else 
  {
    printf("No best class\n");
	strcpy(class_probable,"NONE");
	class_probable_score=0;
  }	
  if (class_probable_score > 100) ERRPOS;
  /*conclude the classification by displaying the most probable class*/  
  if ((rec & 1) == 1) {
  	printf("\n\n<Probable class=%i%%: %s>\n",class_probable_score,class_probable);
  }
  if ((rec & 2) == 2) {
    /* Open the file  */
    fp=fopen(file_output,"a");
    if (fp==NULL){
      fprintf(stderr,"Unable to create %s ->Exit!\n",file_output);
      exit(EXIT_FAILURE);
    }
    fprintf(fp,"\n\n<Probable class=%i%%: %s>\n",class_probable_score,class_probable);
    
    if (fclose(fp) != 0) {
	  ERRPOS
	  fprintf(stderr,"Error: fclose fp");
	  count_silent_bug++;
	}
  }
  
  /*Make a 'profile' of the text - class every n sentences*/
  //!!! bugged !!!
  if ((singlekeywords_found) && (histogram != 0)) {
    if (debug) fprintf(stderr,"\nCALL classfreqevol()\n"); //check pb
    classfreqevol(filename,text,pos_sentence,nbl,histogram,rec);
  }

  /* search main information in list of summaries */
  if ( listofsummaries ) {
	/* Use the list of keywords and the cue words to extract 
	 * the interesting sentences.
	 */
	//file_keyw is the file containing the keywords, "skws" is the class name
	//prepare filename the file containing the cue words
	sprintf(filename,"%s%s.%s.dicA",path_dictionary,file_dictionary,lang);

	if ( *list_targets == '\0' )
		/* default label */
		strcpy(list_targets,"business");
	if ( strstr(list_targets,"*all*") ) {
		*list_targets='\0';
		/* extract the labels of the cue words dictionary and make a list */
		listlabels(list_targets,filename,size_class_name);
	}
	/* we're ready */
	i=0;
	while ( (i=foreachstr(target,list_targets,",;",size_class_name,i)) ) {
		StripSpace(target);
		nbw_abstract=sentencematchcucl( file_abstract1,file_keyw,filename,
										text,pos_sentence,
										10,5,rec,"skws",target, target );
	}
  }
  
  /* summarize the text */
  if ( abstract_mode && !listofsummaries ) {
	  /* smartdecision tries to select the best abstract method */
	  if (debug) fprintf(stderr,"\nCALL smartdecision()\n"); //check pb
	  smartdecision(file_bilan_abstr,&abstract_mode,&abstract_rate,target,class_probable,class_probable_score,nb_best_result,nbtw,nbl);
	  if (verbose) printf("\nAbstract mode: %i Compression: %i\n",abstract_mode,abstract_rate);
	  /*
		 Make the abstracts by extraction, 2 algorithms:
		  - sentencematchclass, need the most relevant / probable class
		  - sentencematchcue, need cue expression
		 and a combination of both sentencematchclass and sentencematchcue
		 Modes I: xxxxxxx1 II: xxxxxx1x III: xxxxx1xx IV: xxxxx11x
	  */
	  
	  if (isofile) strcpy(file_input,file_iso); //work with iso8859 text
		
	  if ((abstract_mode & 1) == 1) { // search sentences that match single keywords from the text
		if (debug) fprintf(stderr,"\nCALL sentencematchclass()\n"); //check pb

		if ((abstract_mode & 8) == 8) { // search sentences that match single keywords from the text	
		  nbw_abstract=sentencematchclass(file_abstract1,file_keyw,text,pos_sentence,nbl,abstract_rate,0,"skws","abstract I");
		  storeforsmartdecision(file_bilan_abstr,nb_best_result,class_probable,class_probable_score,nbtw,nbl,abstract_rate,nbw_abstract,1);
		  if (nbw_abstract > 50) made_abstract=1;
		  sprintf(filename,"%s%s.%s.dicB",path_dictionary,file_dictionary,lang); //remove 'empty' words
		  nobrokenwood(file_abstract1,file_abstract1,filename,rec,"abstract I bis");
		} 
		else {
		  nbw_abstract=sentencematchclass(file_abstract1,file_keyw,text,pos_sentence,nbl,abstract_rate,rec,"skws","abstract I");
		  storeforsmartdecision(file_bilan_abstr,nb_best_result,class_probable,class_probable_score,nbtw,nbl,abstract_rate,nbw_abstract,1);
		  if (nbw_abstract > 50) made_abstract=1;
		}

		if ((made_abstract && abstract_mode & 4) == 4) { //search cue_expressions on second abstract (mode 2+4)	
		  if (debug) fprintf(stderr,"\nCALL sentencematchcue()\n"); //check pb
		  nbw_abstract=sentencematchcue(file_abstract5,file_abstract1,filename,text,nbl,abstract_rate,rec,"abstract V",target);
			storeforsmartdecision(file_bilan_abstr,nb_best_result,class_probable,class_probable_score,nbtw,nbl,abstract_rate,nbw_abstract,5);
		}
	  }

	  if (singlekeywords_found) { // search sentences that match text class
		if ((abstract_mode & 2) == 2) {
			if (debug) fprintf(stderr,"\nCALL sentencematchclass()\n"); //check pb
			
			if ((abstract_mode & 8) == 8) { // remove 'empty words'
			  nbw_abstract=sentencematchclass(file_abstract2,filename,text,pos_sentence,nbl,abstract_rate,0,class_probable,"abstract II");
			  storeforsmartdecision(file_bilan_abstr,nb_best_result,class_probable,class_probable_score,nbtw,nbl,abstract_rate,nbw_abstract,2);
			  if (nbw_abstract > 50) made_abstract=1;
			  sprintf(filename,"%s%s.%s.dicB",path_dictionary,file_dictionary,lang); //filename is the dico for the lang
			  nobrokenwood(file_abstract2,file_abstract2,filename,rec,"abstract II bis");
			} 
		  else {
			  nbw_abstract=sentencematchclass(file_abstract2,filename,text,pos_sentence,nbl,abstract_rate,rec,class_probable,"abstract II");
			  storeforsmartdecision(file_bilan_abstr,nb_best_result,class_probable,class_probable_score,nbtw,nbl,abstract_rate,nbw_abstract,2);
			  if (nbw_abstract > 50) made_abstract=1;
			}

		  if (made_abstract && (abstract_mode & 4) == 4) { //search cue_expressions on second abstract (mode 2+4)
			sprintf(filename,"%s%s.%s.dicA",path_dictionary,file_dictionary,lang);
			if (debug) fprintf(stderr,"\nCALL sentencematchcue()\n"); //check pb
			nbw_abstract=sentencematchcue(file_abstract6,file_abstract2,filename,text,nbl,abstract_rate,rec,"abstract VI",target);
			storeforsmartdecision(file_bilan_abstr,nb_best_result,class_probable,class_probable_score,nbtw,nbl,abstract_rate,nbw_abstract,6);
		  }	  
		  }  
	  }

	  /* !!! sentencematchcue detroys the content of the buffer '*text' */
	  if (abstract_mode == 4) {  //search cue_expressions on temp_file (converted)
		sprintf(filename,"%s%s.%s.dicA",path_dictionary,file_dictionary,lang); //filename is the dico for the lang
		if (debug) fprintf(stderr,"\nCALL sentencematchcue()\n"); //check pb
		nbw_abstract=sentencematchcue(file_abstract4,file_input,filename,text,nbl,abstract_rate,rec,"abstract IV",target);
		  storeforsmartdecision(file_bilan_abstr,nb_best_result,class_probable,class_probable_score,nbtw,nbl,abstract_rate,nbw_abstract,4);
		if (nbw_abstract > 50) made_abstract=1;
		
		if (made_abstract && (abstract_mode & 8) == 8) { // remove 'empty words'
		  sprintf(filename,"%s%s.%s.dicB",path_dictionary,file_dictionary,lang); //filename is the dico for the lang
		  nobrokenwood(file_abstract4,file_abstract4,filename,rec,"abstract IV bis");
		}  	
	  }
	  
	  /* When text is too short it doesn't give a summary
	  Here we provide only a small compression level */
	  if (!made_abstract || abstract_mode == 8) { // remove 'empty words, deadwood expressions...'
		sprintf(filename,"%s%s.%s.dicB",path_dictionary,file_dictionary,lang); //filename is the dico for the lang
		nobrokenwood(file_abstract2,file_input,filename,rec,"abstract O");
	  }  	
  } //end of if abstract_mode

  /*Release memory before leaving*/
  if (debug) fprintf(stderr,"\nRELEASE MEMORY\n"); //check pb
  free(onlyonceword); free(result); free(text); free(longline); 
  free(excludedword); free(best_result); free(pos_sentence);
  /* Tail of the builddico file */  
  if (builddico) {
    /* Open file - record tail - close file */
    fp=fopen(file_builddico,"a");
    if (fp==NULL){
	  ERRPOS
      fprintf(stderr,"Unable to reopen %s ->Exit!\n",file_builddico);
      exit(EXIT_FAILURE);
    }
    fprintf(fp,"\n< End analyze >\n");
    if (fclose(fp) != 0) {
	  ERRPOS
	  fprintf(stderr,"Error: fclose fp");
	  count_silent_bug++;
	}
  }
  
  /*get time - compute duration in second*/
  time(&now_again);
  duration_job=difftime(now_again,now);
  if ((rec & 1) == 1) {
	  printf("\n<Text signature:%s>\n",hash_str);
	  printf("<Computation time %.0f sec>\n",duration_job);
  }
  
  if ((rec & 2) == 2) {
    /* Open the file  */
    fp=fopen(file_output,"a");
    if (fp==NULL){
	  ERRPOS
      fprintf(stderr,"Unable to create %s ->Exit!\n",file_output);
      exit(EXIT_FAILURE);
    }
	fprintf(fp,"\n<Text signature:%s>\n",hash_str);
    fprintf(fp,"<Computation time %.0f sec>\n",duration_job);
    fprintf(fp,"<End Analyze>\n");
    if (fclose(fp) != 0) {
	  ERRPOS
	  fprintf(stderr,"Error:fclose fp");
	  count_silent_bug++;
  } }

  if (!debug) {
    /*delete temporary files*/
    strcpy(filename,path_output_files);
    strcat(filename,"text_ansi7.temp");
    remove(filename);
    strcpy(filename,path_output_files);
    strcat(filename,"singlekeys.temp");
    remove(filename);
    strcpy(filename,path_output_files);
    strcat(filename,"iso8859.temp");
    remove(filename);
  }
  
  /* the job is done */
  if (count_silent_bug) printf("\n<WARNING!!! %i SILENT BUGS>\n",count_silent_bug);
  printf("\n-=-=-END-=-=-\n");
  if (wait_key) {
    printf("Enter any chars and press return to exit!");
    char *answer;
    scanf("%s",answer);
  }
  return 0;
 /* end main */
}

/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
JP Redonnet - August 30 2008
Last rev. August 2010
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
Copyright: This program is released both under the GNU public license 
and under a commercial license.
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
Features:
- Convert html to text
- Make some statistic on the text.
- Evaluate readability.
- Estimate reading time.
- Extract keywords (single and groups) in a text.
- Class the text (use the linear classifier method).
- Make abstracts (need to be improved)
and much more...

Work alone in command line or can be called by a graphic frontend prog
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
Compilation,assembly,linking: make 

Rmq: increase SIZE_WORD in large memory (10*nb_words_in_group)

Exec: texlexan [options] <input  file>
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
Bugs: 
      !!! when realloc more memory => err in result and weightresult()
      memory alloc to low may give wrong result without warning!
      does not realloc correctly more memory when needend (it's required 
      for text,onlyonceword)
      if dico directory is wrong => crash
 
Pb:
      Abreviations dot is view as the end of sentence

Stupidities: plenty

Limitations: 
             syllablesstat[0] gives the number of things without vowel like 1,2,3...
             Flesh readabiliy calculation only english and french implemented
             utf8 conversion in ansi 7bits is limited to the second byte
             conversion utf8 and iso8859 incomplete
             size_class_name limites the size of the class name
             size_nb_class limites the number of classes
             SIZE_WORD is the main limitation of nb of words in group of keyword
             the upper average size of a word is 8 chars (9 with the delimiter)
             so roughly SIZE_WORD/10 = nb of words in one group
             (will be better to malloc word and wordchk ???)
             Larger SIZE_WORD requires larger memory alloc for result
	     
if comment: !!!limitation then increase these values if ram > 128Mo

Futur:

    - Paragraph detection in classfreqevol -> histogram / paragraph
    - Recusive analyze of weighed result (tree analyze)
    - Soundex for fuzzy matching
    - Hash table for faster match ?
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
Files:

Excluded words file name: excluded.lan.word
Basic words file name: basic.lan.word
Excluded/basic words structure: word1;word2;word3\nword4;...wordi\n
separators are ';' '/' '\n'   A comment line starts with '#'

Dictionnary file name: keyworder.lan.dicN
Dictionnary structure: Class Label:/W1\KeyWord1/W2\KeyWord2/..../
Weight = single digit between / and \
KeyWord = single word or grp of words between \ and /
Class = Number 1...32000
Label = Name of the class (max 'size_class_name' chars)
Weight = single digit 0,1...9,A...,Z (0...35)
Wordx = Words in the class

Abstracts file: abstractN.txt (N=1...n)
Abstracts format: basic ansi 7bits text format '\n' as eol

Result file: keyworder.out
Result format: basic ansi 7bits text format '\n' as eol
It's almost a screen copy of the results diplayed

Keyterms list & text info file: keyworder.build
Used by the learning/training program 'buildkeybase'
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
Note/Memo: 
  long int is used as memo in case of need to upgrade to 'long long int' for very huge big text and dico!
  On 32bits processors long int = int = 4bytes  values= -/+ 2x10^9 
  C-99 allows dynamic array[i]
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
 =>Last major corrections, modifications or adds:
 2009/02/12   added: html detection & basic conversion to text
 2009/02/18   added: savesinglekeyword makes a dictionary from the significant keywords extracted from the text
              added: title extraction from html file and upgrade weight
	      	  added: basic pipe from shell
	      	  modified: excluded.word file separator can be ; / or \n
	      	  modified: in sentencematchclass, score_table[] replaces multiple comparisons
 2009/02/25   source has been splited for a better readeability and maintenability
              added: formatage of filtered keywords list
 2009/03/02   toansi7b(): convert iso8859-1/15 char in ansi7 (accents are converted)
              utf8toansi(): convert file in ansi and iso
	      	  abstract routines modified to output accents
 2009/03/16   added: option -b /-B (for the learner engine)
 2009/04/01   added: nodeadwood() make summary clear of empty expressions
 2009/11/22	  added: cnt nb of newline (\n) and create a text signature
 2009/12/05   added: sentiment extraction
 2010/01/05   added: analyse the list of summaries (very experimental)
 
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/
