/* License/copyright: Dual license, read copyright.txt*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>
#include <unistd.h>
#include <time.h>
#include "utils.h"
#include "help.h"
#include "definitions.h"
#include "languages.h"
#include "analyses.h"

extern int debug;
extern int verbose;
extern char lang[];
extern long int size_line;
extern long int size_class_name;
extern long int size_nb_class;
extern char file_input[]; //SIZE_WORD
extern char file_output[];
extern int count_silent_bug;

/* --------- functions of analyze 'result' --------- */
/* keywords and their occurences are extracted one by one from result 
 * each keyword are searched in the dictionnary, a class and the probability 
 * the keyword belongs the class is returned. 
 * The product occurence x probability gives the weight of the keyword
 * A keyword can belong several classes with different probabilities
 */
long int weightresult(char *file,char *result,long int size_result,int nb,int width,int levenstein,int k_cst) {
/*Use dictionary to class word*/
  FILE *fp;
  char *line; /*line limited at 'size_line' chars*/
  char *str_ptr,*str_ptr1,*str_ptr2;
  char word[size_class_name];
  int *class_sum1,*class_sum2,*class_sum3; //'size_nb_class' classes
  char **classname; //'size_nb_class*size_class_name' chars
  int *classconstant;
  long int i,j,gross_sum=0;
  int k,cont,val,val2;
  char shortline[SHORT_STR];  
  char crush_detect='x';
  char *crush_detect_heap;

  if (strlen(result) == 0) {
	  printf("\nNothing to do!\n");
	  return 0;
  }

  fp=fopen(file,"r");
  if (fp==NULL){
    ERRPOS
    fprintf(stderr,"Error:Unable to open %s ->Exit!\n",file);
    exit(EXIT_FAILURE);
  }

  /*Search value size_line fordynamic alloc of line*/  
  size_line=SIZE_LINE;
  fseek(fp,0,SEEK_SET);
  for(i=0;i<10;i++) { //search only in the 10 first lines
    if (fgets(shortline,SHORT_STR,fp) == NULL) break; //eof exit loop
    if (shortline[0] == '#') {
      if ((str_ptr1=strstr(shortline,"<LINE_LG:")) != NULL) {
        if ((str_ptr2=strchr(str_ptr1+9,'>')) != NULL) {
	  *str_ptr2='\0';
	  size_line=atoi(str_ptr1+9);
	  if (debug>1) fprintf(stderr,"\nsize_line is set at %li\n",size_line);
  } } } }
  
  /*dynamic alloc*/
  if ((line = (char*)malloc(size_line)) == NULL) errmalloc("weightresult");
  if ((classname = (char**)malloc(size_nb_class*sizeof(char*))) == NULL) errmalloc("weightresult");
  for (k=0;k<size_nb_class;k++) if ((classname[k] = (char*)malloc(size_class_name)) == NULL) errmalloc("weightresult");
  if ((classconstant = (int*)malloc(size_nb_class*sizeof(int))) == NULL) errmalloc("weightresult");
  if ((class_sum1 = (int*)malloc(size_nb_class*sizeof(int))) == NULL) errmalloc("weightresult");
  if ((class_sum2 = (int*)malloc(size_nb_class*sizeof(int))) == NULL) errmalloc("weightresult");
  if ((class_sum3 = (int*)malloc(size_nb_class*sizeof(int))) == NULL) errmalloc("weightresult");
    
  for(i=0;i<size_nb_class;i++) { 
	  classconstant[i]=0; 
	  class_sum1[i]=0;
	  class_sum2[i]=0; 
	  class_sum3[i]=0;
  }

  crush_detect_heap=strdup("x    "); //unreliable
  
  /* load classname array and classconstant */  
  fseek(fp,0,SEEK_SET);
  for(i=0;i<size_nb_class;i++) {
    line[size_line-1]='\0';
    if (fgets(line,size_line,fp) == NULL) break; //!!!pb if line>size_line
    if (line[size_line-1] != '\0') { 
	  ERRPOS
	  fprintf(stderr,"Pb size_line too small in weightresult\n"); 
	  exit(EXIT_FAILURE); 
	}
    if (line[0] != '#') {
      if ((str_ptr2=strchr(line,':')) != NULL) *str_ptr2='\0';
      else {
	    ERRPOS
	    fprintf(stderr," ':' not found weightresult\n"); 
		exit(EXIT_FAILURE);
	  }
      if ((str_ptr1=strchr(line,' ')) == NULL) {
	    ERRPOS
	    fprintf(stderr," ' ' missing in  weightresult"); 
		exit(EXIT_FAILURE);
	  }
      if ( str_ptr2-str_ptr1 > size_class_name ) {
	    ERRPOS
	    fprintf(stderr," Label too long in weightresult:<%s>\n",line); 
		exit(EXIT_FAILURE);
	  }
      *str_ptr1='\0'; //delimite the class_number  class_number->j
      if ( (j=atoi(line))!=0 && j < size_nb_class ) {
		  strncpy(classname[j],1+str_ptr1,str_ptr2-str_ptr1);
		  classname[j][str_ptr2-str_ptr1]='\0';
		  str_ptr2++;
		  if (isdigit(*str_ptr2)) { //old version dico haven't cst
		    /* affect cst value to S1, and cumul of S1 */
			classconstant[j]=(*(str_ptr2)+48)*k_cst;
			class_sum1[i]=classconstant[i];
			gross_sum+=classconstant[i];
		  }
		  else
		    classconstant[j]=0;
	  }
      else {  //should never occure
	    ERRPOS
	    fprintf(stderr," atoi(line):<%s> or j:<%li>\n",line,j); 
		exit(EXIT_FAILURE);
	  }
    }
  }
    
  /*search word in the dico with levenstein() */
  if (levenstein > 0) {
    j=nb*width;
    for(i=0;i<j;i+=width) {
      /*Extract val*/
      strcpy(word,result+i);
      if ((str_ptr=strpbrk(word,":")) != NULL) *str_ptr=0;
      if (atoi(word)==0) {
	    ERRPOS
	    fprintf(stderr," atoi(word) in weightresult.\n"); 
		exit(EXIT_FAILURE);
	  }
      else val=atoi(word); //freq
      /*Now extract word*/
      if ((str_ptr=strpbrk(result+i,":")) != NULL) {
        strcpy(word,str_ptr+1);
        noplural(word,lang); //chg plural to singular
        fseek(fp,0,SEEK_SET);
        cont=1;
        /*Read each line of the dico*/
        while(cont==1) {
          if (fgets(line,size_line,fp) == NULL) cont=0; //!!!pb if line>size_line
          else if (line[0] != '#') {  
            /* Search for "word" in the line
			 * this part could treated in // easily ? 
			 * Of course, levenshtein is very expensive
			 */
            if ((str_ptr1=strlevenstr(strpbrk(line,":/"),word,'\\','/',levenstein)) !=NULL) {
              /*convert single digit val*/
              val2=chartoi(*(str_ptr1-2)); //str_ptr1 points the word   val2:weight
              if ((str_ptr2=strpbrk(line," ")) != NULL) *str_ptr2=0; //index class_
              class_sum1[atoi(line)]+=val*val2; //S1, score=sum(freq*weight)
              class_sum2[atoi(line)]+=val2; //S2, score=sum(weight)
              class_sum3[atoi(line)]++; //S3, score=sum(nb words)
              gross_sum+=val*val2;      
  } } } } } }
  /*basic search with strstr()*/
  else {
    j=nb*width;
    for(i=0;i<j;i+=width) {
      /*Extract val*/
      strcpy(word,result+i);
      if ((str_ptr=strpbrk(word,":")) != NULL) *str_ptr=0;
      if (atoi(word)==0) {
	    ERRPOS
	    fprintf(stderr," atoi(word) in weightresult.\n"); 
		exit(EXIT_FAILURE);
	  }
      else val=atoi(word);
      /*Now extract word*/
      if ((str_ptr=strpbrk(result+i,":")) != NULL) {
        strcpy(word,"\\"); /*first delimiter*/
        strcat(word,str_ptr+1);
        noplural(word,lang); //chg plural -> singular
        strcat(word,"/"); /*last delimiter*/
        fseek(fp,0,SEEK_SET);
        cont=1;
        /*Read each line of the dico*/
        while(cont==1) {
          if (fgets(line,size_line,fp) == NULL) cont=0; //!!!pb if line<size_line
          else if (line[0] != '#') {  
            /* Search for "\word/" in the line
			 * => this part could  be treated in // easily 
			 * strstr is easy but expensive if line is long 
			 */
            if ((str_ptr1=strstr(strpbrk(line,":"),word)) !=NULL) {
              /*convert single digit val*/
              val2=chartoi(*(str_ptr1-1)); //str_ptr1 points the '\'
              if ((str_ptr2=strpbrk(line," ")) != NULL) *str_ptr2=0; //index class_
              class_sum1[atoi(line)]+=val*val2;  //S1, score=sum(freq*weight)
              class_sum2[atoi(line)]+=val2;  //S2, score=sum(weight)
              class_sum3[atoi(line)]++;  //S3, score=sum(nb words)
              gross_sum+=val*val2;
  } } } } } } 
    
  if (fclose(fp) != 0) {
    ERRPOS
    fprintf(stderr," Error fclose fp\n"); 
    exit(EXIT_FAILURE);
  }
  /*Do result report   !!!rmq: size of field = size_class_name */ 
  j=0;
  for(i=0;i<size_nb_class;i++) 
    if (class_sum3[i]>0) { //if sum3>0 words found in the class i then do result
      if (j*size_class_name > size_result) { //more results (j) than room available
	      ERRPOS
	      fprintf(stderr," Memory  overflow %li is > %li (increase size_result)\n",j*size_class_name,size_result); 
	      fprintf(stderr,"Class skipped:%s\n",classname[i]);
	      count_silent_bug++;
	    }
	    else {
        /*!!!Note: analyze_result() is strongly dependant of the format below*/
        sprintf(result+j*size_class_name,
			"Grade:%4li%% S1:%7i S2:%7i S3:%5i class: %s\n",
			100*class_sum1[i]/gross_sum,
			class_sum1[i],
			class_sum2[i],
			class_sum3[i],
			classname[i]);
        j++; //cnt class found
      }
    }
  //release memory
  free(line);
  for (k=0;k<size_nb_class;k++) free(classname[k]);
  free(classname);
  free(classconstant);
  free(class_sum1);
  free(class_sum2);
  free(class_sum3);
  //try to detect overflow
  if (crush_detect!='x' || crush_detect_heap[0]!='x') {
    ERRPOS
    fprintf(stderr,"Overflow\n");
    count_silent_bug++;
  }
  free(crush_detect_heap);
  return j; //return the number of class
}

/*---------- analyze best_result -----------------------*/
int analyze_result(char *class_probable,char *result,char *best_result,int nb,int width,int method) {
/*
 class_probable contains the class_name with the highest grade
 analyze_result point the best result (Grade...class)
 Used to conclude with the most probable class for the results
 Required for sentencematchclass() 'abstract'
*/
char *str_ptr;
int i,j,index_bestA,index_bestB,updated;
char class_name[size_class_name];
char grade_text[TINY_STR]; //confortable size, I should not to have to take care
int grade_val,s1_val,bestA,bestB,cumul_grade;
int index_array=0;                      //last position in the array
char name_array[nb+1][size_class_name]; //array of class name
int score_array[nb+1];                  //array of scores (grade or s1)
int grade_array[nb+1];                  //array of grades
int cnt_array[nb+1];                    //array of occurence of class
char crush_detect='x';
char *crush_detect_heap;
int proba_val;
int synthetic_score;
char bestresultcompiled[size_class_name*nb]; //best_result compiled and sorted
  
  crush_detect_heap=strdup("x    "); 

  /* Basic analyze on the grades, affect: score=grade */  
  if (method == 1) {  
    for(i=0;i<nb;i++) { //scan best_result line/line
      strncpy(grade_text,7+strstr(best_result+i*width,"Grade:"),3);
	  grade_text[3]='\0';
      grade_val=atoi(grade_text);
	  if (grade_val<0 || grade_val>100) ERRPOS;
      strcpy(class_name,7+strstr(best_result+i*width,"class:"));
      if ((str_ptr=strchr(class_name,'\n')) != '\0') *str_ptr='\0'; //remove eol
      /*Search if class_name exist in name_array
      if yes only update the grade*/
      updated=0;
      for(j=0;j<index_array+1;j++) {
        if (strcmp(name_array[j],class_name) == 0) {
          /*update existing*/
          score_array[j]+=grade_val; //cumul grade
          grade_array[j]+=grade_val; //cumul grade
	        cnt_array[j]++; //nb time class_name incremented
	        updated=1; //grade has been updated
	        break;
        } 
      }
      if (updated == 0) {
        /*class_name does not exist in name_arrayadd, so add it*/
        strcpy(name_array[index_array],class_name); //add class_name
        score_array[index_array]=grade_val; //add its grade
        grade_array[index_array]=grade_val; //add its grade
        cnt_array[index_array]=1; //first time class_name is seen
        if (index_array < nb) index_array++;
	      else {
		      ERRPOS
	        fprintf(stderr,"\nError in analyze_result\n");
	        count_silent_bug++;
	      }
      }
    }
  } 
  /* Basic analyze on s1 (weighed scores), affect: score=s1 */
  else if (method > 1) 
  {  
    for(i=0;i<nb;i++) {
      strncpy(grade_text,7+strstr(best_result+i*width,"Grade:"),3);
	  grade_text[3]='\0';
      grade_val=atoi(grade_text);
	  if (grade_val<0 || grade_val>100) ERRMSG(("Err=%s\n"),(grade_text));
      strncpy(grade_text,3+strstr(best_result+i*width,"S1:"),7);
	  grade_text[7]='\0';
      s1_val=atoi(grade_text);
	  if (s1_val<0) ERRMSG(("Err=%s\n"),(grade_text));
      strcpy(class_name,7+strstr(best_result+i*width,"class:"));
      if ((str_ptr=strchr(class_name,'\n')) != '\0') *str_ptr='\0'; //remove eol
      /*Search if class_name exist in name_array
      if yes only update the grade*/
      updated=0;
      for(j=0;j<index_array+1;j++) {
        if (strcmp(name_array[j],class_name) == 0) {
          /*update existing*/
          score_array[j]+=s1_val; //cumul score S1
          grade_array[j]+=grade_val; //cumul grade
	        cnt_array[j]++; //nb time class_name incremented
	        updated=1; //grade has been updated
	        break;
        } 
      }
      if (updated == 0) {
        /*class_name does not exist in name_arrayadd, so add it*/
        strcpy(name_array[index_array],class_name); //add class_name
        grade_array[index_array]=grade_val; //add its grade
        score_array[index_array]=s1_val; //add its score S1
        cnt_array[index_array]=1; //first time class_name is seen
        if (index_array < nb) index_array++;
	    else {
	        ERRPOS
	        fprintf(stderr,"\nError #1 in analyze_result\n");
	        count_silent_bug++;
	    }
      }
    }
  }
  
  /* Sort the compiled score & grade */
  if (method == 4) {
	  /* prepare compiled results */
	  for(j=0;j<index_array;j++) {
		synthetic_score=score_array[j]*grade_array[j];
		sprintf(bestresultcompiled+j*size_class_name,"%7i:Grade:%4i%% Class: %s",synthetic_score,grade_array[j]/cnt_array[j],name_array[j]);
	  }
	  /* sort */	
	  qsort(bestresultcompiled,index_array,size_class_name,str_cmp);
	  /* print */
	  printf("\n<List of probables classes>\n");
	  for(j=0;j<index_array;j++) {
		if ( (str_ptr=strchr(bestresultcompiled+j*size_class_name,':')) ) {
			printf("%s\n",str_ptr+1);
		}
		else ERRPOS;
	  }
	  printf("\n");
  } 
  
  /* Methods 1,2,3,4 need the highest cumul of score and the higest cumul of grade*/
  if (method > 0) {
   if (debug) 
      for(j=0;j<index_array;j++) fprintf(stderr,"%i Best Class Name:%s Score:%i Grade:%i Cnt:%i\n",j,name_array[j],score_array[j],grade_array[j],cnt_array[j]);    
    /*sequencial search for the highest score*/
    bestA=bestB=cumul_grade=0;
    index_bestA=-1;
	index_bestB=-1;
    for(j=0;j<index_array;j++) {
      cumul_grade+=grade_array[j]; //used to return the 'probability'
      if (score_array[j] > bestA) {
		  bestA=score_array[j];
		  index_bestA=j;
      }
	  if (grade_array[j] > bestB) {
		  bestB=grade_array[j];
		  index_bestB=j;
      }
    }//end sequencial search
	
	proba_val = grade_array[index_bestA]/cnt_array[index_bestA];
	strcpy(class_probable,name_array[index_bestA]); //cpy the best class
	
	/* choose the most robust grading */
	if ( method == 3 || method ==4 ) {
		/* compute average proba */
		proba_val = grade_array[index_bestA]/cnt_array[index_bestA];
		/* risk is acceptable? */
		if ( proba_val < 63 ) { 
			/* no: check if grade gives a more robust decision */
			if ( grade_array[index_bestB]/cnt_array[index_bestB] > proba_val)
			{
				proba_val = grade_array[index_bestB]/cnt_array[index_bestB];
				strcpy(class_probable,name_array[index_bestB]); //cpy the best class
			}
		}
	}
	
    if (index_bestA == -1 || index_bestB == -1) {
	    ERRPOS
	    fprintf(stderr,"\nError #2 in analyze_result\n"); 
	    exit(EXIT_FAILURE);
	}
    
	if (proba_val<0 || proba_val>100) ERRPOS;
	//try to detect overflow (works sometime)
	if (crush_detect!='x' || crush_detect_heap[0]!='x') {
		ERRPOS
		fprintf(stderr,"Overflow\n");
		count_silent_bug++;
	}
	free(crush_detect_heap);	
    return  proba_val; //job is done, return proba (100: max)
  }
        
  /*DEFAULT METHOD: sort to put but the best score in the top*/
  qsort(best_result,nb,width,str_cmp);
  /*Just take the first = the best grade => supposed the most probable class*/
  strcpy(class_probable,7+strstr(best_result,"class:"));
  //try to detect overflow
  if (crush_detect!='x' || crush_detect_heap[0]!='x') {
    ERRPOS
    fprintf(stderr,"Overflow\n");
    count_silent_bug++;
  }
  free(crush_detect_heap);
  return 0; //job is done default
}

/* --------- functions of analyze 'text' --------- */
long int classfreqevol(char *file,char *text,long int *pos_sentence,int nbl,int histogram,int rec) {
/* freq  of classes along the text
 p1,classi:freqN,...,classj:freqN,p2,... */
  FILE *fp,*fp1;
  char *line; /*line limited at 'size_line' chars*/
  char *str_ptr1,*str_ptr2;
  char word[size_class_name],wordchk[size_class_name+2];
  int *class_sum,*class_diff; //'size_nb_class' classes
  char **classname; //'size_nb_class*size_class_name' chars
  long int i,j,length;
  int cont,val;
  char shortline[255];
  int prt_thresh;
  long int k,line_cnt; //count lines
  char crush_detect='x';
  char *crush_detect_heap;
  
  
  if (histogram > 0) prt_thresh=nbl/histogram; //histogram is the nb of slices
    else prt_thresh=histogram*-1;  //histogram is the nb of lines

  fp=fopen(file,"r");
  if (fp==NULL){
    ERRPOS
    fprintf(stderr,"Error:Unable to open %s ->Exit!\n",file);
    exit(EXIT_FAILURE);
  }
  
  /*Search value size_line for dynamic alloc of line*/  
  size_line=SIZE_LINE;
  fseek(fp,0,SEEK_SET);
  for(i=0;i<10;i++) { //search only in the 10 first lines
    if (fgets(shortline,255,fp) == NULL) break; //eof exit loop
    if (shortline[0] == '#') {
      if ((str_ptr1=strstr(shortline,"<LINE_LG:")) != NULL) {
        if ((str_ptr2=strchr(str_ptr1+9,'>')) != NULL) {
	  *str_ptr2='\0';
	  size_line=atoi(str_ptr1+9);
	  if (debug>1) fprintf(stderr,"\nsize_line is set at %li\n",size_line);
  } } } }
  
  /*dynamic alloc*/
  if ((line = (char*)malloc(size_line)) == NULL) errmalloc("classfreqevol");  
  if ((classname = (char**)malloc(size_nb_class*sizeof(char*))) == NULL) errmalloc("classfreqevol");
  for (k=0;k<size_nb_class;k++) if ((classname[k] = (char*)malloc(size_class_name)) == NULL) errmalloc("classfreqevol");
  if ((class_sum = (int*)malloc(size_nb_class*sizeof(int))) == NULL) errmalloc("weightresult");
  if ((class_diff = (int*)malloc(size_nb_class*sizeof(int))) == NULL) errmalloc("weightresult");
  
  if ((length=strlen(text)) == 0) return 0;
  for(i=0;i<size_nb_class;i++) { class_sum[i]=0; class_diff[i]=0; }

  crush_detect_heap=strdup("x    ");
  
  if ((rec & 2) == 2) {
    /* Open the file  */
    fp1=fopen(file_output,"a");
    if (fp1==NULL){
	  ERRPOS
      fprintf(stderr,"Error:Unable to open %s ->Exit!\n",file_input);
      exit(EXIT_FAILURE);
    }
    fprintf(fp1,"\n< Histogram >\n");
  }
  if ((rec & 1) ==1) printf("\n< Histogram >\n");

  /*do the classname array*/  
  fseek(fp,0,SEEK_SET);
  for(i=0;i<size_nb_class;i++) {
    line[size_line-1]='\0';
    if (fgets(line,size_line,fp) == NULL) break;
    if (line[size_line-1] != '\0') {
	  ERRPOS
	  fprintf(stderr,"pb size_line too small\n");
	  count_silent_bug++;
	}
    if (line[0] != '#') {
      if ((str_ptr2=strpbrk(line,":")) != NULL) *str_ptr2=0;
      if (strlen(line) < size_class_name) strcpy(word,line);
      else {
	    ERRPOS
	    fprintf(stderr,"Err label too long in classfreqevol:<%s>\n",line);
	    count_silent_bug++;
	  }
      if ((str_ptr2=strpbrk(line," ")) != NULL) *str_ptr2=0;
      if ((j=atoi(line))!=0) strcpy(classname[j],word);
      else {
	    ERRPOS
	    fprintf(stderr,"E1 Err atoi(line) classfreqevol:<%s>\n",line);
	    count_silent_bug++;
	  }
    }
  }
  
  k=line_cnt=0;
  for(i=0;i<length;i++) {    //scan each char of the text
    if (text[i]=='\n') {     //new word
      for(j=0;i+j+1<length;j++) {   //scan the word
        if (text[j+i+1] != '\n') word[j]=text[j+i+1];  //store the word
          else {   //end of word
            word[j]=0;  //end of chain
            if (strcmp(word,"EOS") != 0) {  //it isn't an end-of-sentence marker
              noplural(word,lang); //plural -> singular
              strcpy(wordchk,"\\"); //first delimiter
              strcat(wordchk,word); //wordchk will be used in the search
              strcat(wordchk,"/"); //last delimiter
	      if (debug>1) fprintf(stderr,"%s",wordchk);
              fseek(fp,0,SEEK_SET);
              cont=1;
              /*Now search class : Read each line of the dico*/
              while(cont==1) {
                if (fgets(line,size_line,fp) == NULL) cont=0;
                else if (line[0] != '#') {  
                  /*Search /word/ in the line*/
                  if ((str_ptr1=strstr(strpbrk(line,":"),wordchk)) !=NULL) {
                    /*convert single digit val*/
                    val=chartoi(*(str_ptr1-1));
                    if ((str_ptr2=strpbrk(line," ")) != NULL) *str_ptr2=0;
                    class_sum[atoi(line)]+=val;
                    class_diff[atoi(line)]++;	    
                  }
                }
              }
            } else {
	      k++;  //k counts line but reset to 0 when == prt_thresh
	      line_cnt++; //no reset  =>line_cnt points the end of each sentence
	    }
            /*Histogram val = nb slices*/
            if (k >= prt_thresh) {    //if > total_of_line / nb_of_slice
	      if (debug>1) fprintf(stderr,"\n");
              if ((rec & 1) == 1) printf("--- Slice:%li k=%li Pos=%li Lg=%li ---\n",line_cnt,k,pos_sentence[line_cnt-1],pos_sentence[line_cnt]-pos_sentence[line_cnt-1]);
              if ((rec & 2) == 2) fprintf(fp1,"--- Slice:%li k=%li Pos=%li Lg=%li ---\n",line_cnt,k,pos_sentence[line_cnt-1],pos_sentence[line_cnt]-pos_sentence[line_cnt-1]);
	      
	      /*--------*/
	      // pos_sentence[cnt] and lg sentence are stored allowing print raw sentence later
	      /*--------*/
	      
	      /*scan class array to display results*/
              for(k=0;k<size_nb_class;k++) 
                if (class_diff[k]>0) { //if not empty
                  if ((rec & 1) == 1) printf("%s=%i\n",classname[k],class_diff[k]);
                  if ((rec & 2) == 2) fprintf(fp1,"%s=%i\n",classname[k],class_diff[k]);
                  class_diff[k]=0;
                }
              k=0;    //reset the line_counter
            }
            i=i+j;    //set the index to the next word
            break;     
          }
      }
    }        
  }
  /*last slice*/
  if (k > 0) {
    if ((rec & 1) == 1) printf("--- Last slice k=%li ---\n",k);
    if ((rec & 2) == 2) fprintf(fp1,"--- Last slice k=%li ---\n",k);
    
    for(k=0;k<size_nb_class;k++) {
      if (class_diff[k]>0) {
        if ((rec & 1) == 1) printf("%s=%i\n",classname[k],class_diff[k]);
        if ((rec & 2) == 2) fprintf(fp1,"%s=%i\n",classname[k],class_diff[k]);
  } } }
    
  if (fclose(fp) != 0) {
    ERRPOS
    fprintf(stderr,"Error fclose fp in analyses");
    count_silent_bug++;
  }
  if ((rec & 2) == 2) if (fclose(fp1) != 0) {
    ERRPOS
    fprintf(stderr,"Error fclose fp1 in analyses");
    count_silent_bug++;
  }
  free(line);
  for (k=0;k<size_nb_class;k++) free(classname[k]);
  free(classname);
  free(class_sum);
  free(class_diff);
  //try to detect overflow
  if (crush_detect!='x' || crush_detect_heap[0]!='x') {
    ERRPOS
    fprintf(stderr,"Overflow\n");
    count_silent_bug++;
  }
  free(crush_detect_heap);
  return 0;
}

