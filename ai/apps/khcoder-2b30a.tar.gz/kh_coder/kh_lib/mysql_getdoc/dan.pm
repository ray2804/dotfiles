package mysql_getdoc::dan;
use base qw(mysql_getdoc);
use strict;


1;
