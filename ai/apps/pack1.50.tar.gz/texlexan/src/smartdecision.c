/* License/copyright: Read the copyright.txt file */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>
#include <unistd.h>
#include <time.h>
#include "utils.h"
#include "help.h"
#include "definitions.h"
#include "languages.h"
#include "analyses.h"
#include "abstracts.h"
#include "smartdecision.h"

extern int debug;
extern int verbose;
extern long int size_class_name;

int flag_stored=0;

int smartdecision(char *file,int *abstract_mode,int *abstract_rate,char *target,char *class_probable,int probability,int nb_best_result,int nb_of_words,int nb_of_lines) {
/* 
  Try to decide the best abstract mode
  but not always very smart!
*/
FILE *fp;
long int nb_words_rec=0,nb_lines_rec=0,nb_result_rec=0,probability_rec=0;
char class_rec[size_class_name];
long int diff1=0,diff2=0,diff3=0,diff4=0,diff5=0;
long int sum_diff,prev_sum_diff=999999999;
long int mode_rec,nbwa_rec,compress_rec;
long int compression=0,nb=0,nbt=0,compress_goal=0;
char line[1001];
char *str_ptr;
long int best_mode[101],sum[101],highest,cumul_sum,deviation;
long int feedback;
int i,hi;

  for (i=0;i<100;i++) {
    best_mode[i]=0; //initialize
    sum[i]=0;
  }
  /***First part is a case based reasoning ***/
  /*Search in the previous abstract job the best mode and compression rate
   search the closest characteristics of past text that match the text to summarize*/
  fp=fopen(file,"r"); //open the file containing info from the previous abstracts
  if (fp==NULL) {
	  fprintf(stderr,"Unable to open %s\n",file);
	  goto some_logic;
  }
  line[1000]='\0'; 
  while (fgets(line,1000,fp) != NULL) {
    /*Extract the value of each field*/
    if (line[1000]!='\0') {
      ERRPOS
	    fprintf(stderr,"line too long!\n");
      goto some_logic; 
    }
		// wt:nb of word
    if ((str_ptr=extract_val(&nb_words_rec,line,"wt:")) != NULL) {
      /*differential number of words in the text*/
      diff1=nb_of_words-nb_words_rec;
			// st:nb of sentences
      if ((str_ptr=extract_val(&nb_lines_rec,str_ptr,"st:")) != NULL) {
        /*differential number of lines in the abstract*/
        diff2=nb_of_lines-nb_lines_rec;
				// ar:compression achieved
        if ((str_ptr=extract_val(&compress_rec,str_ptr,"ar:")) != NULL 
					// br:nb of classes found
          && (str_ptr=extract_val(&nb_result_rec,str_ptr,"br:")) != NULL 
					// cp:class probable (name of the class with the highest probability)
					&& (str_ptr=extract_str(class_rec,size_class_name,str_ptr,"cp:")) != NULL 
					// pr:probability of the most probable class
          && (str_ptr=extract_val(&probability_rec,str_ptr,"pr:")) != NULL) {
          /*differential nb of classes*/
          diff3=nb_best_result-nb_result_rec;
          /*differential probability*/
          diff4=probability-probability_rec;
					/*diff between 2 class_name
					 * Not a very good solution */
					diff5=levenshtein_distance(class_rec,class_probable);
					if (diff5<0) {  //str empty =>bug?
						ERRPOS
						goto some_logic;
					}
          /*sum differentials between the current text and the past text*/
          sum_diff=abs(diff1)+abs(diff2)+abs(diff3)+abs(diff4)+diff5;
          nbt++; //count all results (population)
					/*---------- search the closiest match with the current text  -------------*/
          if (sum_diff < prev_sum_diff) { //is it the lowest difference?
            if ((str_ptr=extract_val(&mode_rec,str_ptr,"mo:")) != NULL) {
              if (extract_val(&nbwa_rec,str_ptr,"=") != NULL) {
                deviation=abs(100*(100*nbwa_rec-nb_words_rec*compress_rec)/(nb_words_rec*compress_rec));
                /*** deviation under 68% =>
                 *the nb of words obtained is close of the nb of words expected
                 *so memorize the mode ***/
                if (deviation < 68 && nbwa_rec) {
									/*if the user returned a feedback fb:N */
									if (extract_val(&feedback,str_ptr,"fb:") == NULL)
										feedback=1; //no feedback so default=1
                  nb++; //count good results
                  compression+=nb_words_rec/nbwa_rec;
                  compress_goal+=compress_rec;
                  prev_sum_diff=sum_diff;
									/*** good summarization feedback=2 mediocre=1 poor=0
									 * poor penalize the mode because 'sum[hi]/best_mode[hi]' 
									 * is degraded (see code below '***' )
									 * value 2 is empiric ****/
                  best_mode[mode_rec]+=feedback;
                  sum[mode_rec]+=deviation;
                }
              }
            }
          }
        }
      }
    }
  }

  fclose(fp);
  
  /*need enough data at least population of 16 and sample of 1*/
  if (compression && compress_goal && *abstract_rate && nb > 0 && nbt > 15) {
    /*compute new compression level (abstract_rate)*/
    *abstract_rate=((*abstract_rate)*compression)/compress_goal;
    /*search the highest val*/
      highest=hi=0;
    for (i=0;i<100;i++) {
      if (best_mode[i] > highest) {
        highest=best_mode[i];
        hi=i;
      }
      cumul_sum+=sum[i];
    }
    if (debug) fprintf(stderr,"\n=>mode: %i average deviation:%li nb of values:%li\n",hi,sum[hi]/best_mode[hi],best_mode[hi]);

    /* see code above '***'
		 * mode found and no mode forced by the user and average deviation under 34%
		 */
    if (hi && *abstract_mode < 1 && sum[hi]/best_mode[hi] < 34) {
      if (probability >= 75) *abstract_mode= hi; //set the abstract mode
      else *abstract_mode=1;
      *abstract_mode |= 8; //force remove deadwood expression
      return 1; //the decision is done => very often we stop here
    }    
  }

some_logic:;
/***Larger is the experience of summarization less often this part below will be used
 This part uses some fuzzy logics where a noise rand() is introducted***/

  /* Select the best list of cue expressions to use in function of the text class */
  if (str7bstr(class_probable,"science",0) != NULL) strcpy(target,"technic");
    else if (str7bstr(class_probable,"technic",0) != NULL) strcpy(target,"technic");
      else if (str7bstr(class_probable,"law",0) != NULL) strcpy(target,"technic");
        else if (str7bstr(class_probable,"politic",0) != NULL) strcpy(target,"politic");
          else  strcpy(target,"other");
  
  /*mode has been set by the user in the command line*/
  if (*abstract_mode>0) {
    /*if no class found cannot do abstact II*/
    if (nb_best_result == 0) *abstract_mode &= 253; //bin:11111101 no mode II
    return 1;
  }
  /*mode has been set 'auto' by the user (default mode)*/
  if (*abstract_mode == -1 || *abstract_mode == -2) {
    /*** if no class found (text cannot be categorized) or the classification uncertain ***/
    if (nb_best_result == 0 || probability < 75) {
	  if (nb_of_words > 50+(int)(50*(double)rand()/RAND_MAX)) *abstract_mode= 13; //bin 00001101
	  else *abstract_mode= 8; //bin 00001000
      return 1;
    }
    /*** the text belongs a class, we are going to choose the mode in function of the
      number of words of the text, the random number gives some fluctuation to enrich
      the database ***/
	/* if the text is large (x > 1000...2000 words) */
    if (nb_of_words > 500+(int)(500*(double)rand()/RAND_MAX)) { 
      *abstract_mode= 14; //bin:00001110
      return 1;
    }
	/* if the text is medium (100...200 < x < 1000...2000)*/
    else if (nb_of_words > 50+(int)(50*(double)rand()/RAND_MAX)) { 
      *abstract_mode= 10; //bin:00001010
      return 1;
    }
	else {
	/* the text is small (x < 100...200)*/
      *abstract_mode= 8; //bin:00001000
      return 1;
    }
  }
  
  return 0; //no change
}

int 
storeforsmartdecision(char *file,int nb_best_result,char *class_probable,int probability,int nb_of_words,int nb_of_lines,int abstract_rate,int nbw_abstract,int mode) 
{
/*Store many informations about the text with the hope they'll be useful*/
FILE *fp;

  fp=fopen(file,"a");
  if (fp==NULL) {
    ERRPOS
	  fprintf(stderr,"Unable to open %s\n",file);
	  exit(EXIT_FAILURE);
  }
  if (!flag_stored) {
		/* nwt:nb words text st:nb sentences text ar:abstrctrate br:nb classes cp:class probable pr:probability
		 * mo:mode#=nb words abstract   (mo is repeated if several abstracts) */
    fprintf(fp,"\nwt:%i st:%i ar:%i br:%i cp:%s pr:%i mo:%i=%i",
			nb_of_words,nb_of_lines,abstract_rate,nb_best_result,class_probable,probability,mode,nbw_abstract);
	  flag_stored=1; //will not repeat same infos if more than 1 summary
  } 
	else fprintf(fp," mo:%i=%i",mode,nbw_abstract);
  fclose(fp);
  return 0;
}

/*
 * The idea is to store the result of the abstract (nb of words...) and the 
 * characteristic (nb of words, nb of sentences...) of the text to summarize; 
 * then 'smartdecision use these info to decide of the best summary mode.
 */
