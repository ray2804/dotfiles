/*
 *	Class:			AdminAuthorization
 *	Supports class:	AdminItem
 *	Purpose:		To handle authorization
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "AdminItem.h"
#include "GeneralizationItem.cpp"
#include "Presentation.cpp"
#include "SpecificationItem.cpp"

class AdminAuthorization
	{
	// Private constructible variables

	bool userHasPasswordAssigned_;
	bool userEnteredCorrectPassword_;

	unsigned short foundUserNr_;

	unsigned int loginSentenceNr_;

	SpecificationItem *passwordAssignmentItem_;

	WordItem *currentUserWordItem_;
	WordItem *foundUserWordItem_;

	CommonVariables *commonVariables_;
	AdminItem *admin_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	ResultType findUserWord( char *userNameString )
		{
		WordResultType wordResult;
		GeneralizationItem *currentGeneralizationItem;
		WordItem *currentGeneralizationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findUserWord";

		foundUserNr_ = NO_USER_NR;
		foundUserWordItem_ = NULL;

		if( userNameString != NULL )
			{
			if( commonVariables_->predefinedNounUserWordItem != NULL )
				{
				if( ( currentGeneralizationItem = commonVariables_->predefinedNounUserWordItem->firstActiveGeneralizationItemOfSpecification() ) != NULL )
					{
					do	{
						if( ( currentGeneralizationWordItem = currentGeneralizationItem->generalizationWordItem() ) != NULL )
							{
							if( currentGeneralizationItem->isGeneralizationPropername() )
								{
								if( ( wordResult = currentGeneralizationWordItem->findWordType( false, WORD_TYPE_PROPER_NAME, userNameString ) ).result == RESULT_OK )
									{
									if( wordResult.foundWordTypeItem != NULL )
										{
										if( ( foundUserNr_ = currentGeneralizationWordItem->collectionOrderNrByWordTypeNr( WORD_TYPE_PROPER_NAME ) ) == NO_ORDER_NR )
											foundUserNr_ = 1;	// Only one user (not collected)

										foundUserWordItem_ = currentGeneralizationWordItem;
										}
									}
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find the user name" );
								}
							}
						else
							return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found an undefined generalization word" );
						}
					while( ( currentGeneralizationItem = currentGeneralizationItem->nextGeneralizationItemOfSpecification() ) != NULL );
					}
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The predefined user noun word item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given user name string is undefined" );

		return commonVariables_->result;
		}

	ResultType checkUserForPasswordAssignment( WordItem *userWordItem )
		{
		SpecificationResultType specificationResult;
		WordItem *predefinedNounPasswordWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkUserForPasswordAssignment";

		userHasPasswordAssigned_ = true;		// Fail safe
		passwordAssignmentItem_ = NULL;

		if( userWordItem != NULL )
			{
			if( ( predefinedNounPasswordWordItem = admin_->predefinedNounPasswordWordItem() ) != NULL )
				{
				if( ( specificationResult = predefinedNounPasswordWordItem->findAssignmentByRelationContext( false, false, false, false, NO_QUESTION_PARAMETER, userWordItem ) ).result == RESULT_OK )
					{
					if( ( passwordAssignmentItem_ = specificationResult.foundSpecificationItem ) == NULL )
						{
						// No assignment found. So, check for explict negative password specification
						if( userWordItem->firstAssignmentOrSpecificationButNotAQuestion( true, false, false, false, false, true, true, NO_COLLECTION_NR, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_CONTEXT_NR, predefinedNounPasswordWordItem ) != NULL )
							userHasPasswordAssigned_ = false;
						}
					}
				else
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find the password assignment" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The predefined password noun word item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given user word item is undefined" );

		return commonVariables_->result;
		}

	ResultType checkPassword( char *enteredPasswordString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkPassword";
		userEnteredCorrectPassword_ = false;		// Fail safe

		if( enteredPasswordString != NULL )
			{
			if( passwordAssignmentItem_ != NULL )
				{
				if( passwordAssignmentItem_->specificationWordItem() != NULL )
					{

					if( passwordAssignmentItem_->specificationWordItem()->isCorrectHiddenWordType( passwordAssignmentItem_->specificationWordTypeNr(), enteredPasswordString, this ) )
						userEnteredCorrectPassword_ = true;
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The password assignment specification item is undefined" );
				}
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given password string is undefined" );

		return commonVariables_->result;
		}


	public:
	// Constructor

	AdminAuthorization( AdminItem *admin, WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		userHasPasswordAssigned_ = true;		// Fail safe
		userEnteredCorrectPassword_ = false;	// Fail safe

		foundUserNr_ = NO_USER_NR;

		loginSentenceNr_ = NO_SENTENCE_NR;

		passwordAssignmentItem_ = NULL;
		currentUserWordItem_ = NULL;
		foundUserWordItem_ = NULL;

		admin_ = admin;
		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "AdminAuthorization" );

		if( commonVariables_ != NULL )
			{
		if( admin_ != NULL )
			{
			if( myWord_ == NULL )
				strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given admin is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	unsigned int myFirstSentenceNr()
		{
		return ( loginSentenceNr_ + 1 );
		}

	ResultType authorizeWord( WordItem *authorizationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "authorizeWord";
		if( authorizationWordItem != NULL )
			{
			if( admin_->isSystemStartingUp() )
				{
				if( authorizationWordItem->assignChangePermissions( this ) != RESULT_OK )
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to assign my authorization permissions to a word" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "You are not authorized to authorize the given word" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given authorization word item is undefined" );

		return commonVariables_->result;
		}

	ResultType login( WordItem *specificationWordItem )
		{
		WordItem *predefinedNounPasswordWordItem;
		char readUserNameString[MAX_READ_WRITE_STRING_LENGTH] = EMPTY_STRING;
		char readPasswordString[MAX_READ_WRITE_STRING_LENGTH] = EMPTY_STRING;
		char functionNameString[FUNCTION_NAME_LENGTH] = "login";

		userHasPasswordAssigned_ = true;		// Fail safe
		userEnteredCorrectPassword_ = false;	// Fail safe
		passwordAssignmentItem_ = NULL;
		foundUserWordItem_ = NULL;

		if( commonVariables_->predefinedNounUserWordItem != NULL )
			{
			if( ( predefinedNounPasswordWordItem = admin_->predefinedNounPasswordWordItem() ) != NULL )
				{
				if( specificationWordItem == NULL )		// No user name is given
					{
					if( admin_->getUserInput( false, true, false, commonVariables_->predefinedNounUserWordItem->activeSingularNounString(), readUserNameString ) != RESULT_OK )
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to read to user name" );
					}
				else
					strcat( readUserNameString, specificationWordItem->anyWordTypeString() );

				if( strlen( readUserNameString ) > 0 )
					{
					if( findUserWord( readUserNameString ) != RESULT_OK )
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find the user" );
					}

				if( foundUserWordItem_ != NULL &&
				foundUserWordItem_ == currentUserWordItem_ )
					{
					if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_NOTIFICATION, INTERFACE_CONSOLE_ALREADY_LOGGED_IN_START, readUserNameString, INTERFACE_CONSOLE_LOGIN_END ) != RESULT_OK )
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface notification" );
					}
				else
					{
					if( foundUserWordItem_ != NULL )
						{
						if( checkUserForPasswordAssignment( foundUserWordItem_ ) != RESULT_OK )
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check the user for password assignment" );
						}

					if( foundUserWordItem_ != NULL &&
					!userHasPasswordAssigned_ )
						userEnteredCorrectPassword_ = true;		// User has no password
					else
						{
						if( admin_->getUserInput( true, true, false, predefinedNounPasswordWordItem->activeSingularNounString(), readPasswordString ) == RESULT_OK )
							{
							if( foundUserWordItem_ != NULL )	// Only check password if user was found
								{
								if( checkPassword( readPasswordString ) != RESULT_OK )
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check the user and password" );
								}
							}
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to read to password" );
						}

					if( userEnteredCorrectPassword_ &&
					foundUserWordItem_ != NULL )
						{
						if( assignSpecificationWithAuthorization( false, false, false, false, false, false, false, NO_PREPOSITION_PARAMETER, NO_QUESTION_PARAMETER, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, 0, NULL, foundUserWordItem_, commonVariables_->predefinedNounUserWordItem, NULL ).result == RESULT_OK )
							{
							currentUserWordItem_ = foundUserWordItem_;
							loginSentenceNr_ = commonVariables_->currentSentenceNr;
							commonVariables_->myFirstSentenceNr = loginSentenceNr_;
							commonVariables_->currentUserNr = foundUserNr_;

							if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_NOTIFICATION, INTERFACE_CONSOLE_LOGGED_IN_START, readUserNameString, INTERFACE_CONSOLE_LOGIN_END ) == RESULT_OK )
								{
								}
							else
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface notification" );
							}
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to assign the user" );
						}
					else
						{
						if( !admin_->isSystemStartingUp() )
							{
							if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_NOTIFICATION, INTERFACE_CONSOLE_LOGIN_FAILED ) != RESULT_OK )
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface notification" );
							}
						else
							return myWord_->startSystemErrorInItem( functionNameString, moduleNameString_, "The user name or it's password isn't correct" );
						}
					}
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The predefined password noun word item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The predefined user noun word item is undefined" );

		return commonVariables_->result;
		}

	SpecificationResultType addSpecificationWithAuthorization( bool isAssignment, bool isConditional, bool isDeactiveAssignment, bool isArchivedAssignment, bool isExclusive, bool isNegative, bool isPossessive, bool isSelection, bool isSpecificationGeneralization, bool isValueSpecification, unsigned short prepositionParameter, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addSpecificationWithAuthorization";

		if( generalizationWordItem != NULL )
			{
			if( specificationWordItem != NULL )
				{
				if( generalizationWordItem->isNounPassword() ||
				specificationWordItem->isNounDeveloper() ||
				specificationWordItem->isNounUser() ||
				generalizationWordItem->isVerbImperativeLogin() )
					{
					if( generalizationWordItem->isNounPassword() )
						{
						if( specificationWordItem->hideWordType( specificationWordTypeNr, this ) != RESULT_OK )
							myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to hide a password" );
						}
					else
						{
						if( !isNegative &&
						specificationWordItem->isNounUser() &&
						questionParameter == NO_QUESTION_PARAMETER &&
						admin_->predefinedVerbLoginWordItem() != NULL )		// Create a login for this user
							{
							if( ( specificationResult = admin_->predefinedVerbLoginWordItem()->addSpecificationInWord( false, false, false, false, false, false, false, false, false, false, NO_PREPOSITION_PARAMETER, NO_QUESTION_PARAMETER, WORD_TYPE_VERB_SINGULAR, generalizationWordTypeNr, WORD_TYPE_UNDEFINED, generalizationCollectionNr, specificationCollectionNr, relationCollectionNr, NO_CONTEXT_NR, generalizationContextNr, NO_CONTEXT_NR, nContextRelations, specificationJustificationItem, generalizationWordItem, NULL, NULL, this ) ).result != RESULT_OK )
								myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a specification with authorization" );
							}
						}
					}

				if( commonVariables_->result == RESULT_OK )
					{
					if( ( specificationResult = generalizationWordItem->addSpecificationInWord( isAssignment, isConditional, isDeactiveAssignment, isArchivedAssignment, isExclusive, isNegative, isPossessive, isSelection, isSpecificationGeneralization, isValueSpecification, prepositionParameter, questionParameter, generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, generalizationCollectionNr, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, nContextRelations, specificationJustificationItem, specificationWordItem, relationWordItem, specificationString, this ) ).result != RESULT_OK )
						myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a specification with authorization" );
					}
				}
			else
				myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );
			}
		else
			myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		specificationResult.result = commonVariables_->result;
		return specificationResult;
		}

	SpecificationResultType assignSpecificationWithAuthorization( bool isAmbiguousRelationContext, bool isAssignedOrClear, bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, bool isSelfGenerated, unsigned short prepositionParameter, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int originalSentenceNr, unsigned int activeSentenceNr, unsigned int deactiveSentenceNr, unsigned int archiveSentenceNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "assignSpecificationWithAuthorization";

		if( generalizationWordItem != NULL )
			{
			if( ( specificationResult = generalizationWordItem->assignSpecificationInWord( isAmbiguousRelationContext, isAssignedOrClear, isDeactive, isArchived, isNegative, isPossessive, isSelfGenerated, prepositionParameter, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, originalSentenceNr, activeSentenceNr, deactiveSentenceNr, archiveSentenceNr, nContextRelations, specificationJustificationItem, specificationWordItem, specificationString, this ) ).result != RESULT_OK )
				myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to assign a specification with authorization" );
			}
		else
			myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		specificationResult.result = commonVariables_->result;
		return specificationResult;
		}

	char *currentUserName()
		{
		return ( currentUserWordItem_ == NULL ? NULL : currentUserWordItem_->anyWordTypeString() );
		}
	};

/*************************************************************************
 *
 *	"We thank you, O God!
 *	We give thanks because you are near.
 *	People everywhere tell your wonderful deeds." (Psalm 75:1)
 *
 *************************************************************************/
