<?php

	/** 	
	* Command Generation Class
	*/
	
	class CommandGenerator{
		
		/**
		Constructor
		*/
		function CommandGenerator(){}

		/**
		* Generate the python command to delete a file
		* @param $fileid the id of the file
		* return the python command with arguments
		*/
		function d_file($fileid){
			$fid = escapeshellarg($fileid);
			return "python ../bin/docsum.py --delete=$fid";
		}
		
		function d_suggest($tpc){
			$sug = escapeshellarg($tpc);
			return "python ../bin/docsum.py --suggest=$sug";
		}
		
		/**
		* Generate the python command to produce a summary
		* @param $tpc the topic to summarize, string
		* @param $pg the number of pages for the topic
		* return - the python command with arguements
		*/
		function d_summarize($tpc,$pg){
			$topic = escapeshellarg($tpc);
			$pages = escapeshellarg($pg);
			return "python ../bin/docsum.py --generate=$topic --pages=$pages";
		}
		
		/**
		* Generate the python command to list the repository
		* return the python command with arguments
		*/
		function l_files($active){
			if($active == 0) 	return "python ../bin/docsum.py --inactive";
			else				return "python ../bin/docsum.py --list";
		}
		
		/**
		*Generate the python command to add a file
		* return the python command with arguments
		*/
		function a_file($file){
			$arg = escapeshellarg($file);
			$cmd = "python ../bin/docsum.py --add=$arg";
			return $cmd;
		}
		
		/**
		*Generate the python command to list the most recent searches
		*return the python command with arguemnts
		*/
		function l_recent($many){
			$arg = escapeshellarg($many);
			return "python ../bin/docsum.py --recent=$arg";
		}
		
		/**
		* Generate the python command to list the most recent searches
		* return the python command with arguemnts
		*/
		function l_freq($many){
			$arg = escapeshellarg($many);
			return "python ../bin/docsum.py --frequent=$arg";
		}
	
	}
	
	/**
	* Link Generator Class 
	*/
	class LinkGenerator{		
		
		var $main;

		function LinkGenerator($main){
			$this->main = $main;
		}
		/**
		* Generate history link
		* return html
		*/
		function t_link(){	
			return '<a href="history.php">history</a>'; 
		}
		
		/**
		* Construct the add file link 
		*return html string to echo for link 
		*/
		function a_link(){
			return "<a href=\"".$this->main."?page=add\">add file</a>";	
		}
		
		/** 
		* Construct the index link 
		* return html string to echo for link 
		*/
		function i_link(){
			return "<a href=\"".$this->main."\">main</a>";	
		}
		
		/**
		* Construct back and download links
		* return html string to echo for link
		*/
		function s_links($backPage){
			return '<table width="100%" summary="" border="0">
			<tr><td style="text-align: left;">
			<a href="'.$backPage.'">back</a></td>
			<td style="text-align: right;">download as pdf <small>(coming soon!)</small>
			</td></tr></table>';
		}
	}
	
	/**
	* Command line executor
	*All python commands generated from the command generator are executed by this object.
	*/
	class CommandExecuter{
		/**
		*Execute a python command, and echo the results of the command
		* @param $cmd the command text
		* return the output from the command execution
		*/
		function py_exe($cmd){
			//echo $cmd;
			//$status = 0;
			//$output = "";
			exec($cmd,$output,$status);
			if($status != 0){
				echo "<br>Bad command execution. Check scripts. Exit status: $status<br>";
			}
			return $output;
		}	
	}
	
	/**
	* Object that handle adding files to the repository
	*/
	class FileAdder{		
		/**
		* Move an uploaded file to the the $file_store location with a new name
		* @param $tmp temp file name
		* @param $mvdir location to move the file
		* @param $base base name to move file too
		* return file after function execution, might be the new, might be the old
		*/
		function moveFile($tmp,$mvdir,$base){
			$uploadfile = $mvdir.'/'. $base;
			if (move_uploaded_file($tmp, $uploadfile)) {
				echo "File was moved successfully to '$uploadfile' from '$tmp'.<br>";
				return True;
			}
			echo "Could not move file to '$uploadfile', will use '$tmp'<br>";
			return False;
		
		}
		
		/**
		*Store the file in the repository
		* @param $cmd the command to add the file
		*@param $executor the command executor
		* return the output for the command
		*/
		function storeFile($cmd,$executor){
			$output = $executor->py_exe($cmd);
			return $output;
		}
	}
	
	/**
	* Site page generation class
	*/
	class PageGenerator{
		var $main;
		
		function PageGenerator($main){
			$this->main = $main;
		}

		/**
		* Generate html form for summary generation
		* @param $action page action
		* return html string to echo for form
		*/
		function summaryForm($action){			
			$files = $_GET["files"];
			$listtype = $_GET["listtype"];
			$showtopics= $_GET["showtopics"];
			
			return '<center>
			<form name="input" action="'.$action.'" method="get">
			topic: <input type="text" name="topic" value="" size="35" onkeyup="showHint(this.value)"> pages: <select name="pages">
			<option value="1">1
			<option value="2">2
			<option value="3">3
			<option value="4">4
			<option value="5">5
			</select>
			<input type="submit" value="summarize">
			</form>
			</center>
			<p class="suggestion">suggestion: <span class="suggest" id="suggest"></span></p>';
			
		}
		
		/**
		* Generate the listing for the topics 
		* @param $header the header information for that page section
		* @param $output command output from the listing
		*/	
		function listTopicsTable($header,$output){
			echo $header;
			echo '<center><table class="topic-list" summary="topics">';
			$rank = 1;
			/* $value will be each line of output from the command */
			foreach($output as $value){
				echo '<tr>';
				$link = '<a href="'.$this->main.'?topic='.urlencode($value).'&amp;pages=1">'.$value.'</a>';
				//echo "<td class=\"topic-rank-list\">$rank</td><td class=\"topic-item-list\">\"$link\"</td>";
				if($value == "#No topics."){
					echo "<td class=\"topic-item-list\">No topics.</td>";
				} else {
					echo "<td class=\"topic-item-list\">\"$link\"</td>";
				}
				$rank++;
				echo '</tr>';
			}
			echo "</table></center>";
		}
		
		/**
		* Generate the listing for the topics 
		* @param $header the header information for that page section
		* @param $output command output from the listing
		* @param $active the active file flag
		*/	
		function listFilesTable($header,$output,$active){
			echo $header;
			echo '<center><table class="file-list" summary="files">';
			$head = True;
			foreach($output as $value){
				$temp = $value;
				unset($value);
				$pieces = explode("|",$temp);
				echo '<tr>';
				foreach($pieces as $part){
					$newpart = wordwrap($part, 50, "<br>",1);
					echo "<td class=\"file-list\">$newpart</td>";
				}
				if($head == True){
					echo '<td class="file-list">&nbsp;</td><td class="file-list">&nbsp;</td>';
					
					$head = False;
				} else{ 
					//echo '<td class="file-list">view</td>';
					$url = ereg_replace('\'','',$pieces[2]);
					$updurl = "<a href=\"".$this->main."?userfile=".urlencode($url)."\">";
					if($active == 1){
						echo "<td class=\"file-list\">".$updurl."update</a></td>";
						echo "<td class=\"file-list\"><a href=\"history.php?delete=$pieces[0]\">delete</a></td>";
					} else {
						//$url = ereg_replace('\'', '', $pieces[2]);
						echo "<td class=\"file-list\">".$updurl."update</a></td>";
						echo "<td class=\"file-list\">".$updurl."activate</a></td>";
					} 
				}
				echo "</tr>";
			}
			echo "</table></center>";
		}
		
		/** 
		* Generate the summary of a topic and pages
		* @param $cgen 
		* @param $cexe
		* return html string for page
		*/
		function summaryPage($cgen,$cexe){
			$pages = urldecode($_GET["pages"]);
			if(!ereg("[1-5]", $pages)) $pages = 1; 
			$cmd = $cgen->d_summarize(urldecode($_GET["topic"]),$pages);
			$output = $cexe->py_exe($cmd);
			foreach($output as $line) echo "$line<br>";
		}
		
		/**
		* Generates the content for the tracking page 
		*/
		function trackingPage($cmdGen,$cmdExe){
			
			echo '<center><table summary="table holder" width="90%"><tr><td>';
			/* Show the tracking detail for the recent and frequent topics */
			$header = '<center><h3 class="indented">frequent summary topics</h3></center>';
			$cmd = $cmdGen->l_freq("10");
			$output = $cmdExe->py_exe($cmd);		
			$this->listTopicsTable($header,$output);
			echo '</td><td>';
			
			$header = '<center><h3 class="indented">recent summary topics</h3></center>';
			$cmd = $cmdGen->l_recent("10");
			$output = $cmdExe->py_exe($cmd);	
			$this->listTopicsTable($header,$output);
			echo '</td></tr></table></center>';
			
			/* Show the tracking detail of the active files */
			$cmd = $cmdGen->l_files(1);
			$header = '<center><h3 class="indented">active docsum files</h3></center>';
			$output = $cmdExe->py_exe($cmd);
			$this->listFilesTable($header,$output,1);
			
			/* Show the tracking detail of the inactive files */
			$cmd = $cmdGen->l_files(0);
			$header = '<center><h3 class="indented">inactive docsum files</h3></center>';
			$output = $cmdExe->py_exe($cmd);
			$this->listFilesTable($header,$output,0);
		}
		
		function historyShowFiles($cmdGen,$cmdExe,$which){
			/* Show the tracking detail of the active files */
			$cmd = $cmdGen->l_files($which);
			if($which == 1){
				$header = '<center><h3 class="indented">active docsum files</h3></center>';
			} else {
				$header = '<center><h3 class="indented">inactive docsum files</h3></center>';
			}
			$output = $cmdExe->py_exe($cmd);
			$this->listFilesTable($header,$output,$which);
		
		}
		
		function historyTopicLists($cmdGen,$cmdExe){
			echo '<center><table summary="table holder" width="90%"><tr><td>';
			/* Show the tracking detail for the recent and frequent topics */
			$header = '<center><h3 class="indented">frequent summary topics</h3></center>';
			$cmd = $cmdGen->l_freq("10");
			$output = $cmdExe->py_exe($cmd);		
			$this->listTopicsTable($header,$output);
			echo '</td><td>';
			
			$header = '<center><h3 class="indented">recent summary topics</h3></center>';
			$cmd = $cmdGen->l_recent("10");
			$output = $cmdExe->py_exe($cmd);	
			$this->listTopicsTable($header,$output);
			echo '</td></tr></table></center>';
		}
		
		/**
		* Generates the content for the tracking page 
		*/
		function suggestionPage($cmdGen,$cmdExe,$value){
			//echo $value;
			$cmd = $cmdGen->d_suggest($value);
			//echo $cmd;
			$output = $cmdExe->py_exe($cmd);
			//$this->returnSuggestion($output,$value);
			if($output[0] != "#No topics."){
				echo "<a href=\"".$this->main."?topic=$output[0]&pages=1\">$output[0]</a>";
			} else {
				echo "no suggestion";
			}
			//return;
		}
		
		function addFilePage(){
			echo '<form action="'.$this->main.'" method="GET">
			<p class="indented">
			<center>
				<table class="add-form" summary="add file form">
				<tr><td>file url: </td><td><input name="userfile" size="35" type="text" /></td><td>
				<input type="hidden" name="page" value="add" />
				<input type="submit" value="Add File" /></td></tr>
				</table>
			</center>
			</form>
			<center>
			<small>plain text files only!</small>
			</center>';
			
			/*return '<center>
			<form name="input" action="'.$action.'" method="get">
			topic: <input type="text" name="topic" value="" size="35" onkeyup="showHint(this.value)"> pages: <select name="pages">
			<option value="1">1
			<option value="2">2
			<option value="3">3
			<option value="4">4
			<option value="5">5
			</select>
			<input type="submit" value="summarize">
			</form>
			</center>*/
		}
	}
?>
