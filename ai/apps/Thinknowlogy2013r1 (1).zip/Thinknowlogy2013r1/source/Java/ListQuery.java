/*
 *	Class:			ListQuery
 *	Supports class:	List
 *	Purpose:		To process queries
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

class ListQuery
	{
	// Private constructible variables

	private List myList_;
	private String moduleNameString_;


	// Private methods

	private void itemQuery( boolean isSelectOnFind, boolean isReferenceQuery, int querySentenceNr, int queryItemNr, Item queryItem )
		{
		while( queryItem != null )
			{
			if( ( isReferenceQuery &&
			queryItem.hasFoundReferenceItemById( querySentenceNr, queryItemNr ) ) ||

			( !isReferenceQuery &&
			( querySentenceNr == Constants.NO_SENTENCE_NR ||
			querySentenceNr == queryItem.creationSentenceNr() ) &&

			( queryItemNr == Constants.NO_SENTENCE_NR ||
			queryItemNr == queryItem.itemNr() ) ) )
				{
				if( isSelectOnFind &&
				!queryItem.isSelectedByQuery )
					{
					CommonVariables.hasFoundQuery = true;
					queryItem.isSelectedByQuery = true;
					}
				}
			else
				{
				if( !isSelectOnFind &&
				queryItem.isSelectedByQuery )
					queryItem.isSelectedByQuery = false;
				}

			queryItem = queryItem.nextItem;
			}
		}

	private void listQuery( boolean isSelectOnFind, Item queryItem )
		{
		while( queryItem != null )
			{
			if( isSelectOnFind )
				{
				if( !queryItem.isSelectedByQuery )
					{
					CommonVariables.hasFoundQuery = true;
					queryItem.isSelectedByQuery = true;
					}
				}
			else
				{
				if( queryItem.isSelectedByQuery )
					queryItem.isSelectedByQuery = false;
				}

			queryItem = queryItem.nextItem;
			}
		}

	private void wordTypeQuery( boolean isSelectOnFind, short queryWordTypeNr, Item queryItem )
		{
		while( queryItem != null )
			{
			if( queryItem.hasFoundWordType( queryWordTypeNr ) )
				{
				if( isSelectOnFind &&
				!queryItem.isSelectedByQuery )
					{
					CommonVariables.hasFoundQuery = true;
					queryItem.isSelectedByQuery = true;
					}
				}
			else
				{
				if( !isSelectOnFind &&
				queryItem.isSelectedByQuery )
					queryItem.isSelectedByQuery = false;
				}

			queryItem = queryItem.nextItem;
			}
		}

	private void parameterQuery( boolean isSelectOnFind, int queryParameter, Item queryItem )
		{
		while( queryItem != null )
			{
			if( queryItem.hasFoundParameter( queryParameter ) )
				{
				if( isSelectOnFind &&
				!queryItem.isSelectedByQuery )
					{
					CommonVariables.hasFoundQuery = true;
					queryItem.isSelectedByQuery = true;
					}
				}
			else
				{
				if( !isSelectOnFind &&
				queryItem.isSelectedByQuery )
					queryItem.isSelectedByQuery = false;
				}

			queryItem = queryItem.nextItem;
			}
		}

	private void wordQuery( boolean isSelectOnFind, Item queryItem )
		{
		while( queryItem != null )
			{
			if( isSelectOnFind )
				{
				if( !queryItem.isSelectedByQuery )
					{
					CommonVariables.hasFoundQuery = true;
					queryItem.isSelectedByQuery = true;
					}
				}
			else
				{
				if( queryItem.isSelectedByQuery )
					queryItem.isSelectedByQuery = false;
				}

			queryItem = queryItem.nextItem;
			}
		}

	private void clearQuerySelections( Item searchItem )
		{
		while( searchItem != null )
			{
			searchItem.isSelectedByQuery = false;
			searchItem = searchItem.nextItem;
			}
		}

	private byte wordReferenceQuery( boolean isSelectOnFind, String wordReferenceNameString, Item queryItem )
		{
		while( queryItem != null )
			{
			if( queryItem.findMatchingWordReferenceString( wordReferenceNameString ) == Constants.RESULT_OK )
				{
				if( CommonVariables.hasFoundMatchingStrings )
					{
					if( isSelectOnFind &&
					!queryItem.isSelectedByQuery )
						{
						CommonVariables.hasFoundQuery = true;
						queryItem.isSelectedByQuery = true;
						}
					}
				else
					{
					if( !isSelectOnFind &&
					queryItem.isSelectedByQuery )
						queryItem.isSelectedByQuery = false;
					}

				queryItem = queryItem.nextItem;
				}
			else
				return myList_.addError( 1, moduleNameString_, "I failed to check the word references" );
			}

		return CommonVariables.result;
		}

	private byte stringQuery( boolean isSelectOnFind, String wordString, Item queryItem )
		{
		boolean hasFoundString;
		String itemString;

		while( queryItem != null )
			{
			hasFoundString = false;

			if( ( itemString = queryItem.itemString() ) != null )
				{
				if( compareStrings( wordString, itemString ) == Constants.RESULT_OK )
					{
					if( CommonVariables.hasFoundMatchingStrings )
						hasFoundString = true;
					}
				else
					return myList_.addError( 1, moduleNameString_, "I failed to compare two strings" );
				}

			if( !hasFoundString &&
			( itemString = queryItem.extraItemString() ) != null )
				{
				if( compareStrings( wordString, itemString ) == Constants.RESULT_OK )
					{
					if( CommonVariables.hasFoundMatchingStrings )
						hasFoundString = true;
					}
				else
					return myList_.addError( 1, moduleNameString_, "I failed to compare two strings" );
				}

			if( hasFoundString )
				{
				if( isSelectOnFind &&
				!queryItem.isSelectedByQuery )
					{
					CommonVariables.hasFoundQuery = true;
					queryItem.isSelectedByQuery = true;
					}
				}
			else
				{
				if( !isSelectOnFind &&
				queryItem.isSelectedByQuery )
					queryItem.isSelectedByQuery = false;
				}

			queryItem = queryItem.nextItem;
			}

		return CommonVariables.result;
		}

	private byte showQueryResult( boolean showOnlyWords, boolean showOnlyWordReferences, boolean showOnlyStrings, boolean returnQueryToPosition, short promptTypeNr, short queryWordTypeNr, int queryWidth, Item queryItem )
		{
		while( queryItem != null )
			{
			if( queryItem.isSelectedByQuery )
				{
				if( showOnlyWords )
					queryItem.showWords( returnQueryToPosition, queryWordTypeNr );
				else
					{
					if( showOnlyWordReferences )
						queryItem.showWordReferences( returnQueryToPosition );
					else
						{
						if( showOnlyStrings )
							queryItem.showString( returnQueryToPosition );
						else
							{
							if( Presentation.writeText( true, promptTypeNr, queryWidth, queryItem.toStringBuffer( queryWordTypeNr ) ) != Constants.RESULT_OK )
								return myList_.addError( 1, moduleNameString_, "I failed to show the info of an active item" );
							}
						}
					}
				}

			queryItem = queryItem.nextItem;
			}

		return CommonVariables.result;
		}


	// Constructor

	protected ListQuery( List myList )
		{
		String errorString = null;

		myList_ = myList;
		moduleNameString_ = this.getClass().getName();

		if( myList_ == null )
			errorString = "The given my list is undefined";

		if( errorString != null )
			{
			if( myList_ != null )
				myList_.startSystemError( 1, moduleNameString_, errorString );
			else
				{
				CommonVariables.result = Constants.RESULT_SYSTEM_ERROR;
				Console.addError( "\nClass:" + moduleNameString_ + "\nMethod:\t" + Constants.PRESENTATION_ERROR_CONSTRUCTOR_METHOD_NAME + "\nError:\t\t" + errorString + ".\n" );
				}
			}
		}


	// Protected methods

	protected void countQuery()
		{
		Item searchItem = myList_.firstActiveItem();

		while( searchItem != null )
			{
			if( searchItem.isSelectedByQuery )
				CommonVariables.nActiveQueryItems++;

			searchItem = searchItem.nextItem;
			}

		searchItem = myList_.firstDeactiveItem();

		while( searchItem != null )
			{
			if( searchItem.isSelectedByQuery )
				CommonVariables.nDeactiveQueryItems++;

			searchItem = searchItem.nextItem;
			}

		searchItem = myList_.firstArchivedItem();

		while( searchItem != null )
			{
			if( searchItem.isSelectedByQuery )
				CommonVariables.nArchivedQueryItems++;

			searchItem = searchItem.nextItem;
			}

		searchItem = myList_.firstDeletedItem();

		while( searchItem != null )
			{
			if( searchItem.isSelectedByQuery )
				CommonVariables.nDeletedQueryItems++;

			searchItem = searchItem.nextItem;
			}
		}

	protected void clearQuerySelections()
		{
		clearQuerySelections( myList_.firstActiveItem() );
		clearQuerySelections( myList_.firstDeactiveItem() );
		clearQuerySelections( myList_.firstArchivedItem() );
		clearQuerySelections( myList_.firstDeletedItem() );
		}

	protected void itemQuery( boolean isSelectOnFind, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, boolean isReferenceQuery, int querySentenceNr, int queryItemNr )
		{
		if( isSelectActiveItems )
			itemQuery( isSelectOnFind, isReferenceQuery, querySentenceNr, queryItemNr, myList_.firstActiveItem() );

		if( isSelectDeactiveItems )
			itemQuery( isSelectOnFind, isReferenceQuery, querySentenceNr, queryItemNr, myList_.firstDeactiveItem() );

		if( isSelectArchivedItems )
			itemQuery( isSelectOnFind, isReferenceQuery, querySentenceNr, queryItemNr, myList_.firstArchivedItem() );

		if( isSelectDeletedItems )
			itemQuery( isSelectOnFind, isReferenceQuery, querySentenceNr, queryItemNr, myList_.firstDeletedItem() );
		}

	protected void listQuery( boolean isSelectOnFind, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems )
		{
		if( isSelectActiveItems )
			listQuery( isSelectOnFind, myList_.firstActiveItem() );

		if( isSelectDeactiveItems )
			listQuery( isSelectOnFind, myList_.firstDeactiveItem() );

		if( isSelectArchivedItems )
			listQuery( isSelectOnFind, myList_.firstArchivedItem() );

		if( isSelectDeletedItems )
			listQuery( isSelectOnFind, myList_.firstDeletedItem() );
		}

	protected void wordTypeQuery( boolean isSelectOnFind, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, short queryWordTypeNr )
		{
		if( isSelectActiveItems )
			wordTypeQuery( isSelectOnFind, queryWordTypeNr, myList_.firstActiveItem() );

		if( isSelectDeactiveItems )
			wordTypeQuery( isSelectOnFind, queryWordTypeNr, myList_.firstDeactiveItem() );

		if( isSelectArchivedItems )
			wordTypeQuery( isSelectOnFind, queryWordTypeNr, myList_.firstArchivedItem() );

		if( isSelectDeletedItems )
			wordTypeQuery( isSelectOnFind, queryWordTypeNr, myList_.firstDeletedItem() );
		}

	protected void parameterQuery( boolean isSelectOnFind, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, int queryParameter )
		{
		if( isSelectActiveItems )
			parameterQuery( isSelectOnFind, queryParameter, myList_.firstActiveItem() );

		if( isSelectDeactiveItems )
			parameterQuery( isSelectOnFind, queryParameter, myList_.firstDeactiveItem() );

		if( isSelectArchivedItems )
			parameterQuery( isSelectOnFind, queryParameter, myList_.firstArchivedItem() );

		if( isSelectDeletedItems )
			parameterQuery( isSelectOnFind, queryParameter, myList_.firstDeletedItem() );
		}

	protected void wordQuery( boolean isSelectOnFind, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems )
		{
		if( isSelectActiveItems )
			wordQuery( isSelectOnFind, myList_.firstActiveItem() );

		if( isSelectDeactiveItems )
			wordQuery( isSelectOnFind, myList_.firstDeactiveItem() );

		if( isSelectArchivedItems )
			wordQuery( isSelectOnFind, myList_.firstArchivedItem() );

		if( isSelectDeletedItems )
			wordQuery( isSelectOnFind, myList_.firstDeletedItem() );
		}

	protected byte compareStrings( String searchString, String sourceString )
		{
		boolean stop;
		int searchStringPosition = 0;
		int sourceStringPosition = 0;

		CommonVariables.hasFoundMatchingStrings = false;

		if( searchString != null )
			{
			if( sourceString != null )
				{
				if( searchString != sourceString )
					{
					CommonVariables.hasFoundMatchingStrings = true;

					while( CommonVariables.hasFoundMatchingStrings &&
					searchStringPosition < searchString.length() &&
					sourceStringPosition < sourceString.length() )
						{
						if( searchString.charAt( searchStringPosition ) == sourceString.charAt( sourceStringPosition ) ||
						searchString.charAt( searchStringPosition ) == Constants.SYMBOL_QUESTION_MARK )
							{
							searchStringPosition++;
							sourceStringPosition++;
							}
						else
							{
							if( searchString.charAt( searchStringPosition ) == Constants.SYMBOL_ASTERISK )
								{
								if( ++searchStringPosition < searchString.length() )
									{
									stop = false;

									while( !stop &&
									sourceStringPosition < sourceString.length() )
										{
										if( searchString.charAt( searchStringPosition ) == sourceString.charAt( sourceStringPosition ) )
											{
											// Check remaining strings
											if( compareStrings( searchString.substring( searchStringPosition ), sourceString.substring( sourceStringPosition ) ) == Constants.RESULT_OK )
												{
												if( CommonVariables.hasFoundMatchingStrings )
													{
													stop = true;
													searchStringPosition++;
													}
												else
													CommonVariables.hasFoundMatchingStrings = true;	// Reset indicator

												sourceStringPosition++;
												}
											else
												return myList_.addError( 1, moduleNameString_, "I failed to compare the remaining strings" );
											}
										else
											sourceStringPosition++;					// Skip source characters when not equal
										}
									}
								else
									sourceStringPosition = sourceString.length();	// Empty source string after asterisk
								}
							else
								CommonVariables.hasFoundMatchingStrings = false;
							}
						}

					if( CommonVariables.hasFoundMatchingStrings &&
					sourceStringPosition == sourceString.length() )
						{
						// Check search string for extra asterisks
						while( searchStringPosition < searchString.length() &&
						searchString.charAt( searchStringPosition ) == Constants.SYMBOL_ASTERISK )
							searchStringPosition++;		// Skip extra asterisks
						}

					if( searchStringPosition < searchString.length() ||
					sourceStringPosition < sourceString.length() )
						CommonVariables.hasFoundMatchingStrings = false;
					}
				else
					return myList_.startError( 1, moduleNameString_, "The given strings are the same" );
				}
			else
				return myList_.startError( 1, moduleNameString_, "The given source string is undefined" );
			}
		else
			return myList_.startError( 1, moduleNameString_, "The given search string is undefined" );

		return CommonVariables.result;
		}

	protected byte wordReferenceQuery( boolean isSelectOnFind, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, String wordReferenceNameString )
		{
		if( isSelectActiveItems )
			{
			if( wordReferenceQuery( isSelectOnFind, wordReferenceNameString, myList_.firstActiveItem() ) != Constants.RESULT_OK )
				return myList_.addError( 1, moduleNameString_, "I failed to check the word references of an active word" );
			}

		if( isSelectDeactiveItems )
			{
			if( wordReferenceQuery( isSelectOnFind, wordReferenceNameString, myList_.firstDeactiveItem() ) != Constants.RESULT_OK )
				return myList_.addError( 1, moduleNameString_, "I failed to check the word references of a deactive word" );
			}

		if( isSelectArchivedItems )
			{
			if( wordReferenceQuery( isSelectOnFind, wordReferenceNameString, myList_.firstArchivedItem() ) != Constants.RESULT_OK )
				return myList_.addError( 1, moduleNameString_, "I failed to check the word references of an archive word" );
			}

		if( isSelectDeletedItems )
			{
			if( wordReferenceQuery( isSelectOnFind, wordReferenceNameString, myList_.firstDeletedItem() ) != Constants.RESULT_OK )
				return myList_.addError( 1, moduleNameString_, "I failed to check the word references of a deleted word" );
			}

		return CommonVariables.result;
		}

	protected byte stringQuery( boolean isSelectOnFind, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, String wordString )
		{
		if( isSelectActiveItems )
			{
			if( stringQuery( isSelectOnFind, wordString, myList_.firstActiveItem() ) != Constants.RESULT_OK )
				return myList_.addError( 1, moduleNameString_, "I failed to string query an active word" );
			}

		if( isSelectDeactiveItems )
			{
			if( stringQuery( isSelectOnFind, wordString, myList_.firstDeactiveItem() ) != Constants.RESULT_OK )
				return myList_.addError( 1, moduleNameString_, "I failed to string query a deactive word" );
			}

		if( isSelectArchivedItems )
			{
			if( stringQuery( isSelectOnFind, wordString, myList_.firstArchivedItem() ) != Constants.RESULT_OK )
				return myList_.addError( 1, moduleNameString_, "I failed to string query an archive word" );
			}

		if( isSelectDeletedItems )
			{
			if( stringQuery( isSelectOnFind, wordString, myList_.firstDeletedItem() ) != Constants.RESULT_OK )
				return myList_.addError( 1, moduleNameString_, "I failed to string query a deleted word" );
			}

		return CommonVariables.result;
		}

	protected byte showQueryResult( boolean showOnlyWords, boolean showOnlyWordReferences, boolean showOnlyStrings, boolean returnQueryToPosition, short promptTypeNr, short queryWordTypeNr, int queryWidth )
		{
		if( showQueryResult( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth, myList_.firstActiveItem() ) == Constants.RESULT_OK )
			{
			if( showQueryResult( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth, myList_.firstDeactiveItem() ) == Constants.RESULT_OK )
				{
				if( showQueryResult( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth, myList_.firstArchivedItem() ) == Constants.RESULT_OK )
					{
					if( showQueryResult( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth, myList_.firstDeletedItem() ) != Constants.RESULT_OK )
						return myList_.addError( 1, moduleNameString_, "I failed to show the query result of a deleted word" );
					}
				else
					return myList_.addError( 1, moduleNameString_, "I failed to show the query result of an archive word" );
				}
			else
				return myList_.addError( 1, moduleNameString_, "I failed to show the query result of a deactive word" );
			}
		else
			return myList_.addError( 1, moduleNameString_, "I failed to show the query result of an active word" );

		return CommonVariables.result;
		}
	};

/*************************************************************************
 *
 *	"Your name, O Lord, endures forever;
 *	your name, O Lord, is known to every generation." (Psalm 135:13)
 *
 *************************************************************************/
