/* License/copyright: At the end of this file or read copyright.txt */

/*---------- Declarations --------------*/
int emotion_extract(
	char *file,char *result,long int size_result,
	char *text,long int *pos_sentence,
	int levenstein,char *targetlst,
	int doemotion,int rec);
