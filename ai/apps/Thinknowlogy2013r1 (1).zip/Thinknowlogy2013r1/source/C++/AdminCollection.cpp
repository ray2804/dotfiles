/*
 *	Class:			AdminCollection
 *	Supports class:	AdminItem
 *	Purpose:		To collect (associate, combine) words in the knowledge structure
 *					that belong together (which implies differentiating
 *					words that doesn't belong together)
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "AdminItem.h"
#include "GeneralizationItem.cpp"
#include "SpecificationItem.cpp"

class AdminCollection
	{
	// Private constructible variables

	unsigned short existingPairCollectionOrderNr_;

	CommonVariables *commonVariables_;
	AdminItem *admin_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	ResultType checkCollectionInAllWords( unsigned int collectionNr, WordItem *collectionWordItem, WordItem *commonWordItem )
		{
		unsigned short foundCollectionOrderNr = NO_ORDER_NR;
		unsigned int nWords = 0;
		WordItem *currentWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkCollectionInAllWords";

		existingPairCollectionOrderNr_ = NO_ORDER_NR;

		if( collectionNr > NO_COLLECTION_NR )
			{
			if( collectionWordItem != NULL )
				{
				if( ( currentWordItem = commonVariables_->firstWordItem ) != NULL )
					{
					do	{
						if( ( foundCollectionOrderNr = currentWordItem->collectionOrderNr( collectionNr, collectionWordItem, commonWordItem ) ) > NO_ORDER_NR )
							{
							if( ++nWords == 2 )		// Found existing collection pair
								existingPairCollectionOrderNr_ = foundCollectionOrderNr;
							}
						}
					while( existingPairCollectionOrderNr_ == NO_ORDER_NR &&
					( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The first word item is undefined" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given collection word item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given collection number is undefined" );

		return commonVariables_->result;
		}

	ResultType collectGeneralizationWords( bool isExclusiveGeneralization, bool isQuestion, unsigned short generalizationWordTypeNr, unsigned short commonWordTypeNr, WordItem *previousGeneralizationWordItem, WordItem *newGeneralizationWordItem, WordItem *commonWordItem )
		{
		CollectionResultType collectionResult;
		bool hasFoundCollection = false;
		unsigned int collectionNr = NO_COLLECTION_NR;
		char functionNameString[FUNCTION_NAME_LENGTH] = "collectGeneralizationWords";

		if( previousGeneralizationWordItem != NULL )
			{
			if( newGeneralizationWordItem != NULL )
				{
				if( previousGeneralizationWordItem != newGeneralizationWordItem )
					{
					if( commonWordItem != NULL )
						{
						if( ( collectionNr = previousGeneralizationWordItem->collectionNr( generalizationWordTypeNr, commonWordItem, NULL ) ) == NO_COLLECTION_NR )
							collectionNr = newGeneralizationWordItem->collectionNr( generalizationWordTypeNr, commonWordItem, NULL );

						if( collectionNr == NO_COLLECTION_NR )
							{
							if( ( collectionNr = myWord_->highestCollectionNrInAllWords() ) < MAX_COLLECTION_NR )
								collectionNr++;
							else
								return myWord_->startSystemErrorInItem( functionNameString, moduleNameString_, "Collection number overflow" );
							}
						else
							{
							if( ( collectionResult = newGeneralizationWordItem->findCollection( false, previousGeneralizationWordItem, commonWordItem ) ).result == RESULT_OK )
								{
								if( collectionResult.isCollected )
									hasFoundCollection = true;
								}
							else
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find out if word \"", previousGeneralizationWordItem->anyWordTypeString(), "\" is collected with word \"", newGeneralizationWordItem->anyWordTypeString(), "\"" );
							}

						if( !hasFoundCollection )
							{
							if( previousGeneralizationWordItem->addCollection( isExclusiveGeneralization, false, generalizationWordTypeNr, commonWordTypeNr, collectionNr, newGeneralizationWordItem, commonWordItem, NULL, NULL ) == RESULT_OK )
								{
								if( newGeneralizationWordItem->addCollection( isExclusiveGeneralization, false, generalizationWordTypeNr, commonWordTypeNr, collectionNr, previousGeneralizationWordItem, commonWordItem, NULL, NULL ) == RESULT_OK )
									{
									if( previousGeneralizationWordItem->collectGeneralizationAndSpecifications( isExclusiveGeneralization, true, isQuestion, collectionNr ) == RESULT_OK )
										{
										if( newGeneralizationWordItem->collectGeneralizationAndSpecifications( isExclusiveGeneralization, true, isQuestion, collectionNr ) != RESULT_OK )
											return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to collect the generalizations and specifications in the new generalization word" );
										}
									else
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to collect the generalizations and specifications in the previous generalization word" );
									}
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to collect word \"", newGeneralizationWordItem->anyWordTypeString(), "\" with word \"", previousGeneralizationWordItem->anyWordTypeString(), "\"" );
								}
							else
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to collect word \"", previousGeneralizationWordItem->anyWordTypeString(), "\" with word \"", newGeneralizationWordItem->anyWordTypeString(), "\"" );
							}
						}
					else
						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given common word item is undefined" );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given previous and new generalization word items are the same" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given new generalization word item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given previous generalization word item is undefined" );

		return commonVariables_->result;
		}


	public:
	// Constructor

	AdminCollection( AdminItem *admin, WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		existingPairCollectionOrderNr_ = NO_ORDER_NR;

		admin_ = admin;
		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "AdminCollection" );

		if( commonVariables_ != NULL )
			{
		if( admin_ != NULL )
			{
			if( myWord_ == NULL )
				strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given admin is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	CollectionResultType collectSpecificationWords( bool isExclusive, bool isExclusiveGeneralization, bool isQuestion, bool isSpecificationGeneralization, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, WordItem *compoundGeneralizationWordItem, WordItem *generalizationWordItem, WordItem *previousSpecificationWordItem, WordItem *currentSpecificationWordItem )
		{
		CollectionResultType collectionResult;
		bool hasFoundCollection = false;
		unsigned short collectionOrderNr = NO_ORDER_NR;
		unsigned int collectionNr = NO_COLLECTION_NR;
		char functionNameString[FUNCTION_NAME_LENGTH] = "collectSpecificationWords";

		if( generalizationWordItem != NULL )
			{
			if( previousSpecificationWordItem != NULL )
				{
				if( currentSpecificationWordItem != NULL )
					{
					if( previousSpecificationWordItem != currentSpecificationWordItem )
						{
						if( compoundGeneralizationWordItem == NULL )
							{
							if( ( collectionNr = previousSpecificationWordItem->collectionNr( specificationWordTypeNr, generalizationWordItem ) ) == NO_COLLECTION_NR )
								{
								if( ( collectionNr = currentSpecificationWordItem->collectionNr( specificationWordTypeNr, generalizationWordItem ) ) == NO_COLLECTION_NR )
									{
									if( ( collectionNr = previousSpecificationWordItem->collectionNr( specificationWordTypeNr ) ) == NO_COLLECTION_NR )
										collectionNr = currentSpecificationWordItem->collectionNr( specificationWordTypeNr );
									}
								}
							}
						else
							collectionNr = myWord_->collectionNrInAllWords( specificationWordTypeNr, compoundGeneralizationWordItem );

						if( collectionNr > NO_COLLECTION_NR )
							{
							if( checkCollectionInAllWords( collectionNr, currentSpecificationWordItem, generalizationWordItem ) == RESULT_OK )
								{
								if( existingPairCollectionOrderNr_ > NO_ORDER_NR )
									{
									if( ( collectionOrderNr = myWord_->highestCollectionOrderNrInAllWords( collectionNr ) ) > 1 )
										{
										if( existingPairCollectionOrderNr_ < collectionOrderNr - 1 )	// "- 1" because collections come in pairs
											{
											collectionNr = NO_COLLECTION_NR;
											collectionResult.needToRedoSpecificationCollection = true;
											}
										}
									}
								}
							else
								myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check the collection in all words" );
							}

						if( commonVariables_->result == RESULT_OK )
							{
							if( collectionNr > NO_COLLECTION_NR )
								{
								if( ( collectionResult = previousSpecificationWordItem->findCollection( true, currentSpecificationWordItem, generalizationWordItem ) ).result == RESULT_OK )
									{
									if( collectionResult.isCollected )
										hasFoundCollection = true;
									}
								else
									myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find out if word \"", currentSpecificationWordItem->anyWordTypeString(), "\" is collected with word \"", previousSpecificationWordItem->anyWordTypeString(), "\"" );
								}

							if( commonVariables_->result == RESULT_OK &&
							!hasFoundCollection )
								{
								if( collectionNr == NO_COLLECTION_NR )
									{
									if( ( collectionNr = myWord_->highestCollectionNrInAllWords() ) < MAX_COLLECTION_NR )
										collectionNr++;
									else
										myWord_->startSystemErrorInItem( functionNameString, moduleNameString_, "Collection number overflow" );
									}

								if( collectionOrderNr < MAX_ORDER_NR - 2 )
									{
									if( previousSpecificationWordItem->addCollection( isExclusive, isSpecificationGeneralization, specificationWordTypeNr, generalizationWordTypeNr, collectionNr, currentSpecificationWordItem, generalizationWordItem, compoundGeneralizationWordItem, NULL ) == RESULT_OK )
										{
										if( currentSpecificationWordItem->addCollection( isExclusive, isSpecificationGeneralization, specificationWordTypeNr, generalizationWordTypeNr, collectionNr, previousSpecificationWordItem, generalizationWordItem, compoundGeneralizationWordItem, NULL ) != RESULT_OK )
											myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to collect word \"", currentSpecificationWordItem->anyWordTypeString(), "\" with word \"", previousSpecificationWordItem->anyWordTypeString(), "\"" );
										}
									else
										myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to collect word \"", previousSpecificationWordItem->anyWordTypeString(), "\" with word \"", currentSpecificationWordItem->anyWordTypeString(), "\"" );
									}
								else
									myWord_->startSystemErrorInItem( functionNameString, moduleNameString_, "Collection order number overflow" );
								}

							if( commonVariables_->result == RESULT_OK &&
							!collectionResult.needToRedoSpecificationCollection )
								{
								if( generalizationWordItem->collectGeneralizationAndSpecifications( isExclusiveGeneralization, false, isQuestion, collectionNr ) != RESULT_OK )
									myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to collect the specification in the given generalization word" );
								}
							}
						}
					else
						myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given previous and current specification words are the same" );
					}
				else
					myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given current specification word item is undefined" );
				}
			else
				myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given previous specification word item is undefined" );
			}
		else
			myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		collectionResult.result = commonVariables_->result;
		return collectionResult;
		}

	CollectionResultType collectSpecificationStrings( bool isExclusive, bool isExclusiveGeneralization, bool isQuestion, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, WordItem *generalizationWordItem, char *previousSpecificationString, char *currentSpecificationString )
		{
		CollectionResultType collectionResult;
		unsigned int collectionNr;
		char functionNameString[FUNCTION_NAME_LENGTH] = "collectSpecificationStrings";

		if( generalizationWordItem != NULL )
			{
			if( previousSpecificationString != NULL )
				{
				if( currentSpecificationString != NULL )
					{
					if( ( collectionNr = generalizationWordItem->collectionNr( specificationWordTypeNr, NULL ) ) == NO_COLLECTION_NR )
						{
						if( ( collectionNr = myWord_->highestCollectionNrInAllWords() ) < MAX_COLLECTION_NR )
							{
							if( generalizationWordItem->addCollection( isExclusive, false, specificationWordTypeNr, generalizationWordTypeNr, ++collectionNr, NULL, NULL, NULL, previousSpecificationString ) != RESULT_OK )
								myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to collect the previous specification string \"", previousSpecificationString, "\" in generalization word \"", generalizationWordItem->anyWordTypeString(), "\"" );
							}
						else
							myWord_->startSystemErrorInItem( functionNameString, moduleNameString_, "Collection number overflow" );
						}

					if( commonVariables_->result == RESULT_OK )
						{
						if( generalizationWordItem->addCollection( isExclusive, false, specificationWordTypeNr, generalizationWordTypeNr, collectionNr, NULL, NULL, NULL, currentSpecificationString ) == RESULT_OK )
							{
							if( generalizationWordItem->collectGeneralizationAndSpecifications( isExclusiveGeneralization, false, isQuestion, collectionNr ) != RESULT_OK )
								myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to collect the specification in the given generalization word" );
							}
						else
							myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to collect the current specification string \"", currentSpecificationString, "\" in generalization word \"", generalizationWordItem->anyWordTypeString(), "\"" );
						}
					}
				else
					myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given current specification string item is undefined" );
				}
			else
				myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given previous specification string item is undefined" );
			}
		else
			myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		collectionResult.result = commonVariables_->result;
		return collectionResult;
		}

	ResultType collectGeneralizationWordWithPreviousOne( bool isExclusive, bool isExclusiveGeneralization, bool isPossessive, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short questionParameter, unsigned int relationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem )
		{
		GeneralizationResultType generalizationResult;
		GeneralizationItem *currentGeneralizationItem;
		SpecificationItem *foundSpecificationItem;
		WordItem *currentGeneralizationWordItem;
		WordItem *mostRecentGeneralizationWordItem = NULL;
		char functionNameString[FUNCTION_NAME_LENGTH] = "collectGeneralizationWordWithPreviousOne";

		if( admin_->isGeneralizationReasoningWordType( true, generalizationWordTypeNr ) )
			{
			if( generalizationWordItem != NULL )
				{
				if( specificationWordItem != NULL )
					{
					if( ( currentGeneralizationItem = specificationWordItem->firstActiveGeneralizationItemOfSpecification() ) != NULL )
						{
						do	{
							if( ( currentGeneralizationWordItem = currentGeneralizationItem->generalizationWordItem() ) != NULL )
								{
								// Check 1
								if( currentGeneralizationWordItem != generalizationWordItem &&
								currentGeneralizationItem->generalizationWordTypeNr() == generalizationWordTypeNr )
									{
									if( ( generalizationResult = currentGeneralizationWordItem->findGeneralization( true, questionParameter, generalizationWordTypeNr, generalizationWordItem ) ).result == RESULT_OK )
										{
										// Check 2
										if( !generalizationResult.hasFoundGeneralization )
											{
											// Check 3
											if( ( foundSpecificationItem = currentGeneralizationWordItem->firstAssignmentOrSpecification( isPossessive, questionParameter, relationContextNr, specificationWordItem ) ) != NULL )
												{
												// Check 4
												if( foundSpecificationItem->isExclusive() == isExclusive ||
												foundSpecificationItem->hasGeneralizationCollection() )
													mostRecentGeneralizationWordItem = currentGeneralizationWordItem;
												}
											}
										}
									else
										myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a generalization item" );
									}
								}
							else
								return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found an undefined generalization word" );
							}
						while( commonVariables_->result == RESULT_OK &&
						( currentGeneralizationItem = currentGeneralizationItem->nextGeneralizationItemOfSpecification() ) != NULL );

						if( commonVariables_->result == RESULT_OK &&
						mostRecentGeneralizationWordItem != NULL )
							{
							if( collectGeneralizationWords( isExclusiveGeneralization, ( questionParameter > NO_QUESTION_PARAMETER ), generalizationWordTypeNr, specificationWordTypeNr, mostRecentGeneralizationWordItem, generalizationWordItem, specificationWordItem ) != RESULT_OK )
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to collect generalization words \"", generalizationWordItem->anyWordTypeString(), "\" and \"", mostRecentGeneralizationWordItem->anyWordTypeString(), "\"" );
							}
						}
					else
						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I couldn't find any generalization word" );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word item is undefined" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word type isn't a reasoning type" );

		return commonVariables_->result;
		}

	ResultType collectRelationWords( bool isExclusive, unsigned short relationWordTypeNr, unsigned short commonWordTypeNr, WordItem *previousRelationWordItem, WordItem *currentRelationWordItem, WordItem *commonWordItem )
		{
		CollectionResultType collectionResult;
		bool hasFoundCollection = false;
		unsigned int collectionNr = NO_COLLECTION_NR;
		char functionNameString[FUNCTION_NAME_LENGTH] = "collectRelationWords";

		if( previousRelationWordItem != NULL )
			{
			if( currentRelationWordItem != NULL )
				{
				if( previousRelationWordItem != currentRelationWordItem )
					{
					if( ( collectionNr = previousRelationWordItem->collectionNr( relationWordTypeNr, commonWordItem, NULL ) ) == NO_COLLECTION_NR )
						collectionNr = currentRelationWordItem->collectionNr( relationWordTypeNr, commonWordItem, NULL );

					if( collectionNr == NO_COLLECTION_NR )
						{
						if( ( collectionNr = myWord_->highestCollectionNrInAllWords() ) < MAX_COLLECTION_NR )
							collectionNr++;
						else
							return myWord_->startSystemErrorInItem( functionNameString, moduleNameString_, "Collection number overflow" );
						}
					else
						{
						if( ( collectionResult = previousRelationWordItem->findCollection( false, currentRelationWordItem, commonWordItem ) ).result == RESULT_OK )
							{
							if( collectionResult.isCollected )
								hasFoundCollection = true;
							}
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find out if word \"", previousRelationWordItem->anyWordTypeString(), "\" is collected with word \"", currentRelationWordItem->anyWordTypeString(), "\"" );
						}

					if( !hasFoundCollection )
						{
						if( previousRelationWordItem->addCollection( isExclusive, false, relationWordTypeNr, commonWordTypeNr, collectionNr, currentRelationWordItem, commonWordItem, NULL, NULL ) == RESULT_OK )
							{
							if( currentRelationWordItem->addCollection( isExclusive, false, relationWordTypeNr, commonWordTypeNr, collectionNr, previousRelationWordItem, commonWordItem, NULL, NULL ) != RESULT_OK )
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to collect word \"", currentRelationWordItem->anyWordTypeString(), "\" with word \"", previousRelationWordItem->anyWordTypeString(), "\"" );
							}
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to collect word \"", previousRelationWordItem->anyWordTypeString(), "\" with word \"", currentRelationWordItem->anyWordTypeString(), "\"" );
						}
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given previous and current relation words are the same" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given current relation word item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given previous relation word item is undefined" );

		return commonVariables_->result;
		}
	};

/*************************************************************************
 *
 *	"I will sing of your love and justice, O Lord.
 *	I will praise you with songs." (Psalm 101:1)
 *
 *************************************************************************/
