/*
 *	Class:			ListCleanup
 *	Supports class:	List
 *	Purpose:		To cleanup unnecessary items in the lists
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include <limits.h>		// Needed by some compilers, like Code::Blocks
#include "List.h"

class ListCleanup
	{
	// Private constructible variables

	CommonVariables *commonVariables_;
	List *myList_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	void currentItemNr( Item *searchItem )
		{
		while( searchItem != NULL )
			{
			if( searchItem->hasCurrentCreationSentenceNr() &&
			searchItem->itemNr() > commonVariables_->currentItemNr )
				commonVariables_->currentItemNr = searchItem->itemNr();

			searchItem = searchItem->nextItem;
			}
		}

	unsigned int highestInUseSentenceNrInList( unsigned int highestSentenceNr, Item *searchItem )
		{
		unsigned int tempSentenceNr;
		unsigned int highestInUseSentenceNr = NO_SENTENCE_NR;

		while( searchItem != NULL &&
		highestInUseSentenceNr < highestSentenceNr )
			{
			tempSentenceNr = searchItem->activeSentenceNr();

			if( tempSentenceNr > highestInUseSentenceNr &&
			tempSentenceNr <= highestSentenceNr )
				highestInUseSentenceNr = tempSentenceNr;

			tempSentenceNr = searchItem->deactiveSentenceNr();

			if( tempSentenceNr > highestInUseSentenceNr &&
			tempSentenceNr <= highestSentenceNr )
				highestInUseSentenceNr = tempSentenceNr;

			tempSentenceNr = searchItem->archiveSentenceNr();

			if( tempSentenceNr > highestInUseSentenceNr &&
			tempSentenceNr <= highestSentenceNr )
				highestInUseSentenceNr = tempSentenceNr;

			searchItem = searchItem->nextItem;
			}

		return highestInUseSentenceNr;
		}

	ResultType decrementSentenceNrs( unsigned int startSentenceNr, Item *searchItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "decrementSentenceNrs";
		while( searchItem != NULL )
			{
			if( searchItem->activeSentenceNr() >= startSentenceNr )
				{
				if( searchItem->activeSentenceNr() > startSentenceNr )
					{
					if( searchItem->decrementActiveSentenceNr() != RESULT_OK )
						return myList_->addError( functionNameString, moduleNameString_, "I failed to decrement the active sentence number of an item" );
					}
				else
					return myList_->startError( functionNameString, moduleNameString_, "I found an item with an active sentence number equal to the given start sentence number ", startSentenceNr );
				}

			if( searchItem->deactiveSentenceNr() >= startSentenceNr )
				{
				if( searchItem->deactiveSentenceNr() > startSentenceNr )
					{
					if( searchItem->decrementDeactiveSentenceNr() != RESULT_OK )
						return myList_->addError( functionNameString, moduleNameString_, "I failed to decrement the deactive sentence number of an item" );
					}
				else
					return myList_->startError( functionNameString, moduleNameString_, "I found an item with a deactive sentence number equal to the given start sentence number ", startSentenceNr );
				}

			if( searchItem->originalSentenceNr() >= startSentenceNr )
				{
				if( searchItem->originalSentenceNr() > startSentenceNr )
					{
					if( searchItem->decrementOriginalSentenceNr() != RESULT_OK )
						return myList_->addError( functionNameString, moduleNameString_, "I failed to decrement the original sentence number of an item" );
					}
				else
					return myList_->startError( functionNameString, moduleNameString_, "I found an item with an original sentence number equal to the given start sentence number ", startSentenceNr );
				}

			if( searchItem->creationSentenceNr() >= startSentenceNr )
				{
				if( searchItem->creationSentenceNr() > startSentenceNr )
					{
					if( searchItem->decrementCreationSentenceNr() != RESULT_OK )
						return myList_->addError( functionNameString, moduleNameString_, "I failed to decrement the creation sentence number of an item" );
					}
				else
					return myList_->startError( functionNameString, moduleNameString_, "I found an item with a creation sentence number equal to the given start sentence number ", startSentenceNr );
				}

			if( searchItem->archiveSentenceNr() >= startSentenceNr )
				{
				if( searchItem->archiveSentenceNr() > startSentenceNr )
					{
					if( searchItem->decrementArchivedSentenceNr() != RESULT_OK )
						return myList_->addError( functionNameString, moduleNameString_, "I failed to decrement the archive sentence number of an item" );
					}
				else
					return myList_->startError( functionNameString, moduleNameString_, "I found an item with an archive sentence number equal to the given start sentence number ", startSentenceNr );
				}

			searchItem = searchItem->nextItem;
			}

		return commonVariables_->result;
		}

	ResultType decrementItemNrRange( unsigned int decrementSentenceNr, unsigned int startDecrementItemNr, unsigned int decrementOffset, Item *searchItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "decrementItemNrRange";
		while( searchItem != NULL )
			{
			if( searchItem->creationSentenceNr() == decrementSentenceNr &&
			searchItem->itemNr() >= startDecrementItemNr )
				{
				if( searchItem->itemNr() > startDecrementItemNr )
					{
					if( searchItem->decrementCreationItemNr( decrementOffset ) != RESULT_OK )
						return myList_->addError( functionNameString, moduleNameString_, "I failed to decrement the creation item number of an item with a certain offset" );
					}
				else
					return myList_->startError( functionNameString, moduleNameString_, "I found an item number equal to the given start item number" );
				}

			searchItem = searchItem->nextItem;
			}

		return commonVariables_->result;
		}


	public:
	// Constructor

	ListCleanup( List *myList, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		myList_ = myList;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "ListCleanup" );

		if( commonVariables_ != NULL )
			{
		if( myList_ == NULL )
			strcpy( errorString, "The given my list is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myList_ != NULL )
				myList_->startSystemError( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	void currentItemNr()
		{
		currentItemNr( myList_->firstActiveItem() );
		currentItemNr( myList_->firstDeactiveItem() );
		currentItemNr( myList_->firstArchivedItem() );
		currentItemNr( myList_->firstDeletedItem() );
		}

	void deleteRollbackInfo()
		{
		Item *searchItem = myList_->firstDeletedItem();

		while( searchItem != NULL )
			{
			if( searchItem->isAvailableForRollback &&
			searchItem->deleteSentenceNr() >= commonVariables_->currentSentenceNr )
				searchItem->isAvailableForRollback = false;

			searchItem = searchItem->nextItem;
			}
		}

	unsigned int highestInUseSentenceNrInList( bool includeDeletedItems, unsigned int highestSentenceNr )
		{
		unsigned int tempSentenceNr;
		unsigned int highestInUseSentenceNr = highestInUseSentenceNrInList( highestSentenceNr, myList_->firstActiveItem() );

		if( ( tempSentenceNr = highestInUseSentenceNrInList( highestSentenceNr, myList_->firstDeactiveItem() ) ) > highestInUseSentenceNr )
			highestInUseSentenceNr = tempSentenceNr;

		if( ( tempSentenceNr = highestInUseSentenceNrInList( highestSentenceNr, myList_->firstArchivedItem() ) ) > highestInUseSentenceNr )
			highestInUseSentenceNr = tempSentenceNr;

		if( includeDeletedItems &&
		( tempSentenceNr = highestInUseSentenceNrInList( highestSentenceNr, myList_->firstDeletedItem() ) ) > highestInUseSentenceNr )
			highestInUseSentenceNr = tempSentenceNr;

		return highestInUseSentenceNr;
		}

	ResultType rollbackDeletedRedoInfo()
		{
		Item *searchItem = myList_->firstDeletedItem();
		char functionNameString[FUNCTION_NAME_LENGTH] = "rollbackDeletedRedoInfo";

		while( searchItem != NULL )
			{
			if( searchItem->isAvailableForRollback &&
			searchItem->hasCurrentDeletedSentenceNr() )
				{
				searchItem->isAvailableForRollback = false;

				if( myList_->removeItemFromDeletedList( searchItem ) == RESULT_OK )
					{
					if( searchItem->hasDeactiveSentenceNr() )
						{
						if( searchItem->hasArchivedSentenceNr() )
							{
							searchItem->setArchivedStatus();

							if( myList_->addItemToArchivedList( searchItem ) == RESULT_OK )
								searchItem = myList_->nextListItem();
							else
								return myList_->addError( functionNameString, moduleNameString_, "I failed to add an item to the archive list" );
							}
						else
							{
							searchItem->setDeactiveStatus();

							if( myList_->addItemToDeactiveList( searchItem ) == RESULT_OK )
								searchItem = myList_->nextListItem();
							else
								return myList_->addError( functionNameString, moduleNameString_, "I failed to add an item to the deactive list" );
							}
						}
					else
						{
						searchItem->setActiveStatus();

						if( myList_->addItemToActiveList( searchItem ) == RESULT_OK )
							searchItem = myList_->nextListItem();
						else
							return myList_->addError( functionNameString, moduleNameString_, "I failed to add an item to the active list" );
						}
					}
				else
					return myList_->addError( functionNameString, moduleNameString_, "I failed to remove an item from the deleted list" );
				}
			else
				searchItem = searchItem->nextItem;
			}

		return commonVariables_->result;
		}

	ResultType decrementSentenceNrs( unsigned int startSentenceNr )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "decrementSentenceNrs";
		if( startSentenceNr > NO_SENTENCE_NR )
			{
			if( decrementSentenceNrs( startSentenceNr, myList_->firstActiveItem() ) == RESULT_OK )
				{
				if( decrementSentenceNrs( startSentenceNr, myList_->firstDeactiveItem() ) == RESULT_OK )
					{
					if( decrementSentenceNrs( startSentenceNr, myList_->firstArchivedItem() ) == RESULT_OK )
						decrementSentenceNrs( startSentenceNr, myList_->firstDeletedItem() );
					}
				}
			}
		else
			return myList_->startError( functionNameString, moduleNameString_, "The given start sentence number is undefined" );

		return commonVariables_->result;
		}

	ResultType decrementItemNrRange( unsigned int decrementSentenceNr, unsigned int startDecrementItemNr, unsigned int decrementOffset )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "decrementItemNrRange";
		if( decrementSentenceNr >= NO_SENTENCE_NR &&
		decrementSentenceNr < MAX_SENTENCE_NR )
			{
			if( startDecrementItemNr > NO_ITEM_NR )
				{
				if( decrementOffset > 0 )
					{
					if( decrementItemNrRange( decrementSentenceNr, startDecrementItemNr, decrementOffset, myList_->firstActiveItem() ) == RESULT_OK )
						{
						if( decrementItemNrRange( decrementSentenceNr, startDecrementItemNr, decrementOffset, myList_->firstDeactiveItem() ) == RESULT_OK )
							{
							if( decrementItemNrRange( decrementSentenceNr, startDecrementItemNr, decrementOffset, myList_->firstArchivedItem() ) == RESULT_OK )
								return decrementItemNrRange( decrementSentenceNr, startDecrementItemNr, decrementOffset, myList_->firstDeletedItem() );
							}
						}
					}
				else
					return myList_->startError( functionNameString, moduleNameString_, "The given decrement offset is undefined" );
				}
			else
				return myList_->startError( functionNameString, moduleNameString_, "The given start item number is undefined" );
			}
		else
			return myList_->startError( functionNameString, moduleNameString_, "The given decrement sentence number is undefined" );

		return commonVariables_->result;
		}

	ResultType deleteSentences( bool isAvailableForRollback, unsigned int lowestSentenceNr )
		{
		Item *searchItem = myList_->firstActiveItem();
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteSentences";

		if( lowestSentenceNr > NO_SENTENCE_NR )
			{
			while( searchItem != NULL )
				{
				if( searchItem->activeSentenceNr() >= lowestSentenceNr )
					{
					if( searchItem->creationSentenceNr() >= lowestSentenceNr )
						{
						if( myList_->deleteActiveItem( isAvailableForRollback, searchItem ) != RESULT_OK )
							return myList_->addError( functionNameString, moduleNameString_, "I failed to delete an active item" );
						}
					else
						{
						if( myList_->deactivateActiveItem( searchItem ) != RESULT_OK )
							return myList_->addError( functionNameString, moduleNameString_, "I failed to deactivate an active item" );
						}

					searchItem = myList_->nextListItem();

					if( myList_->isAssignmentList() )
						commonVariables_->isAssignmentChanged = true;
					}
				else
					searchItem = searchItem->nextItem;
				}

			searchItem = myList_->firstDeactiveItem();

			while( searchItem != NULL )
				{
				if( searchItem->deactiveSentenceNr() >= lowestSentenceNr )
					{
					if( searchItem->creationSentenceNr() >= lowestSentenceNr )
						{
						if( myList_->deleteDeactiveItem( isAvailableForRollback, searchItem ) != RESULT_OK )
							return myList_->addError( functionNameString, moduleNameString_, "I failed to archive a deactive item" );
						}
					else
						{
						if( myList_->activateDeactiveItem( searchItem ) != RESULT_OK )
							return myList_->addError( functionNameString, moduleNameString_, "I failed to activate a deactive item" );
						}

					searchItem = myList_->nextListItem();

					if( myList_->isAssignmentList() )
						commonVariables_->isAssignmentChanged = true;
					}
				else
					searchItem = searchItem->nextItem;
				}

			searchItem = myList_->firstArchivedItem();

			while( searchItem != NULL )
				{
				if( searchItem->archiveSentenceNr() >= lowestSentenceNr )
					{
					if( searchItem->creationSentenceNr() >= lowestSentenceNr )
						{
						if( myList_->deleteArchivedItem( isAvailableForRollback, searchItem ) != RESULT_OK )
							return myList_->addError( functionNameString, moduleNameString_, "I failed to delete an archive item" );
						}
					else
						{
						searchItem->clearArchivedSentenceNr();

						if( searchItem->wasActiveBeforeArchiving )
							{
							if( myList_->activateArchivedItem( true, searchItem ) != RESULT_OK )
								return myList_->addError( functionNameString, moduleNameString_, "I failed to activate an archive item" );
							}
						else
							{
							if( myList_->deactivateArchivedItem( true, searchItem ) != RESULT_OK )
								return myList_->addError( functionNameString, moduleNameString_, "I failed to deactivate an archive item" );
							}
						}

					searchItem = myList_->nextListItem();

					if( myList_->isAssignmentList() )
						commonVariables_->isAssignmentChanged = true;
					}
				else
					searchItem = searchItem->nextItem;
				}
			}
		else
			return myList_->startError( functionNameString, moduleNameString_, "The given lowest sentence number is undefined" );

		return commonVariables_->result;
		}

	ResultType undoCurrentSentence()
		{
		Item *searchItem = myList_->firstActiveItem();
		char functionNameString[FUNCTION_NAME_LENGTH] = "undoCurrentSentence";

		while( searchItem != NULL )
			{
			if( searchItem->activeSentenceNr() >= commonVariables_->currentSentenceNr )
				{
				if( searchItem->hasDeactiveSentenceNr() &&
				searchItem->hasCurrentActiveSentenceNr() &&
				searchItem->deactiveSentenceNr() < searchItem->activeSentenceNr() )
					{
					if( myList_->deactivateActiveItem( searchItem ) != RESULT_OK )
						return myList_->addError( functionNameString, moduleNameString_, "I failed to deactivate an active item" );
					}
				else
					{
					if( myList_->archiveActiveItem( searchItem ) != RESULT_OK )
						return myList_->addError( functionNameString, moduleNameString_, "I failed to archive an active item" );
					}

				searchItem = myList_->nextListItem();

				if( myList_->isAssignmentList() )
					commonVariables_->isAssignmentChanged = true;
				}
			else
				searchItem = searchItem->nextItem;
			}

		searchItem = myList_->firstDeactiveItem();

		while( searchItem != NULL )
			{
			if( searchItem->deactiveSentenceNr() >= commonVariables_->currentSentenceNr )
				{
				if( searchItem->hasActiveSentenceNr() &&
				searchItem->hasCurrentDeactiveSentenceNr() &&
				searchItem->activeSentenceNr() < searchItem->deactiveSentenceNr() )
					{
					if( myList_->activateDeactiveItem( searchItem ) != RESULT_OK )
						return myList_->addError( functionNameString, moduleNameString_, "I failed to activate a deactive item" );
					}
				else
					{
					if( myList_->archiveDeactiveItem( searchItem ) != RESULT_OK )
						return myList_->addError( functionNameString, moduleNameString_, "I failed to archive a deactive item" );
					}

				searchItem = myList_->nextListItem();

				if( myList_->isAssignmentList() )
					commonVariables_->isAssignmentChanged = true;
				}
			else
				searchItem = searchItem->nextItem;
			}

		searchItem = myList_->firstArchivedItem();

		while( searchItem != NULL )
			{
			if( ( searchItem->archiveSentenceNr() == commonVariables_->currentSentenceNr &&
			searchItem->creationSentenceNr() < commonVariables_->currentSentenceNr ) ||

			( searchItem->archiveSentenceNr() + 1 == commonVariables_->currentSentenceNr &&
			searchItem->creationSentenceNr() + 1 == commonVariables_->currentSentenceNr ) )
				{
				if( ( searchItem->wasActiveBeforeArchiving &&
				( searchItem->activeSentenceNr() >= searchItem->deactiveSentenceNr() ||
				searchItem->activeSentenceNr() != commonVariables_->currentSentenceNr ) ) ||

				( !searchItem->wasActiveBeforeArchiving &&
				searchItem->activeSentenceNr() < searchItem->deactiveSentenceNr() &&
				searchItem->hasCurrentDeactiveSentenceNr() ) )
					{
					if( myList_->activateArchivedItem( true, searchItem ) != RESULT_OK )
						return myList_->addError( functionNameString, moduleNameString_, "I failed to activate an archive item" );
					}
				else
					{
					if( myList_->deactivateArchivedItem( true, searchItem ) != RESULT_OK )
						return myList_->addError( functionNameString, moduleNameString_, "I failed to deactivate an archive item" );
					}

				searchItem = myList_->nextListItem();

				if( myList_->isAssignmentList() )
					commonVariables_->isAssignmentChanged = true;
				}
			else
				searchItem = searchItem->nextItem;
			}

		return commonVariables_->result;
		}

	ResultType redoCurrentSentence()
		{
		Item *searchItem = myList_->firstActiveItem();
		char functionNameString[FUNCTION_NAME_LENGTH] = "redoCurrentSentence";

		while( searchItem != NULL )
			{
			if( searchItem->activeSentenceNr() < commonVariables_->currentSentenceNr &&

			( searchItem->hasCurrentDeactiveSentenceNr() ||
			searchItem->hasCurrentArchivedSentenceNr() ) )
				{
				if( searchItem->deactiveSentenceNr() > searchItem->archiveSentenceNr() )
					{
					if( myList_->deactivateActiveItem( searchItem ) != RESULT_OK )
						return myList_->addError( functionNameString, moduleNameString_, "I failed to deactivate an active item" );
					}
				else
					{
					if( myList_->archiveActiveItem( searchItem ) != RESULT_OK )
						return myList_->addError( functionNameString, moduleNameString_, "I failed to archive an active item" );
					}

				searchItem = myList_->nextListItem();

				if( myList_->isAssignmentList() )
					commonVariables_->isAssignmentChanged = true;
				}
			else
				searchItem = searchItem->nextItem;
			}

		searchItem = myList_->firstDeactiveItem();

		while( searchItem != NULL )
			{
			if( searchItem->deactiveSentenceNr() < commonVariables_->currentSentenceNr &&
			( searchItem->hasCurrentActiveSentenceNr() ||
			searchItem->hasCurrentArchivedSentenceNr() ) )
				{
				if( searchItem->deactiveSentenceNr() > searchItem->archiveSentenceNr() )
					{
					if( myList_->activateDeactiveItem( searchItem ) != RESULT_OK )
						return myList_->addError( functionNameString, moduleNameString_, "I failed to activate a deactive item" );
					}
				else
					{
					if( myList_->archiveDeactiveItem( searchItem ) != RESULT_OK )
						return myList_->addError( functionNameString, moduleNameString_, "I failed to archive a deactive item" );
					}

				searchItem = myList_->nextListItem();

				if( myList_->isAssignmentList() )
					commonVariables_->isAssignmentChanged = true;
				}
			else
				searchItem = searchItem->nextItem;
			}

		searchItem = myList_->firstArchivedItem();

		while( searchItem != NULL )
			{
			if( searchItem->hasCurrentCreationSentenceNr() )
				{
				if( searchItem->wasActiveBeforeArchiving )
					{
					if( myList_->activateArchivedItem( true, searchItem ) != RESULT_OK )
						return myList_->addError( functionNameString, moduleNameString_, "I failed to activate an archive item" );
					}
				else
					{
					if( myList_->deactivateArchivedItem( true, searchItem ) != RESULT_OK )
						return myList_->addError( functionNameString, moduleNameString_, "I failed to deactivate an archive item" );
					}

				searchItem = myList_->nextListItem();

				if( myList_->isAssignmentList() )
					commonVariables_->isAssignmentChanged = true;
				}
			else
				searchItem = searchItem->nextItem;
			}

		return commonVariables_->result;
		}
	};

/*************************************************************************
 *
 *	"The winds blows, and we are gone -
 *	as though we had never been here.
 *	But the love of the Lord remains forever
 *	with those who fear him." (Psalm 103:16-17)
 *
 *************************************************************************/
