/*
 *	Class:			ContextList
 *	Parent class:	List
 *	Purpose:		To store context items
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "ContextItem.cpp"
#include "List.h"

class ContextList : private List
	{
	friend class WordItem;


	// Private deconstructor functions

	void deleteContextList( ContextItem *searchItem )
		{
		ContextItem *deleteItem;

		while( searchItem != NULL )
			{
			deleteItem = searchItem;
			searchItem = searchItem->nextContextItem();
			delete deleteItem;
			}
		}


	// Private functions

	bool hasContext( bool isPossessive, unsigned int contextNr )
		{
		ContextItem *searchItem = firstActiveContextItem();

		while( searchItem != NULL )
			{
			if( searchItem->isPossessive() == isPossessive &&
			searchItem->contextNr() == contextNr )
				return true;

			searchItem = searchItem->nextContextItem();
			}

		return false;
		}

	ResultType createContextItem( bool isPossessive, unsigned short contextWordTypeNr, unsigned short specificationWordTypeNr, unsigned int contextNr, WordItem *specificationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "createContextItem";
		if( contextNr > NO_CONTEXT_NR )
			{
			if( commonVariables()->currentItemNr < MAX_ITEM_NR )
				{
				if( addItemToActiveList( (Item *)( new ContextItem( isPossessive, contextWordTypeNr, specificationWordTypeNr, contextNr, specificationWordItem, this, myWord(), commonVariables() ) ) ) != RESULT_OK )
					return addError( functionNameString, NULL, "I failed to add an active context item" );
				}
			else
				return startError( functionNameString, NULL, "The current item number is undefined" );
			}
		else
			return startError( functionNameString, NULL, "The given context number is undefined" );

		return commonVariables()->result;
		}


	public:
	// Constructor

	ContextList( WordItem *myWord, CommonVariables *commonVariables )
		{
		initializeListVariables( WORD_CONTEXT_LIST_SYMBOL, "ContextList", myWord, commonVariables );
		}

	// Deconstructor

	~ContextList()
		{
		deleteContextList( firstActiveContextItem() );
		deleteContextList( (ContextItem *)firstDeactiveItem() );
		deleteContextList( firstArchivedContextItem() );
		deleteContextList( (ContextItem *)firstDeletedItem() );
		}


	// Protected functions

	void clearContextWriteLevel( unsigned short currentWriteLevel, unsigned int contextNr )
		{
		ContextItem *searchItem = firstActiveContextItem();

		while( searchItem != NULL )
			{
			if( searchItem->contextNr() == contextNr )
				myWord()->clearWriteLevel( currentWriteLevel );

			searchItem = searchItem->nextContextItem();
			}
		}

	bool hasContext( unsigned int contextNr )
		{
		ContextItem *searchItem = firstActiveContextItem();

		while( searchItem != NULL )
			{
			if( searchItem->contextNr() == contextNr )
				return true;

			searchItem = searchItem->nextContextItem();
			}

		return false;
		}

	bool hasContext( bool isPossessive, unsigned int contextNr, WordItem *specificationWordItem )
		{
		ContextItem *searchItem = firstActiveContextItem();

		while( searchItem != NULL )
			{
			if( searchItem->isPossessive() == isPossessive &&
			searchItem->contextNr() == contextNr &&
			searchItem->specificationWordItem() == specificationWordItem )
				return true;

			searchItem = searchItem->nextContextItem();
			}

		return false;
		}

	bool isContextCurrentlyUpdated( bool isPossessive, unsigned int contextNr, WordItem *specificationWordItem )
		{
		ContextItem *searchItem = firstActiveContextItem();

		while( searchItem != NULL )
			{
			if( searchItem->hasCurrentCreationSentenceNr() &&
			searchItem->isPossessive() == isPossessive &&
			searchItem->contextNr() == contextNr &&
			searchItem->specificationWordItem() == specificationWordItem )
				return true;

			searchItem = searchItem->nextContextItem();
			}

		return false;
		}

	bool isContextSubset( unsigned int subsetContextNr, unsigned int fullSetContextNr )
		{
		ContextItem *searchItem = firstActiveContextItem();

		while( searchItem != NULL )
			{
			if( searchItem->contextNr() == subsetContextNr &&
			hasContext( searchItem->isPossessive(), fullSetContextNr, searchItem->specificationWordItem() ) )
				return true;

			searchItem = searchItem->nextContextItem();
			}

		return false;
		}

	unsigned int contextNr( bool isPossessive, unsigned short contextWordTypeNr, WordItem *specificationWordItem )
		{
		ContextItem *searchItem = firstActiveContextItem();

		while( searchItem != NULL )
			{
			if( searchItem->isPossessive() == isPossessive &&
			searchItem->contextWordTypeNr() == contextWordTypeNr &&
			searchItem->specificationWordItem() == specificationWordItem )
				return searchItem->contextNr();

			searchItem = searchItem->nextContextItem();
			}

		return NO_CONTEXT_NR;
		}

	unsigned int highestContextNr()
		{
		unsigned int highestContextNr = NO_CONTEXT_NR;
		ContextItem *searchItem = firstActiveContextItem();

		while( searchItem != NULL )
			{
			if( searchItem->contextNr() > highestContextNr )
				highestContextNr = searchItem->contextNr();

			searchItem = searchItem->nextContextItem();
			}

		searchItem = firstArchivedContextItem();

		while( searchItem != NULL )
			{
			if( searchItem->contextNr() > highestContextNr )
				highestContextNr = searchItem->contextNr();

			searchItem = searchItem->nextContextItem();
			}

		return highestContextNr;
		}

	ResultType checkWordItemForUsage( WordItem *unusedWordItem )
		{
		ContextItem *searchItem = firstActiveContextItem();
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkWordItemForUsage";

		if( unusedWordItem != NULL )
			{
			while( searchItem != NULL )
				{
				if( searchItem->specificationWordItem() == unusedWordItem )
					return startError( functionNameString, NULL, "The specification word item is still in use" );

				searchItem = searchItem->nextContextItem();
				}
			}
		else
			return startError( functionNameString, NULL, "The given unused word item is undefined" );

		return commonVariables()->result;
		}

	ResultType addContext( bool isPossessive, unsigned short contextWordTypeNr, unsigned short specificationWordTypeNr, unsigned int contextNr, WordItem *specificationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "addContext";
		if( contextNr > NO_CONTEXT_NR )
			{
			if( ( specificationWordItem == NULL &&				// Pronoun context
			!hasContext( contextNr ) ) ||

			( specificationWordItem != NULL &&					// Relation context
			!hasContext( isPossessive, contextNr, specificationWordItem ) ) )
				{
				if( !hasContext( !isPossessive, contextNr ) )	// Opposite possessive context should have a different context number
					{
					if( createContextItem( isPossessive, contextWordTypeNr, specificationWordTypeNr, contextNr, specificationWordItem ) != RESULT_OK )
						return addError( functionNameString, NULL, "I failed to create a context item" );
					}
				else
					return startError( functionNameString, NULL, "The given context number already exists as an opposite possessive" );
				}
			}
		else
			return startError( functionNameString, NULL, "The given context number is undefined" );

		return commonVariables()->result;
		}

	ContextItem *firstActiveContextItem()
		{
		return (ContextItem *)firstActiveItem();
		}

	ContextItem *firstArchivedContextItem()
		{
		return (ContextItem *)firstArchivedItem();
		}

	ContextItem *nextContextListItem()
		{
		return (ContextItem *)nextListItem();
		}

	ContextItem *contextItem( unsigned int contextNr )
		{
		ContextItem *searchItem = firstActiveContextItem();

		while( searchItem != NULL )
			{
			if( searchItem->contextNr() == contextNr )
				return searchItem;

			searchItem = searchItem->nextContextItem();
			}

		return NULL;
		}

	ContextItem *contextItem( bool isPossessive, unsigned short contextWordTypeNr, WordItem *specificationWordItem )
		{
		ContextItem *searchItem = firstActiveContextItem();

		while( searchItem != NULL )
			{
			if( searchItem->isPossessive() == isPossessive &&
			searchItem->contextWordTypeNr() == contextWordTypeNr &&
			searchItem->specificationWordItem() == specificationWordItem )
				return searchItem;

			searchItem = searchItem->nextContextItem();
			}

		return NULL;
		}

	ContextItem *contextItem( bool isPossessive, unsigned short contextWordTypeNr, unsigned int contextNr, WordItem *specificationWordItem )
		{
		ContextItem *searchItem = firstActiveContextItem();

		while( searchItem != NULL )
			{
			if( searchItem->isPossessive() == isPossessive &&
			searchItem->contextWordTypeNr() == contextWordTypeNr &&
			searchItem->contextNr() == contextNr &&
			searchItem->specificationWordItem() == specificationWordItem )
				return searchItem;

			searchItem = searchItem->nextContextItem();
			}

		return NULL;
		}
	};

/*************************************************************************
 *
 *	"O Lord my God, you have performed many wonders for us.
 *	Your plans for us are too numerous to list.
 *	You have no equal.
 *	I have tried to recite all your wonderful deeds,
 *	I would never come to the end of them." (Psalm 40:5)
 *
 *************************************************************************/
