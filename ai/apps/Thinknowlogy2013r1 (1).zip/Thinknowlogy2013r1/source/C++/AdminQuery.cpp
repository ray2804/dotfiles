/*
 *	Class:			AdminQuery
 *	Supports class:	AdminItem
 *	Purpose:		To process queries
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "AdminItem.h"
#include "Presentation.cpp"
#include "WordList.cpp"

class AdminQuery
	{
	// Private constructible variables

	unsigned int queryItemNr_;
	unsigned int querySentenceNr_;
	size_t queryStringPosition_;

	CommonVariables *commonVariables_;
	AdminItem *admin_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	void clearQuerySelections()
		{
		if( admin_->wordList != NULL )						// Inside words
			admin_->wordList->clearQuerySelectionsInWordList();

		for( unsigned short adminListNr = 0; adminListNr < NUMBER_OF_ADMIN_LISTS; adminListNr++ )
			{
			if( admin_->adminList[adminListNr] != NULL )	// Inside admin lists
				admin_->adminList[adminListNr]->clearQuerySelectionsInList();
			}
		}

	bool hasFoundMoreCategories()
		{
		return ( ( commonVariables_->nActiveQueryItems > 0 &&
				commonVariables_->nDeactiveQueryItems > 0 ) ||

				( commonVariables_->nActiveQueryItems > 0 &&
				commonVariables_->nArchivedQueryItems > 0 ) ||

				( commonVariables_->nActiveQueryItems > 0 &&
				commonVariables_->nDeletedQueryItems > 0 ) ||

				( commonVariables_->nDeactiveQueryItems > 0 &&
				commonVariables_->nArchivedQueryItems > 0 ) ||

				( commonVariables_->nDeactiveQueryItems > 0 &&
				commonVariables_->nDeletedQueryItems > 0 ) ||

				( commonVariables_->nArchivedQueryItems > 0 &&
				commonVariables_->nDeletedQueryItems > 0 ) );
		}

	bool isAdminListChar( char queryListChar )
		{
		return ( queryListChar == ADMIN_FILE_LIST_SYMBOL ||
				queryListChar == ADMIN_READ_LIST_SYMBOL ||
				queryListChar == ADMIN_SCORE_LIST_SYMBOL ||
				queryListChar == ADMIN_WORD_LIST_SYMBOL ||
				queryListChar == ADMIN_CONDITION_LIST_SYMBOL ||
				queryListChar == ADMIN_ACTION_LIST_SYMBOL ||
				queryListChar == ADMIN_ALTERNATIVE_LIST_SYMBOL );
		}

	bool isWordListChar( char queryListChar )
		{
		return ( queryListChar == WORD_ASSIGNMENT_LIST_SYMBOL ||
				queryListChar == WORD_COLLECTION_LIST_SYMBOL ||
				queryListChar == WORD_GENERALIZATION_LIST_SYMBOL ||
				queryListChar == WORD_INTERFACE_LANGUAGE_LIST_SYMBOL ||
				queryListChar == WORD_JUSTIFICATION_LIST_SYMBOL ||
				queryListChar == WORD_GRAMMAR_LANGUAGE_LIST_SYMBOL ||
				queryListChar == WORD_WRITE_LIST_SYMBOL ||
				queryListChar == WORD_SPECIFICATION_LIST_SYMBOL ||
				queryListChar == WORD_TYPE_LIST_SYMBOL ||
				queryListChar == WORD_CONTEXT_LIST_SYMBOL );
		}

	unsigned int nTotalCount()
		{
		return ( commonVariables_->nActiveQueryItems +
				commonVariables_->nDeactiveQueryItems +
				commonVariables_->nArchivedQueryItems +
				commonVariables_->nDeletedQueryItems );
		}

	unsigned int countQuery()
		{
		commonVariables_->nActiveQueryItems = 0;
		commonVariables_->nDeactiveQueryItems = 0;
		commonVariables_->nArchivedQueryItems = 0;
		commonVariables_->nDeletedQueryItems = 0;

		if( admin_->wordList != NULL )						// Inside words
			admin_->wordList->countQueryInWordList();

		for( unsigned short adminListNr = 0; adminListNr < NUMBER_OF_ADMIN_LISTS; adminListNr++ )
			{
			if( admin_->adminList[adminListNr] != NULL )	// Inside admin lists
				admin_->adminList[adminListNr]->countQueryInList();
			}

		return nTotalCount();
		}

	ResultType itemQuery( bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, bool suppressMessage, char *textString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "itemQuery";
		if( textString != NULL )
			{
			if( itemQuery( true, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, false, NO_SENTENCE_NR, NO_ITEM_NR ) == RESULT_OK )
				{
				if( commonVariables_->currentInterfaceLanguageWordItem != NULL )
					{
					if( !suppressMessage &&
					countQuery() == 0 )
						strcat( textString, commonVariables_->currentInterfaceLanguageWordItem->interfaceString( INTERFACE_QUERY_NO_ITEMS_WERE_FOUND ) );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The current interface language word item is undefined" );
				}
			else
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to query items" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given text string is undefined" );

		return commonVariables_->result;
		}

	ResultType showQueryResult( bool showOnlyWords, bool showOnlyWordReferences, bool showOnlyStrings, bool returnQueryToPosition, unsigned short promptTypeNr, unsigned short queryWordTypeNr, size_t queryWidth )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "showQueryResult";
		if( admin_->wordList != NULL )						// Inside words
			{
			if( admin_->wordList->showQueryResultInWordList( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, ( queryWordTypeNr == WORD_TYPE_UNDEFINED ? commonVariables_->matchingWordTypeNr : queryWordTypeNr ), queryWidth ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to show the query result in my word list" );
			}

		for( unsigned short adminListNr = 0; adminListNr < NUMBER_OF_ADMIN_LISTS; adminListNr++ )
			{
			if( admin_->adminList[adminListNr] != NULL )	// Inside admin lists
				{
				if( admin_->adminList[adminListNr]->showQueryResultInList( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth ) != RESULT_OK )
					return myWord_->addErrorInItem( admin_->adminListChar( adminListNr ), functionNameString, moduleNameString_, "I failed to show the query result" );
				}
			}

		return commonVariables_->result;
		}

	ResultType getIdFromQuery( bool hasEndChar, char *sourceString, char startChar, char endChar )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "getIdFromQuery";
		querySentenceNr_ = NO_SENTENCE_NR;
		queryItemNr_ = NO_ITEM_NR;

		if( sourceString != NULL )
			{
				if( queryStringPosition_ < strlen( sourceString ) )
					{
					if( sourceString[queryStringPosition_] == startChar )
						{
						queryStringPosition_++;

						if( queryStringPosition_ < strlen( sourceString ) &&
						sourceString[queryStringPosition_] != endChar )
							{
							if( sourceString[queryStringPosition_] == SYMBOL_ASTERISK )
								{
								queryStringPosition_++;
								querySentenceNr_ = MAX_SENTENCE_NR;
								}
							else
								{
								if( sourceString[queryStringPosition_] != QUERY_SEPARATOR_CHAR )
									{
									if( isdigit( sourceString[queryStringPosition_] ) )
										{
										while( queryStringPosition_ < strlen( sourceString ) &&
										isdigit( sourceString[queryStringPosition_] ) &&
										querySentenceNr_ <= MAX_SENTENCE_NR / 10 )
											{
											querySentenceNr_ = ( querySentenceNr_ * 10 ) + ( sourceString[queryStringPosition_] - '0' );
											queryStringPosition_++;
											}
										}
									else
										return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I couldn't find a number in the query string" );
									}

								if( hasEndChar &&
								queryStringPosition_ < strlen( sourceString ) &&
								sourceString[queryStringPosition_] == QUERY_SEPARATOR_CHAR )
									{
									queryStringPosition_++;

									if( queryStringPosition_ < strlen( sourceString ) &&
									sourceString[queryStringPosition_] != endChar )
										{
										if( isdigit( sourceString[queryStringPosition_] ) )
											{
											while( queryStringPosition_ < strlen( sourceString ) &&
											isdigit( sourceString[queryStringPosition_] ) &&
											queryItemNr_ <= MAX_SENTENCE_NR / 10 )
												{
												queryItemNr_ = ( queryItemNr_ * 10 ) + ( sourceString[queryStringPosition_] - '0' );
												queryStringPosition_++;
												}
											}
										else
											return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I couldn't find the item number in the query string" );
										}
									}
								}
							}

						if( hasEndChar )
							{
							if( queryStringPosition_ < strlen( sourceString ) &&
							sourceString[queryStringPosition_] == endChar )
								queryStringPosition_++;
							else
								return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given query string is corrupt" );
							}
						}
					else
						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given command does not start with character '", startChar, "', but with '", sourceString[queryStringPosition_], "'" );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given source string is empty or the given query source string position is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given source string is undefined" );

		return commonVariables_->result;
		}

	ResultType getNameFromQuery( char *sourceString, char *nameString, char startChar, char endChar )
		{
		size_t nameLength = 0;
		size_t startSourceStringPosition;
		char functionNameString[FUNCTION_NAME_LENGTH] = "getNameFromQuery";

		if( sourceString != NULL )
			{
			if( nameString != NULL )
				{
					if( queryStringPosition_ < strlen( sourceString ) )
						{
						if( sourceString[queryStringPosition_] == startChar )
							{
							if( queryStringPosition_ + 1 < strlen( sourceString ) )
								{
								queryStringPosition_++;

								if( sourceString[queryStringPosition_] != endChar )
									{
									startSourceStringPosition = queryStringPosition_;

									while( queryStringPosition_ + 1 < strlen( sourceString ) &&
									nameLength <= MAX_READ_WRITE_STRING_LENGTH - 1 &&
									sourceString[queryStringPosition_] != endChar )
										{
										nameLength++;
										queryStringPosition_++;
										}

									if( sourceString[queryStringPosition_] == endChar )
										strncpy( nameString, &sourceString[startSourceStringPosition], nameLength );
									else
										return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The name in the given query string is corrupt" );
									}

								nameString[nameLength] = NULL_CHAR;
								queryStringPosition_++;
								}
							else
								return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The name in the given query string is corrupt" );
							}
						else
							return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given name does not start with character '", startChar, "', but with '", sourceString[0], "'" );
						}
					else
						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given source string is empty or the given query source string position is undefined" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given name string is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given source string is undefined" );

		return commonVariables_->result;
		}

	ResultType itemQuery( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, bool isReferenceQuery, unsigned int querySentenceNr_, unsigned int queryItemNr_ )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "itemQuery";
		if( admin_->wordList != NULL )						// Inside words
			{
			if( admin_->wordList->itemQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, isReferenceQuery, querySentenceNr_, queryItemNr_ ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to query item numbers in my word list" );
			}

		for( unsigned short adminListNr = 0; adminListNr < NUMBER_OF_ADMIN_LISTS; adminListNr++ )
			{
			if( admin_->adminList[adminListNr] != NULL )	// Inside admin lists
				{
				if( admin_->adminList[adminListNr]->itemQueryInList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, isReferenceQuery, querySentenceNr_, queryItemNr_ ) != RESULT_OK )
					return myWord_->addErrorInItem( admin_->adminListChar( adminListNr ), functionNameString, moduleNameString_, "I failed to query item numbers in" );
				}
			}

		return commonVariables_->result;
		}

	ResultType listQuery( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *queryListString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "listQuery";
		if( admin_->wordList != NULL )						// Inside words
			{
			if( admin_->wordList->listQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryListString ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to query my word list" );
			}

		for( unsigned short adminListNr = 0; adminListNr < NUMBER_OF_ADMIN_LISTS; adminListNr++ )
			{
			if( admin_->adminList[adminListNr] != NULL )	// Inside admin lists
				{
				if( admin_->adminList[adminListNr]->listQueryInList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryListString ) != RESULT_OK )
					return myWord_->addErrorInItem( admin_->adminListChar( adminListNr ), functionNameString, moduleNameString_, "I failed to do a list query" );
				}
			}

		return commonVariables_->result;
		}

	ResultType wordTypeQuery( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, unsigned short queryWordTypeNr )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "wordTypeQuery";
		if( admin_->wordList != NULL )						// Inside words
			{
			if( admin_->wordList->wordTypeQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryWordTypeNr ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to query word types in my word list" );
			}

		for( unsigned short adminListNr = 0; adminListNr < NUMBER_OF_ADMIN_LISTS; adminListNr++ )
			{
			if( admin_->adminList[adminListNr] != NULL )	// Inside admin lists
				{
				if( admin_->adminList[adminListNr]->wordTypeQueryInList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryWordTypeNr ) != RESULT_OK )
					return myWord_->addErrorInItem( admin_->adminListChar( adminListNr ), functionNameString, moduleNameString_, "I failed to word types" );
				}
			}

		return commonVariables_->result;
		}

	ResultType parameterQuery( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, unsigned int queryParameter )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "parameterQuery";
		if( admin_->wordList != NULL )						// Inside words
			{
			if( admin_->wordList->parameterQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryParameter ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to query parameters in my word list" );
			}

		for( unsigned short adminListNr = 0; adminListNr < NUMBER_OF_ADMIN_LISTS; adminListNr++ )
			{
			if( admin_->adminList[adminListNr] != NULL )	// Inside admin lists
				{
				if( admin_->adminList[adminListNr]->parameterQueryInList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryParameter ) != RESULT_OK )
					return myWord_->addErrorInItem( admin_->adminListChar( adminListNr ), functionNameString, moduleNameString_, "I failed to parameters" );
				}
			}

		return commonVariables_->result;
		}

	ResultType wordQuery( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *wordNameString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "wordQuery";
		if( admin_->wordList != NULL )		// Inside words
			{
			if( admin_->wordList->wordQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordNameString ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to query the words in my word list" );
			}

		return commonVariables_->result;
		}

	ResultType wordReferenceQuery( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *wordReferenceNameString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "wordReferenceQuery";
		if( admin_->wordList != NULL )						// Inside words
			{
			if( admin_->wordList->wordReferenceQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordReferenceNameString ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to query word references in my word list" );
			}

		for( unsigned short adminListNr = 0; adminListNr < NUMBER_OF_ADMIN_LISTS; adminListNr++ )
			{
			if( admin_->adminList[adminListNr] != NULL )	// Inside admin lists
				{
				if( admin_->adminList[adminListNr]->wordReferenceQueryInList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordReferenceNameString ) != RESULT_OK )
					return myWord_->addErrorInItem( admin_->adminListChar( adminListNr ), functionNameString, moduleNameString_, "I failed to query word references" );
				}
			}

		return commonVariables_->result;
		}

	ResultType stringQuery( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *queryString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "stringQuery";
		if( admin_->wordList != NULL )						// Inside words
			{
			if( admin_->wordList->stringQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryString ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to query strings in my word list" );
			}

		for( unsigned short adminListNr = 0; adminListNr < NUMBER_OF_ADMIN_LISTS; adminListNr++ )
			{
			if( admin_->adminList[adminListNr] != NULL )	// Inside admin lists
				{
				if( admin_->adminList[adminListNr]->stringQueryInList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryString ) != RESULT_OK )
					return myWord_->addErrorInItem( admin_->adminListChar( adminListNr ), functionNameString, moduleNameString_, "I failed to query strings" );
				}
			}

		return commonVariables_->result;
		}

	public:
	// Constructor

	AdminQuery( AdminItem *admin, WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		queryItemNr_ = NO_ITEM_NR;
		querySentenceNr_ = NO_SENTENCE_NR;
		queryStringPosition_ = 1;

		admin_ = admin;
		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "AdminQuery" );

		if( commonVariables_ != NULL )
			{
		if( admin_ != NULL )
			{
			if( myWord_ == NULL )
				strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given admin is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	void initializeQueryStringPosition()
		{
		queryStringPosition_ = 1;
		}

	ResultType writeTextWithPossibleQueryCommands( unsigned short promptTypeNr, char *textString )
		{
		bool hasFoundNewLine = false;
		size_t previousPosition;
		size_t position = 0;
		char textChar = SYMBOL_QUESTION_MARK;
		char charString[2] = SPACE_STRING;
		char writeString[MAX_READ_WRITE_STRING_LENGTH] = EMPTY_STRING;
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeTextWithPossibleQueryCommands";

		if( textString != NULL )
			{
			if( textString[0] == SYMBOL_DOUBLE_QUOTE )
				position++;

			while( position < strlen( textString ) &&
			textString[position] != SYMBOL_DOUBLE_QUOTE )
				{
				if( textString[position] == QUERY_CHAR )
					{
					if( ++position < strlen( textString ) )
						{
						previousPosition = position;
						queryStringPosition_ = position;

						if( executeQuery( true, false, true, promptTypeNr, textString ) == RESULT_OK )
							position = queryStringPosition_;
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to execute query \"", &textString[previousPosition], "\"" );
						}
					else
						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The text string ended with a query character" );
					}
				else
					{
					if( textString[position] == TEXT_DIACRITICAL_CHAR )
						{
						if( ++position < strlen( textString ) )
							{
							if( ( textChar = commonVariables_->presentation->convertDiacriticalChar( textString[position] ) ) == NEW_LINE_CHAR )
								hasFoundNewLine = true;
							}
						else
							return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The text string ended with a diacritical sign" );
						}
					else
						textChar = textString[position];

					position++;
					charString[0] = textChar;
					strcat( writeString, charString );
					}

				if( hasFoundNewLine ||
				strlen( writeString ) + 1 == MAX_READ_WRITE_STRING_LENGTH ||

				( position < strlen( textString ) &&
				textString[position] != SYMBOL_DOUBLE_QUOTE &&
				textString[position] == QUERY_CHAR &&
				strlen( writeString ) > 0 ) )
					{
					if( commonVariables_->presentation->writeText( false, promptTypeNr, NO_CENTER_WIDTH, writeString ) == RESULT_OK )
						{
						hasFoundNewLine = false;
						strcpy( writeString, EMPTY_STRING );
						}
					else
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write a character" );
					}
				}

			if( strlen( writeString ) > 0 )
				{
				if( commonVariables_->presentation->writeText( false, promptTypeNr, NO_CENTER_WIDTH, writeString ) != RESULT_OK )
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write the last characters" );
				}
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given text string is undefined" );

		return commonVariables_->result;
		}

	ResultType executeQuery( bool suppressMessage, bool returnToPosition, bool writeQueryResult, unsigned short promptTypeNr, char *queryString )
		{
		bool showCount = false;
		bool invalidChar = false;
		bool isEndOfQuery = false;
		bool showOnlyStrings = false;
		bool showOnlyWords = false;
		bool showOnlyWordReferences = false;
		bool isSelectActiveItems = true;
		bool isSelectDeactiveItems = true;
		bool isSelectArchivedItems = true;
		bool isSelectDeletedItems = true;
		bool isFirstInstruction = true;
		bool returnQueryToPosition = returnToPosition;
		unsigned short queryWordTypeNr = WORD_TYPE_UNDEFINED;
		unsigned int nTotal;
		size_t listStringPosition;
		size_t queryWidth = NO_CENTER_WIDTH;
		char nameString[MAX_READ_WRITE_STRING_LENGTH] = EMPTY_STRING;
		char functionNameString[FUNCTION_NAME_LENGTH] = "executeQuery";

		strcpy( commonVariables_->queryString, EMPTY_STRING );

		if( queryString != NULL )
			{
			if( queryStringPosition_ > 0 &&
			queryStringPosition_ < strlen( queryString ) )
				{
				if( commonVariables_->currentInterfaceLanguageWordItem != NULL )
					{
					clearQuerySelections();

					querySentenceNr_ = NO_SENTENCE_NR;
					queryItemNr_ = NO_ITEM_NR;

					commonVariables_->hasFoundQuery = false;
					commonVariables_->matchingWordTypeNr = WORD_TYPE_UNDEFINED;

					while( !isEndOfQuery &&
					strlen( commonVariables_->queryString ) == 0 &&
					queryStringPosition_ < strlen( queryString ) )
						{
						switch( queryString[queryStringPosition_] )
							{
							case QUERY_ITEM_START_CHAR:

								if( getIdFromQuery( true, queryString, QUERY_ITEM_START_CHAR, QUERY_ITEM_END_CHAR ) == RESULT_OK )
									{
									if( itemQuery( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, false, querySentenceNr_, queryItemNr_ ) == RESULT_OK )
										{
										isFirstInstruction = false;

										if( !suppressMessage &&
										countQuery() == 0 )
											strcat( commonVariables_->queryString, commonVariables_->currentInterfaceLanguageWordItem->interfaceString( INTERFACE_QUERY_NO_ITEM_WAS_FOUND ) );
										}
									else
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to query items" );
									}
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get an identification from the item" );

								break;

							case QUERY_REF_ITEM_START_CHAR:

								if( getIdFromQuery( true, queryString, QUERY_REF_ITEM_START_CHAR, QUERY_REF_ITEM_END_CHAR ) == RESULT_OK )
									{
									if( itemQuery( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, true, querySentenceNr_, queryItemNr_ ) == RESULT_OK )
										{
										isFirstInstruction = false;

										if( !suppressMessage &&
										countQuery() == 0 )
											strcat( commonVariables_->queryString, commonVariables_->currentInterfaceLanguageWordItem->interfaceString( INTERFACE_QUERY_NO_REFERENCE_ITEM_WAS_FOUND ) );
										}
									else
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to query item references" );
									}
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get a reference identification from the item" );

								break;

							case QUERY_LIST_START_CHAR:
								strcpy( nameString, EMPTY_STRING );

								if( getNameFromQuery( queryString, nameString, QUERY_LIST_START_CHAR, QUERY_LIST_END_CHAR ) == RESULT_OK )
									{
									listStringPosition = 0;

									do	{	// Check list characters on existence
										if( strlen( nameString ) > 0 &&
										!isWordListChar( nameString[listStringPosition] ) &&
										!isAdminListChar( nameString[listStringPosition] ) )
											{
											invalidChar = true;
											strcat( commonVariables_->queryString, commonVariables_->currentInterfaceLanguageWordItem->interfaceString( suppressMessage ? INTERFACE_QUERY_ERROR : INTERFACE_QUERY_INVALID_CHARACTER_IN_LIST ) );
											}
										}
									while( !invalidChar &&
									++listStringPosition < strlen( nameString ) );

									if( !invalidChar )	// All list characters are valid
										{
										if( listQuery( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, nameString ) == RESULT_OK )
											{
											isFirstInstruction = false;

											if( !suppressMessage &&
											countQuery() == 0 )
												strcat( commonVariables_->queryString, commonVariables_->currentInterfaceLanguageWordItem->interfaceString( INTERFACE_QUERY_NO_LIST_WAS_FOUND ) );
											}
										else
											return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to query lists" );
										}
									}
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get a list string from the text" );

								break;

							case QUERY_WORD_START_CHAR:
								if( queryStringPosition_ + 1 < strlen( queryString ) &&
								queryString[queryStringPosition_ + 1] != QUERY_CHAR )
									{
									strcpy( nameString, EMPTY_STRING );

									if( getNameFromQuery( queryString, nameString, QUERY_WORD_START_CHAR, QUERY_WORD_END_CHAR ) == RESULT_OK )
										{
										if( strlen( nameString ) == 0 )
											{
											if( queryStringPosition_ < strlen( queryString ) &&
											queryString[queryStringPosition_] != QUERY_CHAR )
												strcat( commonVariables_->queryString, commonVariables_->currentInterfaceLanguageWordItem->interfaceString( suppressMessage ? INTERFACE_QUERY_ERROR : INTERFACE_QUERY_EMPTY_WORD_SPECIFICATION ) );
											else
												{
												showOnlyWords = true;
												returnQueryToPosition = true;
												}
											}
										else
											{
											if( wordQuery( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, nameString ) == RESULT_OK )
												{
												isFirstInstruction = false;

												if( !suppressMessage &&
												countQuery() == 0 )
													strcat( commonVariables_->queryString, commonVariables_->currentInterfaceLanguageWordItem->interfaceString( INTERFACE_QUERY_NO_WORD_WAS_FOUND ) );
												}
											else
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to query words" );
											}
										}
									else
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get a word name from the query specification" );
									}
								else
									{
									showOnlyWords = true;
									returnQueryToPosition = false;
									queryStringPosition_++;
									}

								break;

							case QUERY_WORD_REFERENCE_START_CHAR:
								if( queryStringPosition_ + 1 < strlen( queryString ) &&
								queryString[queryStringPosition_ + 1] != QUERY_CHAR )
									{
									strcpy( nameString, EMPTY_STRING );

									if( getNameFromQuery( queryString, nameString, QUERY_WORD_REFERENCE_START_CHAR, QUERY_WORD_REFERENCE_END_CHAR ) == RESULT_OK )
										{
										if( strlen( nameString ) == 0 )
											{
											if( queryStringPosition_ < strlen( queryString ) &&
											queryString[queryStringPosition_] != QUERY_CHAR )
												strcat( commonVariables_->queryString, commonVariables_->currentInterfaceLanguageWordItem->interfaceString( suppressMessage ? INTERFACE_QUERY_ERROR : INTERFACE_QUERY_EMPTY_WORD_REFERENCE ) );
											else
												{
												returnQueryToPosition = true;
												showOnlyWordReferences = true;
												}
											}
										else
											{
											if( wordReferenceQuery( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, nameString ) == RESULT_OK )
												{
												isFirstInstruction = false;

												if( !suppressMessage &&
												countQuery() == 0 )
													strcat( commonVariables_->queryString, commonVariables_->currentInterfaceLanguageWordItem->interfaceString( INTERFACE_QUERY_NO_WORD_REFERENCE_WAS_FOUND ) );
												}
											else
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to query word references" );
											}
										}
									else
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get a word reference name from the query specification" );
									}
								else
									{
									returnQueryToPosition = false;
									showOnlyWordReferences = true;
									queryStringPosition_++;
									}

								break;

							case SYMBOL_BACK_SLASH:		// Escape character for string
								if( queryStringPosition_ + 1 < strlen( queryString ) &&
								queryString[queryStringPosition_ + 1] != QUERY_CHAR )
									queryStringPosition_++;

								// Don't insert a break statement here

							case QUERY_STRING_START_CHAR:
								if( queryStringPosition_ + 1 < strlen( queryString ) &&
								queryString[queryStringPosition_ + 1] != QUERY_CHAR )
									{
									strcpy( nameString, EMPTY_STRING );

									if( getNameFromQuery( queryString, nameString, QUERY_STRING_START_CHAR, QUERY_STRING_END_CHAR ) == RESULT_OK )
										{
										if( strlen( nameString ) == 0 )
											{
											if( queryStringPosition_ < strlen( queryString ) &&
											queryString[queryStringPosition_] != QUERY_CHAR )
												strcat( commonVariables_->queryString, commonVariables_->currentInterfaceLanguageWordItem->interfaceString( suppressMessage ? INTERFACE_QUERY_ERROR : INTERFACE_QUERY_EMPTY_STRING_SPECIFICATION ) );
											else
												{
												showOnlyStrings = true;
												returnQueryToPosition = true;
												}
											}
										else
											{
											if( stringQuery( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, nameString ) == RESULT_OK )
												{
												isFirstInstruction = false;

												if( !suppressMessage &&
												countQuery() == 0 )
													strcat( commonVariables_->queryString, commonVariables_->currentInterfaceLanguageWordItem->interfaceString( INTERFACE_QUERY_NO_STRING_WAS_FOUND ) );
												}
											else
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to query strings" );
											}
										}
									else
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get a string from the query specification" );
									}
								else
									{
									showOnlyStrings = true;
									returnQueryToPosition = false;
									queryStringPosition_++;
									}

								break;

							case QUERY_WORD_TYPE_CHAR:

								querySentenceNr_ = NO_SENTENCE_NR;

								if( getIdFromQuery( false, queryString, QUERY_WORD_TYPE_CHAR, QUERY_WORD_TYPE_CHAR ) == RESULT_OK )
									{
									if( queryItemNr_ == NO_ITEM_NR )
										{
										if( wordTypeQuery( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, (unsigned short)querySentenceNr_ ) == RESULT_OK )
											{
											isFirstInstruction = false;
											queryWordTypeNr = (unsigned short)querySentenceNr_;		// Remember given word type number

											if( !suppressMessage &&
											countQuery() == 0 )
												strcat( commonVariables_->queryString, commonVariables_->currentInterfaceLanguageWordItem->interfaceString( INTERFACE_QUERY_NO_WORD_TYPE_WAS_FOUND ) );
											}
										else
											return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to query word types" );
										}
									else
										return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given parameter is undefined" );
									}
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get a word type" );

								break;

							case QUERY_PARAMETER_CHAR:

								querySentenceNr_ = NO_SENTENCE_NR;

								if( getIdFromQuery( false, queryString, QUERY_PARAMETER_CHAR, QUERY_PARAMETER_CHAR ) == RESULT_OK )
									{
									if( queryItemNr_ == NO_ITEM_NR )
										{
										if( parameterQuery( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, querySentenceNr_ ) == RESULT_OK )
											{
											isFirstInstruction = false;

											if( !suppressMessage &&
											countQuery() == 0 )
												strcat( commonVariables_->queryString, commonVariables_->currentInterfaceLanguageWordItem->interfaceString( INTERFACE_QUERY_NO_PARAMETER_WAS_FOUND ) );
											}
										else
											return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to query parameters" );
										}
									else
										return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given parameter is undefined" );
									}
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get a parameter" );

								break;

							case QUERY_CHAR:

								isEndOfQuery = true;
								queryStringPosition_++;

								break;

							case QUERY_ACTIVE_CHAR:

								if( isSelectActiveItems &&
								isSelectDeactiveItems &&
								isSelectArchivedItems &&
								isSelectDeletedItems )	// Initially
									{
									isSelectDeactiveItems = false;
									isSelectArchivedItems = false;
									isSelectDeletedItems = false;
									}
								else
									isSelectActiveItems = true;

								queryStringPosition_++;

								if( queryStringPosition_ >= strlen( queryString ) ||
								queryString[queryStringPosition_] == QUERY_CHAR )	// End of query
									{
									if( itemQuery( isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, suppressMessage, commonVariables_->queryString ) != RESULT_OK )
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to perform an item query of active items" );
									}

								break;

							case QUERY_DEACTIVE_CHAR:

								if( isSelectActiveItems &&
								isSelectDeactiveItems &&
								isSelectArchivedItems &&
								isSelectDeletedItems )	// Initially
									{
									isSelectActiveItems = false;
									isSelectArchivedItems = false;
									isSelectDeletedItems = false;
									}
								else
									isSelectDeactiveItems = true;

								queryStringPosition_++;

								if( queryStringPosition_ >= strlen( queryString ) ||
								queryString[queryStringPosition_] == QUERY_CHAR )	// End of query
									{
									if( itemQuery( isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, suppressMessage, commonVariables_->queryString ) != RESULT_OK )
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to perform an item query of deactive items" );
									}

								break;

							case QUERY_ARCHIVE_CHAR:

								if( isSelectActiveItems &&
								isSelectDeactiveItems &&
								isSelectArchivedItems &&
								isSelectDeletedItems )	// Initially
									{
									isSelectActiveItems = false;
									isSelectDeactiveItems = false;
									isSelectDeletedItems = false;
									}
								else
									isSelectArchivedItems = true;

								queryStringPosition_++;

								if( queryStringPosition_ >= strlen( queryString ) ||
								queryString[queryStringPosition_] == QUERY_CHAR )	// End of query
									{
									if( itemQuery( isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, suppressMessage, commonVariables_->queryString ) != RESULT_OK )
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to perform an item query of archive items" );
									}

								break;

							case QUERY_DELETED_CHAR:

								if( isSelectActiveItems &&
								isSelectDeactiveItems &&
								isSelectArchivedItems &&
								isSelectDeletedItems )	// Initially
									{
									isSelectActiveItems = false;
									isSelectDeactiveItems = false;
									isSelectArchivedItems = false;
									}
								else
									isSelectDeletedItems = true;

								queryStringPosition_++;

								if( queryStringPosition_ >= strlen( queryString ) ||
								queryString[queryStringPosition_] == QUERY_CHAR )	// End of query
									{
									if( itemQuery( isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, suppressMessage, commonVariables_->queryString ) != RESULT_OK )
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to perform an item query of deleted items" );
									}

								break;

							case QUERY_COUNT_CHAR:

								showCount = true;
								queryStringPosition_++;

								if( queryStringPosition_ >= strlen( queryString ) ||
								queryString[queryStringPosition_] == QUERY_CHAR )	// End of query
									{
									if( itemQuery( true, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, false, NO_SENTENCE_NR, NO_ITEM_NR ) != RESULT_OK )
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to query items" );
									}

								break;

							default:
								// Set query width parameter
								if( isdigit( queryString[queryStringPosition_] ) )
									{
									while( queryStringPosition_ < strlen( queryString ) &&
									isdigit( queryString[queryStringPosition_] ) &&
									queryWidth <= MAX_SENTENCE_NR / 10 )
										{
										queryWidth = ( queryWidth * 10 + queryString[queryStringPosition_] - '0' );
										queryStringPosition_++;
										}
									if( queryWidth >= NUMBER_OF_CONSOLE_COLUMNS )
										return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The query width in the query is too high" );
									}
								else
									return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found an illegal character '", queryString[queryStringPosition_], "' in the query" );
							}
						}

					if( strlen( commonVariables_->queryString ) == 0 )
						{
						if( isFirstInstruction )	// No query performed yet
							{
							if( itemQuery( true, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, false, NO_SENTENCE_NR, NO_ITEM_NR ) != RESULT_OK )
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to query items" );
							}

						if( showCount )
							{
							nTotal = countQuery();

							if( suppressMessage )
								sprintf( commonVariables_->queryString, "%u", nTotal );
							else
								{
								if( nTotal == 0 )
									strcat( commonVariables_->queryString, commonVariables_->currentInterfaceLanguageWordItem->interfaceString( INTERFACE_QUERY_NO_ITEMS_WERE_FOUND ) );
								else
									{
									if( hasFoundMoreCategories() )		// Total only needed when more categories are found
										sprintf( commonVariables_->queryString, "total:%u", nTotal );

									if( commonVariables_->nActiveQueryItems > 0 )
										{
										if( strlen( commonVariables_->queryString ) > 0 )
											strcat( commonVariables_->queryString, QUERY_SEPARATOR_SPACE_STRING );

										sprintf( commonVariables_->queryString, "%sactive:%u", commonVariables_->queryString, commonVariables_->nActiveQueryItems );
										}

									if( commonVariables_->nDeactiveQueryItems > 0 )
										{
										if( strlen( commonVariables_->queryString ) > 0 )
											strcat( commonVariables_->queryString, QUERY_SEPARATOR_SPACE_STRING );

										sprintf( commonVariables_->queryString, "%sdeactive:%u.\n", commonVariables_->queryString, commonVariables_->nDeactiveQueryItems );
										}

									if( commonVariables_->nArchivedQueryItems > 0 )
										{
										if( strlen( commonVariables_->queryString ) > 0 )
											strcat( commonVariables_->queryString, QUERY_SEPARATOR_SPACE_STRING );

										sprintf( commonVariables_->queryString, "%sarchive:%u.\n", commonVariables_->queryString, commonVariables_->nArchivedQueryItems );
										}

									if( commonVariables_->nDeletedQueryItems > 0 )
										{
										if( strlen( commonVariables_->queryString ) > 0 )
											strcat( commonVariables_->queryString, QUERY_SEPARATOR_SPACE_STRING );

										sprintf( commonVariables_->queryString, "%srollback:%u.\n", commonVariables_->queryString, commonVariables_->nDeletedQueryItems );
										}
									}
								}
							}
						else
							{
							commonVariables_->hasFoundQuery = false;

							if( showQueryResult( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth ) == RESULT_OK )
								{
								if( !commonVariables_->hasFoundQuery &&
								!suppressMessage &&
								strlen( commonVariables_->queryString ) == 0 )
									{
									if( showOnlyWords )
										strcat( commonVariables_->queryString, commonVariables_->currentInterfaceLanguageWordItem->interfaceString( INTERFACE_QUERY_NO_WORDS_WERE_FOUND ) );
									else
										{
										if( showOnlyWordReferences )
											strcat( commonVariables_->queryString, commonVariables_->currentInterfaceLanguageWordItem->interfaceString( INTERFACE_QUERY_NO_WORD_REFERENCES_WERE_FOUND ) );
										else
											{
											if( showOnlyStrings )
												strcat( commonVariables_->queryString, commonVariables_->currentInterfaceLanguageWordItem->interfaceString( INTERFACE_QUERY_NO_STRINGS_WERE_FOUND ) );
											}
										}
									}
								}
							else
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to show the query result" );
							}
						}

					if( nTotalCount() == 0 ||	// Show comment on empty query
					commonVariables_->hasFoundQuery ||
					queryWidth > NO_CENTER_WIDTH )
						{
						if( writeQueryResult &&

						( queryWidth > NO_CENTER_WIDTH ||
						strlen( commonVariables_->queryString ) > 0 ) )
							{
							if( commonVariables_->presentation->writeText( ( !suppressMessage && !commonVariables_->hasFoundQuery && queryWidth == NO_CENTER_WIDTH ), promptTypeNr, queryWidth, commonVariables_->queryString ) != RESULT_OK )
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write the query result" );
							}
						}
					else
						strcpy( commonVariables_->queryString, EMPTY_STRING );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The current interface language word item is undefined" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given instruction string is empty or the given instruction string position is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given instruction string is undefined" );

		return commonVariables_->result;
		}
	};

/*************************************************************************
 *
 *	"Honor the Lord, you heavenly beings;
 *	honor the Lord for his glory and strength." (Psalm 29:1)
 *
 *************************************************************************/
