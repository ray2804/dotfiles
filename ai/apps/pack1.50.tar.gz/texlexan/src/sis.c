/*
 *      search in summaries sis.c
 *      
 *      Copyright 2009 jpr <inphilly@gmail.com>
 *      
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *      
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *      MA 02110-1301, USA.
 */


#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>
#include <unistd.h>
#include <time.h>
#include "utils.h"
#define VERSION "0.0.3b"
#define DATE "2009 Dec 25th"
#define AUTOR "JP Redonnet"
#define ERRPOS fprintf(stderr,"\nError:%s %d  ",__FILE__,__LINE__);

void help(char *msg) {
  printf("Usage: sis [options] \"terms searched\"\n");
  printf("\nSearch sentence or words in the list of summaries archived\n\n");
  printf("Options:\n");
  printf("-c \t\tcase ignored\n");
  printf("-e 0...99 \terrors accepted\n");
  printf("-f <folder>\tfull path to the archives (default:/texlexan_archive/classification.lst)\n");
  printf("-l \t\tshow link\n");
  printf("-m \t\tmarkup: bold (default:background color)\n"); 
  printf("-s0...2 \tsummaries displayed: none,sentence,full\n");
  printf("-w \t\tweak stemming (default no stemming)\n");
  printf("-V \t\tVersion\n");
  printf("-h \t\tThis help\n");
  
  if (*msg != '\0') printf("-=- Message -=-\n%s",msg);
  exit(EXIT_FAILURE);
}

int main(int argc, char** argv)
{
	FILE *fp1;
	char *line,*longline,*file_input;
	char *home_dir,*archive_dir;
	char *str_ptr,*hash_str,*link_str,*ext_str;
	char *summary;
	char *ptr_table[100];
	int lg_table[100];
	char **term;
	int	index_table=0;
	int	index_t=0;
	int	it=0;
	char *s2,*s2up,*wordfound;
	int err=0;
	int archive_found=0;
	int term_found=0;
	int found_in_line=0;
	int found_in_summary=0;
	int flag_summary=0;
	int cont;
	int size_line=10000;
	int size_summary=100000;
	int i,j,k,l,lg,count_silent_bug;
	int lg_summary=0;
	int markup=0;
	int show_summary=2; //whole summary
	int max_err=1;
	int link_flag=0;
	int nocase=0; //char case matter
	int check_link=0; //don't check link
	int weakstem=0;
		
	home_dir=strdup(env("HOME"));
	if ((file_input=(char*)malloc(strlen(home_dir)+100)) == NULL) errmalloc("sis");
	if ((archive_dir=(char*)malloc(strlen(home_dir)+100)) == NULL) errmalloc("sis");
	
	sprintf(file_input,"%s/texlexan_archive/classification.lst",home_dir);
	sprintf(archive_dir,"%s/texlexan_archive/",home_dir);
	
	 /* get options from the cmd line */
	int oc;
	int nbopt=0; 
	while ((oc=getopt(argc,argv,":a:ce:f:hmls:Vw")) != -1){
		nbopt++;
		switch(oc) {
			case 'a':
				free(archive_dir);
				if ((archive_dir = (char*)malloc(strlen(optarg)+100)) == NULL) errmalloc("Search");
				strcpy(archive_dir,optarg);
				/*check is path is valid*/
				if (testdir(archive_dir) == 0) {
					ERRPOS
					fprintf(stderr,"Unable to access to %s\n",archive_dir);
					exit(EXIT_FAILURE);
				}
				break;
			case 'c':
				nocase=1;
				break;
			case 'e':
				max_err=atoi(optarg);
				break;
			case 'f':
				free(file_input);
				if ((file_input = (char*)malloc(strlen(optarg)+100)) == NULL) errmalloc("Search");
				strcpy(file_input,optarg);
				/*check is path is valid*/
				if (testdir(file_input) == 0) {
					ERRPOS
					fprintf(stderr,"Unable to access to %s\n",file_input);
					exit(EXIT_FAILURE);
				}
				strcat(file_input,"classification.lst");
				break;
			case 'l':
				link_flag=1;
				break;	
			case 'm':
				markup=1;
				break;
			case 's':
				show_summary=atoi(optarg);
				if (show_summary > 2) {
					fprintf(stderr,"set as -s2\n");
					show_summary=2;
				}
				break;
			case 'V':
				printf("sis ver. %s - %s - %s\n",VERSION,AUTOR,DATE);
				exit(0);
				break;
			case 'w':
				weakstem=1;
				break;	
			case ':':
				fprintf(stderr,"%s: option `-%c' requires an argument\n",argv[0],optopt);
				exit(EXIT_FAILURE);
				break;
			case '?':
			case 'h':
				help("");
			default:
				fprintf(stderr,"%s: option `-%c' is invalid: ignored\n",argv[0],optopt);
				exit(EXIT_FAILURE);
				break;
		}
	}

	if (argc > 1) {
		s2 = strdup(*(argv+argc-1));
		s2up = strdup(s2);
		for (i=0;i<strlen(s2up);i++) 
		*(s2up+i) = toupper(*(s2up+i));
	} 
	else {
		fprintf(stderr,"Searched terms missing\n");
		exit(EXIT_FAILURE);
	}
	/* prepare term[] */
	i=2; j=0; k=1; l=1;
	while  (*(s2+j) != '\0') {
		if (*(s2+j) == ',') { 
			i++; k=1;
		}
		j++; k++;
		if (k > l) l=k;
	}
	i++;
	if ((term = (char**)malloc(i*sizeof(char*))) == NULL) errmalloc("weightresult");
    for (j=0;j<i;j++) 
		if ((term[j]=(char*)malloc(l+10)) == NULL) errmalloc("sis");
	/* extract each term */
	index_t=i=j=0;
	while (*(s2+j) != '\0') {
		if (*(s2+j) != ',')
			term[index_t][i++]=*(s2+j);
		else {
			term[index_t][i++]='\0';
			i=0;
			index_t++;
		}
		j++;
	}
	term[index_t][i++]='\0';
	index_t++;
	
	/* eventually a tiny simplification */
	if (weakstem)
		for (i=0;i<index_t;i++) term[i]=weakstemmer(term[i]);
	
	/* allocate memory */
	if ((wordfound = (char*)malloc(strlen(s2)+10)) == NULL) errmalloc("sis");
	if ((line = (char*)malloc(size_line)) == NULL) errmalloc("sis");
	if ((longline = (char*)malloc(size_line+10)) == NULL) errmalloc("sis");
	if ((hash_str = (char*)malloc(110)) == NULL) errmalloc("sis");
	if ((link_str = (char*)malloc(1010)) == NULL) errmalloc("sis");
	if ((ext_str = (char*)malloc(1010)) == NULL) errmalloc("sis");
	if ((summary = (char*)malloc(size_summary)) == NULL) errmalloc("sis");
	
	/* open the list of summaries */
	fp1=fopen(file_input,"r"); //temp file -> sentences are extracted from it
	if (fp1==NULL){
		ERRPOS
		fprintf(stderr,"Unable to open %s ->Exit!\n",file_input);
		exit(EXIT_FAILURE);
	}
	
	/* html head*/
	printf("<HTML>\n");
	printf("<HEAD>\n");
	printf("<META HTTP-EQUIV=\"CONTENT-TYPE\" CONTENT=\"text/html; charset= charset=ISO-8859-1\">\n");
	printf("<META HTTP-EQUIV=\"CONTENT-TYPE\" CONTENT=\"text/html; charset= charset=utf-8\">\n");
	printf("<TITLE>Search result</TITLE>\n");
	printf("</HEAD>\n");
	printf("<BODY>\n");
	
	/* get the first line */
	fseek(fp1,0,SEEK_SET);
	cont=1;
	while (cont) {
		line[size_line-2]='\0';
		if (fgets(line,size_line,fp1) == NULL) break; //where are at the end
		if (line[size_line-2] != '\0') {
			ERRPOS
			fprintf(stderr,"Pb size_line allocated too small!\n");
			count_silent_bug++;
		}
		if (line[0] != '#') { //skip comment
			/* search tags */
			str_ptr=line;
			if ( (str_ptr=strstr(line,"<Hash:")) != NULL ) {
				strncpy(hash_str,str_ptr+6,100);
				*(hash_str+100)='\0';
				if ( (str_ptr=strchr(hash_str,'>')) != NULL ) *str_ptr='\0';
				else fprintf(stderr,"Pb! Check tag <Hash:...>\n");
				term_found=0;
				flag_summary=0;
				found_in_summary=0;
			}
			else if ( (str_ptr=strstr(line,"<Link:")) != NULL ) {
				/* Extract the url */
				strncpy(link_str,str_ptr+6,1000);
				*(link_str+1000)='\0';
				if ( (str_ptr=strchr(link_str,'>')) != NULL ) *str_ptr='\0';
				else fprintf(stderr,"Pb! Check tag <Link:...>\n");
				if ( check_link ) {
					/* try to open the link */
				}
				term_found=0;
				flag_summary=0;
				found_in_summary=0;
			}
			else if ( (str_ptr=strstr(line,"<Ext:")) != NULL ) {
				/* Extract the url */
				*ext_str='\0';
				strncpy(ext_str,str_ptr+5,1000);
				*(ext_str+1000)='\0';
				if ( (str_ptr=strchr(ext_str,'>')) != NULL ) *str_ptr='\0';
				else fprintf(stderr,"Pb! Check tag <Ext:...>\n");
			}
			else if  ( (str_ptr=strstr(line,"<Start abstract")) != NULL ) {
				if  ( (str_ptr=strstr(str_ptr+15,">")) != NULL ) {
					flag_summary=1;
					found_in_summary=0;
					*summary='\0';
					lg_summary=1;
				}
				else fprintf(stderr,"Pb! Check tag <Start abstract ..>\n");
			}
			else if  ( (str_ptr=strstr(line,"<End abstract")) != NULL ) {
				if  ( (str_ptr=strstr(str_ptr+13,">")) != NULL ) {
					/* Print summary if something found */
					if ( found_in_summary && show_summary > 0 ) 
						printf("<P>%s</P>",summary);
					flag_summary=0;
					found_in_summary=0;
				}
				else fprintf(stderr,"Pb! Check tag <End abstract ..>\n");
			}
			else if (flag_summary) {
				/* line of the summary */
				found_in_line=0;
				index_table=0;
				it=0;
				while (it < index_t)	{
					str_ptr=line;
					/* search each occurence of s2 in the line */
					while ((str_ptr=astrstr(str_ptr, term[it], nocase, &err)) != NULL) {
						if (err <= max_err) {
							if ( ! term_found ) {
								/* print links */
								printf("\n");
								printf("<P>Hash:%s</P>\n",hash_str);
								if (*ext_str == '\0')
									printf("<P><A HREF=\"%s%s.%s\">Archive</A>",archive_dir,hash_str,"bz2");
								else
									printf("<P><A HREF=\"%s%s.%s.%s\">Archive</A>",archive_dir,hash_str,ext_str,"bz2");
								if (link_flag) printf("&nbsp;&nbsp;&nbsp;&nbsp;Original:<A HREF=\"%s\">%s</A>",link_str,link_str);
								printf("</P>\n");
								archive_found++;
							}
							term_found++;
							found_in_line=1; //flag is set, okay to store the line
							ptr_table[index_table]=str_ptr;
							lg_table[index_table]=strlen(term[it]);
							index_table++;
						}
						str_ptr++; 	
					} //endwhile search term[]
					it++;
				}
				
				if ( found_in_line ) 
				/* searched term found in the line */
				{
					/* inefficient sort, okay if very few elements */
					for (i=0; i<index_table; i++) {
						for (j=i; j<index_table; j++) {
							if (ptr_table[i] > ptr_table[j]) {
								str_ptr=ptr_table[i];
								ptr_table[i]=ptr_table[j];
								ptr_table[j]=str_ptr;
								k=lg_table[i];
								lg_table[i]=lg_table[j];
								lg_table[j]=k;
							}
						}
					}
					found_in_summary=1;
					/* extracted sentences containing searched terms */
					str_ptr=line;
					for (i=0; i<index_table; i++) {
						strncpy(wordfound,ptr_table[i],lg_table[i]);
						wordfound[lg_table[i]]='\0';
						*ptr_table[i]='\0';
						if (markup == 1) 
							sprintf(longline,"%s<B>%s</B>",str_ptr,wordfound);
						else
							sprintf(longline,"%s<SPAN STYLE=\"background: #ffff00\">%s</SPAN>",str_ptr,wordfound);
						lg=strlen(longline);
						if ( lg_summary+lg < size_summary ) {
							strcat(summary,longline);
							lg_summary+=lg;
						}
						else ERRPOS;
						str_ptr = ptr_table[i]+lg_table[i];
					} //endfor i
					/* print last word found -> end of the line */
					sprintf(longline,"%s",str_ptr);
					lg=strlen(longline);
					if ( lg_summary+lg < size_summary ) {
						strcat(summary,longline);
						lg_summary+=lg;
					}
					else ERRPOS;
				} //endif found 
				else if (show_summary == 2) {
					/* term not found in the line but take the whole summary */
					lg=strlen(line);
					if ( lg_summary+lg < size_summary ) {
						strcat(summary,line);
						lg_summary+=lg;
					} 
					else ERRPOS;
				}
			} //endif flag_summary
		} //endif '#'
	} //endwhile cont
	if (archive_found ) {
		printf("<P>=>%i archive(s) found for: ",archive_found);
		for (i=0; i<index_t; i++) printf("'%s' ",term[i]);
		printf("</P>\n");
	}
	else printf("<P>%s Not found!</P>\n",s2);
	printf("</BODY>\n");
	printf("</HTML>\n");
	fclose(fp1);
	free(line);
	free(longline);
	free(hash_str);
	free(link_str);
	free(s2);
	free(s2up);
	for (i=0; i<index_t; i++) free(term[i]);
	free(term);
	return 0;
}
