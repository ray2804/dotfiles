/*
 *	Class:			WordQuestion
 *	Supports class:	WordItem
 *	Purpose:		To answer questions about this word
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "Presentation.cpp"
#include "SpecificationItem.cpp"

class WordQuestion
	{
	// Private constructible variables

	bool hasFoundDeeperPositiveAnswer_;
	bool hasFoundSpecificationGeneralizationAnswer_;
	bool isNegativeAnswer_;
	bool showAnsweredQuestion_;

	SpecificationItem *uncertainAboutAnswerRelationSpecificationItem_;

	CommonVariables *commonVariables_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	ResultType findAnswerToQuestion( SpecificationItem *questionSpecificationItem )
		{
		SpecificationResultType specificationResult;
		bool hasRelationContext;
		bool isAssignment;
		bool isDeactiveAssignment;
		bool isArchivedAssignment;
		bool isExclusive;
		bool isNegative;
		bool isPossessive;
		bool isNegativeAnswer = false;
		bool isPositiveAnswer = false;
		bool isUncertainAboutRelation = false;
		unsigned short questionAssumptionLevel;
		unsigned short answerAssumptionLevel;
		unsigned int specificationCollectionNr;
		unsigned int generalizationContextNr;
		unsigned int specificationContextNr;
		unsigned int relationContextNr;
		SpecificationItem *answerSpecificationItem = NULL;
		WordItem *specificationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findAnswerToQuestion";

		if( questionSpecificationItem != NULL )
			{
			hasRelationContext = questionSpecificationItem->hasRelationContext();

			isAssignment = ( hasRelationContext ||
							questionSpecificationItem->isAssignment() );

			isDeactiveAssignment = questionSpecificationItem->isDeactiveAssignment();
			isArchivedAssignment = questionSpecificationItem->isArchivedAssignment();
			isExclusive = questionSpecificationItem->isExclusive();
			isNegative = questionSpecificationItem->isNegative();
			isPossessive = questionSpecificationItem->isPossessive();
			specificationCollectionNr = questionSpecificationItem->specificationCollectionNr();
			generalizationContextNr = questionSpecificationItem->generalizationContextNr();
			specificationContextNr = questionSpecificationItem->specificationContextNr();
			relationContextNr = questionSpecificationItem->relationContextNr();
			specificationWordItem = questionSpecificationItem->specificationWordItem();

			// Find correct answer
			if( ( answerSpecificationItem = myWord_->firstAssignmentOrSpecificationButNotAQuestion( false, false, isAssignment, isDeactiveAssignment, isArchivedAssignment, isNegative, isPossessive, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem ) ) == NULL )
				{
				// Find answer with different relation context
				if( ( answerSpecificationItem = myWord_->firstAssignmentOrSpecificationButNotAQuestion( false, false, isAssignment, isDeactiveAssignment, isArchivedAssignment, isNegative, isPossessive, specificationCollectionNr, generalizationContextNr, specificationContextNr, NO_CONTEXT_NR, specificationWordItem ) ) == NULL )
					{
					// Find negative answer
					if( ( answerSpecificationItem = myWord_->firstAssignmentOrSpecificationButNotAQuestion( false, false, isAssignment, isDeactiveAssignment, isArchivedAssignment, !isNegative, isPossessive, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem ) ) == NULL )
						{
						// Find possessive answer
						if( ( answerSpecificationItem = myWord_->firstAssignmentOrSpecificationButNotAQuestion( false, false, isAssignment, isDeactiveAssignment, isArchivedAssignment, isNegative, !isPossessive, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem ) ) != NULL )
							isNegativeAnswer = true;
						}
					else
						isNegativeAnswer = true;
					}
				else
					{
					// Find out if the relation context of the question lies within the relation context set of the answer
					if( hasRelationContext &&
					!answerSpecificationItem->hasRelationContext() )
						isUncertainAboutRelation = true;
					else
						isNegativeAnswer = true;
					}
				}
			else
				{
				if( ( !isExclusive &&
				answerSpecificationItem->isExclusive() ) ||

				answerSpecificationItem->specificationWordItem() != specificationWordItem )
					isNegativeAnswer = true;	// Has different specification word
				else
					{
					// Only confirm the answer with 'yes' if the answer is at least as reliable as the question
					if( !isExclusive &&

					// If a structure question is mapped to an assignment question, the answer is negative
					answerSpecificationItem->isRelatedQuestion( isExclusive, questionSpecificationItem->specificationCollectionNr(), relationContextNr ) )
						{
						if( ( specificationResult = questionSpecificationItem->getAssumptionLevel() ).result == RESULT_OK )
							{
							questionAssumptionLevel = specificationResult.assumptionLevel;

							if( ( specificationResult = answerSpecificationItem->getAssumptionLevel() ).result == RESULT_OK )
								{
								answerAssumptionLevel = specificationResult.assumptionLevel;

								if( questionAssumptionLevel >= answerAssumptionLevel )
									isPositiveAnswer = true;
								}
							else
								return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to get the answer assumption level" );
							}
						else
							return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to get the question assumption level" );
						}
					}

				if( ( isPositiveAnswer ||
				isNegativeAnswer ) &&

				!hasRelationContext &&
				answerSpecificationItem->isAssignment() &&
				answerSpecificationItem->hasRelationContext() )
					{
					if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_NOTIFICATION, INTERFACE_SENTENCE_NOTIFICATION_AMBIGUOUS_QUESTION_MISSING_RELATION ) != RESULT_OK )
						return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write an interface notification about ambiguity" );
					}
				}

			if( answerSpecificationItem != NULL &&
			answerSpecificationItem->isOlderSentence() )		// Ignore suggestive assumptions
				{
				if( writeAnswerToQuestion( isNegativeAnswer, isPositiveAnswer, isUncertainAboutRelation, questionSpecificationItem, answerSpecificationItem ) != RESULT_OK )
					return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write an answer to a question" );
				}
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given question specification item is undefined" );

		return commonVariables_->result;
		}

	ResultType findAlternativeAnswerToQuestion( SpecificationItem *questionSpecificationItem )
		{
		bool isAssignment;
		bool isNegative;
		bool isPossessive;
		unsigned short generalizationWordTypeNr;
		unsigned int generalizationCollectionNr;
		unsigned int specificationCollectionNr;
		unsigned int generalizationContextNr;
		unsigned int specificationContextNr;
		unsigned int relationContextNr;
		unsigned int tempSpecificationGeneralizationCollectionNr;
		unsigned int specificationGeneralizationCollectionNr = NO_COLLECTION_NR;
		SpecificationItem *currentSpecificationItem;
		WordItem *currentSpecificationWordItem;
		WordItem *specificationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findAlternativeAnswerToQuestion";

		hasFoundSpecificationGeneralizationAnswer_ = false;

		if( questionSpecificationItem != NULL )
			{
			if( ( currentSpecificationItem = myWord_->firstSelectedSpecification( questionSpecificationItem->isAssignment(), questionSpecificationItem->isDeactiveAssignment(), questionSpecificationItem->isArchivedAssignment(), false ) ) != NULL )
				{
				isAssignment = ( questionSpecificationItem->isAssignment() ||
								questionSpecificationItem->hasRelationContext() );

				isNegative = questionSpecificationItem->isNegative();
				isPossessive = questionSpecificationItem->isPossessive();
				generalizationWordTypeNr = questionSpecificationItem->generalizationWordTypeNr();
				generalizationCollectionNr = questionSpecificationItem->generalizationCollectionNr();
				specificationCollectionNr = questionSpecificationItem->specificationCollectionNr();
				generalizationContextNr = questionSpecificationItem->generalizationContextNr();
				specificationContextNr = questionSpecificationItem->specificationContextNr();
				relationContextNr = questionSpecificationItem->relationContextNr();
				specificationWordItem = questionSpecificationItem->specificationWordItem();

				do	{
					if( currentSpecificationItem->isSpecificationGeneralization() )
						{
						tempSpecificationGeneralizationCollectionNr = myWord_->collectionNr( generalizationWordTypeNr, specificationWordItem );

						if( specificationGeneralizationCollectionNr == NO_COLLECTION_NR )
							{
							hasFoundSpecificationGeneralizationAnswer_ = true;
							specificationGeneralizationCollectionNr = tempSpecificationGeneralizationCollectionNr;
							}
						else
							{
							if( specificationGeneralizationCollectionNr != tempSpecificationGeneralizationCollectionNr )
								return myWord_->startErrorInWord( functionNameString, moduleNameString_, "I found specification-generalization multiple collection numbers" );
							}
						}

					if( relationContextNr == NO_CONTEXT_NR ||
					uncertainAboutAnswerRelationSpecificationItem_ == NULL )
						{
						if( currentSpecificationItem->isRelatedSpecification( isNegative, isPossessive, generalizationCollectionNr, specificationCollectionNr, relationContextNr ) )
							{
							if( writeAnswerToQuestion( true, false, false, questionSpecificationItem, currentSpecificationItem ) != RESULT_OK )
								return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write an answer to a question" );
							}
						else
							{
							if( questionSpecificationItem->isSpecificationGeneralization() &&
							( currentSpecificationWordItem = currentSpecificationItem->specificationWordItem() ) != NULL )
								{
								if( currentSpecificationWordItem->firstAssignmentOrSpecificationButNotAQuestion( false, false, isAssignment, true, true, isNegative, isPossessive, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem ) != NULL )
									{
									hasFoundDeeperPositiveAnswer_ = true;
									hasFoundSpecificationGeneralizationAnswer_ = true;
									}
								}
							}
						}
					}
				while( ( currentSpecificationItem = currentSpecificationItem->nextSelectedSpecificationItem( false ) ) != NULL );
				}
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given question specification item is undefined" );

		return commonVariables_->result;
		}

	ResultType findAlternativeAnswerToQuestionInOtherWords( bool hasFoundSpecificationGeneralizationAnswer, SpecificationItem *questionSpecificationItem )
		{
		bool isAssignment;
		bool isDeactiveAssignment;
		bool isArchivedAssignment;
		bool isNegative;
		bool isPossessive;
		unsigned short generalizationWordTypeNr;
		unsigned int generalizationContextNr;
		unsigned int specificationContextNr;
		unsigned int relationContextNr;
		SpecificationItem *foundSpecificationItem;
		WordItem *currentWordItem;
		WordItem *specificationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findAlternativeAnswerToQuestionInOtherWords";

		if( questionSpecificationItem != NULL )
			{
			isAssignment = ( questionSpecificationItem->isAssignment() ||
							questionSpecificationItem->hasRelationContext() );

			isDeactiveAssignment = questionSpecificationItem->isDeactiveAssignment();
			isArchivedAssignment = questionSpecificationItem->isArchivedAssignment();
			isNegative = questionSpecificationItem->isNegative();
			isPossessive = questionSpecificationItem->isPossessive();
			generalizationWordTypeNr = questionSpecificationItem->generalizationWordTypeNr();
			generalizationContextNr = questionSpecificationItem->generalizationContextNr();
			specificationContextNr = questionSpecificationItem->specificationContextNr();
			relationContextNr = questionSpecificationItem->relationContextNr();
			specificationWordItem = questionSpecificationItem->specificationWordItem();

			// Do in all words for an alternative answer
			if( ( currentWordItem = commonVariables_->firstWordItem ) != NULL )
				{
				do	{
					if( currentWordItem != myWord_ )
						{
						foundSpecificationItem = currentWordItem->firstAssignmentOrSpecificationButNotAQuestion( false, false, isAssignment, isDeactiveAssignment, isArchivedAssignment, isNegative, isPossessive, NO_COLLECTION_NR, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem );

						if( foundSpecificationItem != NULL &&

						( hasFoundSpecificationGeneralizationAnswer ||
						foundSpecificationItem->isRelatedSpecification( isNegative, isPossessive, generalizationWordTypeNr ) ) )
							{
							if( currentWordItem->writeAnswerToQuestion( !hasFoundDeeperPositiveAnswer_, hasFoundDeeperPositiveAnswer_, questionSpecificationItem, foundSpecificationItem ) != RESULT_OK )
								return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write an answer to a question" );
							}
						}
					}
				while( ( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
				}
			else
				return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The first word item is undefined" );
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given question specification item is undefined" );

		return commonVariables_->result;
		}

	ResultType markQuestionAsAnswered( SpecificationItem *questionSpecificationItem )
		{
		SpecificationResultType specificationResult;
		bool isPossessive;
		unsigned short questionParameter;
		unsigned int generalizationContextNr;
		unsigned int specificationContextNr;
		SpecificationItem *answeredQuestion;
		SpecificationItem *foundSpecificationItem;
		WordItem *specificationWordItem;
		char *specificationString;
		char functionNameString[FUNCTION_NAME_LENGTH] = "markQuestionAsAnswered";

		if( questionSpecificationItem != NULL )
			{
			if( !questionSpecificationItem->isAnsweredQuestion() )
				{
				if( !questionSpecificationItem->isDeletedItem() )
					{
					isPossessive = questionSpecificationItem->isPossessive();
					questionParameter = questionSpecificationItem->questionParameter();
					generalizationContextNr = questionSpecificationItem->generalizationContextNr();
					specificationContextNr = questionSpecificationItem->specificationContextNr();
					specificationWordItem = questionSpecificationItem->specificationWordItem();
					specificationString = questionSpecificationItem->specificationString();

					if( questionSpecificationItem->isAssignment() )
						{
						if( ( specificationResult = myWord_->createAssignment( true, questionSpecificationItem->isConcludedAssumption(), questionSpecificationItem->isDeactiveItem(), questionSpecificationItem->isArchivedItem(), questionSpecificationItem->isExclusive(), questionSpecificationItem->isNegative(), isPossessive, questionSpecificationItem->isValueSpecification(), questionSpecificationItem->assignmentLevel(), questionSpecificationItem->assumptionLevel(), questionSpecificationItem->grammarLanguageNr(), questionSpecificationItem->prepositionParameter(), questionParameter, questionSpecificationItem->generalizationWordTypeNr(), questionSpecificationItem->specificationWordTypeNr(), questionSpecificationItem->generalizationCollectionNr(), questionSpecificationItem->specificationCollectionNr(), generalizationContextNr, specificationContextNr, questionSpecificationItem->relationContextNr(), questionSpecificationItem->originalSentenceNr(), questionSpecificationItem->activeSentenceNr(), questionSpecificationItem->deactiveSentenceNr(), questionSpecificationItem->archiveSentenceNr(), questionSpecificationItem->nContextRelations(), questionSpecificationItem->specificationJustificationItem(), specificationWordItem, questionSpecificationItem->specificationString() ) ).result == RESULT_OK )
							{
							if( ( answeredQuestion = specificationResult.createdSpecificationItem ) != NULL )
								{
								if( myWord_->archiveOrDeletedSpecification( questionSpecificationItem, answeredQuestion ) == RESULT_OK )
									{
									if( ( foundSpecificationItem = myWord_->firstSpecification( false, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, NO_CONTEXT_NR, specificationWordItem, specificationString ) ) != NULL )
										{
										if( markQuestionAsAnswered( foundSpecificationItem ) != RESULT_OK )
											return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to mark the specification of an assignment question as been answered" );
										}
									}
								else
									return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to archive or delete an answered question assignment" );
								}
							else
								return myWord_->startErrorInWord( functionNameString, moduleNameString_, "I couldn't create an answered question assignment item" );
							}
						else
							return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to create an answered question assignment item" );
						}
					else
						{
						if( ( specificationResult = myWord_->createSpecification( true, questionSpecificationItem->isConditional(), questionSpecificationItem->isConcludedAssumption(), questionSpecificationItem->isDeactiveItem(), questionSpecificationItem->isArchivedItem(), questionSpecificationItem->isExclusive(), questionSpecificationItem->isNegative(), isPossessive, questionSpecificationItem->isSpecificationGeneralization(), questionSpecificationItem->isValueSpecification(), questionSpecificationItem->assumptionLevel(), questionSpecificationItem->grammarLanguageNr(), questionSpecificationItem->prepositionParameter(), questionParameter, questionSpecificationItem->generalizationWordTypeNr(), questionSpecificationItem->specificationWordTypeNr(), questionSpecificationItem->generalizationCollectionNr(), questionSpecificationItem->specificationCollectionNr(), generalizationContextNr, specificationContextNr, questionSpecificationItem->relationContextNr(), questionSpecificationItem->originalSentenceNr(), questionSpecificationItem->nContextRelations(), questionSpecificationItem->specificationJustificationItem(), specificationWordItem, questionSpecificationItem->specificationString() ) ).result == RESULT_OK )
							{
							if( ( answeredQuestion = specificationResult.createdSpecificationItem ) != NULL )
								{
								if( myWord_->archiveOrDeletedSpecification( questionSpecificationItem, answeredQuestion ) != RESULT_OK )
									return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to archive or delete an answered question specification" );
								}
							else
								return myWord_->startErrorInWord( functionNameString, moduleNameString_, "I couldn't create an answered question specification item" );
							}
						else
							return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to create an answered question specification item" );
						}

					// Don't archive or delete the context or justification of answered questions
					}
				else
					return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given question specification item is deleted" );
				}
			else
				return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given question specification item is already answered" );
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given question specification item is undefined" );

		return commonVariables_->result;
		}

	ResultType findAnswerToNewUserQuestion( SpecificationItem *questionSpecificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "findAnswerToNewUserQuestion";
		isNegativeAnswer_ = false;
		hasFoundDeeperPositiveAnswer_ = false;
		uncertainAboutAnswerRelationSpecificationItem_ = NULL;

		if( questionSpecificationItem != NULL )
			{
			if( questionSpecificationItem->isQuestion() )
				{
				if( !questionSpecificationItem->isDeletedItem() )
					{
					if( findAnswerToQuestion( questionSpecificationItem ) == RESULT_OK )
						{
						if( !commonVariables_->hasFoundAnswerToQuestion )
							{
							// Check collections for an alternative current-tense assignment answer to the question
							if( findAlternativeAnswerToQuestion( questionSpecificationItem ) != RESULT_OK )
								return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find an alternative answer to a question" );
							}

						if( isNegativeAnswer_ ||
						hasFoundSpecificationGeneralizationAnswer_ ||
						uncertainAboutAnswerRelationSpecificationItem_ != NULL )
							{
							// Check other words for an alternative answer to the question
							if( findAlternativeAnswerToQuestionInOtherWords( hasFoundSpecificationGeneralizationAnswer_, questionSpecificationItem ) != RESULT_OK )
								return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find an alternative answer to a question" );
							}

						if( commonVariables_->hasFoundAnswerToQuestion &&
						uncertainAboutAnswerRelationSpecificationItem_ == NULL )
							{
							if( markQuestionAsAnswered( false, questionSpecificationItem ) != RESULT_OK )
								return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to mark a question specification as been answered" );
							}
						else
							{
							if( myWord_->firstSpecificationButNotAQuestion() == NULL )
								{
								// I don't know anything at all about this word
								if( commonVariables_->presentation->writeInterfaceText( true, PRESENTATION_PROMPT_NOTIFICATION, INTERFACE_QUESTION_I_DONT_KNOW_ANYTHING_ABOUT_WORD_START, questionSpecificationItem->activeGeneralizationWordTypeString(), INTERFACE_QUESTION_I_DONT_KNOW_ANYTHING_ABOUT_WORD_END ) != RESULT_OK )
									return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write an interface notification" );
								}
							else	// A specification exists, but it isn't a question
								{
								if( uncertainAboutAnswerRelationSpecificationItem_ != NULL )
									{
									if( myWord_->writeSelectedSpecification( true, true, false, false, NO_ANSWER_PARAMETER, uncertainAboutAnswerRelationSpecificationItem_ ) == RESULT_OK )
										{
										if( strlen( commonVariables_->writeSentenceString ) > 0 )
											{
											if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_NOTIFICATION, INTERFACE_LISTING_I_ONLY_KNOW ) == RESULT_OK )
												{
												if( commonVariables_->presentation->writeDiacriticalText( PRESENTATION_PROMPT_WRITE, commonVariables_->writeSentenceString ) != RESULT_OK )
													return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write an answer to a question" );
												}
											else
												return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a header" );
											}
										else
											return myWord_->startErrorInWord( functionNameString, moduleNameString_, "I couldn't write the selected answer to a question" );
										}
									else
										return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a selected answer to a question" );
									}
								}
							}
						}
					else
						return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find an answer to a question" );
					}
				else
					return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given question specification item is deleted" );
				}
			else
				return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given question specification item isn't a question" );
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given question specification item is undefined" );

		return commonVariables_->result;
		}

	ResultType findPossibleQuestionAndMarkAsAnswered( bool isAssignment, bool isSelfGenerated, unsigned int compoundSpecificationCollectionNr, SpecificationItem *answerSpecificationItem )
		{
		bool isPossessive;
		unsigned int answerGeneralizationCollectionNr;
		unsigned int answerSpecificationCollectionNr;
		SpecificationItem *currentQuestionSpecificationItem;
		WordItem *answerSpecificationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findPossibleQuestionAndMarkAsAnswered";

		if( answerSpecificationItem != NULL )
			{
			if( !answerSpecificationItem->isQuestion() )
				{
				if( ( currentQuestionSpecificationItem = myWord_->firstSelectedSpecification( isAssignment, false, false, true ) ) != NULL )
					{
					isPossessive = answerSpecificationItem->isPossessive();
					answerGeneralizationCollectionNr = answerSpecificationItem->generalizationCollectionNr();
					answerSpecificationCollectionNr = answerSpecificationItem->specificationCollectionNr();
					answerSpecificationWordItem = answerSpecificationItem->specificationWordItem();

					do	{
						if( currentQuestionSpecificationItem->isOlderSentence() &&	// To avoid deactivating questions created during the current sentence
						currentQuestionSpecificationItem->isRelatedSpecification( isPossessive, isSelfGenerated, answerGeneralizationCollectionNr, answerSpecificationCollectionNr, compoundSpecificationCollectionNr, answerSpecificationWordItem ) )
							{
							if( markQuestionAsAnswered( showAnsweredQuestion_, currentQuestionSpecificationItem ) == RESULT_OK )
								{
								if( currentQuestionSpecificationItem->isAssignment() )
									showAnsweredQuestion_ = false;		// Don't show the specification of this assignment

								currentQuestionSpecificationItem = myWord_->firstSelectedSpecification( isAssignment, false, false, true );
								}
							else
								return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to mark a related question as been answered" );
							}
						else
							currentQuestionSpecificationItem = currentQuestionSpecificationItem->nextSelectedSpecificationItem( false );
						}
					while( currentQuestionSpecificationItem != NULL );
					}
				}
			else
				return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given answer specification item is a question" );
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given answer specification item is undefined" );

		return commonVariables_->result;
		}

	SpecificationItem *firstActiveNewUserQuestion()
		{
		SpecificationItem *firstSpecificationItem;
		SpecificationItem *firstNewUserQuestion = NULL;

		if( ( firstSpecificationItem = myWord_->firstActiveAssignment( true ) ) != NULL )
			firstNewUserQuestion = firstSpecificationItem->firstNewUserQuestion();

		if( firstNewUserQuestion == NULL &&
		( firstSpecificationItem = myWord_->firstActiveQuestionSpecification() ) != NULL )
			return firstSpecificationItem->firstNewUserQuestion();

		return firstNewUserQuestion;
		}


	public:
	// Constructor

	WordQuestion( WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		hasFoundDeeperPositiveAnswer_ = false;
		hasFoundSpecificationGeneralizationAnswer_ = false;
		isNegativeAnswer_ = false;
		showAnsweredQuestion_ = false;

		uncertainAboutAnswerRelationSpecificationItem_ = NULL;

		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "WordQuestion" );

		if( commonVariables_ != NULL )
			{
		if( myWord_ == NULL )
			strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInWord( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	ResultType findPossibleQuestionAndMarkAsAnswered( unsigned int compoundSpecificationCollectionNr, SpecificationItem *answerSpecificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "findPossibleQuestionAndMarkAsAnswered";
		showAnsweredQuestion_ = true;

		if( findPossibleQuestionAndMarkAsAnswered( true, false, compoundSpecificationCollectionNr, answerSpecificationItem ) == RESULT_OK )
			{
			if( findPossibleQuestionAndMarkAsAnswered( false, false, compoundSpecificationCollectionNr, answerSpecificationItem ) == RESULT_OK )
				{
				if( findPossibleQuestionAndMarkAsAnswered( true, true, compoundSpecificationCollectionNr, answerSpecificationItem ) == RESULT_OK )
					{
					if( findPossibleQuestionAndMarkAsAnswered( false, true, compoundSpecificationCollectionNr, answerSpecificationItem ) != RESULT_OK )
						return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find a posssible self-generated question in my specifications and mark it as been answered" );
					}
				else
					return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find a posssible self-generated question in my assignments and mark it as been answered" );
				}
			else
				return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find a posssible user question in my specifications and mark it as been answered" );
			}
		else
			return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find a posssible user question in my assignments and mark it as been answered" );

		return commonVariables_->result;
		}

	ResultType findAnswerToNewUserQuestion()
		{
		SpecificationItem *questionSpecificationItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findAnswerToNewUserQuestion";

		if( ( questionSpecificationItem = firstActiveNewUserQuestion() ) != NULL )
			{
			do	{
				if( findAnswerToNewUserQuestion( questionSpecificationItem ) != RESULT_OK )
					return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find an answer to a question" );
				}
			while( ( questionSpecificationItem = ( questionSpecificationItem->isDeletedItem() ? firstActiveNewUserQuestion() : questionSpecificationItem->nextNewUserQuestion() ) ) != NULL );
			}

		return commonVariables_->result;
		}

	ResultType markQuestionAsAnswered( bool showAnsweredQuestion, SpecificationItem *questionSpecificationItem )
		{
		SpecificationResultType specificationResult;
		SpecificationItem *foundRelatedSpecificationItem = NULL;
		char functionNameString[FUNCTION_NAME_LENGTH] = "markQuestionAsAnswered";

		if( questionSpecificationItem != NULL )
			{
			if( questionSpecificationItem->isQuestion() )
				{
				if( showAnsweredQuestion )
					{
					if( myWord_->writeSpecification( false, false, false, questionSpecificationItem ) != RESULT_OK )
						return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write the answered question" );
					}

				do	{
					if( ( specificationResult = myWord_->findRelatedSpecification( false, questionSpecificationItem ) ).result == RESULT_OK )
						{
						if( ( foundRelatedSpecificationItem = specificationResult.relatedSpecificationItem ) != NULL )
							{
							if( markQuestionAsAnswered( foundRelatedSpecificationItem ) != RESULT_OK )
								return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to mark a related question as been answered" );
							}
						}
					else
						return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find a related answered question part" );
					}
				while( foundRelatedSpecificationItem != NULL );

				if( !questionSpecificationItem->isDeletedItem() )
					{
					if( markQuestionAsAnswered( questionSpecificationItem ) != RESULT_OK )
						return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to mark a question as been answered" );
					}
				}
			else
				return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given question specification item isn't a question" );
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given question specification item is undefined" );

		return commonVariables_->result;
		}

	ResultType writeAnswerToQuestion( bool isNegativeAnswer, bool isPositiveAnswer, bool isUncertainAboutRelation, SpecificationItem *questionSpecificationItem, SpecificationItem *answerSpecificationItem )
		{
		unsigned short answerParameter;
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeAnswerToQuestion";

		if( questionSpecificationItem != NULL )
			{
			if( answerSpecificationItem != NULL )
				{
				if( isPositiveAnswer )
					{
					if( commonVariables_->currentGrammarLanguageWordItem != NULL )
						{
						if( myWord_->selectGrammarToWriteSentence( false, ( isPositiveAnswer ? WORD_PARAMETER_ANSWER_YES : NO_ANSWER_PARAMETER ), NO_GRAMMAR_LEVEL, commonVariables_->currentGrammarLanguageWordItem->startOfGrammarItem(), answerSpecificationItem ) != RESULT_OK )
							return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to select the grammar for an answer" );
						}
					else
						return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The current language word item is undefined" );
					}
				else	// Neutral or negative answer
					{
					if( isUncertainAboutRelation )
						{
						if( uncertainAboutAnswerRelationSpecificationItem_ == NULL )
							uncertainAboutAnswerRelationSpecificationItem_ = answerSpecificationItem;
						else
							return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The uncertain about relation specification item is already assigned" );
						}
					else
						{
						answerParameter = ( isNegativeAnswer &&
											commonVariables_->isFirstAnswerToQuestion ? WORD_PARAMETER_ANSWER_NO : NO_ANSWER_PARAMETER );

						if( myWord_->writeSelectedSpecification( true, true, false, false, answerParameter, answerSpecificationItem ) != RESULT_OK )
							return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a selected answer to a question" );
						}
					}

				if( !isUncertainAboutRelation &&
				strlen( commonVariables_->writeSentenceString ) > 0 )
					{
					if( ( commonVariables_->hasShownMessage &&
					commonVariables_->isFirstAnswerToQuestion ) ||

					answerSpecificationItem->isSelfGeneratedAssumption() )
						{
						if( commonVariables_->presentation->writeInterfaceText( true, PRESENTATION_PROMPT_NOTIFICATION, ( answerSpecificationItem->isSelfGeneratedAssumption() ? INTERFACE_LISTING_I_AM_NOT_SURE_I_ASSUME : INTERFACE_LISTING_MY_ANSWER ) ) != RESULT_OK )
							return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a listing header" );
						}

					if( commonVariables_->presentation->writeDiacriticalText( PRESENTATION_PROMPT_WRITE, commonVariables_->writeSentenceString ) == RESULT_OK )
						{
						commonVariables_->hasFoundAnswerToQuestion = true;
						commonVariables_->isFirstAnswerToQuestion = false;

						if( isNegativeAnswer )
							isNegativeAnswer_ = true;
						}
					else
						return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write an answer to a question" );
					}
				}
			else
				return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given answer specification item is undefined" );
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given question specification item is undefined" );

		return commonVariables_->result;
		}

	SpecificationResultType findQuestionToAdjustedByCompoundCollection( bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem )
		{
		SpecificationResultType specificationResult;
		WordItem *currentCollectionWordItem;
		WordItem *currentWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findQuestionToAdjustedByCompoundCollection";

		if( specificationWordItem != NULL )
			{
			if( ( currentWordItem = commonVariables_->firstWordItem ) != NULL )
				{
				do	{
					if( ( currentCollectionWordItem = currentWordItem->compoundCollectionWordItem( specificationCollectionNr, specificationWordItem ) ) != NULL )
						{
						if( ( specificationResult.adjustedQuestionSpecificationItem = myWord_->firstAssignmentOrSpecification( false, false, false, true, true, isNegative, isPossessive, questionParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, currentCollectionWordItem, NULL ) ) != NULL )
							{
							if( myWord_->archiveOrDeletedSpecification( specificationResult.adjustedQuestionSpecificationItem, NULL ) != RESULT_OK )
								myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to archive or delete a question part" );
							}
						}
					}
				while( commonVariables_->result == RESULT_OK &&
				( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
				}
			else
				myWord_->startErrorInWord( functionNameString, moduleNameString_, "The first word item is undefined" );
			}
		else
			myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given specification word item is undefined" );

		specificationResult.result = commonVariables_->result;
		return specificationResult;
		}
	};

/*************************************************************************
 *
 *	"I will sing a new song to you, O God!
 *	I will sing your praises with a ten-stringed harp." (Psalm 144:9)
 *
 *************************************************************************/
