#! /usr/bin/env python
# -*- coding: UTF-8 -*-
###
#
# This file is the legal property of Jean-Pierre Redonnet
# <redonnetbrouk@aol.com>
# Copyright (c) 2008-2009 Jean-Pierre Redonnet
#
# This program 'texlexan.py'(the GUI of texlexan) is a free softwares;
# you can redistribute it and/or modify it under the terms of the GNU
# General Public License version 3 as published by the Free Software
# Foundation.
#
# texlexan.py is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# long with texlexan.py.If not, see <http://www.gnu.org/licenses/>.
#
###
import pygtk
pygtk.require('2.0')
import gtk,gobject
import sys,os,shutil,string,time,urllib
import urlparse
import webbrowser
import getopt
import locale
from time import localtime,strftime,strptime,mktime,clock

Prog_name='TexLexAn'
version='GUI 0.37'
date_version='August 12 2010'

class App:
   pass

#----------- Display info in a small window -------------
def message(title,message):
   dia = gtk.Dialog(title,
        None,  #the toplevel wgt of your app
        gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT,  #binary flags or'ed together
        (gtk.STOCK_OK, gtk.RESPONSE_CLOSE))
   dia.vbox.pack_start(gtk.Label('\n'+message+'\n'))
   dia.show_all()
   result = dia.run()
   dia.destroy()
   return

#--------- Calendar ---------------------------------------
def Calendar(entryN):
    cal=App()

    def calendar_day_selected_double_click(w, wg):
        year, month, day = w.get_date()
        mytime = time.mktime((year, month+1, day, 0, 0, 0, 0, 0, -1))
        entryN.set_text(time.strftime("%Y-%m-%d", time.localtime(mytime)))

    cal.window = gtk.Window(gtk.WINDOW_TOPLEVEL)
    cal.marked_date = 31*[0]

    window = gtk.Window(gtk.WINDOW_TOPLEVEL)
    window.set_title("Calendar")
    window.set_border_width(5)
    window.connect("destroy",  lambda w: window.destroy())

    window.set_resizable(False)
    vbox = gtk.VBox(False, 1)
    window.add(vbox)

    # The top part of the window, Calendar, flags and fontsel.
    hbox = gtk.HBox(False, 1)
    vbox.pack_start(hbox, True, True, 1)
    hbbox = gtk.HButtonBox()
    hbox.pack_start(hbbox, False, False, 1)
    hbbox.set_layout(gtk.BUTTONBOX_SPREAD)
    hbbox.set_spacing(5)

    # Calendar widget
    frame = gtk.Frame("Calendar")
    hbbox.pack_start(frame, False, True, 1)
    calendar = gtk.Calendar()
    cal.window = calendar
    calendar.display_options(gtk.CALENDAR_SHOW_HEADING | gtk.CALENDAR_SHOW_DAY_NAMES)
    frame.add(calendar)
    calendar.connect("day_selected_double_click",
                      calendar_day_selected_double_click,cal)
    vbox2 = gtk.VBox(False, 1)
    hbox.pack_start(vbox2, False, False, 1)
  
    bbox = gtk.HButtonBox ()
    vbox.pack_start(bbox, False, False, 0)
    bbox.set_layout(gtk.BUTTONBOX_END)

    button = gtk.Button("Close")
    button.connect("clicked", lambda w: window.destroy())
    bbox.add(button)
    button.set_flags(gtk.CAN_DEFAULT)
    button.grab_default()

    window.show_all()

#--------- Display options list for texlexan cli ----------
def rapport_help(text):
    rapp=App()

    window_title='TexLexAn CLI help'
          
    rapp.window = gtk.Window(gtk.WINDOW_TOPLEVEL)
    rapp.window.set_title(window_title)
    rapp.window.set_default_size(500, 500)
    rapp.window.set_border_width(5)

    rapp.vbox = gtk.VBox(False, 5)
    rapp.window.add(rapp.vbox)

    #scrollable text window
    sr = gtk.ScrolledWindow()    
    sr.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
    rapp.window.textview = gtk.TextView()
    rapp.window.textbuffer = rapp.window.textview.get_buffer()
    sr.add(rapp.window.textview)
    sr.show()
    rapp.window.textview.show()
    rapp.vbox.pack_start(sr)
    rapp.window.textbuffer.set_text(text)    
    rapp.window.show_all()

#------------- Correct class provided by the user -------------
def check_input_class(text):
   invalid_flag=False
   #prefix language missing?
   if (text[:len(language_detected)] != language_detected):
      text=language_detected+'.'+text
      invalid_flag=True
   #space?
   if ' ' in text:
      text=string.replace(text,' ','_')
      invalid_flag=True
   #invalid char?
   for char in (',',';',':','/','*'):
      if char in text:
         invalid_flag=True
         break
   return text,invalid_flag

#------------- Manage window where results are displayed -------
#add feedback at the end of keyworder.build
def learn_keywords_short(entry,data):
    rfs=data

    #answer 'I don't know' == do nothing
    if rfs.optDont.get_active():
       rfs.window.destroy()
       return

    #Excluded Words (-e 1/2) + dico (-f ) + results Paths (-F)+ options
    prog_learner=learner_path+" -e 2 -f "+dico_path+" -F "+result_path+option_learner

    #return a feedback to the summarizer thru abstracts.data
    #fb:N is added to the last record
    try: f=open(dico_path+'abstracts.data','a')
    except:
       message('Error','impossible to open '+dico_path+'abstracts.data')
       exit()
   
    if rfs.optGood.get_active():
       #Reenforce the summarizing method
       fb=' fb:2'
    elif rfs.optMediocre.get_active():
       fb=' fb:1'
    elif rfs.optPoor.get_active():   
       fb=' fb:0'
    f.write(fb)
    print 'Updated: "'+dico_path+'abstracts.data" with this'+fb
    f.close()

    #feedback classifier
    if rfs.optRight.get_active():
       #Reenforce class_found
       prog_learner=prog_learner+" -a 1 -c "+class_found
    elif rfs.optWrong.get_active():
       #Fade the class_found
       prog_learner=prog_learner+" -a -1 -c "+class_found

    #start the learner
    print 'Commande line:',prog_learner         
    result=os.popen(prog_learner).read()
    if 'OKAY!' in result:
       print 'Update OK!'
    else:
       message('Error!','Sorry the Learner failed\nrun texlexan.py in the console and check the message')
    print result #learner output is printed

    #done - close the window
    rfs.window.destroy()
    return True


""" save_result stores class, keywords and summary in the archives folder
 it allows the user to seach for infomations
"""
def save_result(text,ext_name,link_path):
   hash_code = ''
   #extract some info from the result
   for line in string.split(text,'\n'):
      if ('<' in line[:5] and 'Text signature'in line[1:20]):
         hash_code=string.strip(line[1+string.find(line,':'):string.find(line,'>')])
   #check if the hash exist
   try: f=open(archive_path+'classification.lst','r')
   except:
      print 'cannot open '+archive_path+'classification.lst\n'
      try:  f=open(archive_path+'classification.lst','a')
      except:
         message('Error','cannot create '+archive_path+'classification.lst')
         return '' #abort
      print 'Create '+archive_path+'classification.lst\n'
      (language_code,encoding) = locale.getlocale(locale.LC_TIME)
      f.write('<archiveslist:lan='+language_code+':encod='+encoding+':vers=1>\n')
      f.close()
   else:
      hash_tag='<Hash:'+hash_code+'>'
      for line in f:
         if hash_tag in line:
            #hash already exist!
            message('Problem!',' Text signature found. \n No archiving!')
            return '' #abort
      f.close()
   #add the abstract to the list
   try: f=open(archive_path+'classification.lst','a')
   except:
      message('Error','impossible to append '+archive_path+'classification.lst')
      exit()
   #date in 2 formats human friendly and computer friendly
   f.write('\n<Date:'+strftime("%d %B %Y %H:%M:%S",localtime())+' ('+strftime("%Y%m%d %H%M%S",localtime())+')>\n')
   f.write('\n<Hash:'+hash_code+'>\n')
   f.write('\n<Ext:'+ext_name+'>\n')
   f.write('\n<Link:'+link_path+'>\n')
   f.write('\n<Class:'+class_found+'='+repr(class_proba)+'%>\n')
   start=string.find(text,'<Start abstract')
   end=string.find(text,'<Text signature',start)
   f.write(text[start:end]+'\n')
   f.write('\n<End>\n')
   f.close()
   return hash_code


""" short_rapport is used when we just want drop the link of the webpage 
 url file:///... should work too
 short_rapport shows only the classification and the summary
"""
def short_rapport(text):
    global class_found
    global class_proba
    short=App()
    short.window = gtk.Window(gtk.WINDOW_TOPLEVEL)
    short.window.set_title('Summaries')
    short.window.set_default_size(480, 400)
    short.window.set_border_width(5)
    short.h2box = gtk.HBox(False, 1)
    short.h3box = gtk.HBox(False, 1)
    short.h4box = gtk.HBox(False, 1)
    short.vbox = gtk.VBox(False,1)
    short.window.add(short.vbox)

    #labels
    short.infolabel1 = gtk.Label()
    short.infolabel1.set_line_wrap(True)
    short.infolabel1.set_justify(gtk.JUSTIFY_CENTER)
    short.vbox.pack_start(short.infolabel1)
    short.infolabel2 = gtk.Label()
    short.infolabel2.set_line_wrap(True)
    short.infolabel2.set_justify(gtk.JUSTIFY_LEFT)
    short.vbox.pack_start(short.infolabel2)
    short.infolabel3 = gtk.Label()
    short.infolabel3.set_line_wrap(True)
    short.infolabel3.set_justify(gtk.JUSTIFY_LEFT)
    short.infolabel4 = gtk.Label()
    short.infolabel4.set_line_wrap(True)
    short.infolabel4.set_justify(gtk.JUSTIFY_LEFT)
    
    #display results (text var) in a scrollable text window
    s_short = gtk.ScrolledWindow()
    s_short.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
    short.window.textview = gtk.TextView()
    short.window.textbuffer = short.window.textview.get_buffer()
    s_short.add(short.window.textview)
    s_short.set_size_request(480, 400)
    s_short.show()
    short.window.textview.show()
    short.vbox.pack_start(s_short)

    infotext=''
    #display result html to text conversion
    if 'Conversion html->text' in text:
       pos=string.find(text,'Conversion html->text')+21
       pos=string.find(text,',',pos)+1
       pos=string.find(text,',',pos)+1
       infotext='HTML PAGE CONTAINS: '+text[pos:string.find(text,'link',pos)]+ 'link(s)\n'
    #Reading time
    if 'Estim. reading' in text:
       pos=string.find(text,'Estim. reading')
       infotext=infotext+text[pos:string.find(text,'mn',pos)]+ 'mn'
    #display nb html found & reading time
    short.infolabel1.set_text(infotext)

    #Get the most probable class
    class_found='NONE'
    class_proba=0
    for line in string.split(text,'\n'):
       if ('<' in line[:5] and 'Probable class'in line[1:20]):
           class_found=string.strip(line[1+string.find(line,':'):string.find(line,'>')])
           class_proba=string.atoi(string.strip(line[1+string.find(line,'='):string.find(line,'%')]))    
    #display the classification
    short.infolabel2.set_text('Class ('+repr(class_proba)+'%):'+class_found)

    #display summaries in scrollable text window
    short.window.textbuffer.set_text(text[string.find(text,'<Start abstract'):])

    #enter the feedback
    short.vbox.pack_start(short.infolabel3)
    short.infolabel3.set_text("Feedback: Give your opinion about the results")
    #Classification
    short.optRight = gtk.RadioButton(label = "_Right class")
    short.h2box.pack_start(short.optRight, False, False, 2)
    short.optDont = gtk.RadioButton(short.optRight, "_Don't know")
    short.h2box.pack_start(short.optDont, False, False, 2)
    short.optWrong = gtk.RadioButton(short.optDont, "_Wrong class")
    short.h2box.pack_start(short.optWrong, False, False, 2)       
    short.vbox.add(short.h2box)
    #Summarizer
    short.optGood = gtk.RadioButton(label = "_Good summary")
    short.h3box.pack_start(short.optGood, False, False, 2)
    short.optMediocre = gtk.RadioButton(short.optGood, "_Mediocre summary")
    short.h3box.pack_start(short.optMediocre, False, False, 2)
    short.optPoor = gtk.RadioButton(short.optMediocre, "_Poor summary")
    short.h3box.pack_start(short.optPoor, False, False, 2)       
    short.vbox.add(short.h3box)
    #set radiobuttons with classification probability
    if (class_proba >= 80):
       short.optRight.set_active(True)
       short.optGood.set_active(True)
    elif (class_proba >= 50):
       short.optDont.set_active(True)
       short.optMediocre.set_active(True) 
    else:
       short.optWrong.set_active(True)
       short.optMediocre.set_active(True)
    
    #Button save and close this window
    short.button1 = gtk.Button("_Close",gtk.STOCK_OK)
    short.h4box.pack_start(short.button1, False, False, 0)
    short.button1.connect("clicked", learn_keywords_short, short)
    short.infolabel4.set_text("The knowledge base will be updated and this window closed.")
    short.h4box.add(short.infolabel4)
    short.vbox.add(short.h4box)
    #show
    short.window.show_all()
    erase(w)
    return True

    
#Run the 'learner'engine to update the dico,learner needs keyworder.build
def learn_keywords(entry,data):
    global class_found
    global class_proba
    rf=data

    #answer 'I don't know' == do nothing
    if rf.optDont.get_active():
       rf.window.destroy()
       return

    #Words of exclude (-e 1/2) and dico, results Paths
    prog_learner=learner_path+" -e 2 -f "+dico_path+" -F "+result_path+option_learner
    
    if rf.optRight.get_active():
       #Reenforce class_found
       prog_learner=prog_learner+" -a 1 -c "+class_found
    elif rf.optWrong.get_active():
       #3 possibilities if the class found is wrong:
       iter = rf.combo.get_active_iter()
       rf.model = rf.combo.get_model()
       text = rf.model.get_value(iter, 1)
       if 'New label' in text:
          #1- we can add a new class from the entry
          text=''
          text=string.strip(rf.inputclass.get_text())
          (text,flag_err) = check_input_class(text)
          if flag_err == True:
             rf.inputclass.set_text(text)
             message('Error!',text)
             return
          if text != '':
             prog_learner=prog_learner+" -a 1 -c "+text
             #update the classification vars
             class_found=text
             class_proba=100
       if text=='':
          #2- we can fade the class_found
          prog_learner=prog_learner+" -a -1 -c "+class_found
       else:
          #3- we can add a class from the combo box (predefined classes)
          prog_learner=prog_learner+" -a 1 -c "+text
          #update the classification vars
          class_found=text
          class_proba=100

    if ('L' in debug_mode):
       print 'Commande line:',debugger+prog_learner         
       result=os.popen(debugger+prog_learner).read()
    else:
       print 'Commande line:',prog_learner         
       result=os.popen(prog_learner).read()
       if 'OKAY!' in result:
         print 'Update OK!'
       else:
          message('Error!','Sorry the Learner failed\nrun texlexan.py in the console and check the message')
    print result
    rf.window.destroy()  
    return
    
#add feedback at the end of the file keyworder.build
def record_feedback(entry,data):
    rf=data
    
    try: f=open(dico_path+'keyworder.build','a')
    except:
       message('Error','impossible to open '+texlexan_path+'texlexan.cfg')
       exit()
    f.write('< Begin feedback >\n') 
    f.write('< Label:'+class_id+' >\n')
    if rf.optRight.get_active(): f.write('< Reenforce_text_class:'+class_found+' >\n')
    elif rf.optDont.get_active(): f.write('< Postpone_text_class: >\n')
    elif rf.optWrong.get_active():
       iter = rf.combo.get_active_iter()
       rf.model = rf.combo.get_model()
       text = rf.model.get_value(iter, 1)
       if 'New label' in text:
          text=''
          text=string.strip(rf.inputclass.get_text())
          if text != '':
                (text,flag_err) = check_input_class(text)
                if flag_err == True:
                   rf.inputclass.set_text(text)
                   message('Error!',text)
                   return
                try: g=open(file_kw_class,'a')
                except:
                   message('Error','impossible to write in '+file_kw_class)
                else:
                   g.write(text)
                   g.close()    
       if text=='': f.write('< Wrong_text_class:'+class_found+' >\n')
       else: f.write('< Add_text_class:'+text+' >\n')
    f.write('< End feedback >\n') 
    f.close()
    rf.window.destroy()
    return True


#Just set active the radiobutton Wrong class 
def set_wrong_opt(entry,data):
    swo=data
    swo.optWrong.set_active(True)
    

#window where full results are displayed and feedback entered
def rapport(text):
    global class_found
    global class_proba
    global file_kw_class
    global language_detected
    
    nb_syllables=[]
    frame=[]
    label=[]
   
    window_title='Analyze results'
    button_title='_Previous'
    
    r=App()
        
    r.window = gtk.Window(gtk.WINDOW_TOPLEVEL)
    r.window.set_title(window_title)
    r.window.set_default_size(800, 500)
    r.window.set_border_width(5)

    r.vbox1 = gtk.VBox(False, 1)
    r.vbox2 = gtk.VBox(False, 1)
    r.vbox3 = gtk.VBox(False, 1)
    r.hbox = gtk.HBox(False, 1)
    r.hbox2 = gtk.HBox(False, 1)
    r.hbox3 = gtk.HBox(False, 1)
    r.vbox = gtk.VBox(False,1)
    r.window.add(r.vbox)

    r.separator = gtk.HSeparator()
    
    #display results (text var) in a scrollable text window
    sr = gtk.ScrolledWindow()
    sr.set_size_request(400, 500)
    sr.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
    r.window.textview = gtk.TextView()
    r.window.textbuffer = r.window.textview.get_buffer()
    sr.add(r.window.textview)
    sr.show()
    r.window.textview.show()
    r.hbox.pack_start(sr)
    r.window.textbuffer.set_text(text)

    # get nb words/syllables
    j=0
    maxi=0
    for line in string.split(text,'\n'):   
       if line[:10]=='Words with':
          (left,right)=string.split(line[10:],'=')
          if 'syllable'in left:
             nb_syllables.append(string.atoi(right))
             if nb_syllables[j] > maxi: maxi=nb_syllables[j]
             j+=1

    sr2 = gtk.ScrolledWindow()
    sr2.set_size_request(400, 500)
    sr2.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)

    indexbar=0
    if j >0 : #if nb words/syllables found
       # make a bargraph nb words/syllables
       syllablesframe=gtk.Frame(' Nb Words/syllables')        
       for i in range(0,j):
          if nb_syllables[i] > 0:
             bar=(50*nb_syllables[i]/maxi)*'|'
             if i==0: frame.append(gtk.Frame(' 1 syllable'))
             else: frame.append(gtk.Frame(' '+repr(i+1)+' syllables'))
             label.append(gtk.Label(bar))
             frame[indexbar].add(label[indexbar])
             r.vbox1.pack_start(frame[indexbar])      
             indexbar+=1
             print indexbar,
       syllablesframe.add(r.vbox1)
       r.vbox3.pack_start(syllablesframe)
       r.vbox3.pack_start(r.separator, False, True, 5)
    
    # get percentage (Grade )of terms found
    maxi=0
    keywordsframe=gtk.Frame(' % of keyterms')
    text_nbkeyw= ' '
    for line in string.split(text,'\n'):
       print line
       if '<Classified' in line[:15]:
          text_nbkeyw= string.strip(line[11:])
          r.vbox2.pack_start(gtk.Label("<"+text_nbkeyw+">"))
       elif '<List of' in line[:10]:
          text_nbkeyw= "compiled class"
          r.vbox2.pack_start(gtk.Label("<"+text_nbkeyw+">"))
       elif 'Grade:'in line[:6]:
          (left,right)=string.split(line[6:],'%')
          val=string.atoi(string.strip(left))
          text_label=right[string.rfind(right,':'):]
	  
          #keep the highest value (most probable class)
          #if val>maxi:
            # maxi=val
             #class_found=string.strip(text_label[string.rfind(text_label,' '):])
	     
          #make a bargraph
          if val > -1:
             bar=val*'|'
             frame.append(gtk.Frame('Class'+text_label+', '+text_nbkeyw))
             label.append(gtk.Label(bar))
             frame[indexbar].add(label[indexbar])
             r.vbox2.pack_start(frame[indexbar])
             indexbar+=1
             print indexbar,
    keywordsframe.add(r.vbox2)   
    r.vbox3.pack_start(keywordsframe)
    
    sr2.add_with_viewport(r.vbox3)
    r.hbox.add(sr2)
    
    r.vbox.add(r.hbox)
    
    #Get the most probable class
    class_found="NONE"
    class_proba=0
    for line in string.split(text,'\n'):
       if ('<' in line[:5] and 'Probable class'in line[1:20]):
           class_found=string.strip(line[1+string.find(line,':'):string.find(line,'>')])
           class_proba=string.atoi(string.strip(line[1+string.find(line,'='):string.find(line,'%')]))
       
    ###### if learning mode then add option box and entry ######
           
    if opt1.get_active(): 
       explain = gtk.Label()
       explain.set_line_wrap(True)
       explain.set_text('<<< LEARNING MODE: Give your feedback >>>')
       r.vbox.pack_start(explain, False, False, 0)
       #class found
       classfound = gtk.Label()
       frameclass = gtk.Frame('Class found, probability of '+repr(class_proba)+'%')
       classfound.set_line_wrap(True)
       classfound.set_text(class_found)
       frameclass.add(classfound)
       r.vbox.pack_start(frameclass, False, False, 0)
       #validation
       r.optRight = gtk.RadioButton(label = "It is the _Right class")
       r.hbox2.pack_start(r.optRight, False, False, 2)
       r.optDont = gtk.RadioButton(r.optRight, "I _don't know")
       r.hbox2.pack_start(r.optDont, False, False, 2)
       r.optWrong = gtk.RadioButton(r.optDont, "It is the _Wrong class, you can be more precise and give the right class")
       r.hbox2.pack_start(r.optWrong, False, False, 2)       
       r.vbox.add(r.hbox2)
       #class to record

       #get class label from keyworder.lang.class and show a selection box
       # look for lang
       language_detected=""
       for line in string.split(text,'\n'):
          if 'Language'in line:
             if 'detected:' in line or 'forced:' in line:
                (left,language_detected)=string.split(line,':')
                language_detected=string.strip(language_detected)
                break
             else:
                message('Bug!',line)
                break
       if ( language_detected == "" ):
          message('Bug!',"Check texlexan engine.")
          exit()
       
       # prepare the file name    
       file_kw_class=dico_path+'keyworder.'+language_detected+'.class'
       # open the file containing the class labels
       try: f=open(file_kw_class,'r')
       except:
          message('Error','impossible to read '+file_kw_class)
       else:
          i=0
          #Categories choice displayed in Combo box
          r.store = gtk.TreeStore(gobject.TYPE_INT, gobject.TYPE_STRING)
          iter = r.store.append(None)
          r.store.set(iter, 0, i, 1, "New label")
          #now extract each class label
          for line in f:
             if '#<END>' in line: break #end of file
             if line[0] != '#': #if line is not a comment
                i=i+1
                iter = r.store.append(None)
                class_label=line[:-1]
                if '\t' in class_label:
                   #separate label name and data (nb of updates, nb of words...)
                   class_label=class_label[:string.find(class_label,'\t')]
                r.store.set(iter, 0, i, 1, class_label) #do no take the CR at the end
          #End of categories choice
          # Combo 7 Categorie
          r.combo = gtk.ComboBox(r.store)
          r.renderer = gtk.CellRendererText()
          r.combo.pack_start(r.renderer, True)
          r.combo.add_attribute(r.renderer, 'text', 1)
          r.combo.set_active(0)
          frame7 = gtk.Frame('Choose a class')
          frame7.add(r.combo)
          r.hbox3.pack_start(frame7, False, False, 0)
          f.close();      
       
       commentclass = gtk.Label()
       commentclass.set_text('Enter the label:')
       r.hbox3.pack_start(commentclass, False, False, 0)
       r.inputclass = gtk.Entry()
       r.hbox3.pack_start(r.inputclass, True, True, 0)
       r.vbox.add(r.hbox3)

       #set active the radiobutton Wrong class
       r.inputclass.connect("activate",set_wrong_opt,r)
       r.inputclass.connect("changed",set_wrong_opt,r)
       r.combo.connect("changed",set_wrong_opt,r)
       
       #ok button & connections
       if (learner_mode=='B'):   #batch mode
          button_rfb = gtk.Button("_Record (only save keywords) & close this window")
          r.vbox.pack_start(button_rfb, False, False, 0)
          button_rfb.connect("clicked",record_feedback,r)
       elif (learner_mode=='L'):   #immediatly after texlexan
          button_rfb = gtk.Button("_Learn ("+learner_name+") & close this window")
          r.vbox.pack_start(button_rfb, False, False, 0)
          button_rfb.connect("clicked",learn_keywords,r)
       else:
          message('Error','Check the option LM\nin the configuration file')
       
    r.window.show_all()
    return True
    
#-------------- window to past a text -----------------
def cancel_text(entry,data):
    txt = data
    txt.window.destroy()

def clear_text(entry,data):
    txt = data
    txt.window.text2buffer.set_text('')
    
def valid_text(entry,data):
    txt = data
    #get the text from scrollable text zone of the main window
    iterstart,iterend=txt.window.text2buffer.get_bounds()
    text=txt.window.text2buffer.get_text(iterstart,iterend)
    text+='\n'
    #suppress space
    string.strip(text);
    if text=='': return False #there's nothing!
    
    try: f=open(text_path+'/copy_past.txt','w')
    except:
       message('Error','impossible to write past.txt')
       return False

    f.write(text)
    f.close()
    text1buffer.set_text(text_path+'/copy_past.txt')
    valid(txt)
    return True

def text_to_analyse(w):
    txt=App()
        
    txt.window = gtk.Window(gtk.WINDOW_TOPLEVEL)
    txt.window.set_title('Past your text')
    txt.window.set_default_size(500, 500)
    txt.window.set_border_width(5)
    txt.window.connect("destroy", cancel_text,txt)

    txt.vbox = gtk.VBox(False, 5)
    txt.h2box = gtk.HBox(False, 5)
    txt.h3box = gtk.HBox(False, 5)
    
    txt.window.add(txt.vbox)

    #scrollable text window
    sr = gtk.ScrolledWindow()
    sr.set_size_request(500, 500)
    sr.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
    txt.window.textview = gtk.TextView()
    txt.window.text2buffer = txt.window.textview.get_buffer()
    sr.add(txt.window.textview)
    sr.show()
    txt.window.textview.show()
    txt.vbox.pack_start(sr)
    txt.window.text2buffer.set_text('')

    txt.label = gtk.Label('Drop your text here and validate')
    txt.label.set_line_wrap(True)
    txt.vbox.pack_start(txt.label, True, True, 0)

    txt.button1 = gtk.Button("_valid",gtk.STOCK_OK)
    txt.h2box.pack_start(txt.button1, False, False, 0)
    txt.button1.connect("clicked", valid_text,txt)

    txt.button2 = gtk.Button("_Clear",gtk.STOCK_CLEAR)
    txt.h2box.pack_start(txt.button2, False, False, 0)
    txt.button2.connect("clicked", clear_text, txt)

    txt.button3 = gtk.Button("_Close",gtk.STOCK_CLOSE)
    txt.h2box.pack_start(txt.button3, False, False, 0)
    txt.button3.connect("clicked", cancel_text, txt)
    
    txt.vbox.add(txt.h2box)
        
    txt.window.show_all()


#------------ window the choose a file ------------------------
def files_chooser(w):
   global text_path
   
   dialog = gtk.FileChooserDialog("Choose the text to analyse",
                               None,
                               gtk.FILE_CHOOSER_ACTION_OPEN,
                               (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL,
                                gtk.STOCK_OPEN, gtk.RESPONSE_OK))
   dialog.set_default_response(gtk.RESPONSE_OK)
   dialog.set_current_folder(text_path)
   dialog.set_select_multiple(False)

   filter = gtk.FileFilter()
   filter.set_name("All files")
   filter.add_pattern("*")
   dialog.add_filter(filter)

   filter = gtk.FileFilter()
   filter.set_name("Textes")
   filter.add_mime_type("image/png")
   filter.add_mime_type("image/jpeg")
   filter.add_mime_type("image/gif")
   filter.add_pattern("*.png")
   filter.add_pattern("*.jpg")
   filter.add_pattern("*.gif")
   filter.add_pattern("*.tif")
   filter.add_pattern("*.xpm")
   dialog.add_filter(filter)

   response = dialog.run()
   if response == gtk.RESPONSE_OK:
      #destination=dialog.get_filename()
      #get the text
      iterstart,iterend=text1buffer.get_bounds()
      text=text1buffer.get_text(iterstart,iterend)
      #supress empty lines
      while '\n\n' in text: text=string.replace(text,'\n\n','\n')
      #check if data is valid files
      list_file=''
      filenames = dialog.get_filenames()
      for chain in filenames:
         chain=string.replace(chain,'%20',' ') #space char
         #avoid double
         add_chain=True
         for chain_bis in string.split(text):
            if chain_bis<>chain:
               add_chain=False
         #complete the list
         if add_chain: list_file+=chain+'\n'
      #Display the file selected
      text=list_file
      text1buffer.set_text(text)  
   elif response == gtk.RESPONSE_CANCEL:
      print 'Closed, no files selected'
   dialog.destroy()
   return True

#----------- drag & drop functions ---------------------
def motion_cb(wid, context, x, y, time):
    context.drag_status(gtk.gdk.ACTION_COPY, time)
    return True

def drop_cb(wid, context, x, y, time):
    if context.targets:
        w.drag_get_data(context, context.targets[0], time)
    context.finish(True, False, time)
    return True

#get data dropped and check if valid files
def drag_data_received (window, context, x, y, data, info, time):
    text=''
    for chain in string.split(data.data,'\r'):
       #remove %..%..%..
       chain=urllib.unquote(chain)
       #set_text() doesn't like null char
       chain = string.replace(chain,'\0','')
       print 'Dropped >',chain,'<'
       if 'file:' in chain:
            chain=string.replace(chain,'file:','')
            while '//' in chain: chain=string.replace(chain,'//','/')
            chain=string.replace(chain,'\n','')
            chain=string.replace(chain,'\r','')
            if (len(chain) > 0):
               text+=chain+'\n'
       elif 'http:' in chain:
            #!convert but still pb with accents & special chars
            chain = urlparse.urlsplit(chain)
            chain = chain.geturl()
            chain=string.replace(chain,'\r','\n')
            if '\n' in chain:
                 (chain,right)=string.split(chain,'\n')
            if (len(chain) > 0):
               text+=chain+'\n'
       elif 'https:' in chain:
            #!convert but still pb with accents & special chars
            chain = urlparse.urlsplit(chain)
            chain = chain.geturl()
            chain=string.replace(chain,'\r','\n')
            if '\n' in chain:
                 (chain,right)=string.split(chain,'\n')
            if (len(chain) > 0):
               text+=chain+'\n'
    #Display the file selected
    text1buffer.set_text(text)
    context.finish (True, False, time)
    return True
   
def cancel_valid(entry, data):
    valid = data
    valid.window.destroy()

#---------- start texlexan in command line -----------------
#analyze a list of summaries between 2 dates    
def valid_bis(w):
    global class_id
    global complete_box
    global analyze_summaries
    print "\nStart the CLI Engines...cross your fingers!"
    console_encoding = 'UTF-8'
    prog_texlexan=prg_path #progam path    
    #get the text from scrollable text zone of the main window
    iterstart,iterend=text1buffer.get_bounds()
    text=text1buffer.get_text(iterstart,iterend)
    text+='\n'
    #replace CR with space
    while '\n' in text: text=string.replace(text,'\n',' ')
    while '  ' in text: text=string.replace(text,'  ',' ')
    #if help in command run prog with arg -h
    if ('-h' in text or '--help' in text):
       result=os.popen(prog_texlexan+' -h').read()
       rapport_help(result) #show help in a special window
       return True

    date1 = string.strip(entry02.get_text())
    date2 = string.strip(entry03.get_text())
    if len(date1)==0 or len(date2)==0:
       return False
    if not ':' in date1:
       date1+=" 00:00:00"
    if not ':' in date2:
       date2+=" 00:00:00"

    prog_texlexan+=option_texlexan #add extra options eventually
    prog_texlexan+=' -r 0' #do not check repetition
    #abstracts option -A b => avoid the whole list of classes found
    prog_texlexan+=' -A b'  #lot of data (slow)
    #prog_texlexan+=' -K' #-K filtered keywords -k all keyterms
    prog_texlexan+=' -S 0'#no plagiarism
    prog_texlexan+=' -E 0' #no sentiment
    prog_texlexan+=' -W '+repr(width_col) #format line
    prog_texlexan+=' -c auto' #charset detection
    #dicos path
    summaries_path=archive_path+'classification.lst'
    prog_texlexan+=' -e F'+' -f '+dico_path+' -F '+result_path+' -l '+language+' -i '+summaries_path
    #alloc enough mem
    prog_texlexan+=' -z 50'
    #Option: -D "2 dec 2009 10:25:00;3 dec 2009 10:25:00;target=business" 
    prog_texlexan+=' -D "'+date1+';'+date2+'"'
    #Eventually options from the text window
    prog_texlexan+=' '+text
    #run
    if ('T' in debug_mode):
       print 'Commande line:',debugger+prog_texlexan
       try: result=os.popen(debugger+prog_texlexan).read()
       except:
          message('Error!','Fail to analyse!')
          return False	   
    else:
       print 'Command line:',prog_texlexan
       try: result=os.popen(prog_texlexan).read()
       except:
          message('Error!','Fail to analyse!')
          return False

    """
       output of texlexan is returned in result
       then result is converted to allow accentued char,
       because texlexan return coded Latin-1 text
    """
    if (lang_char != ''):
       status=rapport(unicode(result,lang_char))
    else: status=rapport(result)


def valid(w): #analyze and learn
    global class_id
    global complete_box
    global analyze_summaries

    """ if summaries analysis, call a separate function
    """
    if analyze_summaries:
       valid_bis(w)
       return True

    if check_1_7.get_active():
       archive=True
    else:
       archive=False

    print "\nStart the CLI Engines...cross your fingers!"
    console_encoding = 'UTF-8'
    prog_texlexan=prg_path
    #get the text from scrollable text zone of the main window
    iterstart,iterend=text1buffer.get_bounds()
    text=text1buffer.get_text(iterstart,iterend)
    text+='\n'
    #replace CR with space
    while '\n' in text: text=string.replace(text,'\n',' ')
    #if help in command run prog with arg -h
    if ('-h ' in text or '-help' in text or '--help' in text):
       result=os.popen(prog_texlexan+' -h').read()
       rapport_help(result) #show help in a special window
       return True
    #if file:///...
    if 'file://' in text:
       text=string.replace(text,'file://','')
       #remove %..%..%..
       text=urllib.unquote(text)

    prog_texlexan+=option_texlexan #add extra options eventually
    
    if ('--debug' in text):
       string.replace(text,'--debug ',' ')
       prog_texlexan+=' -d 1 -v 1 '
    if ('--verbose' in text):
       string.replace(text,'--verbose ',' ')
       prog_texlexan+=' -v 1 '
       
    #suppress space
    text=text.strip();
    #!!! check
    if "'" in text:
       textbis='"'+text.encode(console_encoding)+'"'
    else:
       textbis="'"+text.encode(console_encoding)+"'"
    #markers
    text_action='<'+text+'>'
    #if there's nothing to do!
    if text=='':
       message("Error","Please, drop a file.")
       return False 

    """
        'Texlexan cli' understands text and html only,
        so an external conversion is required for the other formats.
        antiword, pdftotext, odt2txt, ppthtml do the job.
        file extension is used to detect the file format, of course it's
        not always reliable.
        converted text is send thought a pipe
    """
    run_directly=1
    external_converter=''
    file_ext=''
    flag_downloaded=False
    flag_dropped=False
    if '<http:/' in text_action or '<www.' in text_action or '<https:/' in text_action:
       #from the net, we use wget to download the file and antiword, odt2txt, pdftotext, ppthtml to convert it
       run_directly=0
       # proceed: .ext>  '>' is omitted for opera that can cause pb
       if '.doc' in text_action:
          print 'Command line: wget -O '+result_path+'msdoc.temp '+textbis
          file_ext='doc'
          flag_downloaded=True
          os.popen('wget -O '+result_path+'msdoc.temp '+textbis)
          external_converter='antiword '+result_path+'msdoc.temp |'
       elif '.odt' in text_action:
          print 'Command line: wget -O '+result_path+'odt.temp '+textbis
          file_ext='odt'
          flag_downloaded=True
          os.popen('wget -O '+result_path+'odt.temp '+textbis)
          external_converter='odt2txt '+result_path+'odt.temp |'
       elif '.pdf' in text_action:
          print 'Command line: wget -O '+result_path+'pdf.temp '+textbis
          file_ext='pdf'
          flag_downloaded=True
          os.popen('wget -O '+result_path+'pdf.temp '+textbis)
          external_converter='pdftotext '+result_path+'pdf.temp - |'
       elif '.ppt' in text_action:
          print 'Command line: wget -O '+result_path+'ptt.temp '+textbis
          file_ext='ptt'
          flag_downloaded=True
          os.popen('wget -O '+result_path+'ptt.temp '+textbis)
          external_converter='ppthtml '+result_path+'ptt.temp |'
       elif '.htm' in text_action:
          print 'Command line: wget -O '+result_path+'html.temp '+textbis
          file_ext='html'
          flag_downloaded=True
          os.popen('wget -O '+result_path+'html.temp '+textbis)
          external_converter='cat '+result_path+'html.temp |'   
       else:
          #no extension, try to guess the mime with file
          print 'Command line: wget -O '+result_path+'temp.temp '+textbis
          os.popen('wget -O '+result_path+'temp.temp '+textbis)
          mime = os.popen("/usr/bin/file -i "+result_path+"temp.temp").read()
          print 'Mime:',mime
          if ('html' in mime or 'text' in mime):  
             file_ext='html'
             flag_downloaded=True
             os.rename(result_path+"temp.temp",result_path+"html.temp")
             external_converter='cat '+result_path+'html.temp |'
          else:
             return False
    else:
       #use antiword, odt2txt, pdftotext, ppthtml to convert the file
       if '.doc>' in text_action:
          external_converter='antiword '+textbis+'|'
          file_ext='doc'
          flag_dropped=True
          run_directly=0
       elif '.odt>' in text_action:
          external_converter='odt2txt '+textbis+'|'
          file_ext='odt'
          flag_dropped=True
          run_directly=0
       elif '.pdf>' in text_action:
          external_converter='pdftotext '+textbis+' - |'
          file_ext='pdf'
          flag_dropped=True
          run_directly=0
       elif '.ppt>' in text_action:
          external_converter='ppthtml '+textbis+' - |'
          file_ext='ppt'
          flag_dropped=True
          run_directly=0
       elif '.txt>' in text_action or  '.text>' in text_action:
          file_ext='txt'
          flag_dropped=True
          run_directly=1 #text doesn't need conversion
       else:
          file_ext='unknw' #marked unknow
          flag_dropped=True
          run_directly=1 #no conversion because we don't know
          print "Document is not converted!\n"
    
    #result file name
    result_file=result_path+'texlexan_'+strftime("%d%b%Y_%H%M%S",localtime())+'.rslt'

    #Prepare the cmde line for texlexan
    
    if opt1.get_active(): #learning mode
       class_id='_class_id_'+strftime("%d%b%Y_%H%M%S",localtime()) #class_id helps retreiving class name
       prog_texlexan+=' -b' #write keyworder.build file
       prog_texlexan+=' -CGoLabel'+class_id #add the class id to keyworder.build file

    if check_1_2.get_active(): prog_texlexan+=' -r 5' #repetition
    else: prog_texlexan+=' -r 0' #do not check repetition

    #abstracts option -A 'mode 1..7/a/b' -a '% compression' -W
    if check_1_1.get_active():
       if (complete_box):
          # -A a abstract in automatic mode + the whole list of classes found
          prog_texlexan+=' -A a -a 10'  #a lot of data (slow)
       else:
          # -A b abstract in automatic mode and don't list the classes found
          prog_texlexan+=' -A b -a 10' #less data (faster)
    else:
       prog_texlexan+=' -A 0'

    #option -M for detail list of classes found for each N-grams
    if check_1_8.get_active(): prog_texlexan+=' -M 1'
    #option -K for filtered keywords  -k for all keyterms
    if check_1_4.get_active(): prog_texlexan+=' -K'
    #options -S for plagiarism
    if check_1_3.get_active(): prog_texlexan+=' -S 1'
    else: prog_texlexan+=' -S 0'
    #options -E for Emotion/sentiment
    if check_1_5.get_active():
       target = string.strip(entry1.get_text())
       if target:
          prog_texlexan+=' -E "'+target+'"'
       else:
          prog_texlexan+=' -E 1'
    else:
       prog_texlexan+=' -E 0'
    if check_1_6.get_active():
       prog_texlexan+=' -E 2'

    # format width of column
    prog_texlexan+=' -W '+repr(width_col)

    if opt21.get_active(): #charset
       prog_texlexan+=' -c auto'
    elif opt22.get_active():
       prog_texlexan+=' -c utf8'
    elif opt23.get_active():
       prog_texlexan+=' -c iso'


    if (run_directly):
       prog_texlexan+=' -e F'+' -f '+dico_path+' -F '+result_path+' -l '+language+' -i '+textbis
    else:
       prog_texlexan+=' -e F'+' -f '+dico_path+' -F '+result_path+' -l '+language+' -i PIPE'


    if (memory_alloc > 0):
       prog_texlexan+=' -z '+repr(memory_alloc)
       
    #memo debug and verbose prog_texlexan+=' -d 1 -v 1 '
    """
       use pipe to display result in window
       may run in the debuger: valgrind or gdb 
    """
    if ('T' in debug_mode):
       print 'Commande line:',debugger+external_converter+prog_texlexan
       try: result=os.popen(debugger+external_converter+prog_texlexan).read()
       except:
          message('Error!','Fail to convert \nor analyze file!')
          return False	   
    else:
       print 'Command line:',external_converter+prog_texlexan
       try: result=os.popen(external_converter+prog_texlexan).read()
       except:
          message('Error!','Fail to convert \nor analyze file!')
          return False
    status=False
    """
       rapport or short_rapport call the learner
    """
    if (complete_box):
       #output of texlexan is returned in result
       #then result is converted to allow accentued char,
       #because texlexan return coded Latin-1 text
       if (lang_char != ''):
          status=rapport(unicode(result,lang_char))
       else: status=rapport(result)
    else:
       #output is sended to short_rapport (only summary)
       #converted in utf8 is necessary
       if (lang_char != ''):
          status=short_rapport(unicode(result,lang_char))
       else: status=short_rapport(result)
    
    if (archive):
       """ 
          save_result(...) records the summary and some other info in a 
          list classification.lst
          the orignal file is compressed
          this stuff is stored in /telexan_archive
       """
       if (lang_char != ''):
          hash_name=save_result(unicode(result,lang_char),file_ext,text)
       else: hash_name=save_result(result,file_ext,text)
       if (hash_name):
          if (flag_downloaded):
             hash_name = archive_path+hash_name+'.'+file_ext
             os.rename(result_path+file_ext+'.temp',hash_name)
             os.popen('bzip2 '+hash_name)
          elif (flag_dropped):
             hash_name = archive_path+hash_name+'.'+file_ext
             shutil.copy(text,hash_name)
             os.popen('bzip2 '+hash_name)

    if (status):
       #clean up temporaries files
       try: os.remove(result_path+'html.temp')
       except: print 'skip remove html.temp' 
       try: os.remove(result_path+'pdf.temp')
       except: print 'skip remove pdf.temp' 
       try: os.remove(result_path+'odt.temp')
       except: print 'skip remove odt.temp'
       try: os.remove(result_path+'msdoc.temp')
       except: print 'skip remove msdoc.temp'
       try: os.remove(result_path+'ptt.temp')
       except: print 'skip remove ptt.temp'
       try: os.remove(result_path+'text.temp')
       except: print 'skip remove text.temp'
       try: os.remove(result_path+'PIPE.txt')
       except: print 'skip remove PIPE.txt'
    else:
       print 'No clean up!  Pb?'
    
    return True

#---------------- Manage a small drop box for url link
def toggle_small_full(entry,w):
   global complete_box
   
   if complete_box: # then switch to small
      complete_box=0 #switch 1->0
      date_entry=1
      analyze_summaries=0
      v01box.hide()
      v02box.hide() 
      opt1.set_active(True) #analyze & learn
      check_1_1.set_active(True) #summarize
      check_1_2.set_active(False) #no repetition
      check_1_3.set_active(False) #no plagia
      check_1_4.set_active(False) #no keyterm listed
      check_1_5.set_active(False) #no sentiment
      check_1_6.set_active(False) #no sentiment summary
      check_1_7.set_active(True) #archive doc
      check_2_0.set_active(False) #always false
      check_1_8.set_active(False) #no detail classes
      check_2_1.set_label("Full options")
   else: #switch to full
      complete_box=1 #switch 0->1
      date_entry=1
      analyze_summaries=0
      v01box.show()
      v02box.hide()
      opt1.set_active(True) #analyze & learn
      check_1_1.set_active(sum_btn) #summarize
      check_1_2.set_active(rep_btn) #repetition
      check_1_3.set_active(pla_btn) #plagia
      check_1_4.set_active(key_btn) #keyterm listed
      check_1_5.set_active(sen_btn) #sentiment
      check_1_6.set_active(sen2_btn) #sentiment summary
      check_1_7.set_active(arc_btn) #archive doc
      check_1_8.set_active(det_btn) #detail classes
      check_2_1.set_label("Small box")
   w.resize(*w.size_request())
   return True

#---------------- Manage 2 entries for the dates
def calendar1(entry,w):
   Calendar(entry02)
   return
def calendar2(entry,w):
   Calendar(entry03)
   return
def dateentry(entry,w):
   global date_entry
   global analyze_summaries
   
   if date_entry: #switch to dates
      date_entry=0
      analyze_summaries=1
      v01box.hide()
      v02box.show()
      opt2.set_active(True) #analyze only
      check_1_1.set_active(True) #summarize
      check_1_2.set_active(False) #no repetition
      check_1_3.set_active(False) #no plagia
      check_1_4.set_active(False) #no keyterm listed
      check_1_5.set_active(False) #no sentiment
      check_1_6.set_active(False) #no sentiment summary
      check_1_7.set_active(False) #archive doc
      check_2_0.set_active(False) #always false
      check_1_8.set_active(False) #no detail classes
      text1buffer.set_text("") #clear text window
   else: #switch to full
      date_entry=1
      complete_box=1
      analyze_summaries=0
      v01box.show()
      v02box.hide()
      opt1.set_active(True) #analyze & learn
      check_1_1.set_active(sum_btn) #summarize
      check_1_2.set_active(rep_btn) #repetition
      check_1_3.set_active(pla_btn) #plagia
      check_1_4.set_active(key_btn) #keyterm listed
      check_1_5.set_active(sen_btn) #sentiment
      check_1_6.set_active(sen2_btn) #sentiment summary
      check_1_7.set_active(arc_btn) #archive doc
      check_1_8.set_active(det_btn) #detail classes
   w.resize(*w.size_request())
   return True


#--------------- store buttons configuration -----------------
def storeconfig(entry,w):
    global sum_btn
    global rep_btn
    global pla_btn
    global key_btn
    global sen_btn
    global sen2_btn
    global arc_btn
    global det_btn
    
    try: f=open(texlexan_path+'texlexan.btn','w')
    except:
        message('Error','impossible to create '+texlexan_path+'texlexan.btn')
        return True
    gtk.gdk.beep()
    f.write('#buttons configuration\n')
    sum_btn=check_1_1.get_active()
    f.write('summarize:'+repr(sum_btn)+'\n')
    rep_btn=check_1_2.get_active()
    f.write('repetition:'+repr(rep_btn)+'\n')
    pla_btn=check_1_3.get_active()
    f.write('plagia:'+repr(pla_btn)+'\n')
    key_btn=check_1_4.get_active()
    f.write('keyterms:'+repr(key_btn)+'\n')
    sen_btn=check_1_5.get_active()
    f.write('sentiment:'+repr(sen_btn)+'\n')
    sen2_btn=check_1_6.get_active()
    f.write('summ_sent:'+repr(sen2_btn)+'\n')
    arc_btn=check_1_7.get_active()
    f.write('archive:'+repr(arc_btn)+'\n')
    det_btn=check_1_8.get_active()
    f.write('detail:'+repr(det_btn)+'\n')
    f.close()
    check_2_0.set_active(False)
    return True

#---------------- Manage the main window ----------------------

#only one sentiments analyze can be activate
def sentiment_switch1(w):
   if check_1_5.get_active():
      check_1_6.set_active(False)
def sentiment_switch2(w):
   if check_1_6.get_active():
      check_1_5.set_active(False)   
  
#clear the text window
def erase(w):
    text1buffer.set_text('')
    return
   
#short help
def help(w):
   if analyze_summaries:
      dia = gtk.Dialog('Help for Summaries Analyzer',
         None,  #the toplevel wgt of your app
         gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT,  #binary flags or'ed together
         ('_More info', 77,gtk.STOCK_CLOSE, gtk.RESPONSE_CLOSE))
      dia.vbox.pack_start(gtk.Label(
         '\nJP Redonnet\nVers. '+version+' - '+date_version+'\n'+Prog_name+' analyzes text.\n\n'+
         'Analyze the summaries between two dates.\n'
         'Click on # to open a calendar.\n'+
         'Double clicks on the date of the calendar.\n'+
         'Close the calendars and validate.\n'
         'The text window allows some extra options.\n'+
         ' !!!Note: Be very patient is the period to analyze is large.\n'))
      dia.show_all()
      result = dia.run()
      dia.destroy()
      if result == 77:
         webbrowser.open("http://texlexan.sourceforge.net/")
         gtk.RESPONSE_CLOSE

   elif complete_box:
      dia = gtk.Dialog('Help for the large box',
         None,  #the toplevel wgt of your app
         gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT,  #binary flags or'ed together
         ('_More info', 77,gtk.STOCK_CLOSE, gtk.RESPONSE_CLOSE))
      dia.vbox.pack_start(gtk.Label(
         '\nJP Redonnet\nVers. '+version+' - '+date_version+'\n'+Prog_name+' analyzes text.\n\n'+
         '1 - Select or Drop the file/http to analyze\n'+
         '    you can drop a text (button paste)\n'+
         '2 - Select Analyze & Learn or Analyze only\n'+
         '3 - Check Repetition, Summarize,keywords\n'+
         '4 - Select UTF-8 or ISO to force the conversion\n'+
         '5 - Click on okay button.\n'+
         '6 - Validate/modify the classification\n'+
         ' Click on Summarize Webpage for less.\n'+
         ' !!!Note: Be patient if the text is large.\n'))
      dia.show_all()
      result = dia.run()
      dia.destroy()
      if result == 77:
         webbrowser.open("http://texlexan.sourceforge.net/")
         gtk.RESPONSE_CLOSE
   else:
      dia = gtk.Dialog('Help for the small box',
         None,  #the toplevel wgt of your app
         gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT,  #binary flags or'ed together
         ('_More info', 77,gtk.STOCK_CLOSE, gtk.RESPONSE_CLOSE))
      dia.vbox.pack_start(gtk.Label(
         '\nJP Redonnet\nVers. '+version+' - '+date_version+'\n'+Prog_name+' analyzes text.\n\n'+
         '1 - From your browser (Firefox...)\n drag & drop the link of the webpage.\n'+
         '2 - Click OK to summarize.\n'+
         ' Click on Full options and help for more.\n'+
         ' !!!Note: Be patient if the text is large (particularly pdf,ppt doc)\n it must be downloaded, converted, analyzed and finaly summarized.\n'))
      dia.show_all()
      result = dia.run()
      dia.destroy()
      if result == 77:
         webbrowser.open("http://texlexan.sourceforge.net/")
         gtk.RESPONSE_CLOSE
   return
      
###############################
#### program starts here ! ####
###############################
home_user_path=os.path.expanduser('~')  #home directory
texlexan_path=home_user_path+'/texlexan_cfg/' #contain the config file
dico_path=home_user_path+'/texlexan_dico/' #dictionnaries
result_path=home_user_path+'/texlexan_result/' #summaries files
archive_path=home_user_path+'/texlexan_archive/' #archives downloaded files
prg_path=home_user_path+'/texlexan_prog' #contain the main prog
text_path=home_user_path #contain texts to analyze
file_kw_class='' #will contain the filename for class names list
class_id=''
class_found='NONE'
class_proba=0
width_col='70' #default abstracts have 70 chars per line
lang_char='Latin-1' #output of texlexan (latin1) is converted in unicode
learner_mode='L'  #default use lasylearner engine
learner_path=prg_path+'/lazylearner' #To keep compatibility with ver. 1
learner_name='Lazy Learner'
complete_box=0 #default small box webpage summarizer
date_entry=1 #default do not analyze summaries between 2 dates
analyze_summaries=0 #default do not analyze summaries
memory_alloc=10 #how many block of mem to alloc
option_texlexan=''
option_learner=''
url_in_arg=''
debug_mode=''
#valgind to detect memory leak... !!!don't forget space before last '
debugger='valgrind -v --tool=memcheck --track-origins=yes --leak-check=full '
sum_btn=False
rep_btn=False
pla_btn=False
key_btn=False
sen_btn=False
sen2_btn=False
arc_btn=False
det_btn=False
full_box=False
dates_box=False
selected_date=''

# check if external progs are available
result=os.popen('whereis ppthtml').read()
(left,right) = string.split(result,':')
if (string.strip(right)==''):
   message('Error!','The program ppthtml is missing?')
result=os.popen('whereis pdftotext').read()
(left,right) = string.split(result,':')
if (string.strip(right)==''):
   message('Error!','The program pdftotext is missing?')
result=os.popen('whereis odt2txt').read()
(left,right) = string.split(result,':')
if (string.strip(right)==''):
   message('Error!','The program odt2txt is missing?')
result=os.popen('whereis antiword').read()
(left,right) = string.split(result,':')
if (string.strip(right)==''):
   message('Error!','The program antiword is missing?')
result=os.popen('whereis wget').read()
(left,right) = string.split(result,':')
if (string.strip(right)==''):
   message('Error!','The program wget is missing?')
result=os.popen('whereis bzip2').read()
(left,right) = string.split(result,':')
if (string.strip(right)==''):
   message('Error!','The program bzip2 is missing?')   

# if config path does'nt exist create it
if not os.path.isdir(texlexan_path):
    print texlexan_path,"doesn't exist!"
    try: os.mkdir(texlexan_path) #create the path
    except:
        message("Error","impossible to create "+texlexan_path)
        exit()
    else:
        print texlexan_path,"has been created"

# if config file doesn't exist create it with default values
if not os.path.isfile(texlexan_path+'texlexan.cfg'):
    print texlexan_path+"texlexan.cfg doesn't exist!"
    try: f=open(texlexan_path+'texlexan.cfg','w')
    except:
        message('Error','impossible to create '+texlexan_path+'texlexan.cfg')
        exit()
    f.write('#configuration file of texlexan - prog TexLexAn\n')
    f.write('#Version number\n')
    f.write('vn:2\n')
    f.write('#Path to the program + texlexan engine\n')
    f.write('pp:'+prg_path+'/texlexan\n')
    f.write('#Path to the program + learner engine\n')
    f.write('lp:'+learner_path+'\n')
    f.write('#Path to the dictionnaries\n')
    f.write('dp:'+dico_path+'\n')
    f.write('#Path to the results (abstracts)\n')
    f.write('rp:'+result_path+'\n')
    f.write('#Path to the downloaded files archived\n')
    f.write('ap:'+archive_path+'\n')
    f.write('#Charset ansi, utf8, ascii, auto\n')
    f.write('cs:auto\n')
    f.write('#Language en,fr,es,it,de,...,auto\n')
    f.write('ln:auto\n')
    f.write('#Text Terminal\n')
    f.write('te:xterm\n')
    f.write('#Path to the text\n')
    f.write('tp:'+text_path+'\n')
    f.write('#Width of column for the abstracts\n')
    f.write('wc:'+width_col+'\n')
    f.write('#Conversion texlexan output in unicode\n')
    f.write('LC:'+lang_char+'\n')
    f.write('#Lazylearner or Batch (L/B)\n')
    f.write('LM:'+learner_mode+'\n')
    f.write('#Name of the learner (info)\n')
    f.write('LN:'+learner_name+'\n')
    f.write('#size box, small box:0 large box:1\n')
    f.write('sb:'+repr(complete_box)+'\n')
    f.write('#Memory block to allocate\n')
    f.write('ma:'+repr(memory_alloc)+'\n')
    f.write('#Options for textlexan\n')
    f.write('ot:'+option_texlexan+'\n')
    f.write('#Options for learner\n')
    f.write('ol:'+option_learner+'\n')
    f.write('#end of file\n')
    f.close()
    message('Important!',texlexan_path+'texlexan.cfg has been created.\nYou can edit the config file with any basic text editor.')

#read config file 
version_n='0'
text_path=''
try: f=open(texlexan_path+'texlexan.cfg','r')
except:
    message('Error','impossible to open '+texlexan_path+'texlexan.cfg')
    exit()
for line in f:
    if line[:3]=='vn:': version_n=string.strip(line[3:-1])
    if line[:3]=='pp:': prg_path=string.strip(line[3:-1])
    if line[:3]=='lp:': learner_path=string.strip(line[3:-1])
    if line[:3]=='dp:': dico_path=string.strip(line[3:-1])
    if line[:3]=='rp:': result_path=string.strip(line[3:-1])
    if line[:3]=='ap:': archive_path=string.strip(line[3:-1])
    if line[:3]=='cs:': char_set=string.upper(string.strip(line[3:-1]))
    if line[:3]=='ln:': language=string.strip(line[3:-1])
    if line[:3]=='te:': terminal_e=string.strip(line[3:-1])
    if line[:3]=='tp:': text_path=string.strip(line[3:-1])
    if line[:3]=='wc:': width_col=string.atoi(string.strip(line[3:-1]))
    if line[:3]=='LC:': lang_char=string.strip(line[3:-1])
    if line[:3]=='LM:': learner_mode=string.upper(string.strip(line[3:-1]))
    if line[:3]=='LN:': learner_name=string.upper(string.strip(line[3:-1]))
    if line[:3]=='sb:': full_box=string.atoi(string.strip(line[3:-1]))
    if line[:3]=='ma:': memory_alloc=string.atoi(string.strip(line[3:-1]))
    if line[:3]=='ot:': option_texlexan=string.strip(line[3:-1])
    if line[:3]=='ol:': option_learner=string.strip(line[3:-1])
f.close()

if version_n<>'2':
    message('Error','Config file is not compatible\n I an continuing with default values\n Please read change.txt')

# eventually add some extra options defined in the config file
if len(option_texlexan)>0:
   option_texlexan=' '+option_texlexan+' '
if len(option_learner)>0:
   option_learner=' '+option_learner+' '

# get the arguments passed to the cmd line
try:
   opts, args = getopt.getopt(sys.argv[1:], "dhfstu:", ["dl","dt","debug","help", "url"])
except getopt.GetoptError:
   print "Usage: ./texlexan.py -f/-s -u url_address\n"
   print "Usage: ./texlexan.py -t\n"
   print "Usage: ./texlexan.py -d/dl/dt -f/-s -u url_address\n"
   sys.exit(2)
for opt, arg in opts:
   if opt in ("-h", "--help"):
      print "Usage: ./texlexan.py -f/-s -u url_address"
      print "Usage: ./texlexan.py -t\n"
      print "Usage: ./texlexan.py -d/dl/dt -f/-s -u url_address\n"
      sys.exit()
   elif opt in ("-d","--debug"):
      debug_mode='TL'
      print "Debug mode\n"
   elif opt in ("--dl"):
      debug_mode='L'
      print "Debug learner engine\n"
   elif opt in ("--dt"):
      print "Debug texlexan engine\n"
      debug_mode='T'
   elif opt == '-f':
      full_box=True
   elif opt == '-s':
      full_box=False
   elif opt == '-t':
      dates_box=True
   elif opt in ("-u", "--url"):
      #convert the string -> utf8
      url_in_arg=urllib.unquote(arg)
      url_in_arg = string.replace(url_in_arg,'\0','')
      if 'http:' in url_in_arg:
         url_in_arg = urlparse.urlsplit(url_in_arg)
         url_in_arg = url_in_arg.geturl()
         url_in_arg=string.replace(url_in_arg,'\r','\n')
         url_in_arg=unicode(url_in_arg,lang_char)
         print 'Argument: >'+url_in_arg+'<'

#where are located texts to analyze
if text_path=='': text_path=home_user_path

#Check if main prog 'texlexan' exist
if not os.path.isfile(prg_path):
    message("Error!!!",prg_path+" doesn't exist?")
    exit()

#This folder is used by the dictionnaries - should exist!
#create dico folder
if not os.path.isdir(dico_path):
    try:os.mkdir(dico_path) #create the path
    except:
        message("Error","impossible to create "+dico_path)
        exit()
    message("Weird!",dico_path+" doesn't exist, I created it.\nNow you have to copy the dictionnaries there,\n So I terminate.")
    exit()

#This folder is used to store summaries
#create result folder
if not os.path.isdir(result_path):
    try: os.mkdir(result_path) #create the path
    except:
        message("Error","impossible to create "+result_path)
        exit()
    message("Info",result_path+" doesn't exist,so I created it.\nSummary files will be there.")
    
#This folder is used to store archived files
#create archive folder
if not os.path.isdir(archive_path):
    try: os.mkdir(archive_path) #create the path
    except:
        message("Error","impossible to create "+archive_path)
        exit()
    message("Info",archive_path+" doesn't exist,so I created it.\nArchived files will be there.")


#read buttons configuration file 
try: f=open(texlexan_path+'texlexan.btn','r')
except:
    print(texlexan_path+'texlexan.btn not found; use defaults')
else:
    for line in f:
        if 'summarize:True' in line: sum_btn=True
        if 'repetition:True' in line: rep_btn=True
        if 'plagia:True' in line: pla_btn=True
        if 'keyterms:True' in line: key_btn=True
        if 'sentiment:True' in line: sen_btn=True
        if 'summ_sent:True' in line: sen2_btn=True
        if 'archive:True' in line: arc_btn=True
        if 'detail:True' in line: det_btn=True
    f.close()


# *** The main window ***
# This window is used to enter the file name of the text to analyze 
# and the options to send to texlexan in command line

w = gtk.Window()
w.set_keep_above(True)
w.set_title(Prog_name+' '+version)
w.set_default_size(100, 100)
w.drag_dest_set(0, [], 0)
h0box = gtk.HBox(False, 0)
h1box = gtk.HBox(False, 0)
h02box = gtk.HBox(False, 0)
h2box = gtk.HBox(False, 0)
h3box = gtk.HBox(False, 0)
h4box = gtk.HBox(False, 0)
h5box = gtk.HBox(False, 0)
h6box = gtk.HBox(False, 0)
v01box = gtk.VBox(False, 0)
v02box = gtk.VBox(False, 0)
v1box = gtk.VBox(False, 0)
v2box = gtk.VBox(False, 0)
v_box = gtk.VBox(False, 0)
hbox = gtk.HBox(False, 0)
w.add(v_box)
#scrollable text window
sw = gtk.ScrolledWindow()    
sw.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
textview = gtk.TextView()
textview.set_wrap_mode(gtk.WRAP_NONE)
text1buffer = textview.get_buffer()
sw.add(textview)
sw.show()
textview.show()
v_box.pack_start(sw)
text1buffer.set_text(url_in_arg)
#label
label = gtk.Label()
frame = gtk.Frame('Drop your file or http link here!')
label.set_line_wrap(True)
label.set_text('\n\n\n')
frame.add(label)
v01box.pack_start(frame, False, False, 0)
#button Left
button0L = gtk.Button("_Folder",gtk.STOCK_OPEN)
h0box.pack_start(button0L, False, False, 0)
#label
label0 = gtk.Label()
label0.set_line_wrap(True)
label0.set_text('<File a file | Paste a text>')
h0box.pack_start(label0, False, False, 0)
v01box.add(h0box)
#button Right
button0R = gtk.Button("_Text",gtk.STOCK_PASTE)
h0box.pack_start(button0R, False, False, 0)
#connection
button0R.connect("clicked",text_to_analyse)
button0L.connect("clicked",files_chooser)
#entry target words for sentiment
entry1 = gtk.Entry()
h1box.pack_start(entry1, True, True, 0)
frame0 = gtk.Frame('Target words for sentiment')
frame0.add(h1box)
v01box.add(frame0)
#radiobuttons I
opt1 = gtk.RadioButton(label = "Analyze & Learn")
h2box.pack_start(opt1, False, False, 2)
opt2 = gtk.RadioButton(opt1, "Only Analyze")
h2box.pack_start(opt2, False, False, 2)
frame1 = gtk.Frame('Mode')
frame1.add(h2box)
v01box.add(frame1)
#checkbox
check_1_1 = gtk.CheckButton("Summarize the text")
v1box.pack_start(check_1_1, False, False, 0)
check_1_1.set_active(sum_btn)
check_1_2 = gtk.CheckButton("Check repetition")
v1box.pack_start(check_1_2, False, False, 0)
check_1_2.set_active(rep_btn)
check_1_3 = gtk.CheckButton("Check plagiarism")
v1box.pack_start(check_1_3, False, False, 0)
check_1_3.set_active(pla_btn)
check_1_8 = gtk.CheckButton("Detail classes")
v1box.pack_start(check_1_8, False, False, 0)
check_1_8.set_active(det_btn)
h3box.add(v1box)
check_1_4 = gtk.CheckButton("List key terms")
v2box.pack_start(check_1_4, False, False, 0)
check_1_4.set_active(key_btn)
check_1_5 = gtk.CheckButton("Check sentiments")
v2box.pack_start(check_1_5, False, False, 0)
check_1_5.set_active(sen_btn)
check_1_6 = gtk.CheckButton("Summ. sentiments")
v2box.pack_start(check_1_6, False, False, 0)
check_1_6.set_active(sen2_btn)
check_1_7 = gtk.CheckButton("Archive files")
v2box.pack_start(check_1_7, False, False, 0)
check_1_7.set_active(arc_btn)
h3box.add(v2box)
v01box.add(h3box)
#Store config buttons
separ=gtk.HSeparator()
v01box.pack_start(separ, False, False, 0)
check_2_0 = gtk.CheckButton("<Store buttons checked>")
v01box.pack_start(check_2_0, False, False, 0)
check_2_0.set_active(False)
#radiobuttons II
opt21 = gtk.RadioButton(label = "Auto")
h4box.pack_start(opt21, False, False, 2)
opt22 = gtk.RadioButton(opt21, "UTF-8")
h4box.pack_start(opt22, False, False, 2)
opt23 = gtk.RadioButton(opt22, "iso")
h4box.pack_start(opt23, False, False, 2)
frame2 = gtk.Frame('Chars Set')
frame2.add(h4box)
v01box.add(frame2)
if (char_set=='UTF-8' or char_set=='UTF8'): opt22.set_active(True)
elif char_set=='ISO': opt23.set_active(True)
else: opt21.set_active(True)
#v01box can be show or hide depending check_2_1
v_box.add(v01box)
#entry date1 date2 for summaries analysis
button02 = gtk.Button("#")
h02box.pack_start(button02, False, False, 0)
entry02 = gtk.Entry()
h02box.pack_start(entry02, True, True, 0)
#
button03 = gtk.Button("#")
h02box.pack_start(button03, False, False, 0)
entry03 = gtk.Entry()
h02box.pack_start(entry03, True, True, 0)
frame02 = gtk.Frame('Date 1 -> Date 2 (YYYY-MM-DD)')
frame02.add(h02box)
v02box.add(frame02)
#v02box can be show or hide depending check_2_2
v_box.add(v02box) 
#Switch to summarize a webpage
check_2_1 = gtk.CheckButton("Small box")
h5box.pack_start(check_2_1, False, False, 0)
check_2_1.set_active(False)
label1 = gtk.Label()
label1.set_line_wrap(False)
label1.set_text(' ')
h5box.pack_start(label1, True, True, 0)
#Switch to analyze the list of summaries
check_2_2 = gtk.CheckButton("Summaries analysis")
h5box.pack_start(check_2_2, False, False, 0)
check_2_2.set_active(False)
v_box.add(h5box)
#buttons
button1 = gtk.Button("_Ok",gtk.STOCK_OK)
hbox.pack_start(button1, False, False, 0)
button2 = gtk.Button("_Clear",gtk.STOCK_CLEAR)
hbox.pack_start(button2, False, False, 0)
button3 = gtk.Button("_Help",gtk.STOCK_HELP)
hbox.pack_start(button3, False, False, 0)
button4 = gtk.Button("_Close",gtk.STOCK_QUIT)
hbox.pack_start(button4, False, False, 0)
v_box.add(hbox)
#connections
check_1_5.connect("clicked",sentiment_switch1)
check_1_6.connect("clicked",sentiment_switch2)
check_2_0.connect("clicked",storeconfig,w)
check_2_1.connect("clicked",toggle_small_full,w)
check_2_2.connect("clicked",dateentry,w) #analyze summaries
button02.connect("clicked",calendar1,w)
button03.connect("clicked",calendar2,w)
button1.connect("clicked",valid)   
button2.connect("clicked",erase)
button3.connect("clicked",help)
button4.connect("clicked",lambda w: gtk.main_quit())
#drap & drop connections
w.connect('drag_motion', motion_cb)
w.connect('drag_drop', drop_cb)
w.connect ('drag_data_received', drag_data_received)
w.connect('destroy', lambda w: gtk.main_quit())
w.show_all()

# option passed to texlexan.py can force the mode
if full_box==True:
   check_2_1.set_active(True)
   complete_box=0
   toggle_small_full(w,w)
else:
   check_2_1.set_active(False)
   complete_box=1
   toggle_small_full(w,w)

if dates_box==True:
   dateentry(w,w)
else:
   #no dates entries
   v02box.hide()

w.resize(*w.size_request())
gtk.main()


#gui frontend for the text analyzer: texlexan
#JP Redonnet, redonnetbrouk@aol.com
#Well, not very fancy but it works!
