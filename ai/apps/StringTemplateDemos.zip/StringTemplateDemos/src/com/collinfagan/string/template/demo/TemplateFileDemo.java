package com.collinfagan.string.template.demo;

import org.antlr.stringtemplate.StringTemplate;
import org.antlr.stringtemplate.StringTemplateGroup;

/**
 * Demonstration class for using StringTemplate with a template defined in a file.
 * 
 * @author Collin Fagan
 */
public class TemplateFileDemo {

	public static void main(String[] args) {
		
		StringTemplateGroup templateGroup = new StringTemplateGroup("spam group", "templates");
		StringTemplate spam419 = templateGroup.getInstanceOf("spam419");

		spam419.setAttribute("to", "Collin");
		spam419.setAttribute("to_addr", "collin@bugmenot.com");
		spam419.setAttribute("from", "Ima Spammer");
		spam419.setAttribute("from_addr", "ima.spammer@spammers-paradise.com");
		
		System.out.println(spam419.toString());
	}

}
