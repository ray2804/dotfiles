/*
 *	Class:			ReadItem
 *	Parent class:	Item
 *	Purpose:		To temporarily store info about the read words of a sentence
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

class ReadItem extends Item
	{
	// Private loadable variables

	private short wordOrderNr_;
	private short wordParameter_;
	private short wordTypeNr_;
	private short wordTypeLanguageNr_;

	private WordItem readWordItem_;


	// Protected constructible variables

	protected boolean isMarkedBySetGrammarParameter;
	protected boolean isUnusedReadItem;
	protected boolean isWordPassingGrammarIntegrityCheck;

	protected short grammarParameter;

	protected GrammarItem definitionGrammarItem;


	// Protected loadable variables

	protected String readString;


	// Constructor

	protected ReadItem( short wordOrderNr, short wordParameter, short wordTypeNr, short wordTypeLanguageNr, int readStringLength, String _readString, WordItem readWordItem, List myList, WordItem myWord )
		{
		initializeItemVariables( Constants.NO_SENTENCE_NR, Constants.NO_SENTENCE_NR, Constants.NO_SENTENCE_NR, Constants.NO_SENTENCE_NR, myList, myWord );


		// Private loadable variables

		wordOrderNr_ = wordOrderNr;
		wordParameter_ = wordParameter;
		wordTypeNr_ = wordTypeNr;
		wordTypeLanguageNr_ = wordTypeLanguageNr;

		readWordItem_ = readWordItem;


		// Protected constructible variables

		isMarkedBySetGrammarParameter = false;
		isUnusedReadItem = false;
		isWordPassingGrammarIntegrityCheck = false;

		grammarParameter = Constants.NO_GRAMMAR_PARAMETER;

		definitionGrammarItem = null;


		// Protected loadable variables

		readString = ( _readString == null ? null : _readString.substring( 0, readStringLength ) );
		}


	// Protected virtual methods

	protected void showString( boolean returnQueryToPosition )
		{
		if( CommonVariables.queryStringBuffer == null )
			CommonVariables.queryStringBuffer = new StringBuffer();

		if( readString != null )
			{
			if( CommonVariables.hasFoundQuery )
				CommonVariables.queryStringBuffer.append( returnQueryToPosition ? Constants.NEW_LINE_STRING : Constants.QUERY_SEPARATOR_SPACE_STRING );

			if( !isActiveItem() )	// Show status when not active
				CommonVariables.queryStringBuffer.append( statusChar() );

			CommonVariables.hasFoundQuery = true;
			CommonVariables.queryStringBuffer.append( readString );
			}
		}

	protected void showWordReferences( boolean returnQueryToPosition )
		{
		String wordString;

		if( CommonVariables.queryStringBuffer == null )
			CommonVariables.queryStringBuffer = new StringBuffer();

		if( readWordItem_ != null &&
		( wordString = readWordItem_.wordTypeString( true, Constants.NO_ORDER_NR, wordTypeNr_ ) ) != null )
			{
			if( CommonVariables.hasFoundQuery )
				CommonVariables.queryStringBuffer.append( returnQueryToPosition ? Constants.NEW_LINE_STRING : Constants.QUERY_SEPARATOR_SPACE_STRING );

			if( !isActiveItem() )	// Show status when not active
				CommonVariables.queryStringBuffer.append( statusChar() );

			CommonVariables.hasFoundQuery = true;
			CommonVariables.queryStringBuffer.append( wordString );
			}
		}

	protected boolean hasFoundParameter( int queryParameter )
		{
		return ( grammarParameter == queryParameter ||
				wordOrderNr_ == queryParameter ||
				wordParameter_ == queryParameter ||

				( queryParameter == Constants.MAX_QUERY_PARAMETER &&

				( grammarParameter > Constants.NO_GRAMMAR_PARAMETER ||
				wordOrderNr_ > Constants.NO_ORDER_NR ||
				wordParameter_ > Constants.NO_WORD_PARAMETER ) ) );
		}

	protected boolean hasFoundReferenceItemById( int querySentenceNr, int queryItemNr )
		{
		return ( ( readWordItem_ == null ? false :
					( querySentenceNr == Constants.NO_SENTENCE_NR ? true : readWordItem_.creationSentenceNr() == querySentenceNr ) &&
					( queryItemNr == Constants.NO_ITEM_NR ? true : readWordItem_.itemNr() == queryItemNr ) ) ||

				( definitionGrammarItem == null ? false :
					( querySentenceNr == Constants.NO_SENTENCE_NR ? true : definitionGrammarItem.creationSentenceNr() == querySentenceNr ) &&
					( queryItemNr == Constants.NO_ITEM_NR ? true : definitionGrammarItem.itemNr() == queryItemNr ) ) );
		}

	protected boolean hasFoundWordType( short queryWordTypeNr )
		{
		return ( wordTypeNr_ == queryWordTypeNr );
		}

	protected boolean isSorted( Item nextSortItem )
		{
		return ( nextSortItem == null ||
				// 1) Descending creationSentenceNr
				creationSentenceNr() > nextSortItem.creationSentenceNr() ||

				// 2) Ascending wordOrderNr_
				( creationSentenceNr() == nextSortItem.creationSentenceNr() &&
				( wordOrderNr_ < ( (ReadItem)nextSortItem ).wordOrderNr_ ||

				// 3) Descending wordTypeNr_
				( wordOrderNr_ == ( (ReadItem)nextSortItem ).wordOrderNr_ &&
				wordTypeNr_ > ( (ReadItem)nextSortItem ).wordTypeNr_ ) ) ) );
		}

	protected byte findMatchingWordReferenceString( String queryString )
		{
		CommonVariables.hasFoundMatchingStrings = false;

		if( readWordItem_ != null )
			{
			if( readWordItem_.findMatchingWordReferenceString( queryString ) != Constants.RESULT_OK )
				return addErrorInItem( 1, null, readString, "I failed to find the word reference for the word reference query" );
			}

		return CommonVariables.result;
		}

	protected byte findWordReference( WordItem referenceWordItem )
		{
		CommonVariables.hasFoundWordReference = false;

		if( referenceWordItem != null )
			{
			if( readWordItem_ == referenceWordItem )
				CommonVariables.hasFoundWordReference = true;
			}
		else
			return startErrorInItem( 1, null, readString, "The given reference word is undefined" );

		return CommonVariables.result;
		}

	protected String itemString()
		{
		return readString;
		}

	protected StringBuffer toStringBuffer( short queryWordTypeNr )
		{
		String wordString;
		String languageNameString = myWord().grammarLanguageNameString( wordTypeLanguageNr_ );
		String readWordTypeString = myWord().wordTypeName( wordTypeNr_ );

		baseToStringBuffer( queryWordTypeNr );

		if( isUnusedReadItem )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "isUnusedReadItem" );

		if( isWordPassingGrammarIntegrityCheck )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "isWordPassingGrammarIntegrityCheck" );

		if( isMarkedBySetGrammarParameter )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "isMarkedBySetGrammarParameter" );

		if( wordTypeLanguageNr_ > Constants.NO_LANGUAGE_NR )
			{
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + ( languageNameString == null ? ( "wordLanguageNr:" + wordTypeLanguageNr_ ) : ( "wordLanguage:" + languageNameString ) ) );
			}

		if( wordOrderNr_ > Constants.NO_ORDER_NR )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "wordOrderNr:" + wordOrderNr_ );

		if( wordParameter_ > Constants.NO_WORD_PARAMETER )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "wordParameter:" + wordParameter_ );

		if( grammarParameter > Constants.NO_GRAMMAR_PARAMETER )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "grammarParameter:" + grammarParameter );

		if( readString != null )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "readString:" + Constants.QUERY_STRING_START_CHAR + readString + Constants.QUERY_STRING_END_CHAR );

		CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "readWordType:" + ( readWordTypeString == null ? Constants.EMPTY_STRING : readWordTypeString ) + Constants.QUERY_WORD_TYPE_STRING + wordTypeNr_ );

		if( readWordItem_ != null )
			{
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "readWordItem" + Constants.QUERY_REF_ITEM_START_CHAR + readWordItem_.creationSentenceNr() + Constants.QUERY_SEPARATOR_CHAR + readWordItem_.itemNr() + Constants.QUERY_REF_ITEM_END_CHAR );

			if( ( wordString = readWordItem_.wordTypeString( true, Constants.NO_ORDER_NR, wordTypeNr_ ) ) != null )
				CommonVariables.queryStringBuffer.append( Constants.QUERY_WORD_REFERENCE_START_CHAR + wordString + Constants.QUERY_WORD_REFERENCE_END_CHAR );
			}

		if( definitionGrammarItem != null )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "definitionGrammarItem" + Constants.QUERY_REF_ITEM_START_CHAR + definitionGrammarItem.creationSentenceNr() + Constants.QUERY_SEPARATOR_CHAR + definitionGrammarItem.itemNr() + Constants.QUERY_REF_ITEM_END_CHAR );

		return CommonVariables.queryStringBuffer;
		}


	// Protected methods

	protected boolean isReadWordSymbol()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_SYMBOL );
		}

	protected boolean isReadWordNumeral()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_NUMERAL );
		}

	protected boolean isReadWordAdjective()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_ADJECTIVE );
		}

	protected boolean isReadWordArticle()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_ARTICLE );
		}

	protected boolean isReadWordNoun()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_NOUN_SINGULAR ||
				wordTypeNr_ == Constants.WORD_TYPE_NOUN_PLURAL );
		}

	protected boolean isReadWordSingularNoun()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_NOUN_SINGULAR );
		}

	protected boolean isReadWordPluralNoun()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_NOUN_PLURAL );
		}

	protected boolean isReadWordDeterminerOrPronoun()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_PERSONAL_PRONOUN_SINGULAR_SUBJECTIVE ||
				wordTypeNr_ == Constants.WORD_TYPE_PERSONAL_PRONOUN_SINGULAR_OBJECTIVE ||

				wordTypeNr_ == Constants.WORD_TYPE_POSSESSIVE_DETERMINER_SINGULAR ||
				wordTypeNr_ == Constants.WORD_TYPE_POSSESSIVE_PRONOUN_SINGULAR ||

				wordTypeNr_ == Constants.WORD_TYPE_PERSONAL_PRONOUN_PLURAL_SUBJECTIVE ||
				wordTypeNr_ == Constants.WORD_TYPE_PERSONAL_PRONOUN_PLURAL_OBJECTIVE ||

				wordTypeNr_ == Constants.WORD_TYPE_POSSESSIVE_DETERMINER_PLURAL ||
				wordTypeNr_ == Constants.WORD_TYPE_POSSESSIVE_PRONOUN_PLURAL );
		}

	protected boolean isReadWordPossessiveDeterminer()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_POSSESSIVE_DETERMINER_SINGULAR ||
				wordTypeNr_ == Constants.WORD_TYPE_POSSESSIVE_DETERMINER_PLURAL );
		}

	protected boolean isReadWordVerb()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_VERB_SINGULAR ||
				wordTypeNr_ == Constants.WORD_TYPE_VERB_PLURAL );
		}

	protected boolean isReadWordText()
		{
		return ( wordTypeNr_ == Constants.WORD_TYPE_TEXT );
		}

	protected boolean isAdjectiveAssigned()
		{
		return ( wordParameter_ == Constants.WORD_PARAMETER_ADJECTIVE_ASSIGNED );
		}

	protected boolean isAdjectiveAssignedOrClear()
		{
		return ( wordParameter_ == Constants.WORD_PARAMETER_ADJECTIVE_CLEAR ||
				wordParameter_ == Constants.WORD_PARAMETER_ADJECTIVE_ASSIGNED );
		}

	protected boolean isAdjectiveCalledOrNamed()
		{
		return ( wordParameter_ == Constants.WORD_PARAMETER_ADJECTIVE_CALLED_OR_NAMED );
		}

	protected boolean isAdjectivePrevious()
		{
		return ( wordParameter_ == Constants.WORD_PARAMETER_ADJECTIVE_PREVIOUS_1 ||
				wordParameter_ == Constants.WORD_PARAMETER_ADJECTIVE_PREVIOUS_2 );
		}

	protected boolean isPreposition()
		{
		return ( wordParameter_ == Constants.WORD_PARAMETER_PREPOSITION_ABOUT ||
				wordParameter_ == Constants.WORD_PARAMETER_PREPOSITION_FOR ||
				wordParameter_ == Constants.WORD_PARAMETER_PREPOSITION_FROM ||
				wordParameter_ == Constants.WORD_PARAMETER_PREPOSITION_IN ||
				wordParameter_ == Constants.WORD_PARAMETER_PREPOSITION_OF ||
				wordParameter_ == Constants.WORD_PARAMETER_PREPOSITION_TO );
		}

	protected boolean isVirtualListPreposition()
		{
		return ( wordParameter_ == Constants.WORD_PARAMETER_PREPOSITION_FROM ||
				wordParameter_ == Constants.WORD_PARAMETER_PREPOSITION_OF ||
				wordParameter_ == Constants.WORD_PARAMETER_PREPOSITION_TO );
		}

	protected boolean isPrepositionIn()
		{
		return ( wordParameter_ == Constants.WORD_PARAMETER_PREPOSITION_IN );
		}

	protected boolean isNegative()
		{
		return ( wordParameter_ == Constants.WORD_PARAMETER_ADJECTIVE_NO ||
				wordParameter_ == Constants.WORD_PARAMETER_ADVERB_NOT );
//				wordParameter_ == Constants.WORD_PARAMETER_ADVERB_DO_NOT );
		}

	protected boolean isNounJustificationReport()
		{
		return ( wordParameter_ == Constants.WORD_PARAMETER_NOUN_JUSTIFICATION_REPORT );
		}

	protected boolean isNounValue()
		{
		return ( wordParameter_ == Constants.WORD_PARAMETER_NOUN_VALUE );
		}

	protected boolean isNounFile()
		{
		return ( wordParameter_ == Constants.WORD_PARAMETER_NOUN_FILE );
		}

	protected boolean isSeparator()
		{
		return ( wordParameter_ == Constants.WORD_PARAMETER_SYMBOL_COMMA ||
				wordParameter_ == Constants.WORD_PARAMETER_SYMBOL_COLON ||
				wordParameter_ == Constants.WORD_PARAMETER_SYMBOL_EXCLAMATION_MARK ||
				wordParameter_ == Constants.WORD_PARAMETER_SYMBOL_QUESTION_MARK );
		}

	protected boolean isUserDefined()
		{
		return ( wordParameter_ == Constants.NO_WORD_PARAMETER );
		}

	protected boolean isSelection()
		{
		return ( grammarParameter == Constants.GRAMMAR_SELECTION );
		}

	protected boolean isImperative()
		{
		return ( grammarParameter == Constants.GRAMMAR_IMPERATIVE );
		}

	protected boolean isGeneralizationWord()
		{
		return ( grammarParameter == Constants.GRAMMAR_GENERALIZATION_WORD );
		}

	protected boolean isSpecificationWord()
		{
		return ( grammarParameter == Constants.GRAMMAR_SPECIFICATION_WORD );
		}

	protected boolean isRelationWord()
		{
		return ( wordTypeNr_ != Constants.WORD_TYPE_ARTICLE &&	// To avoid triggering on the article before a propername preceded-by-defined-article
				grammarParameter == Constants.GRAMMAR_RELATION_WORD );
		}

	protected boolean isGeneralizationPart()
		{
		return ( grammarParameter == Constants.GRAMMAR_GENERALIZATION_PART ||
				grammarParameter == Constants.GRAMMAR_GENERALIZATION_ASSIGNMENT );
		}

	protected boolean isGeneralizationSpecification()
		{
		return ( grammarParameter == Constants.GRAMMAR_GENERALIZATION_SPECIFICATION );
		}

	protected boolean isLinkedGeneralizationConjunction()
		{
		return ( grammarParameter == Constants.GRAMMAR_LINKED_GENERALIZATION_CONJUNCTION );
		}

	protected boolean isSentenceConjunction()
		{
		return ( grammarParameter == Constants.GRAMMAR_SENTENCE_CONJUNCTION );
		}

	protected boolean isVerb()
		{
		return ( grammarParameter == Constants.GRAMMAR_VERB );
		}

	protected boolean isQuestionVerb()
		{
		return ( grammarParameter == Constants.GRAMMAR_QUESTION_VERB );
		}

	protected boolean hasFoundRelationWordInThisList( WordItem relationWordItem )
		{
		ReadItem searchItem = this;

		if( relationWordItem != null )
			{
			while( searchItem != null )
				{
				if( searchItem.isRelationWord() &&
				searchItem.readWordItem() == relationWordItem )
					return true;

				searchItem = searchItem.nextReadItem();
				}
			}

		return false;
		}

	protected short wordOrderNr()
		{
		return wordOrderNr_;
		}

	protected short wordParameter()
		{
		return wordParameter_;
		}

	protected short wordTypeNr()
		{
		return wordTypeNr_;
		}

	protected short wordTypeLanguageNr()
		{
		return wordTypeLanguageNr_;
		}

	protected String readWordTypeString()
		{
		if( readWordItem_ != null )
			return readWordItem_.activeWordTypeString( wordTypeNr_ );

		return null;
		}

	protected ReadItem nextReadItem()
		{
		return (ReadItem)nextItem;
		}

	protected ReadItem getFirstRelationWordReadItem()
		{
		ReadItem searchItem = this;

		while( searchItem != null )
			{
			if( searchItem.isRelationWord() )
				return searchItem;

			searchItem = searchItem.nextReadItem();
			}

		return null;
		}

	protected WordItem readWordItem()
		{
		return readWordItem_;
		}

	protected WordTypeItem activeReadWordTypeItem()
		{
		return ( readWordItem_ == null ? null : readWordItem_.activeWordTypeItem( false, wordTypeNr_ ) );
		}
	};

/*************************************************************************
 *
 *	"The godly will see these things and be glad,
 *	while the wicked are struck in silent." (Psalm 107:42)
 *
 *************************************************************************/
