/* License/copyright: At the end of this file or read copyright.txt */

/*---------- Declarations --------------*/
int printsorted(char *result,int nb,int width,int min,float taux,int nbwordterm,int rec,int builddico);
void printing(char *result,int nb,int width,int rec);
