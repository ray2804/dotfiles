(ns runtests
  (:use org.bituf.test-clj-stringtemplate)
  (:use clojure.test))


(run-tests
  'org.bituf.test-clj-stringtemplate)
