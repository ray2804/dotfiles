/*------------------------------------------------------------------------*/
#define COMPACT_VERSION "0.4.3"
#define DATE_VERSION "2010 August 10th"
#define AUTOR "J.P. Redonnet"
#define PROG_NAME "TexLexAn"
/*------------------------------------------------------------------------*/
#define ERRPOS fprintf(stderr,"Error in %s line %d  ",__FILE__,__LINE__);
//ex usage: ERRMSG(("Message=%s\n"),(string))
#define ERRMSG( a, b ) { \
		fprintf(stderr,"Error in %s line %d \n",__FILE__,__LINE__);\
		fprintf( stderr, a, b );\
}
/*------------------------------------------------------------------------*/
/* We can increase these values if mem available > 512MB                  */
#define SIZE_WORD 200 //main limitation in grp of keywords (about 10 chrs/word => 20 words/grp)
#define SIZE_SENTENCE 1000  //for clever_print(),sentencematchclass(),sentencematchcue() 'abstracts generator'
#define SIZE_LONGLINE 2000 //should be always enough
#define NB_SENTENCES 2500 //max nb sentences allowed
#define SIZE_LINE 50000 //size of each line read of dico
/*------------------------------------------------------------------------*/
/* Should not be decreased                                                */
#define TINY_STR 16
#define SHORT_STR 255
#define MEDIUM_STR 1024
#define LONG_STR 4096
/*------------------------------------------------------------------------*/
/*  for languages.word file used to detect the main language of the text  */
#define NB_LANGUAGES 10 //10 languages possible
#define SIZE_WORDSLIST 1000 //about 100 words per language
/*------------------------------------------------------------------------*/

