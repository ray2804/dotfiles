/*
 *	Class:			WordQuery
 *	Supports class:	WordItem
 *	Purpose:		To process queries
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "List.h"
#include "WordItem.h"

class WordQuery
	{
	// Private constructible variables

	CommonVariables *commonVariables_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	public:
	// Constructor

	WordQuery( WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "WordQuery" );

		if( commonVariables_ != NULL )
			{
		if( myWord_ == NULL )
			strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInWord( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected virtual functions

	char *toString( unsigned short queryWordTypeNr )
		{
		char tempString[MAX_READ_WRITE_STRING_LENGTH];
		myWord_->Item::toString( queryWordTypeNr );

		sprintf( tempString, "%c%c%s%c", QUERY_SEPARATOR_CHAR, QUERY_WORD_START_CHAR, myWord_->wordTypeString( true, NO_ORDER_NR, queryWordTypeNr ), QUERY_WORD_END_CHAR );
		strcat( commonVariables_->queryString, tempString );

		if( myWord_->needsAuthorizationForChanges() )
			{
			strcat( commonVariables_->queryString, QUERY_SEPARATOR_STRING );
			strcat( commonVariables_->queryString, "needsAuthorizationForChanges" );
			}

		if( myWord_->wordParameter() > NO_WORD_PARAMETER )
			{
			sprintf( tempString, "%cwordParameter:%u", QUERY_SEPARATOR_CHAR, myWord_->wordParameter() );
			strcat( commonVariables_->queryString, tempString );
			}

		return commonVariables_->queryString;
		}


	// Protected functions

	void countQuery()
		{
		for( unsigned short wordListNr = 0; wordListNr < NUMBER_OF_WORD_LISTS; wordListNr++ )
			{
			if( myWord_->wordList[wordListNr] != NULL )
				myWord_->wordList[wordListNr]->countQueryInList();
			}
		}

	void clearQuerySelections()
		{
		for( unsigned short wordListNr = 0; wordListNr < NUMBER_OF_WORD_LISTS; wordListNr++ )
			{
			if( myWord_->wordList[wordListNr] != NULL )
				myWord_->wordList[wordListNr]->clearQuerySelectionsInList();
			}
		}

	ResultType itemQuery( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, bool isReferenceQuery, unsigned int querySentenceNr, unsigned int queryItemNr )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "itemQuery";
		for( unsigned short wordListNr = 0; wordListNr < NUMBER_OF_WORD_LISTS; wordListNr++ )
			{
			if( myWord_->wordList[wordListNr] != NULL )
				{
				if( myWord_->wordList[wordListNr]->itemQueryInList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, isReferenceQuery, querySentenceNr, queryItemNr ) != RESULT_OK )
					return myWord_->addErrorInWord( myWord_->wordListChar( wordListNr ), functionNameString, moduleNameString_, "I failed to query item numbers" );
				}
			}

		return commonVariables_->result;
		}

	ResultType listQuery( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *queryListString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "listQuery";
		for( unsigned short wordListNr = 0; wordListNr < NUMBER_OF_WORD_LISTS; wordListNr++ )
			{
			if( myWord_->wordList[wordListNr] != NULL )
				{
				if( myWord_->wordList[wordListNr]->listQueryInList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryListString ) != RESULT_OK )
					return myWord_->addErrorInWord( myWord_->wordListChar( wordListNr ), functionNameString, moduleNameString_, "I failed to do a list query list" );
				}
			}

		return commonVariables_->result;
		}

	ResultType wordTypeQuery( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, unsigned short queryWordTypeNr )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "wordTypeQuery";
		for( unsigned short wordListNr = 0; wordListNr < NUMBER_OF_WORD_LISTS; wordListNr++ )
			{
			if( myWord_->wordList[wordListNr] != NULL )
				{
				if( myWord_->wordList[wordListNr]->wordTypeQueryInList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryWordTypeNr ) != RESULT_OK )
					return myWord_->addErrorInWord( myWord_->wordListChar( wordListNr ), functionNameString, moduleNameString_, "I failed to query word types" );
				}
			}

		return commonVariables_->result;
		}

	ResultType parameterQuery( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, unsigned int queryParameter )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "parameterQuery";
		for( unsigned short wordListNr = 0; wordListNr < NUMBER_OF_WORD_LISTS; wordListNr++ )
			{
			if( myWord_->wordList[wordListNr] != NULL )
				{
				if( myWord_->wordList[wordListNr]->parameterQueryInList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryParameter ) != RESULT_OK )
					return myWord_->addErrorInWord( myWord_->wordListChar( wordListNr ), functionNameString, moduleNameString_, "I failed to query parameters" );
				}
			}

		return commonVariables_->result;
		}

	ResultType wordQuery( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *wordNameString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "wordQuery";
		if( myWord_->findMatchingWordReferenceString( wordNameString ) == RESULT_OK )
			{
			if( commonVariables_->hasFoundMatchingStrings )
				{
				if( isFirstInstruction &&
				!myWord_->isSelectedByQuery )
					{
					commonVariables_->hasFoundQuery = true;
					myWord_->isSelectedByQuery = true;
					}
				}
			else
				{
				if( !isFirstInstruction &&
				myWord_->isSelectedByQuery )
					myWord_->isSelectedByQuery = false;
				}

			for( unsigned short wordListNr = 0; wordListNr < NUMBER_OF_WORD_LISTS; wordListNr++ )
				{
				if( myWord_->wordList[wordListNr] != NULL )
					{
					if( myWord_->wordList[wordListNr]->wordQueryInList( ( isFirstInstruction && commonVariables_->hasFoundMatchingStrings ), isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems ) != RESULT_OK )
						return myWord_->addErrorInWord( myWord_->wordListChar( wordListNr ), functionNameString, moduleNameString_, "I failed to query word items" );
					}
				}
			}
		else
			return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find words" );

		return commonVariables_->result;
		}

	ResultType wordReferenceQuery( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *wordReferenceNameString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "wordReferenceQuery";
		for( unsigned short wordListNr = 0; wordListNr < NUMBER_OF_WORD_LISTS; wordListNr++ )
			{
			if( myWord_->wordList[wordListNr] != NULL )
				{
				if( myWord_->wordList[wordListNr]->wordReferenceQueryInList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordReferenceNameString ) != RESULT_OK )
					return myWord_->addErrorInWord( myWord_->wordListChar( wordListNr ), functionNameString, moduleNameString_, "I failed to query word references" );
				}
			}

		return commonVariables_->result;
		}

	ResultType stringQuery( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *queryString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "stringQuery";
		for( unsigned short wordListNr = 0; wordListNr < NUMBER_OF_WORD_LISTS; wordListNr++ )
			{
			if( myWord_->wordList[wordListNr] != NULL )
				{
				if( myWord_->wordList[wordListNr]->stringQueryInList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryString ) != RESULT_OK )
					return myWord_->addErrorInWord( myWord_->wordListChar( wordListNr ), functionNameString, moduleNameString_, "I failed to query strings" );
				}
			}

		return commonVariables_->result;
		}

	ResultType showQueryResult( bool showOnlyWords, bool showOnlyWordReferences, bool showOnlyStrings, bool returnQueryToPosition, unsigned short promptTypeNr, unsigned short queryWordTypeNr, size_t queryWidth )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "showQueryResult";
		for( unsigned short wordListNr = 0; wordListNr < NUMBER_OF_WORD_LISTS; wordListNr++ )
			{
			if( myWord_->wordList[wordListNr] != NULL )
				{
				if( myWord_->wordList[wordListNr]->showQueryResultInList( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth ) != RESULT_OK )
					return myWord_->addErrorInWord( myWord_->wordListChar( wordListNr ), functionNameString, moduleNameString_, "I failed to show the items" );
				}
			}

		return commonVariables_->result;
		}
	};

/*************************************************************************
 *
 *	"Who can be compared with the Lord or God,
 *	who is enthroned on high?" (Psalm 113:5)
 *
 *************************************************************************/
