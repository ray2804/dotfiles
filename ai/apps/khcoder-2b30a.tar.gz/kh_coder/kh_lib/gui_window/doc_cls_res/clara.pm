package gui_window::doc_cls_res::clara;
use base qw(gui_window::doc_cls_res);

sub _new{
	my $self = shift;
	my %args = @_;
	$self->{tani} = $args{tani};
	$self->{command_f} = $args{command_f};
	$self->{plots} = $args{plots};
	$self->{merge_files} = $args{merge_files};

	my $mw = $::main_gui->mw;
	my $wmw= $self->{win_obj};
	$wmw->title($self->gui_jt(kh_msg->get('gui_window::doc_cls_res->win_title'))); # ʸ��Υ��饹����ʬ��

	#--------------------------------#
	#   �ƥ��饹�����˴ޤޤ��ʸ��   #

	my $fr_top = $wmw->Frame()->pack(-fill => 'both', -expand => 'yes');

	my $fr_dcs = $fr_top->LabFrame(
		-label => kh_msg->get('gui_window::doc_cls_res->docs_in_clusters'), # �ƥ��饹�����˴ޤޤ��ʸ��
		-labelside => 'acrosstop',
		-borderwidth => 2,
	)->pack(-fill=>'both', -expand => 1, -padx => 2, -pady => 2, -side => 'left');

	my $lis2 = $fr_dcs->Scrolled(
		'HList',
		-scrollbars       => 'osoe',
		-header           => 1,
		-itemtype         => 'text',
		-font             => 'TKFN',
		-columns          => 2,
		-padx             => 2,
		#-command          => sub{$self->cls_docs},
		-background       => 'white',
		-selectforeground   => $::config_obj->color_ListHL_fore,
		-selectbackground   => $::config_obj->color_ListHL_back,
		-selectborderwidth  => 0,
		-highlightthickness => 0,
		#-selectmode       => 'single',
		-height           => 10,
		-width            => 10,
	)->pack(-fill =>'both',-expand => 'yes');
	$lis2->header('create',0,-text => kh_msg->get('gui_window::doc_cls_res->h_cls_id')); # ���饹�����ֹ�
	$lis2->header('create',1,-text => kh_msg->get('gui_window::doc_cls_res->h_doc_num')); # ʸ���

	$lis2->bind("<Shift-Double-1>",sub{$self->cls_words;});
	$lis2->bind("<ButtonPress-3>",sub{$self->cls_words;});
	
	$lis2->bind("<Double-1>",sub{$self->cls_docs;});
	$lis2->bind("<Key-Return>",sub{$self->cls_docs;});
	$lis2->bind("<KP_Enter>",sub{$self->cls_docs;});

	my $fhl = $fr_dcs->Frame->pack(-fill => 'x');

	my $btn_ds = $fhl->Button(
		-text        => kh_msg->get('gui_window::doc_cls_res->docs'), # ʸ�񸡺�
		-font        => "TKFN",
		-borderwidth => '1',
		-command     => sub {$self->cls_docs;}
	)->pack(-side => 'left', -padx => 2, -pady => 2, -anchor => 'c');

	$wmw->Balloon()->attach(
		$btn_ds,
		-balloonmsg => kh_msg->get('gui_window::doc_cls_res->bal_docs'), # ���饹�����˴ޤޤ��ʸ��򸡺�\n[���饹��������֥륯��å�]
		-font       => "TKFN"
	);

	my $btn_ass = $fhl->Button(
		-text        => kh_msg->get('gui_window::doc_cls_res->words'), # ��ħ��
		-font        => "TKFN",
		-borderwidth => '1',
		-command     => sub {$self->cls_words;}
	)->pack(-side => 'left', -padx => 2, -pady => 2, -anchor => 'c');
	
	$wmw->Balloon()->attach(
		$btn_ass,
		-balloonmsg => kh_msg->get('gui_window::doc_cls_res->bal_words'), # ���饹��������ħ�򤢤�魯��򸡺�\n[Shift + ���饹��������֥륯��å�]
		-font       => "TKFN"
	);
	
	$self->{copy_btn} = $fhl->Button(
		-text        => kh_msg->gget('copy'), # ���ԡ�
		-font        => "TKFN",
		-borderwidth => '1',
		-command     => sub {gui_hlist->copy_all($self->list);}
	)->pack(-side => 'right', -padx => 2, -pady => 2, -anchor => 'c');

	$fhl->Button(
		-text        => kh_msg->gget('plot'), # �ץ��å�
		-font        => "TKFN",
		-borderwidth => '1',
		-command     => sub {
			if ($::main_gui->if_opened('w_doc_cls_plot')){
				$::main_gui->get('w_doc_cls_plot')->close;
			}
		
			gui_window::r_plot::doc_cls->open(
				plots       => [$self->{plots}{_dendro}],
				plot_size   => 480,
			);
		}
	)->pack(-side => 'right', -padx => 2, -pady => 2, -anchor => 'c')
	->configure(-state => 'disabled');

	#--------------------------#
	#   ���饹����ʻ��β���   #
	
	my $fr_cls = $fr_top->LabFrame(
		-label => kh_msg->get('gui_window::doc_cls_res->agglm'), # ���饹����ʻ��β���
		-labelside => 'acrosstop',
		-borderwidth => 2,
	)->pack(-fill=>'both', -expand => 1, -padx => 2, -pady => 2, -side => 'right');
	
	my $lis_f = $fr_cls->Scrolled(
		'HList',
		-scrollbars       => 'osoe',
		-header           => 0,
		-itemtype         => 'text',
		-font             => 'TKFN',
		-columns          => 1,
		-padx             => 2,
		#-command          => sub{$self->cls_docs},
		-background       => 'gray',
		-selectforeground   => $::config_obj->color_ListHL_fore,
		-selectbackground   => $::config_obj->color_ListHL_back,
		-selectborderwidth  => 0,
		-highlightthickness => 0,
		#-selectmode       => 'single',
		-height           => 10,
		-width            => 10,
	)->pack(-fill =>'both',-expand => 'yes');
	
	$lis_f->bind("<Double-1>",sub{$self->merge_docs;});
	
	my $fhr = $fr_cls->Frame->pack(-fill => 'x');

	my $mb = $fhr->Menubutton(
		-text        => kh_msg->get('gui_window::doc_cls_res->docs'), # ʸ�񸡺�
		-tearoff     => 'no',
		-relief      => 'raised',
		-indicator   => 'no',
		-font        => "TKFN",
		#-width       => $self->{width},
		-borderwidth => 1,
		-state => 'disabled',
	)->pack(-side => 'left',-padx => 2, -pady => 2);

	$mb->command(
		-command => sub {$self->merge_docs();},
		-label   => kh_msg->get('gui_window::doc_cls_res->both'), # 1��2
	);

	$mb->command(
		-command => sub {$self->merge_docs('l');},
		-label   => kh_msg->get('gui_window::doc_cls_res->only1'), # 1�Τ�
	);

	$mb->command(
		-command => sub {$self->merge_docs('r');},
		-label   => kh_msg->get('gui_window::doc_cls_res->only2'), # 2�Τ�
	);

	$wmw->Balloon()->attach(
		$mb,
		-balloonmsg => kh_msg->get('gui_window::doc_cls_res->bal_agg_docs'), # [���֥륯��å�]\nʻ�礷�����饹�����˴ޤޤ��ʸ��򸡺�
		-font       => "TKFN"
	);

	$self->{btn_prev} = $fhr->Button(
		-text => kh_msg->get('gui_window::word_conc->prev').'200', # ��200
		-font => "TKFN",
		-borderwidth => '1',
		-state => 'disabled',
		-command => sub {
			$self->{start} = $self->{start} - 200;
			$self->fill_list2;
		}
	)->pack(-side => 'left',-padx => 2, -pady => 2);

	$self->{btn_next} = $fhr->Button(
		-text => kh_msg->get('gui_window::word_conc->next').'200', # ��200
		-font => "TKFN",
		-borderwidth => '1',
		-state => 'disabled',
		-command => sub {
			$self->{start} = $self->{start} + 200;
			$self->fill_list2;
		}
	)->pack(-side => 'left',-padx => 2, -pady => 2);

	$fhr->Button(
		-text        => kh_msg->gget('copy'), # ���ԡ�
		-font        => "TKFN",
		-borderwidth => '1',
		-state => 'disabled',
		-command     => sub {
			#return 0 unless $::config_obj->os eq 'win32';
			my $t = '';
			foreach my $i (@{$self->{merge}}){
				$t .= "$i->[0]\t$i->[1]\t$i->[2]\t$i->[3]\n";
			}
			#require Win32::Clipboard;
			#my $CLIP = Win32::Clipboard();
			#$CLIP->Empty();
			#$CLIP->Set("$t");
			$t = $self->to_clip($t);
			use Clipboard;
			Clipboard->copy( Encode::encode($::config_obj->os_code,$t) );
		}
	)->pack(-side => 'right', -padx => 2, -pady => 2);
	
	$fhr->Button(
		-text => kh_msg->gget('plot'), # �ץ��å�
		-font => "TKFN",
		-borderwidth => '1',
		-state => 'disabled',
		-command => sub {
			if ($::main_gui->if_opened('w_doc_cls_height')){
				$::main_gui->get('w_doc_cls_height')->renew(
					'_cluster_tmp'
				);
			} else {
				gui_window::cls_height::doc->open(
					plots => $self->{plots},
					type  => '_cluster_tmp'
				);
			}
		}
	)->pack(-side => 'right',-padx => 2, -pady => 2);
	
	
	#----------------#
	#   Window����   #
	
	my $fb = $wmw->Frame()->pack(-fill => 'x', -padx => 2, -pady => 2);
	
	#my @opt = (
	#	[kh_msg->get('m_wrd'),   '_cluster_tmp_w'], # Wardˡ','euc
	#	[kh_msg->get('m_ave'), '_cluster_tmp_a'], # ��ʿ��ˡ','euc
	#	[kh_msg->get('m_clk'), '_cluster_tmp_c'], # �Ǳ���ˡ','euc
	#);
	
	#$self->{optmenu} = gui_widget::optmenu->open(
	#	parent  => $fb,
	#	pack    => {-side => 'left', -padx => 2},
	#	options => \@opt,
	#	variable => \$self->{tmp_out_var},
	#	command  => sub {$self->renew;},
	#);
	#$self->{optmenu}->set_value('_cluster_tmp_w');
	
	$fb->Button(
		-text => kh_msg->get('gui_window::doc_cls_res->config'), # Ĵ��
		-font => "TKFN",
		-borderwidth => '1',
		-command => sub {
			gui_window::doc_cls_res_opt->open(
				command_f => $self->{command_f},
				tani      => $self->{tani},
			);
		}
	)->pack(-side => 'left',-padx => 5);

	$fb->Button(
		-text => kh_msg->get('gui_window::doc_cls_res->save'), # ʬ���̤���¸
		-font => "TKFN",
		-borderwidth => '1',
		-command => sub {
			gui_window::doc_cls_res_sav->open(
				var_from => '_cluster_tmp'
			);
		}
	)->pack(-side => 'right');

	$self->{list}  = $lis2;
	$self->{list2} = $lis_f;

	$self->renew;
	return $self;
}

1;