/*
 *	Class:			AdminImperative
 *	Supports class:	AdminItem
 *	Purpose:		To execute imperative words
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "AdminItem.h"
#include "Presentation.cpp"
#include "ReadItem.cpp"
#include "ScoreList.h"
#include "SpecificationItem.cpp"

class AdminImperative
	{
	// Private constructible variables

	bool hasFoundVirtualListAction_;
	bool isRestart_;

	SpecificationItem *foundVirtualListAssignment_;

	CommonVariables *commonVariables_;
	AdminItem *admin_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	ResultType executeImperativeShow( unsigned short specificationWordParameter, unsigned short specificationWordTypeNr, WordItem *generalizationWordItem, WordItem *specificationWordItem, char *executionString )
		{
		FileResultType fileResult;
		char *singularNounString;
		char functionNameString[FUNCTION_NAME_LENGTH] = "executeImperativeShow";

		if( generalizationWordItem != NULL )
			{
			if( executionString != NULL ||
			specificationWordItem != NULL )
				{
				if( executionString != NULL &&
				specificationWordTypeNr == WORD_TYPE_TEXT )
					{
					if( commonVariables_->currentAssignmentLevel == NO_ASSIGNMENT_LEVEL )
						{
						if( admin_->writeTextWithPossibleQueryCommands( PRESENTATION_PROMPT_INFO, executionString ) != RESULT_OK )
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write the execution string" );
						}
					}
				else
					{
					admin_->initializeAdminWriteVariables();

					switch( specificationWordParameter )
						{
						case WORD_PARAMETER_NOUN_JUSTIFICATION_REPORT:
							if( admin_->writeJustificationReport( specificationWordItem ) != RESULT_OK )
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write justification for a word" );

							break;

						default:
							// Try to read the info file with the specification name
							if( ( fileResult = admin_->readInfoFile( false, specificationWordItem->activeWordTypeString( specificationWordTypeNr ) ) ).result == RESULT_OK )
								{
								if( fileResult.createdFileItem == NULL &&
								specificationWordTypeNr == WORD_TYPE_NOUN_PLURAL &&
								( singularNounString = specificationWordItem->activeSingularNounString() ) != NULL )
									{
									if( admin_->readInfoFile( false, singularNounString ).result != RESULT_OK )
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to read the info file with a singular noun word" );
									}

								// Try to show all knowledge about this specification
								if( admin_->writeInfoAboutWord( false, true, true, true, true, true, true, true, NULL, specificationWordItem ) != RESULT_OK )
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write info about a word" );
								}
							else
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to read the info file" );
						}

					if( !commonVariables_->hasShownMessage &&
					admin_->areReadItemsStillValid() )
						{
						if( admin_->createImperativeSentence() )
							{
							if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_NOTIFICATION, INTERFACE_IMPERATIVE_NOTIFICATION_I_DONT_HAVE_A ) == RESULT_OK )
								{
								if( commonVariables_->presentation->writeDiacriticalText( false, false, PRESENTATION_PROMPT_NOTIFICATION, commonVariables_->writeSentenceString ) != RESULT_OK )
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write a sentence" );
								}
							else
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface notification" );
							}
						else
							{
							if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WARNING, INTERFACE_IMPERATIVE_WARNING_I_DONT_HAVE_ANY_INFO_ABOUT_START, specificationWordItem->anyWordTypeString(), INTERFACE_IMPERATIVE_WARNING_I_DONT_HAVE_ANY_INFO_ABOUT_END ) != RESULT_OK )
								return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface warning" );
							}
						}
					}
				}
			else
				{
				if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WARNING, INTERFACE_IMPERATIVE_WARNING_I_DONT_KNOW_HOW_TO_EXECUTE_IMPERATIVE_VERB_START, generalizationWordItem->anyWordTypeString(), INTERFACE_IMPERATIVE_WARNING_I_DONT_KNOW_HOW_TO_EXECUTE_IMPERATIVE_VERB_END ) != RESULT_OK )
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface warning" );
				}
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		return commonVariables_->result;
		}

	ResultType addWordToVirtualList( bool isSelection, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, WordItem *generalizationWordItem, WordItem *specificationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "addWordToVirtualList";

		if( generalizationWordItem != NULL )
			{
			if( generalizationWordItem->addSpecificationInWord( true, false, false, false, false, false, false, isSelection, false, false, NO_PREPOSITION_PARAMETER, NO_QUESTION_PARAMETER, generalizationWordTypeNr, specificationWordTypeNr, WORD_TYPE_UNDEFINED, NO_COLLECTION_NR, NO_COLLECTION_NR, NO_COLLECTION_NR, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_CONTEXT_NR, 0, NULL, specificationWordItem, NULL, NULL, NULL ).result == RESULT_OK )
				{
				if( generalizationWordItem->assignSpecificationInWord( false, false, false, false, false, false, false, NO_PREPOSITION_PARAMETER, NO_QUESTION_PARAMETER, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, 0, NULL, specificationWordItem, NULL, NULL ).result != RESULT_OK )
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to assign a virtual list word" );
				}
			else
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to assign a virtual list word" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		return commonVariables_->result;
		}

	ResultType executeVirtualListImperative( unsigned short imperativeParameter, unsigned short prepositionParameter, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem )
		{
		bool hasFoundHeadOrTail = false;
		char functionNameString[FUNCTION_NAME_LENGTH] = "executeVirtualListImperative";
		if( generalizationWordItem != NULL )
			{
			if( specificationWordItem != NULL )
				{
				if( relationWordItem != NULL )
					{
					switch( imperativeParameter )
						{
						case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_ADD:
							if( !specificationWordItem->isNounHead() &&
							!specificationWordItem->isNounTail() )
								{
								if( addWordToVirtualList( false, relationWordTypeNr, specificationWordTypeNr, relationWordItem, specificationWordItem ) != RESULT_OK )
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a word to a virtual list" );
								}
							else
								{
								if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WARNING, INTERFACE_IMPERATIVE_WARNING_I_DONT_KNOW_HOW_TO_EXECUTE_IMPERATIVE_VERB_START, generalizationWordItem->anyWordTypeString(), INTERFACE_IMPERATIVE_WARNING_I_DONT_KNOW_HOW_TO_EXECUTE_IMPERATIVE_VERB_END ) != RESULT_OK )
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface warning about the add, move or remove imperative" );
								}

							break;

						case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_MOVE:
							switch( prepositionParameter )
								{
								case WORD_PARAMETER_PREPOSITION_OF:		// Head or tail
									if( specificationWordItem->isNounHead() )
										{
										hasFoundHeadOrTail = true;

										if( ( foundVirtualListAssignment_ = relationWordItem->lastActiveAssignmentButNotAQuestion() ) == NULL )
											hasFoundVirtualListAction_ = true;
										else
											{
											if( relationWordItem->deactivateActiveAssignment( foundVirtualListAssignment_ ) != RESULT_OK )
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to dectivate the head of a virtual list" );
											}
										}
									else
										{
										if( specificationWordItem->isNounTail() )
											{
											hasFoundHeadOrTail = true;

											if( ( foundVirtualListAssignment_ = relationWordItem->firstActiveAssignmentButNotAQuestion() ) == NULL )
												hasFoundVirtualListAction_ = true;
											else
												{
												if( relationWordItem->deactivateActiveAssignment( foundVirtualListAssignment_ ) != RESULT_OK )
													return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to dectivate the tail of a virtual list" );
												}
											}
										}

								// Don't insert a break statement here

								case WORD_PARAMETER_PREPOSITION_FROM:
									if( !hasFoundHeadOrTail )
										{
										if( ( foundVirtualListAssignment_ = relationWordItem->firstAssignment( true, false, false, false, false, (unsigned short)NO_QUESTION_PARAMETER, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_CONTEXT_NR, specificationWordItem, NULL ) ) == NULL )
											hasFoundVirtualListAction_ = true;
										else
											{
											if( relationWordItem->deactivateActiveAssignment( foundVirtualListAssignment_ ) != RESULT_OK )
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to dectivate the word in a virtual list" );
											}
										}

									break;

								case WORD_PARAMETER_PREPOSITION_TO:
									if( foundVirtualListAssignment_ == NULL )
										{
										if( !hasFoundVirtualListAction_ )
											{
											if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WARNING, INTERFACE_IMPERATIVE_WARNING_NEEDS_A_LIST_TO_BE_SPECIFIED ) != RESULT_OK )
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface warning about the add, move or remove imperative" );
											}
										}
									else
										{
										if( addWordToVirtualList( false, foundVirtualListAssignment_->generalizationWordTypeNr(), foundVirtualListAssignment_->specificationWordTypeNr(), relationWordItem, foundVirtualListAssignment_->specificationWordItem() ) != RESULT_OK )
											return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a word to a virtual list" );
										}

									break;

								default:
									if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WARNING, INTERFACE_IMPERATIVE_WARNING_PREPOSITION_NOT_USED_FOR_THIS_ACTION ) != RESULT_OK )
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface warning about the preposition parameter" );
								}

							break;

						case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_REMOVE:
							foundVirtualListAssignment_ = NULL;

							if( specificationWordItem->isNounHead() )
								foundVirtualListAssignment_ = relationWordItem->lastActiveAssignmentButNotAQuestion();
							else
								{
								if( specificationWordItem->isNounTail() )
									foundVirtualListAssignment_ = relationWordItem->firstActiveAssignmentButNotAQuestion();
								else
									foundVirtualListAssignment_ = relationWordItem->firstAssignment( true, false, false, false, false, (unsigned short)NO_QUESTION_PARAMETER, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_CONTEXT_NR, specificationWordItem, NULL );
								}

							if( foundVirtualListAssignment_ != NULL )
								{
								if( relationWordItem->deactivateActiveAssignment( foundVirtualListAssignment_ ) != RESULT_OK )
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to dectivate the head of a virtual list" );
								}

							break;

						default:
							return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given imperative parameter isn't a virtual list action" );
						}
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given relation word item is undefined" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		return commonVariables_->result;
		}

	ResultType executeVirtualListImperative( unsigned short imperativeParameter, unsigned short specificationWordTypeNr, WordItem *generalizationWordItem, WordItem *specificationWordItem, ReadItem *startRelationWordReadItem, ReadItem *endRelationWordReadItem )
		{
		unsigned short prepositionParameter = NO_PREPOSITION_PARAMETER;
		ReadItem *currentReadItem = startRelationWordReadItem;
		WordItem *relationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "executeVirtualListImperative";

		if( generalizationWordItem != NULL )
			{
			if( specificationWordItem != NULL )
				{
				if( startRelationWordReadItem != NULL )
					{
					do	{
						if( currentReadItem->isPreposition() )
							prepositionParameter = currentReadItem->wordParameter();
						else
							{
							if( currentReadItem->isRelationWord() &&
							( relationWordItem = currentReadItem->readWordItem() ) != NULL )
								{
								if( executeVirtualListImperative( imperativeParameter, prepositionParameter, specificationWordTypeNr, currentReadItem->wordTypeNr(), generalizationWordItem, specificationWordItem, relationWordItem ) != RESULT_OK )
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to execute a virtual list imperative" );
								}
							}
						}
					while( currentReadItem != endRelationWordReadItem &&
					( currentReadItem = currentReadItem->nextReadItem() ) != NULL );
					}
				else
					{
					if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WARNING, INTERFACE_IMPERATIVE_WARNING_NEEDS_A_LIST_TO_BE_SPECIFIED ) != RESULT_OK )
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface warning about the add, move or remove imperative" );
					}
				}
			else
				{
				if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WARNING, INTERFACE_IMPERATIVE_WARNING_I_DONT_KNOW_HOW_TO_EXECUTE_IMPERATIVE_VERB_START, generalizationWordItem->anyWordTypeString(), INTERFACE_IMPERATIVE_WARNING_I_DONT_KNOW_HOW_TO_EXECUTE_IMPERATIVE_VERB_END ) != RESULT_OK )
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface warning about the add, move or remove imperative" );
				}
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		return commonVariables_->result;
		}

	ResultType executeVirtualListSelectionImperative( unsigned short imperativeParameter, unsigned short specificationWordTypeNr, WordItem *generalizationWordItem, WordItem *specificationWordItem, SelectionItem *executionSelectionItem )
		{
		WordItem *relationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "executeVirtualListSelectionImperative";

		if( generalizationWordItem != NULL )
			{
			if( specificationWordItem != NULL )
				{
				if( executionSelectionItem != NULL )
					{
					if( ( relationWordItem = executionSelectionItem->relationWordItem() ) != NULL )
						{
						if( executeVirtualListImperative( imperativeParameter, executionSelectionItem->prepositionParameter(), specificationWordTypeNr, executionSelectionItem->relationWordTypeNr(), generalizationWordItem, specificationWordItem, relationWordItem ) != RESULT_OK )
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to execute a virtual list imperative" );
						}
					else
						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given execution selection item has no relation word item" );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given execution selection item is undefined" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		return commonVariables_->result;
		}


	public:
	// Constructor

	AdminImperative( AdminItem *admin, WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		hasFoundVirtualListAction_ = false;
		isRestart_ = false;

		foundVirtualListAssignment_ = NULL;

		admin_ = admin;
		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "AdminImperative" );

		if( commonVariables_ != NULL )
			{
		if( admin_ != NULL )
			{
			if( myWord_ == NULL )
				strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given admin is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	bool hasRequestedRestart()
		{
		return isRestart_;
		}

	ResultType executeImperative( bool initializeVariables, unsigned short executionListNr, unsigned short imperativeParameter, unsigned short specificationWordParameter, unsigned short specificationWordTypeNr, unsigned long endSolveProgress, char *executionString, WordItem *generalizationWordItem, WordItem *specificationWordItem, ReadItem *startRelationWordReadItem, ReadItem *endRelationWordReadItem, SelectionItem *executionSelectionItem, SelectionItem *actionSelectionItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "executeImperative";
		if( initializeVariables )
			{
			hasFoundVirtualListAction_ = false;
			foundVirtualListAssignment_ = NULL;
			}

		switch( imperativeParameter )
			{
			case NO_IMPERATIVE_PARAMETER:	// Selection
				if( admin_->assignSelectionSpecification( executionSelectionItem ) != RESULT_OK )
					return myWord_->addErrorInItem( admin_->adminListChar( executionListNr ), functionNameString, moduleNameString_, "I failed to assign an imperative selection specification at assignment level ", commonVariables_->currentAssignmentLevel );

				break;

			case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_ADD:
			case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_MOVE:
			case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_REMOVE:
				if( executionSelectionItem == NULL )
					{
					if( executeVirtualListImperative( imperativeParameter, specificationWordTypeNr, generalizationWordItem, specificationWordItem, startRelationWordReadItem, endRelationWordReadItem ) != RESULT_OK )
						return myWord_->addErrorInItem( admin_->adminListChar( executionListNr ), functionNameString, moduleNameString_, "I failed to execute a virtual list imperative" );
					}
				else
					{
					if( executeVirtualListSelectionImperative( imperativeParameter, specificationWordTypeNr, generalizationWordItem, specificationWordItem, executionSelectionItem ) != RESULT_OK )
						return myWord_->addErrorInItem( admin_->adminListChar( executionListNr ), functionNameString, moduleNameString_, "I failed to execute a selection virtual list imperative" );
					}

				break;

			case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_CLEAR:
				if( generalizationWordItem != NULL )
					{
					if( startRelationWordReadItem == NULL )
						{
						switch( specificationWordParameter )
							{
							case WORD_PARAMETER_NOUN_MIND:
								if( admin_->deleteSentences( false, admin_->myFirstSentenceNr() ) == RESULT_OK )
									{
									if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_NOTIFICATION, INTERFACE_IMPERATIVE_NOTIFICATION_MY_MIND_IS_CLEAR ) != RESULT_OK )
										return myWord_->addErrorInItem( admin_->adminListChar( executionListNr ), functionNameString, moduleNameString_, "I failed to write an interface notification about clearing my mind" );
									}
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete the previous sentences" );

								break;

							default:
								if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WARNING, INTERFACE_IMPERATIVE_WARNING_I_DONT_KNOW_HOW_TO_EXECUTE_IMPERATIVE_VERB_START, generalizationWordItem->anyWordTypeString(), INTERFACE_IMPERATIVE_WARNING_I_DONT_KNOW_HOW_TO_EXECUTE_IMPERATIVE_VERB_END ) != RESULT_OK )
									return myWord_->addErrorInItem( admin_->adminListChar( executionListNr ), functionNameString, moduleNameString_, "I failed to write an interface warning about clearing" );
							}
						}
					else
						{
						if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WARNING, INTERFACE_IMPERATIVE_WARNING_I_DONT_KNOW_TO_DO_WITH_RELATION ) != RESULT_OK )
							return myWord_->addErrorInItem( admin_->adminListChar( executionListNr ), functionNameString, moduleNameString_, "I failed to write an interface warning about clearing" );
						}
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

				break;

			case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_HELP:
				if( generalizationWordItem != NULL )
					{
					if( startRelationWordReadItem == NULL )
						{
						if( admin_->readInfoFile( true, generalizationWordItem->anyWordTypeString() ).result != RESULT_OK )
							return myWord_->addErrorInItem( admin_->adminListChar( executionListNr ), functionNameString, moduleNameString_, "I failed to read the info help file" );
						}
					else
						{
						if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WARNING, INTERFACE_IMPERATIVE_WARNING_I_DONT_KNOW_TO_DO_WITH_RELATION ) != RESULT_OK )
							return myWord_->addErrorInItem( admin_->adminListChar( executionListNr ), functionNameString, moduleNameString_, "I failed to write an interface warning about clearing" );
						}
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

				break;

			case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_LOGIN:
				if( startRelationWordReadItem == NULL )
					{
					if( admin_->login( specificationWordItem ) != RESULT_OK )
						return myWord_->addErrorInItem( admin_->adminListChar( executionListNr ), functionNameString, moduleNameString_, "I failed to login" );
					}
				else
					{
					if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WARNING, INTERFACE_IMPERATIVE_WARNING_I_DONT_KNOW_TO_DO_WITH_RELATION ) != RESULT_OK )
						return myWord_->addErrorInItem( admin_->adminListChar( executionListNr ), functionNameString, moduleNameString_, "I failed to write an interface warning about clearing" );
					}

				break;

			case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_READ:
				if( startRelationWordReadItem == NULL )
					{
					switch( specificationWordParameter )
						{
						case WORD_PARAMETER_NOUN_FILE:
							if( admin_->readExamplesFile( executionString ) != RESULT_OK )
								return myWord_->addErrorInItem( admin_->adminListChar( executionListNr ), functionNameString, moduleNameString_, "I failed to read an example file" );

							break;

						default:
							if( commonVariables_->currentAssignmentLevel == NO_ASSIGNMENT_LEVEL )
								return myWord_->startErrorInItem( admin_->adminListChar( executionListNr ), functionNameString, moduleNameString_, "I don't know how to perform imperative 'read'. Unknown specification parameter: ", specificationWordParameter );
							else
								return myWord_->startErrorInItem( admin_->adminListChar( executionListNr ), functionNameString, moduleNameString_, "I don't know how to perform imperative 'read'. Unknown specification parameter: ", specificationWordParameter, " at assignment level ", commonVariables_->currentAssignmentLevel );
						}
					}
				else
					{
					if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WARNING, INTERFACE_IMPERATIVE_WARNING_I_DONT_KNOW_TO_DO_WITH_RELATION ) != RESULT_OK )
						return myWord_->addErrorInItem( admin_->adminListChar( executionListNr ), functionNameString, moduleNameString_, "I failed to write an interface warning about clearing" );
					}

				break;

			case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_UNDO:
				if( admin_->undoLastSentence() == RESULT_OK )
					admin_->dontDeletedRollbackInfo();
				else
					return myWord_->addErrorInItem( admin_->adminListChar( executionListNr ), functionNameString, moduleNameString_, "I failed to undo the last sentence" );

				break;

			case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_REDO:
				if( admin_->redoLastUndoneSentence() == RESULT_OK )
					admin_->dontDeletedRollbackInfo();
				else
					return myWord_->addErrorInItem( admin_->adminListChar( executionListNr ), functionNameString, moduleNameString_, "I failed to redo the last undone sentence" );

				break;

			case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_RESTART:
				isRestart_ = true;
				break;

			case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_SHOW:
				if( executeImperativeShow( specificationWordParameter, specificationWordTypeNr, generalizationWordItem, specificationWordItem, executionString ) != RESULT_OK )
					return myWord_->addErrorInItem( admin_->adminListChar( executionListNr ), functionNameString, moduleNameString_, "I failed to execute the show imperative" );

				break;

			case WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_SOLVE:
				if( executionSelectionItem != NULL ||

				( executionListNr == NO_LIST_NR &&
				specificationWordItem != NULL &&
				specificationWordItem->wordParameter() != WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_SOLVE ) )
					{
					admin_->deleteScoreList();
					admin_->clearCurrentSolveProgress();

					if( admin_->solveWord( endSolveProgress, specificationWordItem, actionSelectionItem ) != RESULT_OK )
						return myWord_->addErrorInItem( admin_->adminListChar( executionListNr ), functionNameString, moduleNameString_, "I failed to solve a word at assignment level ", commonVariables_->currentAssignmentLevel );
					}
				else
					{
					if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WARNING, INTERFACE_IMPERATIVE_WARNING_I_DONT_KNOW_HOW_TO_EXECUTE_IMPERATIVE_VERB_START, generalizationWordItem->anyWordTypeString(), INTERFACE_IMPERATIVE_WARNING_I_DONT_KNOW_HOW_TO_EXECUTE_IMPERATIVE_VERB_END ) != RESULT_OK )
						return myWord_->addErrorInItem( admin_->adminListChar( executionListNr ), functionNameString, moduleNameString_, "I failed to write an interface warning about solving" );
					}

				break;

			default:
				if( commonVariables_->currentAssignmentLevel == NO_ASSIGNMENT_LEVEL )
				return myWord_->startErrorInItem( admin_->adminListChar( executionListNr ), functionNameString, moduleNameString_, "I don't know how to execute the imperative with word parameter ", imperativeParameter );
			else
				return myWord_->startErrorInItem( admin_->adminListChar( executionListNr ), functionNameString, moduleNameString_, "I don't know how to execute the imperative with word parameter ", imperativeParameter, " at assignment level ", commonVariables_->currentAssignmentLevel );
			}

		return commonVariables_->result;
		}
	};

/*************************************************************************
 *
 *	"He has given me a new song to sing,
 *	a hymn of praise to our God.
 *	Many will see what he has done and be amazed.
 *	They will put their trust in the Lord." (Psalm 40:3)
 *
 *************************************************************************/
