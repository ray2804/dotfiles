/*
 *	Class:			AdminSpecification
 *	Supports class:	AdminItem
 *	Purpose:		To create and assign specification structures
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "AdminItem.h"
#include "ContextItem.cpp"
#include "Presentation.cpp"
#include "ReadItem.cpp"
#include "SelectionItem.cpp"
#include "SpecificationItem.cpp"

class AdminSpecification
	{
	// Private constructible variables

	unsigned short doneSpecificationWordOrderNr_;
	unsigned short linkedGeneralizationWordTypeNr_;

	unsigned int specificationRelationContextNr_;
	unsigned int userRelationContextNr_;

	WordItem *linkedGeneralizationWordItem_;
	WordItem *userSentenceGeneralizationWordItem_;

	char *previousSpecificationString_;

	CommonVariables *commonVariables_;
	AdminItem *admin_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	ResultType addUserSpecificationWithRelation( bool isAction, bool isAssignedOrClear, bool isAssignment, bool isConditional, bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isNewStart, bool isPossessive, bool isSelection, bool isSpecificationGeneralization, bool isValueSpecification, unsigned short selectionLevel, unsigned short selectionListNr, unsigned short imperativeParameter, unsigned short specificationWordParameter, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int nContextRelations, ReadItem *startRelationReadItem, ReadItem *endRelationWordReadItem, WordItem *generalizationWordItem, WordItem *specificationWordItem, char *specificationString )
		{
		bool isFirstComparisonPart = ( selectionListNr == ADMIN_CONDITION_LIST );
		unsigned short relationWordTypeNr;
		unsigned short prepositionParameter = NO_PREPOSITION_PARAMETER;
		unsigned int nRelationWords = 0;
		ReadItem *currentRelationReadItem = startRelationReadItem;
		SpecificationItem *foundSpecificationItem;
		WordItem *mostRecentContextWord;
		WordItem *relationWordItem;
		WordItem *previousRelationWordItem = NULL;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addUserSpecificationWithRelation";

		if( startRelationReadItem != NULL )
			{
			if( endRelationWordReadItem != NULL )
				{
				if( generalizationWordItem != NULL )
					{
					if( specificationWordItem != NULL )
						{
						if( relationContextNr > NO_CONTEXT_NR )
							{
							do	{
								if( currentRelationReadItem->isRelationWord() &&
								currentRelationReadItem->readWordItem() != NULL )
									nRelationWords++;	// Count number of relation words in this sentence
								}
							while( currentRelationReadItem != endRelationWordReadItem &&
							( currentRelationReadItem = currentRelationReadItem->nextReadItem() ) != NULL );
							}

						currentRelationReadItem = startRelationReadItem;

						do	{
							if( currentRelationReadItem->isPreposition() )
								prepositionParameter = currentRelationReadItem->wordParameter();
							else
								{
								if( currentRelationReadItem->isRelationWord() )
									{
									if( ( relationWordItem = currentRelationReadItem->readWordItem() ) != NULL )
										{
										if( relationWordItem != generalizationWordItem )
											{
											if( relationWordItem != specificationWordItem )
												{
												relationWordTypeNr = currentRelationReadItem->wordTypeNr();

												if( nRelationWords == 1 &&
//												previousRelationWordItem == NULL &&
												( foundSpecificationItem = generalizationWordItem->firstAssignmentOrSpecification( false, false, isAssignment, isDeactive, isArchived, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, NO_CONTEXT_NR, specificationWordItem, NULL ) ) != NULL )
													{
													if( foundSpecificationItem->hasRelationContext() &&
													( mostRecentContextWord = mostRecentContextWordInAllWords( isPossessive, relationWordTypeNr, foundSpecificationItem->relationContextNr(), specificationWordItem ) ) != NULL )
														{
														if( mostRecentContextWord != relationWordItem )
															previousRelationWordItem = mostRecentContextWord;
														}
													}

												if( previousRelationWordItem != NULL )
													{
													if( admin_->collectRelationWords( isExclusive, relationWordTypeNr, specificationWordTypeNr, previousRelationWordItem, relationWordItem, specificationWordItem ) != RESULT_OK )
														return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to collect previous relation word \"", previousRelationWordItem->anyWordTypeString(), "\" to relation word \"", relationWordItem->anyWordTypeString(), "\"" );
													}

												if( selectionListNr == NO_LIST_NR )
													{
													if( addSpecification( isAssignment, isConditional, isDeactive, isArchived, isExclusive, isNegative, isPossessive, isSelection, false, isSpecificationGeneralization, isValueSpecification, prepositionParameter, questionParameter, generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, NO_COLLECTION_NR, specificationCollectionNr, NO_COLLECTION_NR, generalizationContextNr, specificationContextNr, relationContextNr, nContextRelations, NULL, generalizationWordItem, specificationWordItem, relationWordItem, specificationString ).result != RESULT_OK )
														return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a specification having relation word \"", relationWordItem->anyWordTypeString(), "\"" );
													}
												else
													{
													if( ( relationContextNr = relationWordItem->contextNrInWord( isPossessive, relationWordTypeNr, specificationWordItem ) ) == NO_CONTEXT_NR )
														{
														if( ( relationContextNr = admin_->highestContextNr() ) < MAX_CONTEXT_NR )
															{
															if( relationWordItem->addContext( isPossessive, relationWordTypeNr, specificationWordTypeNr, ++relationContextNr, specificationWordItem ) != RESULT_OK )
																return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a relation context to word \"", relationWordItem->anyWordTypeString(), "\"" );
															}
														else
															return myWord_->startSystemErrorInItem( functionNameString, moduleNameString_, "Context number overflow" );
														}

													if( admin_->createSelectionPart( isAction, isAssignedOrClear, isDeactive, isArchived, ( isFirstComparisonPart && !relationWordItem->isNumeralWordType() ), isNewStart, isNegative, isPossessive, isValueSpecification, selectionLevel, selectionListNr, imperativeParameter, prepositionParameter, specificationWordParameter, generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, generalizationContextNr, specificationContextNr, relationContextNr, nContextRelations, generalizationWordItem, specificationWordItem, relationWordItem, specificationString ) == RESULT_OK )
														isFirstComparisonPart = false;
													else
														return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create a selection part having relation word \"", relationWordItem->anyWordTypeString(), "\"" );
													}

												previousRelationWordItem = relationWordItem;
												}
											else
												return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The relation word is the same as the specification word" );
											}
										else
											return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The relation word is the same as the generalization word" );
										}
									else
										return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found an undefined read word" );
									}
								}
							}
						while( currentRelationReadItem != endRelationWordReadItem &&
						( currentRelationReadItem = currentRelationReadItem->nextReadItem() ) != NULL );
						}
					else
						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word item is undefined" );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given end relation read item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given start relation read item is undefined" );

		return commonVariables_->result;
		}

	SpecificationResultType addSpecification( bool isAssignment, bool isConditional, bool isDeactiveAssignment, bool isArchivedAssignment, bool isExclusive, bool isNegative, bool isPossessive, bool isSelection, bool isSpecificationGeneralization, bool isValueSpecification, unsigned short prepositionParameter, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "assignSpecification";

		if( generalizationWordItem != NULL )
			{
			if( admin_->isSystemStartingUp() &&

			( generalizationWordItem->needsAuthorizationForChanges() ||

			( specificationWordItem != NULL &&
			specificationWordItem->needsAuthorizationForChanges() ) ) )
				{
				if( ( specificationResult = admin_->addSpecificationWithAuthorization( isAssignment, isConditional, isDeactiveAssignment, isArchivedAssignment, isExclusive, isNegative, isPossessive, isSelection, isSpecificationGeneralization, isValueSpecification, prepositionParameter, questionParameter, generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, generalizationCollectionNr, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, specificationRelationContextNr_, nContextRelations, specificationJustificationItem, generalizationWordItem, specificationWordItem, relationWordItem, specificationString ) ).result != RESULT_OK )
					myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add specification in generalization word \"", generalizationWordItem->anyWordTypeString(), "\" with authorization" );
				}
			else
				{
				if( !generalizationWordItem->isVerbImperativeLogin() )	// Already created by during startup
					{
					if( ( specificationResult = generalizationWordItem->addSpecificationInWord( isAssignment, isConditional, isDeactiveAssignment, isArchivedAssignment, isExclusive, isNegative, isPossessive, isSelection, isSpecificationGeneralization, isValueSpecification, prepositionParameter, questionParameter, generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, generalizationCollectionNr, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, specificationRelationContextNr_, nContextRelations, specificationJustificationItem, specificationWordItem, relationWordItem, specificationString, NULL ) ).result != RESULT_OK )
						myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add specification in generalization word \"", generalizationWordItem->anyWordTypeString(), "\"" );
					}
				}
			}
		else
			myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		specificationResult.result = commonVariables_->result;
		return specificationResult;
		}

	ContextItem *contextItemInAllWords( bool isPossessive, unsigned short contextWordTypeNr, WordItem *specificationWordItem )
		{
		ContextItem *foundContextItem;
		WordItem *currentWordItem;

		if( ( currentWordItem = commonVariables_->firstWordItem ) != NULL )		// Do in all words
			{
			do	{
				if( ( foundContextItem = currentWordItem->contextItemInWord( isPossessive, contextWordTypeNr, specificationWordItem ) ) != NULL )
					return foundContextItem;
				}
			while( ( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}

		return NULL;
		}

	WordItem *mostRecentContextWordInAllWords( bool isPossessive, unsigned short contextWordTypeNr, unsigned int contextNr, WordItem *specificationWordItem )
		{
		ContextItem *currentContextItem;
		ContextItem *mostRecentContextItem = NULL;
		WordItem *currentWordItem;
		WordItem *mostRecentWordItem = NULL;

		if( contextNr > NO_CONTEXT_NR &&
		( currentWordItem = commonVariables_->firstWordItem ) != NULL )		// Do in all words
			{
			do	{
				if( ( currentContextItem = currentWordItem->contextItemInWord( isPossessive, contextWordTypeNr, contextNr, specificationWordItem ) ) != NULL )
					{
					if( mostRecentContextItem == NULL ||
					currentContextItem->isMoreRecent( mostRecentContextItem ) )
						{
						mostRecentWordItem = currentWordItem;
						mostRecentContextItem = currentContextItem;
						}
					}
				}
			while( ( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}

		return mostRecentWordItem;
		}


	public:
	// Constructor

	AdminSpecification( AdminItem *admin, WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		doneSpecificationWordOrderNr_ = NO_ORDER_NR;
		linkedGeneralizationWordTypeNr_ = WORD_TYPE_UNDEFINED;

		specificationRelationContextNr_ = NO_CONTEXT_NR;
		userRelationContextNr_ = NO_CONTEXT_NR;

		linkedGeneralizationWordItem_ = NULL;
		userSentenceGeneralizationWordItem_ = NULL;
		previousSpecificationString_ = NULL;

		admin_ = admin;
		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "AdminSpecification" );

		if( commonVariables_ != NULL )
			{
		if( admin_ != NULL )
			{
			if( myWord_ == NULL )
				strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given admin is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected assignment functions

	ResultType assignSelectionSpecification( SelectionItem *assignmentSelectionItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "assignSelectionSpecification";
		if( assignmentSelectionItem != NULL )
			{
			if( assignSpecification( false, assignmentSelectionItem->isAssignedOrClear(), assignmentSelectionItem->isDeactive(), assignmentSelectionItem->isArchived(), assignmentSelectionItem->isNegative(), assignmentSelectionItem->isPossessive(), false, assignmentSelectionItem->prepositionParameter(), NO_QUESTION_PARAMETER, assignmentSelectionItem->generalizationContextNr(), assignmentSelectionItem->specificationContextNr(), assignmentSelectionItem->relationContextNr(), NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, assignmentSelectionItem->nContextRelations(), NULL, assignmentSelectionItem->generalizationWordItem(), assignmentSelectionItem->specificationWordItem(), assignmentSelectionItem->specificationString() ).result != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to assign a specification" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given assignment selection item is undefined" );

		return commonVariables_->result;
		}

	SpecificationResultType assignSpecification( bool isAmbiguousRelationContext, bool isAssignedOrClear, bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, bool isSelfGenerated, unsigned short prepositionParameter, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int originalSentenceNr, unsigned int activeSentenceNr, unsigned int deactiveSentenceNr, unsigned int archiveSentenceNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "assignSpecification";

		if( generalizationWordItem != NULL )
			{
			if( admin_->isSystemStartingUp() &&

			( generalizationWordItem->needsAuthorizationForChanges() ||

			( specificationWordItem != NULL &&
			specificationWordItem->needsAuthorizationForChanges() ) ) )
				{
				if( ( specificationResult = admin_->assignSpecificationWithAuthorization( isAmbiguousRelationContext, isAssignedOrClear, isDeactive, isArchived, isNegative, isPossessive, isSelfGenerated, prepositionParameter, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, originalSentenceNr, activeSentenceNr, deactiveSentenceNr, archiveSentenceNr, nContextRelations, specificationJustificationItem, generalizationWordItem, specificationWordItem, specificationString ) ).result != RESULT_OK )
					myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to assign generalization word \"", generalizationWordItem->anyWordTypeString(), "\" to specification word \"", specificationWordItem->anyWordTypeString(), "\" with authorization" );
				}
			else
				{
				if( ( specificationResult = generalizationWordItem->assignSpecificationInWord( isAmbiguousRelationContext, isAssignedOrClear, isDeactive, isArchived, isNegative, isPossessive, isSelfGenerated, prepositionParameter, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, originalSentenceNr, activeSentenceNr, deactiveSentenceNr, archiveSentenceNr, nContextRelations, specificationJustificationItem, specificationWordItem, specificationString, NULL ) ).result != RESULT_OK )
					myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to assign generalization word \"", generalizationWordItem->anyWordTypeString(), "\"" );
				}
			}
		else
			myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		specificationResult.result = commonVariables_->result;
		return specificationResult;
		}


	// Protected specification functions

	void initializeLinkedWord()
		{
		linkedGeneralizationWordTypeNr_ = WORD_TYPE_UNDEFINED;
		linkedGeneralizationWordItem_ = NULL;
		}

	void initializeAdminSpecificationVariables()
		{
		doneSpecificationWordOrderNr_ = NO_ORDER_NR;
//		linkedGeneralizationWordTypeNr_ = WORD_TYPE_UNDEFINED;	// Don't initialize

		specificationRelationContextNr_ = NO_CONTEXT_NR;
		userRelationContextNr_ = NO_CONTEXT_NR;

//		linkedGeneralizationWordItem_ = NULL;					// Don't initialize
		userSentenceGeneralizationWordItem_ = NULL;
		}

	CollectionResultType addUserSpecifications( bool initializeVariables, bool isAction, bool isAssignment, bool isConditional, bool isDeactive, bool isArchived, bool isExclusive, bool isNewStart, bool isPossessive, bool isSpecificationGeneralization, unsigned short prepositionParameter, unsigned short questionParameter, unsigned short selectionLevel, unsigned short selectionListNr, unsigned short imperativeParameter, unsigned short specificationWordParameter, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationPronounContextNr, ReadItem *generalizationReadItem, ReadItem *startSpecificationReadItem, ReadItem *endSpecificationReadItem, ReadItem *startRelationReadItem, ReadItem *endRelationWordReadItem )
		{
		CollectionResultType collectionResult;
		ContextResultType contextResult;
		SpecificationResultType specificationResult;
		bool hasFoundAction = false;
		bool isExclusiveContext = false;
		bool isNegative = false;
		bool isQuestion = ( questionParameter > NO_QUESTION_PARAMETER );
		bool isSelection = ( selectionListNr != NO_LIST_NR );
		bool isSpecificationWordAlreadyAssignedByComparison = false;
		bool isValueSpecificationWord = false;
		bool skipQuestionVerb = false;
		bool skipThisGeneralizationPart = false;
		bool waitForRelation = false;
		bool waitForText = false;
		unsigned short lastSpecificationWordOrderNr;
		unsigned short generalizationWordTypeNr = WORD_TYPE_UNDEFINED;
		unsigned short valueGeneralizationWordTypeNr = WORD_TYPE_UNDEFINED;
		unsigned short linkedSpecificationWordTypeNr = WORD_TYPE_UNDEFINED;
		unsigned short currentSpecificationWordTypeNr = WORD_TYPE_UNDEFINED;
		unsigned short previousSpecificationWordTypeNr = WORD_TYPE_UNDEFINED;
		unsigned int nContextRelations = 0;
		ReadItem *currentReadItem;
		ReadItem *readAheadGeneralizationReadItem;
		WordItem *currentGeneralizationWordItem;
		WordItem *tempSpecificationWordItem;
		WordItem *readWordItem;
		WordItem *currentSpecificationWordItem = NULL;
		WordItem *compoundGeneralizationWordItem = NULL;
		WordItem *valueGeneralizationWordItem = NULL;
		WordItem *linkedSpecificationWordItem = NULL;
		WordItem *previousSpecificationWordItem = NULL;
		char *currentSpecificationString = NULL;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addUserSpecifications";

		previousSpecificationString_ = NULL;

		if( initializeVariables )
			{
			doneSpecificationWordOrderNr_ = NO_ORDER_NR;
			userRelationContextNr_ = NO_CONTEXT_NR;
			}

		if( generalizationReadItem != NULL )
			{
			if( ( currentGeneralizationWordItem = generalizationReadItem->readWordItem() ) != NULL )
				{
				generalizationWordTypeNr = generalizationReadItem->wordTypeNr();
				userSentenceGeneralizationWordItem_ = currentGeneralizationWordItem;
				currentGeneralizationWordItem->clearHasConfirmedAssumption();
				currentGeneralizationWordItem->clearLastShownConflictSpecification();

				if( ( currentReadItem = startSpecificationReadItem ) != NULL )
					{
					if( endSpecificationReadItem != NULL )
						{
						readAheadGeneralizationReadItem = generalizationReadItem->nextReadItem();

						while( readAheadGeneralizationReadItem != NULL &&
						readAheadGeneralizationReadItem->grammarParameter != GRAMMAR_GENERALIZATION_WORD )
							readAheadGeneralizationReadItem = readAheadGeneralizationReadItem->nextReadItem();

						lastSpecificationWordOrderNr = ( readAheadGeneralizationReadItem != NULL ? readAheadGeneralizationReadItem->wordOrderNr() : endSpecificationReadItem->wordOrderNr() );

						do	{
							if( currentReadItem->isQuestionVerb() )
								skipQuestionVerb = true;
							else
								{
								if( skipThisGeneralizationPart )
									{
									if( waitForRelation )
										{
										if( currentReadItem->isRelationWord() ||
										currentReadItem->isReadWordText() )
											{
											skipThisGeneralizationPart = false;
											waitForRelation = false;
											waitForText = false;
											}
										}
									else
										{
										if( generalizationReadItem->wordOrderNr() < currentReadItem->wordOrderNr() )
											skipThisGeneralizationPart = false;
										}
									}
								else
									{
									if( doneSpecificationWordOrderNr_ > currentReadItem->wordOrderNr() )
										skipThisGeneralizationPart = true;
									else
										{
										if( skipQuestionVerb &&
										!currentReadItem->isGeneralizationPart() )
											skipQuestionVerb = false;
										else
											{
											if( currentReadItem->isGeneralizationWord() )
												{
												skipThisGeneralizationPart = true;
												waitForRelation = true;
												}
											else
												{
												if( currentReadItem->isSpecificationWord() &&
												currentGeneralizationWordItem->isAdjectiveComparison() &&
												( tempSpecificationWordItem = currentReadItem->readWordItem() ) != NULL )
													{
													if( !tempSpecificationWordItem->isNounHead() &&
													!tempSpecificationWordItem->isNounTail() )		// Skip head and tail in the comparison
														{
														waitForText = true;
														isSpecificationWordAlreadyAssignedByComparison = true;
														currentSpecificationWordItem = tempSpecificationWordItem;
														}
													}
												}
											}
										}
									}
								}

							readWordItem = currentReadItem->readWordItem();

							if( !waitForText &&
							!skipQuestionVerb &&
							!skipThisGeneralizationPart &&

							( readWordItem == NULL ||
							!readWordItem->isNumeralBoth() ) )	// Skip numeral 'both'. Typically for English: in both ... and ...
								{
								currentSpecificationWordTypeNr = currentReadItem->wordTypeNr();
								currentSpecificationString = NULL;

								if( isSpecificationWordAlreadyAssignedByComparison )
									isSpecificationWordAlreadyAssignedByComparison = false;
								else
									currentSpecificationWordItem = readWordItem;

								if( currentReadItem->isReadWordText() ||

								( currentSpecificationWordItem != NULL &&
								currentSpecificationWordItem->needsAuthorizationForChanges() ) )	// Password
									currentSpecificationString = currentReadItem->readString;

								if( currentReadItem->isNegative() )
									isNegative = true;
								else
									{
									if( isPossessive &&
									currentReadItem->isReadWordNumeral() )
										sscanf( currentReadItem->readWordTypeString(), "%u", &nContextRelations );
									else
										{
										if( initializeVariables &&
										startRelationReadItem != NULL &&
										currentReadItem->isSpecificationWord() )
											{
											if( ( contextResult = admin_->getRelationContextNr( isExclusive, isNegative, isPossessive, true, questionParameter, nContextRelations, generalizationContextNr, specificationContextNr, currentGeneralizationWordItem, currentSpecificationWordItem, NULL, startRelationReadItem ) ).result == RESULT_OK )
												{
												hasFoundAction = true;
												isExclusiveContext = contextResult.isExclusiveContext;
												userRelationContextNr_ = contextResult.contextNr;
												}
											else
												myWord_->addErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I failed to get the relation context number" );
											}

										if( commonVariables_->result == RESULT_OK )
											{
											if( currentReadItem->isReadWordText() ||
											currentReadItem->isReadWordNumeral() ||

											( currentReadItem->isSpecificationWord() &&
											!currentReadItem->isPreposition() ) ||

											( currentReadItem->isRelationWord() &&
											admin_->isPossessivePronounStructure() ) )
												{
												if( isValueSpecificationWord )
													{
													if( isSelection )
														{
														if( admin_->createSelectionPart( isAction, false, isDeactive, isArchived, false, isNewStart, isNegative, isPossessive, true, selectionLevel, selectionListNr, imperativeParameter, prepositionParameter, specificationWordParameter, valueGeneralizationWordTypeNr, currentSpecificationWordTypeNr, WORD_TYPE_UNDEFINED, generalizationContextNr, specificationContextNr, relationPronounContextNr, nContextRelations, valueGeneralizationWordItem, currentSpecificationWordItem, NULL, currentSpecificationString ) != RESULT_OK )
															myWord_->addErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I failed to create a value selection item" );
														}

													if( commonVariables_->result == RESULT_OK )
														{
														if( startRelationReadItem == NULL )
															{
															// Value without relation
															if( addSpecification( isAssignment, isConditional, isDeactive, isArchived, isExclusive, ( isConditional ? false : isNegative ), isPossessive, isSelection, false, isSpecificationGeneralization, true, prepositionParameter, questionParameter, valueGeneralizationWordTypeNr, currentSpecificationWordTypeNr, linkedGeneralizationWordTypeNr_, NO_COLLECTION_NR, specificationCollectionNr, NO_COLLECTION_NR, generalizationContextNr, specificationContextNr, NO_CONTEXT_NR, nContextRelations, NULL, valueGeneralizationWordItem, currentSpecificationWordItem, linkedGeneralizationWordItem_, currentSpecificationString ).result != RESULT_OK )
																myWord_->addErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I failed to add a specification in generalization word \"", currentGeneralizationWordItem->anyWordTypeString(), "\"" );
															}
														else
															{
															// Value with relation
															if( addUserSpecificationWithRelation( false, false, isAssignment, isConditional, isDeactive, isArchived, ( isExclusive || isExclusiveContext ), ( isConditional ? false : isNegative ), false, isPossessive, isSelection, isSpecificationGeneralization, true, NO_SELECTION_LEVEL, NO_LIST_NR, imperativeParameter, specificationWordParameter, questionParameter, valueGeneralizationWordTypeNr, currentSpecificationWordTypeNr, specificationCollectionNr, generalizationContextNr, specificationContextNr, userRelationContextNr_, nContextRelations, startRelationReadItem, endRelationWordReadItem, valueGeneralizationWordItem, currentSpecificationWordItem, currentSpecificationString ) == RESULT_OK )
																hasFoundAction = true;
															else
																myWord_->addErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I failed to add a specification in generalization word \"", currentGeneralizationWordItem->anyWordTypeString(), "\" with a relation" );
															}

														if( commonVariables_->result == RESULT_OK )
															{
															isValueSpecificationWord = false;
															valueGeneralizationWordTypeNr = WORD_TYPE_UNDEFINED;
															valueGeneralizationWordItem = NULL;
															}
														}
													}
												else
													{
													if( currentReadItem->isNounValue() )
														{
														isValueSpecificationWord = true;
														valueGeneralizationWordTypeNr = generalizationWordTypeNr;
														valueGeneralizationWordItem = currentGeneralizationWordItem;
														}
													else
														{
														if( selectionListNr == NO_LIST_NR )
															{
															if( previousSpecificationString_ == NULL )
																{
																if( previousSpecificationWordItem != NULL &&

																( previousSpecificationWordTypeNr == currentSpecificationWordTypeNr ||

																( previousSpecificationWordTypeNr == WORD_TYPE_NOUN_SINGULAR &&
																currentReadItem->isReadWordPluralNoun() ) ||

																( previousSpecificationWordTypeNr == WORD_TYPE_NOUN_PLURAL &&
																currentReadItem->isReadWordSingularNoun() ) ) )
																	{
																	if( ( collectionResult = admin_->collectSpecificationWords( ( isExclusive || isSpecificationGeneralization ), isAssignment, isQuestion, isSpecificationGeneralization, generalizationWordTypeNr, currentSpecificationWordTypeNr, compoundGeneralizationWordItem, currentGeneralizationWordItem, previousSpecificationWordItem, currentSpecificationWordItem ) ).result != RESULT_OK )
																		myWord_->addErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I failed to collect specification words" );
																	}
																}
															else
																{
																if( ( collectionResult = admin_->collectSpecificationStrings( ( isExclusive || isSpecificationGeneralization ), isAssignment, isQuestion, generalizationWordTypeNr, currentSpecificationWordTypeNr, currentGeneralizationWordItem, previousSpecificationString_, currentSpecificationString ) ).result != RESULT_OK )
																	myWord_->addErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I failed to collect specification strings" );
																}

															if( currentSpecificationWordTypeNr != WORD_TYPE_PREPOSITION )
																{
																previousSpecificationWordItem = currentSpecificationWordItem;
																previousSpecificationWordTypeNr = currentSpecificationWordTypeNr;
																previousSpecificationString_ = currentSpecificationString;
																}
															}
														else	// Create selection
															{
															if( startRelationReadItem == NULL )
																{
																if( admin_->createSelectionPart( isAction, currentReadItem->isAdjectiveAssignedOrClear(), isDeactive, isArchived, false, isNewStart, isNegative, isPossessive, false, selectionLevel, selectionListNr, imperativeParameter, prepositionParameter, specificationWordParameter, generalizationWordTypeNr, currentSpecificationWordTypeNr, WORD_TYPE_UNDEFINED, generalizationContextNr, specificationContextNr, userRelationContextNr_, nContextRelations, currentGeneralizationWordItem, currentSpecificationWordItem, NULL, currentSpecificationString ) != RESULT_OK )
																	myWord_->addErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I failed to create a selection part" );
																}
															else
																{
																if( addUserSpecificationWithRelation( isAction, currentReadItem->isAdjectiveAssignedOrClear(), isAssignment, isConditional, isDeactive, isArchived, ( isExclusive || isExclusiveContext ), isNegative, isNewStart, isPossessive, isSelection, isSpecificationGeneralization, false, selectionLevel, selectionListNr, imperativeParameter, specificationWordParameter, questionParameter, generalizationWordTypeNr, currentSpecificationWordTypeNr, specificationCollectionNr, generalizationContextNr, specificationContextNr, userRelationContextNr_, nContextRelations, startRelationReadItem, endRelationWordReadItem, currentGeneralizationWordItem, currentSpecificationWordItem, currentSpecificationString ) != RESULT_OK )
																	myWord_->addErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I failed to create a selection part with relation" );
																}
															}
														}

													if( commonVariables_->result == RESULT_OK &&
													!collectionResult.needToRedoSpecificationCollection &&
													!currentReadItem->isAdjectiveAssignedOrClear() )
														{
														linkedSpecificationWordTypeNr = currentSpecificationWordTypeNr;
														doneSpecificationWordOrderNr_ = currentReadItem->wordOrderNr();
														linkedSpecificationWordItem = currentSpecificationWordItem;

														if( !currentReadItem->isNounValue() &&
														currentReadItem->wordOrderNr() <= lastSpecificationWordOrderNr &&
														currentSpecificationWordTypeNr != WORD_TYPE_ADVERB )
															{
															if( startRelationReadItem == NULL )
																{
																// No value, no relation
																if( addSpecification( isAssignment, isConditional, isDeactive, isArchived, isExclusive, ( isConditional ? false : isNegative ), isPossessive, isSelection, false, isSpecificationGeneralization, false, prepositionParameter, questionParameter, generalizationWordTypeNr, currentSpecificationWordTypeNr, linkedGeneralizationWordTypeNr_, NO_COLLECTION_NR, specificationCollectionNr, NO_COLLECTION_NR, generalizationContextNr, specificationContextNr, userRelationContextNr_, nContextRelations, NULL, currentGeneralizationWordItem, currentSpecificationWordItem, linkedGeneralizationWordItem_, currentSpecificationString ).result == RESULT_OK )
																	hasFoundAction = true;
																else
																	myWord_->addErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I failed to add a specification in generalization word \"", currentGeneralizationWordItem->anyWordTypeString(), "\"" );
																}
															else
																{
																if( addUserSpecificationWithRelation( false, false, isAssignment, isConditional, isDeactive, isArchived, ( isExclusive || isExclusiveContext ), ( isConditional ? false : isNegative ), false, isPossessive, isSelection, isSpecificationGeneralization, false, NO_SELECTION_LEVEL, NO_LIST_NR, imperativeParameter, specificationWordParameter, questionParameter, generalizationWordTypeNr, currentSpecificationWordTypeNr, specificationCollectionNr, generalizationContextNr, specificationContextNr, userRelationContextNr_, nContextRelations, startRelationReadItem, endRelationWordReadItem, currentGeneralizationWordItem, currentSpecificationWordItem, currentSpecificationString ) == RESULT_OK )
																	hasFoundAction = true;
																else
																	myWord_->addErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I failed to add a user specification with a relation in generalization word \"", currentGeneralizationWordItem->anyWordTypeString(), "\"" );
																}

															if( commonVariables_->result == RESULT_OK &&
															!isQuestion &&
															!isSpecificationGeneralization &&
															myWord_->isNounWordType( currentSpecificationWordTypeNr ) )
																{
																// Generalizations with noun specifications - without relations
																if( admin_->findSpecificationSubstitutionConclusionOrQuestion( false, isDeactive, isArchived, isExclusive, isNegative, isPossessive, true, questionParameter, generalizationWordTypeNr, currentSpecificationWordTypeNr, generalizationContextNr, specificationContextNr, currentGeneralizationWordItem, currentSpecificationWordItem ) == RESULT_OK )
																	{
																	if( !commonVariables_->hasShownWarning &&
																	myWord_->isNounWordType( generalizationWordTypeNr ) )	// Definition specification
																		{
																		// Definition specifications
																		if( ( specificationResult = admin_->findCompoundSpecificationSubstitutionConclusion( isNegative, isPossessive, generalizationWordTypeNr, generalizationContextNr, specificationContextNr, userRelationContextNr_, currentGeneralizationWordItem ) ).result == RESULT_OK )
																			compoundGeneralizationWordItem = specificationResult.compoundGeneralizationWordItem;
																		else
																			myWord_->addErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I failed to find a definition specification substitution conclusion about generalization word \"", currentGeneralizationWordItem->anyWordTypeString(), "\"" );
																		}
																	}
																else
																	myWord_->addErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I failed to find a specification substitution conclusion or question for generalization word \"", currentGeneralizationWordItem->anyWordTypeString(), "\"" );
																}
															}
														}
													}
												}
											else
												{
												if( isPossessive &&
												currentReadItem->isReadWordArticle() )
													nContextRelations = 0;
												}

											if( commonVariables_->result == RESULT_OK &&
											!commonVariables_->hasShownWarning &&
											!collectionResult.needToRedoSpecificationCollection &&
											!isSpecificationGeneralization )
												{
												if( currentReadItem->isReadWordVerb() )
													hasFoundAction = true;

												if( currentReadItem->isRelationWord() ||

												( admin_->isPossessivePronounStructure() &&
												currentReadItem->isSpecificationWord() ) )
													{
													if( linkedSpecificationWordItem != NULL )
														{
														if( !isQuestion &&
														myWord_->isNounWordType( linkedSpecificationWordTypeNr ) )
															{
															if( admin_->findExclusiveSpecificationSubstitutionAssumption( isDeactive, isArchived, isExclusive, isNegative, isPossessive, generalizationWordTypeNr, linkedSpecificationWordTypeNr, currentSpecificationWordTypeNr, generalizationContextNr, specificationContextNr, currentGeneralizationWordItem, linkedSpecificationWordItem, currentSpecificationWordItem ) != RESULT_OK )
																myWord_->addErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I failed to find an exclusive specification substitution assumption with specification word \"", linkedSpecificationWordItem->anyWordTypeString(), "\"" );
															}

														if( commonVariables_->result == RESULT_OK &&
														!commonVariables_->hasShownWarning )
															{
															if( currentSpecificationWordItem == linkedSpecificationWordItem )	// Linked specification
																{
																if( linkedGeneralizationWordItem_ == NULL )
																	{
																	linkedGeneralizationWordTypeNr_ = generalizationWordTypeNr;
																	linkedGeneralizationWordItem_ = currentGeneralizationWordItem;
																	}
																else
																	myWord_->startErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "Linked word \"", linkedGeneralizationWordItem_->anyWordTypeString(), "\" is already assigned" );
																}
															else
																{
																if( !isQuestion )
																	{
																	if( admin_->findPossessiveReversibleConclusion( isDeactive, isArchived, isExclusive, isNegative, isPossessive, generalizationWordTypeNr, linkedSpecificationWordTypeNr, currentSpecificationWordTypeNr, specificationContextNr, relationPronounContextNr, userRelationContextNr_, currentGeneralizationWordItem, linkedSpecificationWordItem, currentSpecificationWordItem ) != RESULT_OK )
																		myWord_->addErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I failed to find a possessive reversible conclusion with generalization word \"", currentGeneralizationWordItem->anyWordTypeString(), "\" and specification word \"", linkedSpecificationWordItem->anyWordTypeString(), "\"" );
																	}
																}
															}
														}
													else
														myWord_->startErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "The specification word item is undefined while linking" );
													}
												else
													{
													if( selectionListNr == NO_LIST_NR &&
													currentReadItem->isAdjectiveAssigned() &&
													readWordItem != NULL )	// Skip text
														{
														if( commonVariables_->presentation->writeInterfaceText( PRESENTATION_PROMPT_WARNING, INTERFACE_SENTENCE_WARNING_ASSIGNED_IS_SELECTION_CONDITION_START, currentReadItem->readWordTypeString(), INTERFACE_SENTENCE_WARNING_AT_POSITION_START, currentReadItem->wordOrderNr(), INTERFACE_SENTENCE_WARNING_IS_ONLY_USED_IN_CONDITION_OF_SELECTION ) != RESULT_OK )
															myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface warning" );
														}
													}
												}
											}
										}
									}
								}
							}
						while( commonVariables_->result == RESULT_OK &&
						!commonVariables_->hasShownWarning &&
						!collectionResult.needToRedoSpecificationCollection &&
						currentReadItem != endSpecificationReadItem &&
						( currentReadItem = currentReadItem->nextReadItem() ) != NULL );

						if( commonVariables_->result == RESULT_OK )
							{
							if( hasFoundAction )
								{
								if( currentGeneralizationWordItem->needToRecalculateAssumptionsAfterwards() )
									{
									if( currentGeneralizationWordItem->recalculateAssumptionsOfInvolvedWords() != RESULT_OK )
										myWord_->addErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I failed to recalculate the assumptions of generalization word \"", currentGeneralizationWordItem->anyWordTypeString(), "\" and the involved words" );
									}
								}
							else
								myWord_->startErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "I couldn't find anything to do" );
							}
						}
					else
						myWord_->startErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "The given end specification read item is undefined" );
					}
				else
					myWord_->startErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "The given start specification read item is undefined" );
				}
			else
				myWord_->startErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "The given generalization read item has no read word" );
			}
		else
			myWord_->startErrorInItem( admin_->adminListChar( selectionListNr ), functionNameString, moduleNameString_, "The given generalization read item is undefined" );

		collectionResult.result = commonVariables_->result;
		return collectionResult;
		}

	SpecificationResultType addSpecification( bool isAssignment, bool isConditional, bool isDeactiveAssignment, bool isArchivedAssignment, bool isExclusive, bool isNegative, bool isPossessive, bool isSelection, bool isSelfGenerated, bool isSpecificationGeneralization, bool isValueSpecification, unsigned short prepositionParameter, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString )
		{
		SpecificationResultType specificationResult;
		bool hasRelationContextCollection;
		bool isAmbiguousRelationContext = false;
		ContextItem *foundContextItem;
		SpecificationItem *archiveAssignmentItem;
		SpecificationItem *foundSpecificationItem;
		SpecificationItem *correctedSuggestiveQuestionAssumptionSpecificationItem;
		SpecificationItem *createdAssignmentItem = NULL;
		SpecificationItem *createdSpecificationItem = NULL;
		WordItem *foundContextWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addSpecification";

		specificationRelationContextNr_ = relationContextNr;

		if( generalizationWordItem != NULL )
			{
			if( generalizationWordItem != myWord_ )
				{
				if( specificationWordItem != myWord_ )
					{
					if( generalizationWordItem != specificationWordItem )
						{
						if( relationWordItem != NULL &&
						!relationWordItem->isNumeralWordType() )
							{
							if( specificationRelationContextNr_ == NO_CONTEXT_NR )
								{
								hasRelationContextCollection = ( myWord_->collectionNrInAllWords( userRelationContextNr_ ) > NO_COLLECTION_NR );

								if( ( specificationRelationContextNr_ = relationWordItem->contextNrInWord( isPossessive, relationWordTypeNr, specificationWordItem ) ) == NO_CONTEXT_NR )
									{
									if( ( foundContextItem = contextItemInAllWords( isPossessive, relationWordTypeNr, specificationWordItem ) ) != NULL )
										{
										if( ( foundContextWordItem = foundContextItem->myWord() ) != NULL )
											{
											if( ( specificationResult = generalizationWordItem->findSpecification( true, true, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, specificationWordItem, foundContextWordItem ) ).result == RESULT_OK )
												{
												if( specificationResult.foundSpecificationItem == NULL )
													{
													if( ( foundSpecificationItem = generalizationWordItem->firstAssignmentOrSpecification( true, true, true, true, true, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, NO_CONTEXT_NR, specificationWordItem, specificationString ) ) != NULL )
														specificationRelationContextNr_ = foundSpecificationItem->relationContextNr();
													}
												else
													specificationRelationContextNr_ = foundContextItem->contextNr();
												}
											else
												myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a specific specification in generalization word \"", generalizationWordItem->anyWordTypeString(), "\"" );
											}
										else
											myWord_->startErrorInItem( functionNameString, moduleNameString_, "The word of the found context item is undefined" );
										}

									if( commonVariables_->result == RESULT_OK &&

									( specificationRelationContextNr_ == NO_CONTEXT_NR ||

									( !hasRelationContextCollection &&
									!relationWordItem->hasContextInWord( isPossessive, specificationRelationContextNr_, specificationWordItem ) ) ) )
										{
										if( ( specificationRelationContextNr_ = admin_->highestContextNr() ) < MAX_CONTEXT_NR )
											specificationRelationContextNr_++;
										else
											myWord_->startSystemErrorInItem( functionNameString, moduleNameString_, "Context number overflow" );
										}
									}
								else
									{
									if( isAssignment &&
									!hasRelationContextCollection &&
									// Check if already exists
									generalizationWordItem->firstActiveAssignment( false, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, specificationRelationContextNr_, specificationWordItem, NULL ) == NULL )
										{
										if( ( specificationRelationContextNr_ = admin_->highestContextNr() ) < MAX_CONTEXT_NR )
											{
											// Dynamic semantic ambiguity
											if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_NOTIFICATION, INTERFACE_SENTENCE_NOTIFICATION_I_NOTICED_SEMANTIC_AMBIGUITY_START, relationWordItem->anyWordTypeString(), INTERFACE_SENTENCE_NOTIFICATION_DYNAMIC_SEMANTIC_AMBIGUITY_END ) == RESULT_OK )
												{
												isAmbiguousRelationContext = true;
												specificationRelationContextNr_++;
												}
											else
												myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface notification" );
											}
										else
											myWord_->startSystemErrorInItem( functionNameString, moduleNameString_, "Context number overflow" );
										}
									}
								}

							if( commonVariables_->result == RESULT_OK &&
							!isSelection )
								{
								if( relationWordItem->addContext( isPossessive, relationWordTypeNr, specificationWordTypeNr, specificationRelationContextNr_, specificationWordItem ) != RESULT_OK )
									myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a relation context to word \"", relationWordItem->anyWordTypeString(), "\"" );
								}
							}

						if( commonVariables_->result == RESULT_OK )
							{
							if( ( specificationResult = addSpecification( isAssignment, isConditional, isDeactiveAssignment, isArchivedAssignment, isExclusive, isNegative, isPossessive, isSelection, isSpecificationGeneralization, isValueSpecification, prepositionParameter, questionParameter, generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, generalizationCollectionNr, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, nContextRelations, specificationJustificationItem, generalizationWordItem, specificationWordItem, relationWordItem, specificationString ) ).result == RESULT_OK )
								{
								if( !commonVariables_->hasShownWarning )
									{
									archiveAssignmentItem = specificationResult.archiveAssignmentItem;

									if( specificationJustificationItem == NULL &&	// User specification
									( createdSpecificationItem = specificationResult.createdSpecificationItem ) != NULL )
										{
										if( admin_->isGeneralizationReasoningWordType( false, generalizationWordTypeNr ) )
											{
											if( admin_->collectGeneralizationWordWithPreviousOne( isExclusive, ( isAssignment && questionParameter == NO_QUESTION_PARAMETER ), isPossessive, generalizationWordTypeNr, specificationWordTypeNr, questionParameter, specificationRelationContextNr_, generalizationWordItem, specificationWordItem ) != RESULT_OK )
												myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to collect a generalization word with a previous one" );
											}
										else
											{
											if( !isAssignment &&
											!isExclusive &&
											!isNegative &&
											!isPossessive &&
											!isSpecificationGeneralization &&
											!generalizationWordItem->hasCollection( specificationWordItem ) &&
											generalizationContextNr == NO_CONTEXT_NR &&
											specificationContextNr == NO_CONTEXT_NR &&
											nContextRelations == 0 &&
											relationWordItem == NULL &&
											myWord_->isNounWordType( specificationWordTypeNr ) &&
											admin_->isGeneralizationReasoningWordType( true, generalizationWordTypeNr ) )
												{
												if( admin_->addSpecificationGeneralizationConclusion( generalizationWordTypeNr, specificationWordTypeNr, createdSpecificationItem, generalizationWordItem, specificationWordItem ) != RESULT_OK )
													myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a possible specification generalization definition" );
												}
											}
										}

									if( commonVariables_->result == RESULT_OK &&
									!commonVariables_->hasShownWarning &&
									!isSpecificationGeneralization &&

									( ( isAssignment &&
									!isSelection ) ||	// Selections must be stored - rather than executed. So, don't assign them.

									archiveAssignmentItem != NULL ) )
										{
										if( ( specificationResult = assignSpecification( isAmbiguousRelationContext, ( specificationWordItem != NULL && specificationWordItem->isAdjectiveAssignedOrClear() ), isDeactiveAssignment, isArchivedAssignment, isNegative, isPossessive, isSelfGenerated, prepositionParameter, questionParameter, generalizationContextNr, specificationContextNr, specificationRelationContextNr_, nContextRelations, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, specificationJustificationItem, generalizationWordItem, specificationWordItem, specificationString ) ).result == RESULT_OK )
											{
											if( ( createdAssignmentItem = specificationResult.createdSpecificationItem ) != NULL )
												{
												if( archiveAssignmentItem != NULL )
													{
													if( generalizationWordItem->archiveOrDeletedSpecification( archiveAssignmentItem, createdAssignmentItem ) != RESULT_OK )
														myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to archive or delete an assignment in generalization word \"", generalizationWordItem->anyWordTypeString(), "\"" );
													}

												if( commonVariables_->result == RESULT_OK &&
												relationWordItem != NULL )
													{
													if( ( correctedSuggestiveQuestionAssumptionSpecificationItem = generalizationWordItem->correctedSuggestiveQuestionAssumptionSpecificationItem() ) != NULL )
														{
														createdAssignmentItem = createdAssignmentItem->updatedSpecificationItem();

														if( admin_->findSpecificationSubstitutionConclusionOrQuestion( createdAssignmentItem->isSelfGeneratedAssumption(), createdAssignmentItem->isDeactiveAssignment(), createdAssignmentItem->isArchivedAssignment(), true, createdAssignmentItem->isNegative(), createdAssignmentItem->isPossessive(), true, createdAssignmentItem->questionParameter(), createdAssignmentItem->generalizationWordTypeNr(), createdAssignmentItem->specificationWordTypeNr(), createdAssignmentItem->generalizationContextNr(), createdAssignmentItem->specificationContextNr(), generalizationWordItem, correctedSuggestiveQuestionAssumptionSpecificationItem->specificationWordItem() ) == RESULT_OK )
															{
															if( admin_->findSpecificationSubstitutionConclusionOrQuestion( createdAssignmentItem->isSelfGeneratedAssumption(), createdAssignmentItem->isDeactiveAssignment(), createdAssignmentItem->isArchivedAssignment(), true, createdAssignmentItem->isNegative(), createdAssignmentItem->isPossessive(), true, createdAssignmentItem->questionParameter(), createdAssignmentItem->generalizationWordTypeNr(), createdAssignmentItem->specificationWordTypeNr(), createdAssignmentItem->generalizationContextNr(), createdAssignmentItem->specificationContextNr(), generalizationWordItem, specificationWordItem ) != RESULT_OK )
																myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a specification substitution conclusion or question for generalization word \"", generalizationWordItem->anyWordTypeString(), "\"" );
															}
														else
															myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a specification substitution conclusion or question for generalization word \"", generalizationWordItem->anyWordTypeString(), "\"" );
														}

													if( commonVariables_->result == RESULT_OK &&
													generalizationWordItem->addSuggestiveQuestionAssumption() )
														{
														if( admin_->addSuggestiveQuestionAssumption( isDeactiveAssignment, isArchivedAssignment, isExclusive, isNegative, isPossessive, generalizationWordTypeNr, specificationWordTypeNr, generalizationContextNr, specificationContextNr, specificationRelationContextNr_, createdAssignmentItem, generalizationWordItem, specificationWordItem, relationWordItem ) != RESULT_OK )
															myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create a suggestive question assumption about generalization word \"", generalizationWordItem->anyWordTypeString(), "\"" );
														}
													}
												}
											}
										else
											myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to assign the specification" );
										}
									}
								}
							else
								myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add specification in generalization word \"", generalizationWordItem->anyWordTypeString(), "\"" );
							}
						}
					else
						myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word and the given specification word are the same" );
					}
				else
					myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word is the administrator" );
				}
			else
				myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word is the administrator" );
			}
		else
			myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		specificationResult.result = commonVariables_->result;
		return specificationResult;
		}

	WordItem *userSentenceGeneralizationWordItem()
		{
		return userSentenceGeneralizationWordItem_;
		}
	};

/*************************************************************************
 *
 *	"How amazing are the deeds of the Lord!
 *	All who delight in him should ponder them." (Psalm 111:2)
 *
 *************************************************************************/
