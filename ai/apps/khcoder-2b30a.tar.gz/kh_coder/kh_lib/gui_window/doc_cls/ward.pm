package gui_window::doc_cls::ward;
use base qw(gui_window::doc_cls);

1;