package com.collinfagan.string.template.demo;

import org.antlr.stringtemplate.StringTemplate;

/**
 * Demonstration class for using StringTemplate with an in-line template.
 * @author Collin 
 */
public class SingleLineDemo {

	public static void main(String[] args) {

		StringTemplate query = new StringTemplate(
				"UPDATE customers SET customerName='$customer$'," +
				" customerAddress='$address$' WHERE id=$id$");

		query.setAttribute("customer", "Frank");
		query.setAttribute("address", "1313 Mocking Bird Lane");
		query.setAttribute("id", "4453");

		System.out.println(query);
	}
}
