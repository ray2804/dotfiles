/*
 *	Class:			AdminContext
 *	Supports class:	AdminItem
 *	Purpose:		To create context structures
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "AdminItem.h"
#include "ContextItem.cpp"
#include "GeneralizationItem.cpp"
#include "Presentation.cpp"
#include "ReadItem.cpp"
#include "SpecificationItem.cpp"

class AdminContext
	{
	// Private constructible variables

	CommonVariables *commonVariables_;
	AdminItem *admin_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	ContextResultType findPossessiveReversibleConclusionContextNrOfInvolvedWords( bool isExclusive, bool isNegative, bool isPossessive, unsigned int nContextRelations, unsigned int relationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem )
		{
		ContextResultType contextResult;
		bool hasFoundAllRelationWords;
		unsigned int currentRelationContextNr;
		unsigned int nContextWords;
		GeneralizationItem *currentGeneralizationItem;
		SpecificationItem *currentSpecificationItem;
		WordItem *currentGeneralizationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findPossessiveReversibleConclusionContextNrOfInvolvedWords";

		if( relationContextNr > NO_CONTEXT_NR )
			{
			if( generalizationWordItem != NULL )
				{
				if( specificationWordItem != NULL )
					{
					if( ( currentGeneralizationItem = generalizationWordItem->firstActiveGeneralizationItem() ) != NULL )
						{
						do	{
							if( ( currentGeneralizationWordItem = currentGeneralizationItem->generalizationWordItem() ) != NULL )
								{
								if( ( currentSpecificationItem = currentGeneralizationWordItem->firstSelectedSpecification( false, false, false, false ) ) != NULL )
									{
									do	{
										if( currentSpecificationItem->hasRelationContext() &&
										currentSpecificationItem->isPossessive() == isPossessive &&
										currentSpecificationItem->isRelatedSpecification( isExclusive, isNegative, isPossessive, specificationWordItem ) )
											{
											currentRelationContextNr = currentSpecificationItem->relationContextNr();
											nContextWords = myWord_->nContextWords( isPossessive, currentRelationContextNr, specificationWordItem );
											hasFoundAllRelationWords = ( nContextWords + 1 == nContextRelations );		// This relation word will be the last one

											if( currentSpecificationItem->isSelfGeneratedPossessiveReversibleConclusion() )
												{
												if( ( isPossessive &&
												currentRelationContextNr != relationContextNr ) ||

												( !isPossessive &&
												!hasFoundAllRelationWords &&
												currentRelationContextNr == relationContextNr ) )
													{
													if( hasFoundAllRelationWords )
														{
														contextResult.contextNr = relationContextNr;
														contextResult.replaceContextNr = currentRelationContextNr;
														}
													else
														contextResult.contextNr = currentRelationContextNr;
													}
												}
											else
												{
												if( !isPossessive &&
												nContextWords == nContextRelations &&
												currentRelationContextNr != relationContextNr )
													{
													contextResult.contextNr = currentRelationContextNr;
													contextResult.replaceContextNr = relationContextNr;
													}
												}
											}
										}
									while( contextResult.contextNr == NO_CONTEXT_NR &&
									( currentSpecificationItem = currentSpecificationItem->nextSelectedSpecificationItem( false ) ) != NULL );
									}
								}
							else
								myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found an undefined generalization word" );
							}
						while( commonVariables_->result == RESULT_OK &&
						( currentGeneralizationItem = currentGeneralizationItem->nextGeneralizationItem() ) != NULL );
						}
					}
				else
					myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word item is undefined" );
				}
			else
				myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );
			}
		else
			myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given relation context number is undefined" );

		contextResult.result = commonVariables_->result;
		return contextResult;
		}


	public:
	// Constructor

	AdminContext( AdminItem *admin, WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		admin_ = admin;
		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "AdminContext" );

		if( commonVariables_ != NULL )
			{
		if( admin_ != NULL )
			{
			if( myWord_ == NULL )
				strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given admin is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected context functions

	unsigned int highestContextNr()
		{
		unsigned int tempContextNr;
		unsigned int highestContextNr = NO_CONTEXT_NR;
		WordItem *currentWordItem;

		if( ( currentWordItem = commonVariables_->firstWordItem ) != NULL )		// Do in all words
			{
			do	{
				if( ( tempContextNr = currentWordItem->highestContextNrInWord() ) > highestContextNr )
					highestContextNr = tempContextNr;
				}
			while( ( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}

		return highestContextNr;
		}

	ContextResultType addPronounContext( unsigned short contextWordTypeNr, WordItem *contextWordItem )
		{
		ContextResultType contextResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addPronounContext";

		if( contextWordItem != NULL )
			{
			if( ( contextResult.contextNr = contextWordItem->contextNrInWord( false, contextWordTypeNr, NULL ) ) == NO_CONTEXT_NR )
				{
				if( ( contextResult.contextNr = highestContextNr() ) < MAX_CONTEXT_NR )
					contextResult.contextNr++;
				else
					myWord_->startSystemErrorInItem( functionNameString, moduleNameString_, "Context number overflow" );
				}

			if( contextWordItem->addContext( false, contextWordTypeNr, WORD_TYPE_UNDEFINED, contextResult.contextNr, NULL ) != RESULT_OK )
				myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a context to word \"", contextWordItem->anyWordTypeString(), "\"" );
			}
		else
			myWord_->startErrorInItem( functionNameString, moduleNameString_, "The read word of the read ahead item is undefined" );

		contextResult.result = commonVariables_->result;
		return contextResult;
		}

	ContextResultType getRelationContextNr( bool isExclusive, bool isNegative, bool isPossessive, bool isUserSentence, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int nContextRelations, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem, ReadItem *startRelationReadItem )
		{
		ContextResultType contextResult;
		bool hasFoundRelationContext;
		bool hasFoundRelationWordInThisList;
		bool skipThisContext = false;
		unsigned int currentRelationContextNr;
		ContextItem *currentRelationContextItem;
		ReadItem *relationWordReadItem = NULL;
		SpecificationItem *foundSpecificationItem;
		WordItem *currentWordItem;
		WordItem *relationContextWordItem = relationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "getRelationContextNr";

		if( generalizationWordItem != NULL )
			{
			if( specificationWordItem != NULL )
				{
				if( startRelationReadItem != NULL )
					{
					if( ( relationWordReadItem = startRelationReadItem->getFirstRelationWordReadItem() ) != NULL )
						relationContextWordItem = relationWordReadItem->readWordItem();
					else
						myWord_->startErrorInItem( functionNameString, moduleNameString_, "The read word of the first relation word is undefined" );
					}

				if( commonVariables_->result == RESULT_OK )
					{
					if( relationContextWordItem != NULL )
						{
						if( ( currentRelationContextItem = relationContextWordItem->firstActiveContext() ) != NULL )
							{
							do	{	// Do for all relation context items in the first relation context word
								currentRelationContextNr = currentRelationContextItem->contextNr();

								if( relationContextWordItem->hasContextInWord( isPossessive, currentRelationContextNr, specificationWordItem ) )
									{
									if( ( currentWordItem = commonVariables_->firstWordItem ) != NULL )
										{
										hasFoundRelationWordInThisList = false;
										skipThisContext = false;

										do	{	// Do for all words - either in the current relation list or outside this list
											foundSpecificationItem = ( isUserSentence ? NULL : generalizationWordItem->firstAssignmentOrSpecification( true, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, currentRelationContextNr, specificationWordItem ) );

											if( foundSpecificationItem == NULL ||
											!foundSpecificationItem->isSelfGeneratedConclusion() ||
											foundSpecificationItem->relationContextNr() != currentRelationContextNr )
												{
												if( relationWordReadItem != NULL )
													hasFoundRelationWordInThisList = relationWordReadItem->hasFoundRelationWordInThisList( currentWordItem );

												hasFoundRelationContext = currentWordItem->hasContextInWord( isPossessive, currentRelationContextNr, specificationWordItem );

												// Word is one of the relation words in this list, but doesn't have current context
												if( ( !hasFoundRelationContext &&
												hasFoundRelationWordInThisList ) ||

												// Word is in not current list of relation words, but has current context
												( hasFoundRelationContext &&
												!hasFoundRelationWordInThisList ) )
													skipThisContext = true;
												}
											}
										while( !skipThisContext &&
										( currentWordItem = currentWordItem->nextWordItem() ) != NULL );

										if( !skipThisContext )	// The relation words in the list contain this context exclusively. (So, no other words)
											contextResult.contextNr = currentRelationContextNr;
										}
									else
										myWord_->startErrorInItem( functionNameString, moduleNameString_, "The first word item is undefined" );
									}
								}
							while( commonVariables_->result == RESULT_OK &&
							contextResult.contextNr == NO_CONTEXT_NR &&
							( currentRelationContextItem = currentRelationContextItem->nextContextItem() ) != NULL );
							}

						if( commonVariables_->result == RESULT_OK &&
						questionParameter == NO_QUESTION_PARAMETER &&
						contextResult.contextNr == NO_CONTEXT_NR &&
						( foundSpecificationItem = generalizationWordItem->firstAssignmentOrSpecification( true, false, true, true, true, isNegative, isPossessive, NO_QUESTION_PARAMETER, generalizationContextNr, specificationContextNr, NO_CONTEXT_NR, specificationWordItem, NULL ) ) != NULL )
							{
							if( ( contextResult.contextNr = foundSpecificationItem->relationContextNr() ) > NO_CONTEXT_NR )
								{
								if( foundSpecificationItem->isExclusive() )
									// Static (exclusive) semantic ambiguity
									contextResult.isExclusiveContext = true;
								else
									{
									if( !foundSpecificationItem->isAssignment() )
										{
										if( relationWordItem == NULL )
											{
											if( skipThisContext )
												contextResult.contextNr = NO_CONTEXT_NR;	// Context not found: Different number of relation words
											else
												{
												// Static (exclusive) semantic ambiguity
												if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_NOTIFICATION, INTERFACE_SENTENCE_NOTIFICATION_I_NOTICED_SEMANTIC_AMBIGUITY_START, generalizationWordItem->anyWordTypeString(), INTERFACE_SENTENCE_NOTIFICATION_STATIC_SEMANTIC_AMBIGUITY_END ) == RESULT_OK )
													contextResult.isExclusiveContext = true;
												else
													myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface notification" );
												}
											}
										else	// Try to find the relation context of a possessive reversible conclusion
											{
											if( ( contextResult = findPossessiveReversibleConclusionContextNrOfInvolvedWords( isExclusive, isNegative, isPossessive, nContextRelations, contextResult.contextNr, relationWordItem, specificationWordItem ) ).result != RESULT_OK )
												myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a possessive reversible conclusion context number of involved words" );
											}
										}
									}
								}
							}

						if( commonVariables_->result == RESULT_OK &&
						contextResult.contextNr == NO_CONTEXT_NR )		// No context found
							{
							if( ( contextResult.contextNr = highestContextNr() ) < MAX_CONTEXT_NR )
								contextResult.contextNr++;
							else
								myWord_->startSystemErrorInItem( functionNameString, moduleNameString_, "Context number overflow" );
							}
						}
					else
						myWord_->startErrorInItem( functionNameString, moduleNameString_, "I couldn't find any read context word" );
					}
				}
			else
				myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word item is undefined" );
			}
		else
			myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		contextResult.result = commonVariables_->result;
		return contextResult;
		}
	};

/*************************************************************************
 *
 *	"Praise the Lord!
 *	How joyful are those who fear the Lord
 *	and delight in obeying his commands." (Psalm 112:1)
 *
 *************************************************************************/
