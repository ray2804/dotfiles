/* License/copyright: At the end of this file or read copyright.txt */

void help(char *msg);
