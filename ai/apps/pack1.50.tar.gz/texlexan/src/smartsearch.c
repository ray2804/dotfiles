//####################### DEVELOPMENT DOESN'T WORK #########################
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>
#include <math.h>
#include "languages.h"
#include "exclusion.h"
#include "utils.h"

#define ERRPOS fprintf(stderr,"\nError:%s %d  ",__FILE__,__LINE__);

#define PRGVER "\n\n-=-=-=- The SmartSearch is the TexLexAn fuzzy matching -=-=-=-\nCopyright Jean-Pierre Redonnet Ver 0.1 Nov 22 2009\n\n"
#define LGLINE 2048 //lg each line in keyworder.build   => modify it set auto or by argument
#define MAX_NB_LG 100 //default max nb of class (lines) in dico
#define SIZE_EXCLUDED_WORD 100000 //fixed max 100 kbytes
#define SIZE_KEYWORDER 5000000; //default size dico loaded in memory
#define SIZE_WORD 200

/*---------- Declarations --------------*/
void help(void);
void list_class(char *dico,int *arraylen,int firstline,int endline);
int loaddic(char *file,char *dico,int *arraylen,int lgline,int maxnbline);
int checkramdico(char *dico,int *arraylen,int endline,int maxsize);
int savedic(char *file,char *dico,int *arraylen,int endline);
int updatedico(char *dico,int *arraylen,int lgline,int endline,char *searchclass,char *searchword,int freq,int action);
int addclassdico(char *dico,int *arraylen,int endline,char *class,char *word,int weight);
int createdico(char *file);

//int classexist(char *dico,int *arraylen,int endline,char *class);
//int classsimilar(char *dico,int *arraylen,int endline,char *class,char *classbis);

/*---------- Global variables ---------*/
char alphabet[26]="abcdefghijklmnopqrstuvwxyz";
char numeral[10]="0123456789";
char separator[20]=",/'-+*<>=(){}[]\t\r\n";
char eos[10]=":?!;";
char special[10]="@";
char folder_dico[SIZE_WORD]="~/dico/";     //path of out file (dico)
char folder_results[SIZE_WORD]="~/results/";     //path of input file (keyworder.build)
char input_name[SIZE_WORD]="keyworder.build"; //default input file
char output_name[SIZE_WORD];
char file_input[SIZE_WORD];
char file_output[SIZE_WORD];
char verbose=0,debug=0;
long int setdicosize=SIZE_KEYWORDER; //size dico loaded in memory

/*------------- functions ------------*/

void help(void){
  printf(PRGVER);
  printf("\nSmartSearch is a fuzzy string search.\n");
  printf("It is based on the Levenstein distance.\n");
  printf("It returns the occurence of the string, the edit distance and the postions inside the text\n");
  printf("The search limits in the text and a minimal edit distant can be defined.\n");
  printf("\nUsage: smartsearch [options]\nDefault input:keyworder.build\n");
  printf("Options:\n");
  printf("-h\t\t\tThis help\n");
  printf("-a -1/+1\t\tAction (-1:wrong, +1:correct class)\n");
  printf("-c      \t\tClass label to update\n");
  printf("-d      \t\tDebug (verbose & check dico)\n");
  printf("-e 0/1/2\t\tExcluded word list (0:none,1:excluded,2:basic)\n");
  printf("-f <folder>\t\tDictionnaries folder\n");
  printf("-F <folder>\t\tInput folder of keyworder.build\n");
  printf("-i <file>\t\tInput file name\n");
  printf("-o <file>\t\tOutput file name (postponed texts)\n");
  printf("-z 1..10\t\tMemory allocated (1:default, 2:double...)\n");
  printf("-v\t\t\tVerbose\n");
  exit(0);
}

int loaddic(char *file,char *dico,int *arraylen,int lgline,int maxnbline) {
FILE *fp;
int nbline=0,i;
int offset;
char *line,*str_ptr1,*str_ptr2;
char shortline[1000];

  *dico='\0';                                 //empty the dico
  arraylen[0]=0;

  fp=fopen(file,"r");
  if (fp==NULL){
    return -1; //probably the file doesn't exit
  }

  /*Search the size of line for dynamic alloc of line*/  
  fseek(fp,0,SEEK_SET);
  for(i=0;i<10;i++) { //search only in the 10 first lines
    if (fgets(shortline,255,fp) == NULL) break; //eof exit loop
    if (shortline[0] == '#') {
      if ((str_ptr1=strstr(shortline,"<LINE_LG:")) != NULL) {
        if ((str_ptr2=strchr(str_ptr1+9,'>')) != NULL) {
	  *str_ptr2='\0';
	  lgline=atoi(str_ptr1+9)+100; //size of the line plus a little more in case of bug
	  if (debug) fprintf(stderr,"\nsize_line is set at %i\n",lgline);
  } } } }

  /*Alloc a piece of memory*/
  if ((line = (char*)malloc(lgline))==NULL) {
    ERRPOS
    fprintf(stderr,"Sorry, not enough memory to continue -> Exit!\n");
    exit(0);
  }

  *dico='\0';                                 //empty the dico
  arraylen[0]=0;
  /*Load full dico*/
  fseek(fp,0,SEEK_SET);
  offset=0;
  for(i=0;i<maxnbline;i++) {
    line[lgline-1] = '\255';                  //to check line too long
    if (fgets(line,lgline,fp) == NULL) break; //if no #<END> tag 
    if (line[lgline-1] != '\255') { 
      ERRPOS	
	  fprintf(stderr,"Line too long in %s\n",file); 
	  exit(0); 
	}
    if (strcmp(line,"#<END>") == 0) break;    //normal eof
    if (line[0] != '#') {                     //do not load in memory comments and tags
      arraylen[nbline]=strlen(line)+1;        //length of each line + null char
      sprintf(dico+offset,"%s",line);         //offset point the first char of each line
      offset+=arraylen[nbline];               //offset is the cumul of lg line
      nbline++;                               //count nb of line
    }
  }
  sprintf(dico+offset,"%s","\n");
  arraylen[nbline]=-1;
  if (verbose) printf("\n=>%s is loaded, Nb lines: %i Size: %i bytes\n",file,nbline,offset);
  if (offset > 0.75*setdicosize) {
    ERRPOS
    fprintf(stderr,"Warning: increase dico size!\n");
  }
  return nbline; //nb of lines loaded in memory
}

int updatedico(char *dico,int *arraylen,int lgline,int endline,char *searchclass,char *searchword,int freq,int action) {
/*
   locate the position of the word and the class
   return -1 if the class is not found
   if the word is not found in the class then the word is added
   action == +1 :
   the weight of the word in the class is increased
   the weights of the word in the other classes are decreased
   action == -1 :
   the weight of the word in the class is decreased
   the weights of the word in the other classes are unchanged
   
   work like a perceptron
*/
  char *line;
  char *str_ptr1,*str_ptr2;
  char *enddico; //pointer at end of the dico
  char word[100];
  char class[100];
  int offset=0;
  int nbline=0,err=0;
  int val;
  int classupdate=0,otherupdate=0;
  int hole;
  int i;
  
  strcpy(word,"\\"); /*first delimiter*/
  strcat(word,searchword);
  strcat(word,"/"); /*last delimiter*/
  
  /*Read each line of the dico*/
  offset=0;
  err=0;
  for(nbline=0;nbline < endline;nbline++) {
    line=dico+offset;  
	//printf("\n{%s}",line);
    if (line[0] != '#') {  //skip comments & tags
      /*Search /word/ in the line*/
      if ((str_ptr1=strstr(line,word)) != NULL) {
	    // Word found...
        if (((str_ptr2=strpbrk(line,":")) == NULL) || (str_ptr2-line < 1)) {
		  ERRPOS
		  fprintf(stderr,"Error 1 posworddico %s %s\n",word,line); 
		  exit(0);
		}
        strncpy(class,line,str_ptr2-line);
        class[str_ptr2-line]='\0';
        // Get the weight
        if (*(str_ptr1-1) != ' ') val=((int)(*(str_ptr1-1)))-48; else val=0;
		if (strstr(class,searchclass)!=NULL) {
		  // ...and Class found => a>0 : increase the weight
		  //                       a<0 : decrease the weight
	      // Store the new weight in str_ptr1-1
		  if (action>0 && val<9) {
		    val++;
			*(str_ptr1-1)=(char)(48+val);
		  } 
		  else if (action<0 && val>0) {
		    val--;
		    *(str_ptr1-1)=(char)(48+val);
		  }
		  classupdate++;
		} 
		else
		{
		  // Class not found => a>0 : increase the weight
		  //                    a<0 : no change
		  // Store the new weight in str_ptr1-1
		  if (action>0 && val>1) {
		    val--;
		    *(str_ptr1-1)=(char)(48+val);
		  }
		  otherupdate++;
		}
      } 
	  else
	  {
	    // Word not found...
	    if (((str_ptr2=strpbrk(line,":")) == NULL) || (str_ptr2-line < 1)) {
		  ERRPOS
		  fprintf(stderr,"Error 2 posworddico %s %s\n",word,line); 
		  exit(0);
	    }
	    strncpy(class,line,str_ptr2-line);
        class[str_ptr2-line]='\0';
		if (strstr(class,searchclass)!=NULL) {
		  // ...but Class found  => add the word if a>0 (good class)
		  if (action>0) {
		    val=1; //val is fixed!
		    enddico=dico;
            for(i=0;i < endline;i++) enddico+=arraylen[i]; //the end of dico
		    hole=3+strlen(searchword); //size of word and its weight
		    str_ptr2++;
		    memmove(str_ptr2+hole,str_ptr2,enddico-str_ptr2); //make a hole
		    strcpy(str_ptr2+3,searchword);
		    *(str_ptr2+hole)='/'; //delimiter end of the word
		    *(str_ptr2+2)='\\'; //delimiter between weight and word
		    *(str_ptr2+1)=(char)(48+val);
		    arraylen[nbline]+=hole;  //update the length of the line  
		  } 
		  classupdate++;
		} 
	  }
    } 
	offset+=arraylen[nbline];
  }
  // return the number of update or 0 if class is not found
  return classupdate;
}

int addclassdico(char *dico,int *arraylen,int endline,char *class,char *word,int weight) {
/*Create a class and add one word in this class*/
  char *previous,*enddico;
  char num_class[105];
  int nbline;
  long int dicolg,offset;

  dicolg=0;
  for(nbline=0;nbline < endline;nbline++) dicolg+=arraylen[nbline];
  enddico=dico+dicolg; //pointer to the end
  if (setdicosize < dicolg+strlen(class)+strlen(word)+12) {
    ERRPOS
    fprintf(stderr,"Error dico too small\n"); 
	exit(-1);
  }
  
  previous=enddico;
  sprintf(num_class,"%i %s",endline+1,class);
  strcpy(enddico,num_class);  //add the class name
  enddico+=strlen(num_class);
  *(enddico++)=':'; //separ
  *(enddico++)='/'; //separ beginning number
  *(enddico++)=(char)(48+weight); //ten million
  *(enddico++)='\\'; //separ between number & word
  strcpy(enddico,word);
  enddico+=strlen(word);
  *(enddico++)='/'; //separ end of word
  *(enddico++)='\n'; //cr
  *(enddico)='\0'; //eos
  arraylen[endline]=enddico-previous+1; //store the length
  arraylen[++endline]=-1; //end marker
  
  if (debug) {
    offset=0;
    for(nbline=0;nbline < endline;nbline++) {
      fprintf(stderr,"%li=>%s",offset,dico+offset);
      offset+=arraylen[nbline];
    }
    fprintf(stderr,"\n");
  }
  
  return endline; 
}

int savedic(char *file,char *dico,int *arraylen,int endline) {
FILE *fp;
int nbline;
long int offset,line_lg;
  /*Search the longest line*/
  line_lg=0;
  for(nbline=0;nbline < endline;nbline++) {
    if (line_lg < arraylen[nbline]) line_lg=arraylen[nbline];
  }

  fp=fopen(file,"w");
  if (fp==NULL){
    ERRPOS
    fprintf(stderr,"Error:Unable to create %s ->Exit!\n",file);
    exit(0);
  }
  
  fprintf(fp,"#<LINE_LG:%li>\n",line_lg); //put this info in the head of the file
  fprintf(fp,"#Updated expressions by the leasy learner\n");
  offset=0;
  for(nbline=0;nbline < endline;nbline++) {
    fprintf(fp,"%s",(dico+offset));
    offset+=arraylen[nbline];
  }
  fprintf(fp,"#<END>\n");
  fclose(fp);
  if (verbose) printf("\n=>%s is recorded, Nb lines: %i Size: %li bytes\n",file,endline,offset);
  return 1;
}

int createdic(char *file) {
FILE *fp;

  fp=fopen(file,"w");
  if (fp==NULL){
    ERRPOS
    fprintf(stderr,"Unable to create %s ->Exit!\n",file);
    exit(0);
  }
  
  fprintf(fp,"#<LINE_LG:0>\n"); //put this info in the head of the file
  fprintf(fp,"#Empty new dictionnary by leasy learner\n");
  fprintf(fp,"#<END>\n");
  fclose(fp);
  return 1;
}

void list_class(char *dico,int *arraylen,int firstline,int endline) {
  char class[100];
  char *str_ptr;
  int offset;
  int nbline;
  
  offset=0;
  for(nbline=0;nbline < firstline;nbline++) offset+=arraylen[nbline];
  for(nbline=firstline;nbline < endline;nbline++) {
    if (*(dico+offset) != '#') {
      str_ptr=strpbrk(dico+offset,":");
      strncpy(class,dico+offset,(str_ptr-dico-offset));
      class[str_ptr-dico-offset]='\0';
      if (strncmp(class,"all-lg",6) != 0) printf(" <%s> ",class);
    }
    offset+=arraylen[nbline]; 
} }

int classexist(char *dico,int *arraylen,int endline,char *class) {
/*Search if class exist*/
  char classchk[100];
  char *str_ptr1,*enddico;
  int offset;
  int nbline;

  enddico=dico;
  for(nbline=0;nbline < endline;nbline++) enddico+=arraylen[nbline];
  offset=0;
  strcpy(classchk,class);
  strcat(classchk,":");
  //find the class
  for(nbline=0;nbline < endline;nbline++) {
    if ((str_ptr1=strstr(dico+offset,classchk)) != 0)  return nbline; //found
    offset+=arraylen[nbline];    
  }
  return -1; //no found
}

int classsimilar(char *dico,int *arraylen,int endline,char *class,char *classbis) {
/*Search if similar class*/
  char *str_ptr1,*enddico;
  int offset;
  int nbline;

  enddico=dico;
  for(nbline=0;nbline < endline;nbline++) enddico+=arraylen[nbline];
  offset=0;
  //find the class
  for(nbline=0;nbline < endline;nbline++) {
    if ((str_ptr1=strstr(dico+offset,class)) != 0)
      if (str_ptr1 < strchr(dico+offset,':')) {
        strcpy(classbis,str_ptr1);
        str_ptr1=strchr(classbis,':');
        *str_ptr1='\0';
        return nbline; //found
      }
    offset+=arraylen[nbline];    
  }
  return -1; //no found
}


void update_list_class(char *file_dico,char *file_list) {
/*Extract classes in one dico and add them to the list of class names*/
  FILE *fp;
  char **classname; //'size_nb_class*size_class_name' chars
  long int i,j,k;
  int size_nb_class=200; //check
  int size_class_name=256; //check
  int size_line=200;
  char *str_ptr1,*str_ptr2;
  //char word[SIZE_WORD+1];
  char line[size_line+1];
  int class_found;
    
  /*Alloc mem*/
  if ((classname = (char**)malloc(size_nb_class*sizeof(char*))) == NULL) errmalloc("updatelist");
  for (k=0;k<size_nb_class;k++) if ((classname[k] = (char*)malloc(size_class_name)) == NULL) errmalloc("updatelist");
  /*build the classname array*/
  fp=fopen(file_list,"r");
  if (fp==NULL){
    ERRPOS
    fprintf(stderr,"Err %s \n",file_list);
    return; //probably the file doesn't exit
  }
  
  j=0;
  fseek(fp,0,SEEK_SET);
  for(i=0;i<size_nb_class;i++) {
    if (fgets(line,size_line,fp) == NULL) break;
    line[size_line]='\0';
    if (line[0] != '#') {
      strcpy(classname[j],line); 
      j++;
    }
  }
  fclose(fp);
  
  
  fp=fopen(file_dico,"r");
  if (fp==NULL){
    fprintf(stderr,"\nErr %s \n",file_dico);
    return; //probably the file doesn't exit
  }
  /*Search the size of line for dynamic alloc of line*/  
  fseek(fp,0,SEEK_SET);
  while (fgets(line,size_line,fp) != NULL) {
    line[size_line]='\0';
    if (line[0] != '#') {
      if ((str_ptr1=strstr(line,":/")) != NULL) {
        *str_ptr1='\n';
        *(str_ptr1+1)='\0';
        str_ptr2=strchr(line,' ')+1;
        class_found=0;
        /*search class in the list, 
         * linear search the slowless but always works
         */
        for (i=0;i<j;i++) {
          if (strcmp(str_ptr2,classname[i]) == 0) {
            class_found=1;
            break;
          }
        }
        /*Add class if not found*/
        if (class_found==0) {
          fprintf(stderr,"Add in pos:%li<=%s",j,str_ptr2);
          /*Add this class at the end*/
          strcpy(classname[j],str_ptr2);
          j++;
        }
      }
    }
  }
  fclose(fp);
  /*sort*/
  qsort(classname,j,sizeof(char *),array_str_cmp);
  /*save the new list*/
  fp=fopen(file_list,"w");
  if (fp==NULL){
    ERRPOS
    fprintf(stderr,"Err %s \n",file_list);
    return; //probably the file doesn't exit
  }
  fprintf(fp,"#Updated by lazylearner\n");
  for (i=0;i<j;i++) {
    fprintf(fp,"%s",classname[i]);
  }
  fclose(fp);
  /*free mem*/
  for (k=0;k<size_nb_class;k++) free(classname[k]);
  free(classname);
  
  return;
}


int checkramdico(char *dico,int *arraylen,int endline,int maxsize) {
/*Check the dico in ram is ok*/
char *enddico;
int i,prev_i;
int nbline,ok;

  enddico=dico;
  prev_i=0;
  for(nbline=0;nbline < endline;nbline++) enddico+=arraylen[nbline];
  nbline=ok=0;
  printf("\nCheck dico in RAM\n");
  for(i=0;i<maxsize;i++) {
    if ((dico[i] == '#') && (ok == 0)) ok=6;
    if ((dico[i] == ':') && (ok == 0)) ok=1;
    if ((dico[i] == '/') && (ok == 1)) ok=2;
    if ((strchr("0123456789 ",dico[i]) != NULL) && (ok == 2)) ok=3;
    if ((dico[i] == '/') && (ok == 3)) ok=4;
    if (((int)(dico[i]) >31) && ((int)(dico[i]) < 127) && (ok == 4)) ok=5;
    if (((int)(dico[i]) <32) && ((int)(dico[i]) > 126) && (ok == 4)) {
      ok=5;
	  ERRPOS
      fprintf(stderr,"<word with no pintable chars!>\n");
    }
    if ((dico[i] == '/') && (ok == 5)) ok=6;
    if (dico[i] == '\n') {
      if (ok == 6) ok=7;
      else if (ok == 2) {
        ok=7;
        if (nbline > endline) { printf("\n\n"); return 1; }
      }
      else {
        printf("<L:%i CR Err:%i>",nbline,ok);
        if (nbline > endline) { printf("\n\n"); return 1; }
    } }
    if (dico[i] == '\0') {
      if (ok == 7) {
        ok=0;
        if (arraylen[nbline] == -1) printf("<L:%i End marker>\n",nbline);
        else if (arraylen[nbline] != (i-prev_i)) {
		  ERRPOS
		  fprintf(stderr,"<L:%i Error length:%i/%i>\n",nbline,arraylen[nbline],(i-prev_i));
	    }
        prev_i=i;
        nbline++;
        if (nbline > endline) { printf("\n\n"); return 1; }
      } 
      else {
        if (ok == 0) printf("<L:%i empty line>\n",nbline);
        else printf("<L:%i ligne incomplete Error %i>\n",nbline,ok);
        ok=0;
        if (arraylen[nbline] == -1) printf("<L:%i End marker>\n",nbline);
        else if (arraylen[nbline] != (i-prev_i)) printf("<L:%i Err length:%i/%i>\n",nbline,arraylen[nbline],(i-prev_i));
        prev_i=i;
        nbline++;
        if (nbline > endline) { printf("\n\n"); return 1; }
  } } }
  return 0;
}

/*-----------End of functions------------*/

/*-------------- Start here -------------*/
int main(int argc, char **argv)
{
  char path_name[SIZE_WORD];
  char filename[SIZE_WORD];
  char filename2[SIZE_WORD];
  FILE *fp,*fp1;
  char *str_ptr;
  int  *arraylen1; /*dynamically allocated*/
  char *dico1; /*dynamic alloc dico stored in ram*/
  char *result; /*dynamic alloc result list*/
  char line[LGLINE]; //line read with fgets()
  char word[SIZE_WORD];
  char searchedclass[SIZE_WORD];
  int nbword,nbwordset=5; //nb word in expression
  int position;
  int lgw,enddico1;
  int skip=0;
  char lan[8]="en";
  int f=0; //term freq in the text
  int fcumulw=0; //all word freq in the text
  int feedback; // (-1,0,+1)increase or decrease 'freq' of 'f'
  int status,errcnt=0;
  int text=0;
  int classadded=0,wordupdated=0;
  int term,blockanalyzemark=0,blocktermsmark=0;
  int update=0;
  long int datasize;
  int max_nb_lg=MAX_NB_LG; //max nb of line in dico
  char excludedword[SIZE_EXCLUDED_WORD]="";
  int excluded_mode=1,action=1;
  int coef_mem=1;
  
  printf(PRGVER);  

  if (sizeof(int) < 4) { //should be exceptional
    printf("\nCannot run.\nInteger size < 4 bytes, 32bits processors or + required.\n");
    exit(0);
  }
  
  /* get options from the cmd line */
  strcpy(path_name,*argv++);
  argc--;
  while (argc >0) {
    if (strcmp(*argv,"-h")==0) help();
	else if (strcmp(*argv,"-a")==0) {argv++; action=atoi(*argv++); argc--;}
	else if (strcmp(*argv,"-c")==0) {argv++; strcpy(searchedclass,*argv++); argc--;} //folder of inputfile and postponed
    else if (strcmp(*argv,"-d")==0) {argv++; debug=1;}
	else if (strcmp(*argv,"-e")==0) {argv++; excluded_mode=atoi(*argv++); argc--;}
    else if (strcmp(*argv,"-f")==0) {argv++; strcpy(folder_dico,*argv++); argc--;} //folder of inputfile and postponed
	else if (strcmp(*argv,"-F")==0) {argv++; strcpy(folder_results,*argv++); argc--;} //folder of inputfile and postponed
    else if (strcmp(*argv,"-o")==0) {argv++; strcpy(output_name,*argv++); argc--;}
    else if (strcmp(*argv,"-i")==0) {argv++; strcpy(input_name,*argv++); argc--;}
    else if (strcmp(*argv,"-z")==0) {
	  argv++;
	  coef_mem=atoi(*argv++);
	  argc--;
	  setdicosize*=coef_mem;
	  max_nb_lg*=coef_mem;
	}
    else if (strcmp(*argv,"-v")==0) {argv++; verbose=1;}
    argc--;
  } 
  
  if (searchedclass[0] == '\0') {
    ERRPOS
    fprintf(stderr,"Missing class -> Exit!\n");
    exit(0);
  }
  
  if (input_name[0] == '\0') {
    ERRPOS
    fprintf(stderr,"Missing file name -> Exit!\n");
    exit(0);
  }

  if (output_name[0] == '\0') {
    sprintf(output_name,"%s%s",input_name,".postpone");
  }
  
  if (folder_dico[0] != '\0') {
    if (folder_dico[strlen(folder_dico)-1] != '/') strcat(folder_dico,"/");
  }
  if (folder_results[0] != '\0') {
    if (folder_results[strlen(folder_results)-1] != '/') strcat(folder_results,"/");
  }
 
  sprintf(file_input,"%s%s",folder_results,input_name);
  sprintf(file_output,"%s%s",folder_results,output_name);

  /* Open the input file: list of terms and freq from texts analyzed  */
  fp=fopen(file_input,"r");
  if (fp==NULL){
    ERRPOS
    fprintf(stderr,"Unable to open <%s> ->Exit!\n",file_input);
    return(0);
  }
  /* Open the output file: input file skipped   */
  fp1=fopen(file_output,"a");
  if (fp1==NULL){
    ERRPOS
    fprintf(stderr,"Unable to create %s ->Exit!\n",file_output);
    return(0);
  }

/*Check the length of each line of the input file, if too long exit*/  
  datasize=position=0;
  line[LGLINE-1]='\255';
  while (fgets(line,LGLINE,fp) != NULL) {
    position++;
    if (line[LGLINE-1] != '\255') { 
	  ERRPOS
      fprintf(stderr,"\nLine too long, position:%i in %s\n",position,file_input);
      fprintf(stderr,"Max length %i bytes\n:",LGLINE);
      return(0);
    }
    if (*line != '<') datasize+=strlen(line); //surestim size of the data to addd
  }
  setdicosize+=datasize;
  /*dynamic allocation*/
  dico1 = (char*)malloc(setdicosize); //each 1Mbytes is about 20000 terms 
  arraylen1 = (int*)malloc(max_nb_lg+2);
  result = (char*)malloc(10000);  
  if ((dico1==NULL) ||(arraylen1==NULL) || (result==NULL)) {
    ERRPOS
    fprintf(stderr,"Sorry, not enough memory to continue -> Exit!\n");
    exit(0);
  }

  position=0;
  fseek(fp,0,SEEK_SET); //set to the beginning of the file
  line[LGLINE-1]='\255'; //used to check overflow
  /* 
     MAIN LOOP
     Proceed each line, extract freq & word, 
	 then seach word in the full dico to update 
  */
  while (fgets(line,LGLINE,fp) != NULL) {
    if (line[LGLINE-1] != '\255') {
	  ERRPOS
      fprintf(stderr,"Line too long.\n"); 
      errcnt++; 
      line[LGLINE-1] = '\255';
    }
    if (line[0]=='\n') goto bottom_of_while; //empty skip all test
    position++; //count line
    /********** Proceed tags *********/
    /* Tag < Begin analyze > */  
    if (strncmp(line,"< Begin analyze",15) == 0)  {
	  if (debug) fprintf(stderr,"\nTag:Begin analyze");
      blockanalyzemark++;
    } //End tag < Begin analyze >
      
    /* Tag < End analyze > */  
    if (strncmp(line,"< End analyze",13) == 0)  {
	if (debug) fprintf(stderr,"\nTag:End analyze");
      blockanalyzemark--;
      if ((skip == 0) && (update > 0)) { //should never occure
	    ERRPOS
        fprintf(stderr,"Check input file <End terms> is missing, I record the dico anyway.\n");
        update=0;
      }
	  goto job_done;
    } //End tag < End analyzed >
      
    /* Tag < File analyzed... > */  
    if (strncmp(line,"< File analyzed:",16) == 0)  {
	    if (debug) fprintf(stderr,"\nTag:File analyzed");
      printf("%s",line);
      text++;
      fcumulw=0; //reset cumul of word in text
    } //End tag < File analyzed... >
      
    /* Tag < Text class... >  if class available get it */  
    if (strncmp(line,"< Text class:",13) == 0) {
      //not used
    } //End tag < Text class... >
	
	/* Tag < Language... >  if language available get it */  
    if ((strncmp(line,"< Language:",11) == 0) && (skip == 0)) {
	  if (debug) fprintf(stderr,"\nTag:Language");
      str_ptr=strchr(line,':');
      strncpy(lan,str_ptr+1,8);
      str_ptr=strchr(lan,' ');
      *str_ptr='\0';
    } //End tag < Language... >

    /* Tag < Parameters... >  if language available get it */  
    if ((strncmp(line,"< Parameters lang:",18) == 0) && (skip == 0)) {
	  if (debug) fprintf(stderr,"\nTag:Parameters lang");
      str_ptr=strchr(line,':');
      strncpy(lan,str_ptr+1,8);
      str_ptr=strchr(lan,' ');
      *str_ptr='\0';
    } //End tag < Parameters... >
     
    /* Tag < Number of words: > nb of word in the text */    
    if ((strncmp(line,"< Number of words:",18) == 0) && (skip == 0)) {
	  if (debug) fprintf(stderr,"\nTag:Number of words");
      str_ptr=strpbrk(line,":");
      strcpy(word,str_ptr+1);
      str_ptr=strpbrk(word," ");
      *str_ptr='\0';
      fcumulw=atol(word); //nb of word in text analyzed
    } //End Tag < Number of words: >

    if (skip) {  //Record job posponed
      fprintf(fp1,"%s",line);
    }
      
    /*** part of this loop scans terms ***/
    /* if tag < Begin terms length:N > */  
    if ((strncmp(line,"< Begin terms length:",21) == 0) && (skip == 0)) {
	  if (debug) fprintf(stderr,"\nTag:Begin terms length");
      blocktermsmark++;
      str_ptr=strpbrk(line,":");
      strcpy(word,str_ptr+1);
      str_ptr=strpbrk(word," ");
      *str_ptr='\0';
      nbwordset=atol(word); //nb of separators between 2 words        
      /* load the dico 'keyworder.lan.dicN' lan= language N=nb words in key_expressions */
	    sprintf(filename,"%s%s%s%s%i",folder_dico,"keyworder.",lan,".dic",nbwordset);
      enddico1=loaddic(filename,dico1,arraylen1,1000000,max_nb_lg);
	  if (enddico1 < 0) printf("\nStart with a new dictionnary");
      if (debug) checkramdico(dico1,arraylen1,enddico1,(1000000));
	  /*load the list of excluded or basic words*/
	  *excludedword='\0';
	  if (excluded_mode) {
	    excludedfromfile(folder_dico,excludedword,excluded_mode,lan,SIZE_EXCLUDED_WORD);
	  }
    } //End tag < Begin terms length:N >

    /* Tag < End terms >   */
    if ((strncmp(line,"< End terms",11) == 0) && (skip == 0)) {
	  if (debug) fprintf(stderr,"\nTag:End terms");
      blocktermsmark--;
      if (verbose) printf("  %i terms updated.\n",update);
      update=0; //reset the counter
      // save here CUMULALLWORD and classsearched
	  savedic(filename,dico1,arraylen1,enddico1);
    } //End tag < End terms >
    
    /* If no skip this text and no tag then update dico with term*/    
    if ((*line != '<') && (skip == 0)) {
      term++;
      nbword=1;
      str_ptr=line;
      if (debug) fprintf(stderr,"Position: %i ",position);
	  // freq:word
      str_ptr=strpbrk(line,":");
      strncpy(word,line,str_ptr-line);
      word[str_ptr-line]='\0';
      f=atoi(word)*feedback; //freq of the expression in text
      strcpy(word,str_ptr+1); //get the expression (one word, grp of words)
      lgw=strlen(word)-1;
      word[lgw]='\0'; //expression to update
      //skip numbers and single char
      if (lgw > 2 && !arenumbers(word) && exclusion(excludedword,word)) {
	    noplural(word,lan); //plural->singular
        status=-1;
        //update keyworder.lan.dicN (update the weight / add a new word to the class)
	    if (debug) fprintf(stderr,"\nStart 'updatedico()'\n");
        status=updatedico(dico1,arraylen1,1000000,enddico1,searchedclass,word,f,action);
		wordupdated+=abs(status);
        if (status != 0) {
	      update++;
          if (verbose) printf("Updated! Status=%i Expression<%s> in Class=<%s>\nin dico: <%s>\n",status,word,searchedclass,filename);
        }
        else {
		  //add to keyworder.lan.dicN a new class (insert a line at the end)
		  if (action>0) f=1; else f=0;
		  enddico1=addclassdico(dico1,arraylen1,enddico1,searchedclass,word,f);
          if (enddico1+5>max_nb_lg) {
		    ERRPOS
		    fprintf(stderr,"Warning:Less than %i classes available!\n",max_nb_lg-enddico1);
		  }
		  if (verbose) printf ("\nClass <%s> created for expression <%s>\nin dico: <%s>\n",searchedclass,word,filename); 
		  classadded++; 
	    }
        if (debug) checkramdico(dico1,arraylen1,enddico1,(1000000));
	  } 
	}
    bottom_of_while:;
  }
  
job_done:;

  fclose(fp); //close to flush buffers
  
  sprintf(filename,"%s%s%s%s%i",folder_dico,"keyworder.",lan,".dic",1);
  sprintf(filename2,"%s%s%s%s",folder_dico,"keyworder.",lan,".class");
  update_list_class(filename,filename2);
  
  /*Summary*/
  printf("\n-=-=-Summary-=-=-\n");
  printf("\n%i texts => %i terms => %i classes added / %i words updated.\n",text,term,classadded,wordupdated);
  if (blockanalyzemark+blocktermsmark ==0) {
    printf("\nOKAY! - End.\n\n");
  } else
  {
    if (blockanalyzemark != 0) printf("\n%i Begin/End of analyze block missed",blockanalyzemark);
    if (blocktermsmark != 0) printf("\n%i Begin/End of terms block missed",blocktermsmark);
	fprintf(stderr,"\nERRORS! End.\n\n");
  }
  /*Release memory before living*/
  free(dico1); free(arraylen1); 
  return 1; //ok
 /* end main */
}
/*
JP Redonnet - Sept 2008 - March 2009
Update the keyworder's dictionaries (keyworder.lan.dicN)
Last revision March 19, 2009

exec: lazylearner [options]

bugs: memory alloc to low will give wrong result without warning!
      if tag < End terms > is missing file is not recorded
      Memory smash when new keyworder.lan.dicN are created but not fatal
      
Limitations:

Add:

Improve: check the label of the class, add lan. if required
     
Dico structure: 
Class_Label:/Freq1\Term1/Freq2\Term2/..../

Class_Label = Name of the class (max 100 chars)
Freq = 1 digits 1...9
Term = Word ou grp of words separated with a '-'

Note: sizeof(long int) == sizeof(int) == 4 bytes  (32bits processors)

*/
