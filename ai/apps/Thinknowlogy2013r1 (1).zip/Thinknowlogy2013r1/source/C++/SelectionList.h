/*
 *	Class:			SelectionList
 *	Parent class:	List
 *	Purpose:		To store selection items
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

// Selection List header

#ifndef SELECTIONLIST
#define SELECTIONLIST 1

#include "List.h"
#include "SelectionItem.cpp"

class SelectionList : private List
	{
	friend class AdminSelection;

	// Private deconstructor functions

	void deleteSelectionList( SelectionItem *searchItem );

	// Private selection functions

	unsigned int getLowerSentenceNr( unsigned int duplicateSentenceNr );

	SelectionItem *firstDeactiveSelectionItem();


	public:
	// Constructor

	SelectionList( char _listChar, WordItem *myWord, CommonVariables *commonVariables );

	// Deconstructor

	~SelectionList();


	// Protected virtual functions

	virtual ResultType findWordReference( WordItem *referenceWordItem );


	// Protected functions

	void clearConditionChecksForSolving( unsigned short selectionLevel, unsigned int conditionSentenceNr );

	ResultType checkSelectionItemForUsage( SelectionItem *unusedSelectionItem );
	ResultType checkWordItemForUsage( WordItem *unusedWordItem );

	SelectionResultType checkDuplicateCondition();
	SelectionResultType checkDuplicateSelectionPart( unsigned int duplicateConditionSentenceNr );
	SelectionResultType createSelectionItem( bool isAction, bool isAssignedOrClear, bool isDeactive, bool isArchived, bool isFirstComparisonPart, bool isNewStart, bool isNegative, bool isPossessive, bool isValueSpecification, unsigned short selectionLevel, unsigned short imperativeParameter, unsigned short prepositionParameter, unsigned short specificationWordParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int nContextRelations, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString );
	SelectionResultType findFirstExecutionItem( WordItem *solveWordItem );

	SelectionItem *executionStartEntry( unsigned short executionLevel, unsigned int executionSentenceNr );

	SelectionItem *firstActiveSelectionItem();
	SelectionItem *firstConditionSelectionItem( unsigned int conditionSentenceNr );
	};
#endif

/*************************************************************************
 *
 *	"In my desperation I prayed, and the Lord listened;
 *	he saved me from all my troubles." (Psalm 34:6)
 *
 *************************************************************************/
