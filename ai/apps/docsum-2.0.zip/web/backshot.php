<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><title></title></head>
<body>
<?php

	if($_SERVER['REQUEST_URI'] == $_SERVER['SCRIPT_NAME']) exit();
	
	include_once 'objects.php';
	include_once 'head.php';
	
	$pgGen = new PageGenerator($main_page);
	$cmdGen = new CommandGenerator();
	$cmdExe = new CommandExecuter();
	$where = "";
	
	if (isset($_GET["page"])) {
		$where = $_GET["page"];
	} 
	
	if($where == "add"){
		$pgGen->addFilePage();
		exit();
	} elseif($where == "main") {
		echo $pgGen->summaryForm("$main_page");
		exit();
	} else {
		if(isset($_GET['value']) && isset($_GET['sid'])){
			$value = $_GET['value'];
			$pgGen->suggestionPage($cmdGen,$cmdExe,$value);
			exit("");
		} elseif(!isset($_GET['history'])){
			echo "no suggestion";
			exit();
		}else {
		
			if(isset($_GET['history'])){
				if($_GET['history'] == "active"){
					$pgGen->historyShowFiles($cmdGen,$cmdExe,1);
				}else if($_GET['history'] == "inactive"){
					$pgGen->historyShowFiles($cmdGen,$cmdExe,0);
				} else{
					echo "";
				}
				exit();
			} else {
				exit();
			}
		}
	}
?>
</body>
</html>
