package mysql_crossout;
use strict;

use mysql_exec;
use mysql_crossout::csv;
use mysql_crossout::spss;
use mysql_crossout::tab;
use mysql_crossout::var;
use mysql_crossout::r_com;

use mysql_crossout::selected;

sub new{
	my $class = shift;
	my %args  = @_;
	my $self = \%args;
	bless $self, $class;

	unless ( length($self->{max}) ){
		$self->{max} = 0;
	}

	return $self;
}

sub run{
	my $self = shift;
	
	use Benchmark;
	
	# ���Ф��μ���
	$self->{midashi} = mysql_getheader->get_selected(tani => $self->{tani});

	# ����ե������̿̾
	$self->{file_temp} = "temp.dat";
	while (-e $self->{file_temp}){
		$self->{file_temp} .= ".tmp";
	}

	$self->make_list;
	
	my $t0 = new Benchmark;
	$self->out2;
	$self->finish;
	
	my $t1 = new Benchmark;
	print "\n",timestr(timediff($t1,$t0)),"\n";
}

#----------------#
#   �ǡ�������   #

sub out2{                               # length�����򤹤�
	my $self = shift;
	
	open (F,">$self->{file_temp}") or die;
	
	# �������Ƥκ���
	my $id = 1;
	my $last = 1;
	my %current = ();
	while (1){
		my $sth = mysql_exec->select(
			$self->sql2($id, $id + 100),
			1
		)->hundle;
		$id += 100;
		unless ($sth->rows > 0){
			last;
		}
		
		while (my $i = $sth->fetch){
			if ($last != $i->[0]){
				# �񤭽Ф�
				my $temp = "$last,";
				if ($self->{midashi}){
					my $jcode_tmp = kh_csv->value_conv($self->{midashi}->[$last - 1]).',';
					$jcode_tmp = Jcode->new($jcode_tmp,'euc')->sjis if $::config_obj->os eq 'win32';
					$temp .= $jcode_tmp;
				}
				foreach my $h ( 'length_c','length_w',@{$self->{wList}} ){
					if ($current{$h}){
						$temp .= "$current{$h},";
					} else {
						$temp .= "0,";
					}
				}
				chop $temp;
				print F "$temp\n";
				# �����
				%current = ();
				$last = $i->[0];
			}
			
			# HTML������̵��
			if (
				!  ( $self->{use_html} )
				&& ( $i->[2] =~ /<[h|H][1-5]>|<\/[h|H][1-5]>/o )
			){
				next;
			}
			# ̤���Ѹ��̵��
			if ($i->[3]){
				next;
			}
			
			# ����
			++$current{'length_w'};
			$current{'length_c'} += (length($i->[2]) / 2);
			if ($self->{wName}{$i->[1]}){
				++$current{$i->[1]};
			}
		}
		$sth->finish;
	}
	
	# �ǽ��Ԥν���
	my $temp = "$last,";
	if ($self->{midashi}){
		my $jcode_tmp = kh_csv->value_conv($self->{midashi}->[$last - 1]).',';
		$jcode_tmp = Jcode->new($jcode_tmp,'euc')->sjis if $::config_obj->os eq 'win32';
		$temp .= $jcode_tmp;
	}
	foreach my $h ( 'length_c','length_w',@{$self->{wList}} ){
		if ($current{$h}){
			$temp .= "$current{$h},";
		} else {
			$temp .= "0,";
		}
	}
	chop $temp;
	print F "$temp\n";
	close (F);
}

sub sql2{
	my $self = shift;
	my $d1   = shift;
	my $d2   = shift;


	my $sql;
	$sql .= "SELECT $self->{tani}.id, genkei.id, hyoso.name, genkei.nouse\n";
	$sql .= "FROM   hyosobun, hyoso, genkei, $self->{tani}\n";
	$sql .= "WHERE\n";
	$sql .= "	hyosobun.hyoso_id = hyoso.id\n";
	$sql .= "	AND hyoso.genkei_id = genkei.id\n";
	
	my $flag = 0;
	foreach my $i ("bun","dan","h5","h4","h3","h2","h1"){
		if ($i eq $self->{tani}){ $flag = 1; }
		if ($flag){
			$sql .= "	AND hyosobun.$i"."_id = $self->{tani}.$i"."_id\n";
		}
	}
	#$sql .= "	AND genkei.nouse = 0\n";
	$sql .= "	AND $self->{tani}.id >= $d1\n";
	$sql .= "	AND $self->{tani}.id <  $d2\n";
	$sql .= "ORDER BY hyosobun.id";
	return $sql;
}


#------------------------------------#
#   ���Ϥ���ñ�졦�ʻ�ꥹ�Ȥκ���   #

sub make_list{
	my $self = shift;
	
	# ñ��ꥹ�Ȥκ���
	my $sql = "
		SELECT genkei.id, genkei.name, hselection.khhinshi_id
		FROM   genkei, hselection, df_$self->{tani}
		WHERE
			    genkei.khhinshi_id = hselection.khhinshi_id
			AND genkei.num >= $self->{min}
			AND genkei.nouse = 0
			AND genkei.id = df_$self->{tani}.genkei_id
			AND df_$self->{tani}.f >= $self->{min_df}
			AND (
	";
	
	my $n = 0;
	foreach my $i ( @{$self->{hinshi}} ){
		if ($n){ $sql .= ' OR '; }
		$sql .= "hselection.khhinshi_id = $i\n";
		++$n;
	}
	$sql .= ")\n";
	if ($self->{max}){
		$sql .= "AND genkei.num <= $self->{max}\n";
	}
	if ($self->{max_df}){
		$sql .= "AND df_$self->{tani}.f <= $self->{max_df}\n";
	}
	$sql .= "ORDER BY khhinshi_id, genkei.num DESC, genkei.name\n";
	
	my $sth = mysql_exec->select($sql, 1)->hundle;
	my (@list, %name, %hinshi);
	while (my $i = $sth->fetch) {
		push @list,        $i->[0];
		$name{$i->[0]}   = $i->[1];
		$hinshi{$i->[0]} = $i->[2];
	}
	$sth->finish;
	$self->{wList}   = \@list;
	$self->{wName}   = \%name;
	$self->{wHinshi} = \%hinshi;
	
	# �ʻ�ꥹ�Ȥκ���
	$sql = '';
	$sql .= "SELECT khhinshi_id, name\n";
	$sql .= "FROM   hselection\n";
	$sql .= "WHERE\n";
	$n = 0;
	foreach my $i ( @{$self->{hinshi}} ){
		if ($n){ $sql .= ' OR '; }
		$sql .= "khhinshi_id = $i\n";
		++$n;
	}
	$sth = mysql_exec->select($sql, 1)->hundle;
	while (my $i = $sth->fetch) {
		$self->{hName}{$i->[0]} = $i->[1];
		if ($i->[1] eq 'HTML����' || $i->[1] eq 'HTML_TAG'){
			$self->{use_html} = 1;
		}
	}
	
	return $self;
}

#--------------------------#
#   ���Ϥ���ñ������֤�   #

sub wnum{
	my $self = shift;
	
	$self->{min_df} = 0 unless length($self->{min_df});
	
	my $sql = "
		SELECT count(*)
		FROM   genkei, hselection, df_$self->{tani}
		WHERE
			    genkei.khhinshi_id = hselection.khhinshi_id
			AND genkei.num >= $self->{min}
			AND genkei.nouse = 0
			AND genkei.id = df_$self->{tani}.genkei_id
			AND df_$self->{tani}.f >= $self->{min_df}
			AND (
	";
	
	my $n = 0;
	foreach my $i ( @{$self->{hinshi}} ){
		if ($n){ $sql .= ' OR '; }
		$sql .= "hselection.khhinshi_id = $i\n";
		++$n;
	}
	$sql .= ")\n";
	if ($self->{max}){
		$sql .= "AND genkei.num <= $self->{max}\n";
	}
	if ($self->{max_df}){
		$sql .= "AND df_$self->{tani}.f <= $self->{max_df}\n";
	}
	#print "$sql\n";
	
	$_ = mysql_exec->select($sql,1)->hundle->fetch->[0];
	1 while s/(.*\d)(\d\d\d)/$1,$2/; # �̼���ѤΥ���ޤ�����
	return $_;
}


sub get_default_freq{
	my $self = shift;
	my $target = shift;
	
	$self->{min_df} = 0 unless length($self->{min_df});
	
	my $sql = "
		SELECT num, count(*)
		FROM   genkei, hselection, df_$self->{tani}
		WHERE
			    genkei.khhinshi_id = hselection.khhinshi_id
			# AND genkei.num >= $self->{min}
			AND genkei.nouse = 0
			AND genkei.id = df_$self->{tani}.genkei_id
			AND df_$self->{tani}.f >= $self->{min_df}
			AND (
	";
	
	my $n = 0;
	foreach my $i ( @{$self->{hinshi}} ){
		if ($n){ $sql .= ' OR '; }
		$sql .= "hselection.khhinshi_id = $i\n";
		++$n;
	}
	$sql .= ")\n";
	if ($self->{max}){
		$sql .= "AND genkei.num <= $self->{max}\n";
	}
	if ($self->{max_df}){
		$sql .= "AND df_$self->{tani}.f <= $self->{max_df}\n";
	}
	$sql .= "GROUP BY genkei.num\n";
	$sql .= "ORDER BY genkei.num DESC\n";
	
	my $h = mysql_exec->select($sql,1)->hundle;

	my $lf  = 0;
	my $cum = 0;
	my $r   = 1;
	while (my $i = $h->fetch){
		if ($i->[0] % 5 ==0){
			if ($cum + $i->[1] >= $target){
				# print "$lf->[1]: ", $target - $lf->[1], ", ", $cum + $i->[1], ": ", $cum + $i->[1] - $target, "\n";
				if ( ( $target - $lf->[1] ) >= ( $cum + $i->[1] - $target ) ){
					$r = $i->[0];
				} else {
					$r = $lf->[0];
				}
				last;
			}
			$lf  =  [$i->[0], $cum + $i->[1]]; # 1�����Τ���¸
		}
		$cum += $i->[1]; # ����
	}

	return $r;
}

1;


__END__

sub out1{                               # length�����򤷤ʤ�(150��) + 26��?
	my $self = shift;
	
	open (F,">test.csv") or die;
	my $t;
	foreach my $i (@{$self->{wList}}){
		$t .= "$self->{wName}{$i},";
	}
	chop $t;
	print F Jcode->new($t)->sjis,"\n";
	
	
	my $id = 1;
	my $last = 1;
	my %current = ();
	while (1){
		my $sth = mysql_exec->select(
			$self->sql1($id, $id + 30000),
			1
		)->hundle;
		$id += 30000;
		unless ($sth->rows > 0){
			last;
		}
		
		while (my $i = $sth->fetch){
			if ($last == $i->[0]){
				++$current{$i->[1]};
			} else {
				# �񤭽Ф�
				my $temp;
				foreach my $i (@{$self->{wList}}){
					if ($current{$i}){
						$temp .= "$current{$i},";
					} else {
						$temp .= "0,";
					}
				}
				chop $temp;
				print F "$temp\n";
				# �����
				%current = ();
				$last = $i->[0];
			}
		}
		$sth->finish;
		print "$id,";
	}

}

sub sql1{
	my $self = shift;
	my $d1   = shift;
	my $d2   = shift;


	my $sql;
	$sql .= "SELECT $self->{tani}.id, genkei.id\n";
	$sql .= "FROM   hyosobun, hyoso, genkei, $self->{tani}, hselection\n";
	$sql .= "WHERE\n";
	$sql .= "	hyosobun.hyoso_id = hyoso.id\n";
	$sql .= "	AND hyoso.genkei_id = genkei.id\n";
	$sql .= "	AND genkei.khhinshi_id = hselection.khhinshi_id\n";
	
	my $flag = 0;
	foreach my $i ("bun","dan","h5","h4","h3","h2","h1"){
		if ($i eq $self->{tani}){ $flag = 1; }
		if ($flag){
			$sql .= "	AND hyosobun.$i"."_id = $self->{tani}.$i"."_id\n";
		}
	}
	$sql .= "	AND hyosobun.id >= $d1\n";
	$sql .= "	AND hyosobun.id <  $d2\n";
	$sql .= "	AND genkei.num >= $self->{min}\n";
	if ($self->{max}){
		$sql .= "AND genkei.num <= $self->{max}\n";
	}
	$sql .= "AND (\n";
	my $n = 0;
	foreach my $i ( @{$self->{hinshi}} ){
		if ($n){ $sql .= ' OR '; }
		$sql .= "hselection.khhinshi_id = $i\n";
		++$n;
	}
	$sql .= ")\n";
	return $sql;
}