/*
 *	Class:			AdminReadCreateWords
 *	Supports class:	AdminItem
 *	Purpose:		To create words of the read sentence
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

class AdminReadCreateWords
	{
	// Private constructible variables

	private boolean hasCreatedReadWord_;
	private boolean isProbablyPluralNoun_;

	private short currentWordOrderNr_;
	private short wordTypeNr_;

	private int nextTextStringPosition_;
	private int singularWordLength_;

	private String exactWordString_;
	private String lowerCaseWordString_;
	private String singularNounString_;

	private AdminItem admin_;
	private WordItem myWord_;
	private String moduleNameString_;


	// Private methods

	private boolean isSymbol( char character )
		{
		return ( character == Constants.SYMBOL_COMMA ||
			character == Constants.SYMBOL_COLON ||
			character == Constants.SYMBOL_SEMI_COLON ||
			character == Constants.SYMBOL_DOUBLE_COLON ||
			character == Constants.SYMBOL_QUESTION_MARK ||
			character == Constants.SYMBOL_EXCLAMATION_MARK ||
			character == Constants.SYMBOL_PIPE ||
			character == Constants.SYMBOL_AMPERSAND ||
			character == Constants.SYMBOL_ASTERISK ||
			character == Constants.SYMBOL_PERCENT ||
			character == Constants.SYMBOL_DOLLAR ||
			character == Constants.SYMBOL_SLASH ||
			character == Constants.SYMBOL_BACK_SLASH ||
			character == Constants.SYMBOL_QUOTE ||
			// Don't add Constants.SYMBOL_DOUBLE_QUOTE to avoid analyzing in text strings
			character == Constants.SYMBOL_OPEN_ROUNDED_BRACKET ||
			character == Constants.SYMBOL_CLOSE_ROUNDED_BRACKET ||
			character == Constants.SYMBOL_OPEN_CURVED_BRACKET ||
			character == Constants.SYMBOL_CLOSE_CURVED_BRACKET ||
			character == Constants.SYMBOL_OPEN_HOOKED_BRACKET ||
			character == Constants.SYMBOL_CLOSE_HOOKED_BRACKET ||
			character == Constants.SYMBOL_OPEN_SQUARE_BRACKET ||
			character == Constants.SYMBOL_CLOSE_SQUARE_BRACKET );
		}

	private ReadResultType createWordStrings( int startPosition, String wordString )
		{
		ReadResultType readResult = new ReadResultType();
		exactWordString_ = null;
		lowerCaseWordString_ = null;

		if( wordString != null )
			{
			if( ( readResult = getWordInfo( false, startPosition, wordString ) ).result == Constants.RESULT_OK )
				{
				if( readResult.wordLength > 0 )
					{
					exactWordString_ = wordString.substring( startPosition, ( startPosition + readResult.wordLength ) );
					lowerCaseWordString_ = wordString.substring( startPosition, ( startPosition + readResult.wordLength ) ).toLowerCase();
					}
				else
					myWord_.startErrorInItem( 1, moduleNameString_, "The given word string is empty or has no words left anymore" );
				}
			else
				myWord_.addErrorInItem( 1, moduleNameString_, "I failed to get the length of the given word string" );
			}
		else
			myWord_.startErrorInItem( 1, moduleNameString_, "The given word string is undefined" );

		readResult.result = CommonVariables.result;
		return readResult;
		}

	private byte comparePluralEndingOfWord( int singularNounWordStringLength, int nounWordStringLength, String singularNounEndingString, String nounWordString, String pluralNounEndingString )
		{
		int tempWordLength;
		int pluralNounEndingStringLength;

		isProbablyPluralNoun_ = false;
		singularWordLength_ = 0;
		singularNounString_ = null;

		if( nounWordStringLength > 0 )
			{
			if( nounWordString != null )
				{
				if( pluralNounEndingString != null )
					{
					pluralNounEndingStringLength = pluralNounEndingString.length();
					tempWordLength = ( nounWordStringLength - pluralNounEndingStringLength );
					singularWordLength_ = ( nounWordStringLength + singularNounWordStringLength - pluralNounEndingStringLength );

					if( tempWordLength >= 0 &&
					singularWordLength_ > 0 )
						{
						if( nounWordString.substring( tempWordLength ).startsWith( pluralNounEndingString ) )
							{
							isProbablyPluralNoun_ = true;
							singularNounString_ = nounWordString.substring( 0, tempWordLength ) + ( singularNounEndingString == null ? Constants.EMPTY_STRING : singularNounEndingString );
							}
						}
					}
				else
					return myWord_.startErrorInItem( 1, moduleNameString_, "The grammar string is undefined" );
				}
			else
				return myWord_.startErrorInItem( 1, moduleNameString_, "The given noun word string is undefined" );
			}
		else
			return myWord_.startErrorInItem( 1, moduleNameString_, "The noun word string length is undefined" );

		return CommonVariables.result;
		}

	private byte checkNounWordType( int nounWordStringLength, String nounWordString, GrammarItem pluralNounEndingGrammarItem )
		{
		String singularNounEndingString = null;
		GrammarItem singularNounEndingGrammarItem;

		isProbablyPluralNoun_ = false;
		singularWordLength_ = 0;
		singularNounString_ = null;

		if( nounWordStringLength > 0 )
			{
			if( nounWordString != null )
				{
				if( pluralNounEndingGrammarItem != null )
					{
					do	{
						if( pluralNounEndingGrammarItem.isDefinitionStart() )
							{
							singularNounEndingGrammarItem = pluralNounEndingGrammarItem.nextDefinitionGrammarItem;
							singularNounEndingString = ( singularNounEndingGrammarItem == null ? null : singularNounEndingGrammarItem.grammarString() );

							if( comparePluralEndingOfWord( ( singularNounEndingString == null ? 0 : singularNounEndingString.length() ), nounWordStringLength, singularNounEndingString, nounWordString, pluralNounEndingGrammarItem.itemString() ) != Constants.RESULT_OK )
								return myWord_.addErrorInItem( 1, moduleNameString_, "I failed to find the plural ending of an undefined word type" );
							}
						}
					while( !isProbablyPluralNoun_ &&
					( pluralNounEndingGrammarItem = pluralNounEndingGrammarItem.nextPluralNounEndingGrammarItem() ) != null );
					}
				else
					return myWord_.startErrorInItem( 1, moduleNameString_, "The current grammar language word item is undefined" );
				}
			else
				return myWord_.startErrorInItem( 1, moduleNameString_, "The given noun word string is undefined" );
			}
		else
			return myWord_.startErrorInItem( 1, moduleNameString_, "The given noun word string is empty" );

		return CommonVariables.result;
		}

	private byte checkNounWordTypeOfAllLanguages( int nounWordStringLength, String nounWordString )
		{
		GeneralizationItem currentGeneralizationItem;
		GrammarItem pluralNounEndingGrammarItem;
		WordItem currentGeneralizationWordItem;
		WordItem currentGrammarLanguageWordItem;

		singularWordLength_ = 0;
		singularNounString_ = null;

		if( ( currentGrammarLanguageWordItem = CommonVariables.currentGrammarLanguageWordItem ) != null )
			{
			if( ( pluralNounEndingGrammarItem = CommonVariables.currentGrammarLanguageWordItem.firstPluralNounEndingGrammarItem() ) != null )
				{
				if( checkNounWordType( nounWordStringLength, nounWordString, pluralNounEndingGrammarItem ) == Constants.RESULT_OK )
					{
					if( !isProbablyPluralNoun_ )
						{
						if( CommonVariables.predefinedNounGrammarLanguageWordItem != null )
							{
							if( ( currentGeneralizationItem = CommonVariables.predefinedNounGrammarLanguageWordItem.firstActiveGeneralizationItemOfSpecification() ) != null )
								{
								do	{
									if( ( currentGeneralizationWordItem = currentGeneralizationItem.generalizationWordItem() ) != null )
										{
										if( currentGeneralizationWordItem != currentGrammarLanguageWordItem )
											{
											if( ( pluralNounEndingGrammarItem = currentGeneralizationWordItem.firstPluralNounEndingGrammarItem() ) != null )
												{
												if( checkNounWordType( nounWordStringLength, nounWordString, pluralNounEndingGrammarItem ) != Constants.RESULT_OK )
													return myWord_.addErrorInItem( 1, moduleNameString_, "I failed to check for noun type" );
												}
											else
												return myWord_.startErrorInItem( 1, moduleNameString_, "I failed to get the first plural noun ending grammar item of grammar word \"" + currentGeneralizationWordItem.anyWordTypeString() + "\"" );
											}
										}
									}
								while( !isProbablyPluralNoun_ &&
								( currentGeneralizationItem = currentGeneralizationItem.nextGeneralizationItemOfSpecification() ) != null );
								}
							}
						else
							return myWord_.startErrorInItem( 1, moduleNameString_, "The predefined grammar language noun word item is undefined" );
						}
					}
				else
					return myWord_.addErrorInItem( 1, moduleNameString_, "I failed to check for noun type" );
				}
			else
				return myWord_.startErrorInItem( 1, moduleNameString_, "I failed to get the first plural noun ending grammar item" );
			}
		else
			return myWord_.startErrorInItem( 1, moduleNameString_, "The current grammar language word item is undefined" );

		return CommonVariables.result;
		}

	private byte getWordTypeNr( boolean checkPropername, int wordTypeStringLength, String wordTypeString )
		{
		int wordPosition = 0;

		wordTypeNr_ = Constants.WORD_TYPE_UNDEFINED;

		if( wordTypeString != null )
			{
			if( wordTypeStringLength > 0 )
				{
				if( Character.isLetter( wordTypeString.charAt( wordPosition ) ) )
					{
					if( wordTypeStringLength == 1 )
						wordTypeNr_ = ( Character.isUpperCase( wordTypeString.charAt( wordPosition ) ) ? Constants.WORD_TYPE_LETTER_CAPITAL : Constants.WORD_TYPE_LETTER_SMALL );
					else
						{
						if( checkPropername &&
						Character.isUpperCase( wordTypeString.charAt( wordPosition ) ) )
							wordTypeNr_ = Constants.WORD_TYPE_PROPER_NAME;
						}
					}
				else
					{
					while( wordPosition < wordTypeStringLength &&
					Character.isDigit( wordTypeString.charAt( wordPosition ) ) )
						wordPosition++;

					if( wordPosition == wordTypeStringLength )
						wordTypeNr_ = Constants.WORD_TYPE_NUMERAL;
					}
				}
			else
				return myWord_.startErrorInItem( 1, moduleNameString_, "The given word type string is empty" );
			}
		else
			return myWord_.startErrorInItem( 1, moduleNameString_, "The given word type string is undefined" );

		return CommonVariables.result;
		}


	// Constructor

	protected AdminReadCreateWords( AdminItem admin, WordItem myWord )
		{
		String errorString = null;

		hasCreatedReadWord_ = false;
		isProbablyPluralNoun_ = false;

		currentWordOrderNr_ = Constants.NO_ORDER_NR;
		wordTypeNr_ = Constants.WORD_TYPE_UNDEFINED;

		nextTextStringPosition_ = 0;
		singularWordLength_ = 0;

		exactWordString_ = null;
		lowerCaseWordString_ = null;
		singularNounString_ = null;

		admin_ = admin;
		myWord_ = myWord;
		moduleNameString_ = this.getClass().getName();

		if( admin_ != null )
			{
			if( myWord_ == null )
				errorString = "The given my word is undefined";
			}
		else
			errorString = "The given admin is undefined";

		if( errorString != null )
			{
			if( myWord_ != null )
				myWord_.startSystemErrorInItem( 1, moduleNameString_, errorString );
			else
				{
				CommonVariables.result = Constants.RESULT_SYSTEM_ERROR;
				Console.addError( "\nClass:" + moduleNameString_ + "\nMethod:\t" + Constants.PRESENTATION_ERROR_CONSTRUCTOR_METHOD_NAME + "\nError:\t\t" + errorString + ".\n" );
				}
			}
		}


	// Protected methods

	protected ReadResultType createReadWord( short wordOrderNr, short wordTypeNr, int textStringStartPosition, String textString, WordItem readWordItem )
		{
		ReadResultType readResult = new ReadResultType();
		short wordParameter = ( wordTypeNr == Constants.WORD_TYPE_NOUN_PLURAL || readWordItem == null ? Constants.NO_WORD_PARAMETER : readWordItem.wordParameter() );
		String readString = null;

		hasCreatedReadWord_ = false;
		nextTextStringPosition_ = 0;

		if( wordTypeNr > Constants.WORD_TYPE_UNDEFINED )
			{
			if( textString != null ||
			readWordItem != null )
				{
				if( textString != null )
					{
					if( ( readResult = getWordInfo( true, textStringStartPosition, textString ) ).result == Constants.RESULT_OK )
						{
						if( readResult.startWordPosition < textString.length() )
							{
							nextTextStringPosition_ = readResult.nextWordPosition;
							readString = textString.substring( readResult.startWordPosition );
							}
						else
							myWord_.startErrorInItem( 1, moduleNameString_, "The found start word position is invalid" );
						}
					else
						myWord_.addErrorInItem( 1, moduleNameString_, "I failed to get the length of the current text string" );
					}

				if( CommonVariables.result == Constants.RESULT_OK )
					{
					if( admin_.readList == null )
						{
						// Create list
						if( ( admin_.readList = new ReadList( myWord_ ) ) != null )
							admin_.adminList[Constants.ADMIN_READ_LIST] = admin_.readList;
						else
							myWord_.startErrorInItem( 1, moduleNameString_, "I failed to create a read list" );
						}
					else
						{
						// Find out if already exists
						if( admin_.readList.hasFoundReadItem( wordOrderNr, wordParameter, wordTypeNr, CommonVariables.currentGrammarLanguageNr, readString, readWordItem ) )
							myWord_.startErrorInItem( 1, moduleNameString_, "The given read item already exists" );
						}

					if( ( readResult = admin_.readList.createReadItem( wordOrderNr, wordParameter, wordTypeNr, readResult.wordLength, readString, readWordItem ) ).result == Constants.RESULT_OK )
						hasCreatedReadWord_ = true;
					else
						myWord_.addErrorInItem( 1, moduleNameString_, "I failed to create an admin read words item" );
					}
				}
			else
				myWord_.startErrorInItem( 1, moduleNameString_, "Both the given text string and the given read word item are undefined" );
			}
		else
			myWord_.startErrorInItem( 1, moduleNameString_, "The given word type number is undefined" );

		readResult.result = CommonVariables.result;
		return readResult;
		}

	protected ReadResultType createReadWords( String readSentenceString )
		{
		ReadResultType readResult = new ReadResultType();
		WordResultType wordResult = new WordResultType();
		boolean hasFoundExactWord;
		boolean hasFoundSingularNounWord;
		boolean hasFoundPluralNounWord;
		boolean isFirstFind;
		boolean wasPreviousWordAdjective;
		boolean wasPreviousWordArticle;
		boolean wasPreviousWordConjunction;
		boolean wasPreviousWordPossessiveDeterminer;
		boolean wasPreviousWordPossessivePronoun;
		boolean wasPreviousWordSymbol;
		boolean wasPreviousWordUndefined = false;
		boolean isFirstWord = true;
		boolean isSymbol = false;
		boolean isLetter = false;
		boolean isNumeral = false;
		boolean isAdjective = false;
		boolean isArticle = false;
		boolean isConjunction = false;
		boolean isPossessiveDeterminer = false;
		boolean isPossessivePronoun = false;
		boolean isUndefinedWord = false;
		boolean isBasicVerb = false;
		boolean isVerb = false;
		short previousWordDefiniteArticleParameter;
		short previousWordIndefiniteArticleParameter;
		short currentWordDefiniteArticleParameter = Constants.NO_DEFINITE_ARTICLE_PARAMETER;
		short currentWordIndefiniteArticleParameter = Constants.NO_INDEFINITE_ARTICLE_PARAMETER;
		int readSentenceStringLength;
		int wordStringLength;
		int nextWordPosition = 0;
		int readPosition = 0;
		WordItem createdWordItem;
		WordItem foundWordItem;
		WordItem pluralNounWordItem;
		WordItem singularNounWordItem;
		WordTypeItem foundWordTypeItem;

		hasCreatedReadWord_ = true;		// Set to pass while loop for the first time
		currentWordOrderNr_ = Constants.NO_ORDER_NR;

		if( readSentenceString != null )
			{
			if( ( readSentenceStringLength = readSentenceString.length() ) > 0 )
				{
				do	{
					if( ++currentWordOrderNr_ < Constants.MAX_ORDER_NR )
						{
						if( currentWordOrderNr_ > 1 )
							isFirstWord = false;

						hasCreatedReadWord_ = false;

						if( readSentenceString.charAt( readPosition ) == Constants.SYMBOL_DOUBLE_QUOTE )
							{
							if( createReadWord( currentWordOrderNr_, Constants.WORD_TYPE_TEXT, readPosition, readSentenceString, null ).result == Constants.RESULT_OK )
								nextWordPosition = nextTextStringPosition_;
							else
								myWord_.addErrorInItem( 1, moduleNameString_, "I failed to create a read word" );
							}
						else
							{
							hasFoundExactWord = false;
							hasFoundSingularNounWord = false;
							hasFoundPluralNounWord = false;

							wasPreviousWordAdjective = isAdjective;
							wasPreviousWordArticle = isArticle;
							wasPreviousWordConjunction = isConjunction;
							wasPreviousWordPossessiveDeterminer = isPossessiveDeterminer;
							wasPreviousWordPossessivePronoun = isPossessivePronoun;
							wasPreviousWordSymbol = isSymbol;
							wasPreviousWordUndefined = isUndefinedWord;

							previousWordDefiniteArticleParameter = currentWordDefiniteArticleParameter;
							previousWordIndefiniteArticleParameter = currentWordIndefiniteArticleParameter;

							isSymbol = false;
							isLetter = false;
							isNumeral = false;
							isAdjective = false;
							isArticle = false;
							isConjunction = false;
							isPossessiveDeterminer = false;
							isPossessivePronoun = false;
							isUndefinedWord = false;
							isBasicVerb = false;
							isVerb = false;

							currentWordDefiniteArticleParameter = Constants.NO_DEFINITE_ARTICLE_PARAMETER;
							currentWordIndefiniteArticleParameter = Constants.NO_INDEFINITE_ARTICLE_PARAMETER;

							createdWordItem = null;
							pluralNounWordItem = null;
							singularNounWordItem = null;

							if( ( readResult = createWordStrings( readPosition, readSentenceString ) ).result == Constants.RESULT_OK )
								{
								nextWordPosition = readResult.nextWordPosition;
								wordStringLength = readResult.wordLength;
								foundWordItem = null;

								// Step 1: Find exact word types in all words
								do	{
									if( ( wordResult = myWord_.findWordTypeInAllWords( false, Constants.WORD_TYPE_UNDEFINED, exactWordString_, foundWordItem ) ).result == Constants.RESULT_OK )
										{
										foundWordItem = wordResult.foundWordItem;
										foundWordTypeItem = wordResult.foundWordTypeItem;

										if( foundWordItem != null &&
										foundWordTypeItem != null )		// Found exact word
											{
											if( createReadWord( currentWordOrderNr_, foundWordTypeItem.wordTypeNr(), 0, null, foundWordItem ).result == Constants.RESULT_OK )
												{
												hasFoundExactWord = true;

												if( foundWordItem.isBasicVerb() )
													isBasicVerb = true;

												if( foundWordTypeItem.isWordTypeAdjective() )
													{
													isAdjective = true;

													if( wordResult.foundWordItem != null &&
													wordResult.foundWordItem.isAdjectiveNo() )		// Adjective 'no' can be used as article
														isArticle = true;
													}

												if( foundWordTypeItem.isWordTypeArticle() )
													isArticle = true;

												if( foundWordTypeItem.isWordTypeConjunction() )
													isConjunction = true;

												if( foundWordTypeItem.isWordTypeLetter() )
													isLetter = true;

												if( foundWordTypeItem.isWordTypeNumeral() )
													isNumeral = true;

												if( foundWordTypeItem.isWordTypePossessiveDeterminer() )
													isPossessiveDeterminer = true;

												if( foundWordTypeItem.isWordTypePossessivePronoun() )
													isPossessivePronoun = true;

												if( foundWordTypeItem.isWordTypeSymbol() )
													isSymbol = true;

												if( foundWordTypeItem.isWordTypeDefiniteArticle() )
													currentWordDefiniteArticleParameter = foundWordTypeItem.definiteArticleParameter();

												if( foundWordTypeItem.isWordTypeIndefiniteArticle() )
													currentWordIndefiniteArticleParameter = foundWordTypeItem.indefiniteArticleParameter();

												if( foundWordTypeItem.isWordTypePluralNoun() )
													hasFoundPluralNounWord = true;

												if( foundWordTypeItem.isWordTypeSingularNoun() )
													{
													hasFoundSingularNounWord = true;

													if( foundWordTypeItem.hasUndefinedDefiniteArticle() &&

													( previousWordDefiniteArticleParameter == Constants.WORD_PARAMETER_ARTICLE_DEFINITE_1 ||
													previousWordDefiniteArticleParameter == Constants.WORD_PARAMETER_ARTICLE_DEFINITE_2 ) )
														{
														if( foundWordTypeItem.setDefiniteArticleParameter( previousWordDefiniteArticleParameter ) != Constants.RESULT_OK )
															myWord_.addErrorInItem( 1, moduleNameString_, "I failed to set the definite article parameter of a singular noun" );
														}
													else
														{
														// Typically for English: Store the use of 'a' or 'an'
														if( foundWordTypeItem.hasUndefinedIndefiniteArticle() &&

														( previousWordIndefiniteArticleParameter == Constants.WORD_PARAMETER_ARTICLE_INDEFINITE_1 ||
														previousWordIndefiniteArticleParameter == Constants.WORD_PARAMETER_ARTICLE_INDEFINITE_2 ) )
															{
															if( foundWordTypeItem.setIndefiniteArticleParameter( previousWordIndefiniteArticleParameter ) != Constants.RESULT_OK )
																myWord_.addErrorInItem( 1, moduleNameString_, "I failed to set the indefinite article parameter of a singular noun" );
															}
														}
													}
												}
											else
												myWord_.addErrorInItem( 1, moduleNameString_, "I failed to create another read word" );
											}
										}
									else
										myWord_.addErrorInItem( 1, moduleNameString_, "I failed to find an exact word type in all words" );
									}
								while( CommonVariables.result == Constants.RESULT_OK &&
								foundWordItem != null );	// Allow multiple finds

								if( CommonVariables.result == Constants.RESULT_OK &&
								isFirstWord &&
								Character.isUpperCase( readSentenceString.charAt( readPosition ) ) )
									{
									if( getWordTypeNr( false, wordStringLength, lowerCaseWordString_ ) == Constants.RESULT_OK )
										{
										foundWordItem = null;

										if( wordTypeNr_ == Constants.WORD_TYPE_UNDEFINED )
											isUndefinedWord = true;

										// Step 2: Find word type with lowercase first letter in all words
										do	{
											if( ( wordResult = myWord_.findWordTypeInAllWords( true, Constants.WORD_TYPE_UNDEFINED, lowerCaseWordString_, foundWordItem ) ).result == Constants.RESULT_OK )
												{
												foundWordItem = wordResult.foundWordItem;
												foundWordTypeItem = wordResult.foundWordTypeItem;

												if( foundWordItem != null &&
												foundWordTypeItem != null )		// Found word type with lowercase first letter
													{
													if( foundWordTypeItem.wordTypeNr() == wordTypeNr_ &&
													foundWordTypeItem.wordTypeLanguageNr() != CommonVariables.currentGrammarLanguageNr )
														{
														// Create same word type for different language
														if( foundWordItem.addWordType( false, Constants.NO_DEFINITE_ARTICLE_PARAMETER, Constants.NO_INDEFINITE_ARTICLE_PARAMETER, wordTypeNr_, wordStringLength, lowerCaseWordString_ ) != Constants.RESULT_OK )
															myWord_.addErrorInItem( 1, moduleNameString_, "I failed to add a word type with lowercase first letter" );
														}

													if( createReadWord( currentWordOrderNr_, foundWordTypeItem.wordTypeNr(), 0, null, foundWordItem ).result == Constants.RESULT_OK )
														{
														if( foundWordTypeItem.isWordTypeAdjective() )
															{
															isAdjective = true;

															if( wordResult.foundWordItem != null &&
															wordResult.foundWordItem.isAdjectiveNo() )		// Adjective 'no' can be used as article
																isArticle = true;
															}

														if( foundWordTypeItem.isWordTypeArticle() )
															isArticle = true;

														if( foundWordTypeItem.isWordTypeLetter() )
															isLetter = true;

														if( foundWordTypeItem.isWordTypePossessiveDeterminer() )
															isPossessiveDeterminer = true;

														if( foundWordTypeItem.isWordTypePossessivePronoun() )
															isPossessivePronoun = true;

														if( foundWordTypeItem.isWordTypeSingularNoun() )
															hasFoundSingularNounWord = true;

														if( foundWordTypeItem.isWordTypePluralNoun() )
															hasFoundPluralNounWord = true;

														if( foundWordTypeItem.isWordTypeVerb() )
															isVerb = true;

														if( foundWordTypeItem.isWordTypeDefiniteArticle() )
															currentWordDefiniteArticleParameter = foundWordTypeItem.definiteArticleParameter();

														if( foundWordTypeItem.isWordTypeIndefiniteArticle() )
															currentWordIndefiniteArticleParameter = foundWordTypeItem.indefiniteArticleParameter();
														}
													else
														myWord_.addErrorInItem( 1, moduleNameString_, "I failed to create a read word with a word type with difference case of the first letter" );
													}
												}
											else
												myWord_.addErrorInItem( 1, moduleNameString_, "I failed to find a word type with difference case of the first letter in all words" );
											}
										while( CommonVariables.result == Constants.RESULT_OK &&
										foundWordItem != null );	// Allow multiple finds

										if( CommonVariables.result == Constants.RESULT_OK &&
										!isUndefinedWord &&
										wordStringLength == 1 )
											{
											// Step 3: Typically for English: Find or create lowercase letter 'a' as first letter of a sentence.
											if( ( wordResult = myWord_.findWordTypeInAllWords( true, wordTypeNr_, lowerCaseWordString_, null ) ).result == Constants.RESULT_OK )
												{
												if( wordResult.foundWordItem == null )
													{
													if( ( wordResult = createWord( Constants.NO_DEFINITE_ARTICLE_PARAMETER, Constants.NO_INDEFINITE_ARTICLE_PARAMETER, wordTypeNr_, Constants.NO_WORD_PARAMETER, wordStringLength, lowerCaseWordString_ ) ).result == Constants.RESULT_OK )
														{
														if( ( createdWordItem = wordResult.createdWordItem ) != null )
															{
															if( createReadWord( currentWordOrderNr_, wordTypeNr_, 0, null, createdWordItem ).result != Constants.RESULT_OK )
																myWord_.addErrorInItem( 1, moduleNameString_, "I failed to create a read word with lowercase letter" );
															}
														else
															myWord_.startErrorInItem( 1, moduleNameString_, "The created word with lowercase letter is undefined" );
														}
													else
														myWord_.addErrorInItem( 1, moduleNameString_, "I failed to create word with lowercase letter" );
													}
												}
											else
												myWord_.addErrorInItem( 1, moduleNameString_, "I failed to find a lowercase letter" );
											}
										}
									else
										myWord_.addErrorInItem( 1, moduleNameString_, "I failed to get the word type number of a lowercase word" );
									}

								if( CommonVariables.result == Constants.RESULT_OK &&

								( !hasFoundExactWord ||
								isPossessivePronoun ) )		// Typically for Dutch: 'u' is a letter as well as a possessive pronoun
									{
									isFirstFind = true;
									foundWordItem = null;

									// Step 4: Find exact word types in all words
									do	{
										if( ( wordResult = myWord_.findWordTypeInAllWords( true, Constants.WORD_TYPE_UNDEFINED, exactWordString_, foundWordItem ) ).result == Constants.RESULT_OK )
											{
											createdWordItem = null;
											foundWordItem = wordResult.foundWordItem;
											foundWordTypeItem = wordResult.foundWordTypeItem;

											if( isFirstFind ||

											( foundWordItem != null &&
											foundWordTypeItem != null ) )	// Skip if later runs have no result
												{
												if( getWordTypeNr( true, wordStringLength, exactWordString_ ) == Constants.RESULT_OK )
													{
													if( wordTypeNr_ == Constants.WORD_TYPE_UNDEFINED )
														isUndefinedWord = true;
													else
														{
														if( foundWordItem == null )
															{
															// Small letters, capital letters, numerals and proper-names
															if( ( wordResult = createWord( previousWordDefiniteArticleParameter, previousWordIndefiniteArticleParameter, wordTypeNr_, Constants.NO_WORD_PARAMETER, wordStringLength, exactWordString_ ) ).result == Constants.RESULT_OK )
																{
																if( ( createdWordItem = wordResult.createdWordItem ) == null )
																	myWord_.startErrorInItem( 1, moduleNameString_, "The last created exact word is undefined" );
																}
															else
																myWord_.addErrorInItem( 1, moduleNameString_, "I failed to create an exact word" );
															}
														else
															{
															if( foundWordTypeItem.wordTypeNr() == wordTypeNr_ &&
															foundWordTypeItem.wordTypeLanguageNr() != CommonVariables.currentGrammarLanguageNr )
																{
																// Create same word type for different language
																if( foundWordItem.addWordType( false, Constants.NO_DEFINITE_ARTICLE_PARAMETER, Constants.NO_INDEFINITE_ARTICLE_PARAMETER, wordTypeNr_, wordStringLength, exactWordString_ ) == Constants.RESULT_OK )
																	createdWordItem = foundWordItem;
																else
																	myWord_.addErrorInItem( 1, moduleNameString_, "I failed to add an exact word type" );
																}
															}

														if( CommonVariables.result == Constants.RESULT_OK &&
														createdWordItem != null )
															{
															if( createReadWord( currentWordOrderNr_, wordTypeNr_, 0, null, createdWordItem ).result == Constants.RESULT_OK )
																isFirstFind = false;
															else
																myWord_.addErrorInItem( 1, moduleNameString_, "I failed to create an exact read word" );
															}
														}
													}
												else
													myWord_.addErrorInItem( 1, moduleNameString_, "I failed to get the word type number of an exact word" );
												}
											}
										else
											myWord_.addErrorInItem( 1, moduleNameString_, "I failed to find an exact word" );
										}
									while( CommonVariables.result == Constants.RESULT_OK &&
									foundWordItem != null );	// Allow multiple finds
									}

								// Create a noun
								if( CommonVariables.result == Constants.RESULT_OK &&
								!isSymbol &&
								!isLetter &&
								!isNumeral &&
								!isAdjective &&
								!isArticle &&
								!isConjunction &&
								!isPossessiveDeterminer &&
								!isPossessivePronoun &&
								!isBasicVerb &&
								!isVerb &&
								wordStringLength > 1 &&

								( isUndefinedWord ||
								wasPreviousWordArticle ||
								wasPreviousWordConjunction ||
								wasPreviousWordSymbol ) &&

								( isFirstWord ||
								!Character.isUpperCase( readSentenceString.charAt( readPosition ) ) ) )
									{
									if( checkNounWordTypeOfAllLanguages( wordStringLength, exactWordString_ ) == Constants.RESULT_OK )
										{
										if( isFirstWord ||
										isProbablyPluralNoun_ ||
										wasPreviousWordAdjective ||
										wasPreviousWordArticle ||
										wasPreviousWordConjunction ||
										wasPreviousWordSymbol ||
										wasPreviousWordPossessiveDeterminer ||
										wasPreviousWordPossessivePronoun )
											{
											if( isProbablyPluralNoun_ )
												{
												if( ( wordResult = myWord_.findWordTypeInAllWords( true, Constants.WORD_TYPE_NOUN_SINGULAR, singularNounString_, null ) ).result == Constants.RESULT_OK )
													{
													if( ( foundWordItem = wordResult.foundWordItem ) == null )
														{
														if( !hasFoundSingularNounWord )
															{
															if( ( wordResult = createWord( Constants.NO_DEFINITE_ARTICLE_PARAMETER, Constants.NO_INDEFINITE_ARTICLE_PARAMETER, Constants.WORD_TYPE_NOUN_PLURAL, Constants.NO_WORD_PARAMETER, wordStringLength, exactWordString_ ) ).result == Constants.RESULT_OK )
																{
																if( ( pluralNounWordItem = wordResult.createdWordItem ) != null )
																	{
																	if( pluralNounWordItem.addWordType( false, Constants.NO_DEFINITE_ARTICLE_PARAMETER, Constants.NO_INDEFINITE_ARTICLE_PARAMETER, Constants.WORD_TYPE_NOUN_SINGULAR, singularWordLength_, singularNounString_ ) == Constants.RESULT_OK )
																		singularNounWordItem = pluralNounWordItem;
																	else
																		myWord_.addErrorInItem( 1, moduleNameString_, "I failed to add a singular noun word type item for plural noun word \"" + pluralNounWordItem.anyWordTypeString() + "\"" );
																	}
																else
																	myWord_.startErrorInItem( 1, moduleNameString_, "The created word item is undefined" );
																}
															else
																myWord_.addErrorInItem( 1, moduleNameString_, "I failed to create a singular noun word" );
															}
														}
													else	// Found singular noun
														{
														if( !hasFoundPluralNounWord )
															{
															if( foundWordItem.addWordType( false, Constants.NO_DEFINITE_ARTICLE_PARAMETER, Constants.NO_INDEFINITE_ARTICLE_PARAMETER, Constants.WORD_TYPE_NOUN_PLURAL, wordStringLength, exactWordString_ ) == Constants.RESULT_OK )
																pluralNounWordItem = foundWordItem;
															else
																myWord_.addErrorInItem( 1, moduleNameString_, "I failed to add a plural noun word type item for word \"" + foundWordItem.anyWordTypeString() + "\"" );
															}
														}
													}
												else
													myWord_.addErrorInItem( 1, moduleNameString_, "I failed to find if a singular noun word already exists" );
												}
											else
												{
												if( !hasFoundSingularNounWord )
													{
													if( ( wordResult = createWord( previousWordDefiniteArticleParameter, previousWordIndefiniteArticleParameter, Constants.WORD_TYPE_NOUN_SINGULAR, Constants.NO_WORD_PARAMETER, wordStringLength, exactWordString_ ) ).result == Constants.RESULT_OK )
														singularNounWordItem = wordResult.createdWordItem;
													else
														myWord_.addErrorInItem( 1, moduleNameString_, "I failed to create a singular noun word" );
													}
												}

											if( CommonVariables.result == Constants.RESULT_OK &&
											singularNounWordItem != null )
												{
												if( createReadWord( currentWordOrderNr_, Constants.WORD_TYPE_NOUN_SINGULAR, 0, null, singularNounWordItem ).result != Constants.RESULT_OK )
													myWord_.addErrorInItem( 1, moduleNameString_, "I failed to create a singular noun read word" );
												}

											if( CommonVariables.result == Constants.RESULT_OK &&
											pluralNounWordItem != null )
												{
												if( createReadWord( currentWordOrderNr_, Constants.WORD_TYPE_NOUN_PLURAL, 0, null, pluralNounWordItem ).result != Constants.RESULT_OK )
													myWord_.addErrorInItem( 1, moduleNameString_, "I failed to create a plural noun read word" );
												}
											}

										// Create an adjective
										if( CommonVariables.result == Constants.RESULT_OK &&
										!hasFoundExactWord &&
										!wasPreviousWordUndefined &&

										( wasPreviousWordConjunction ||
										wasPreviousWordSymbol ||
										pluralNounWordItem == null ) )
											{
											if( ( wordResult = createWord( Constants.NO_DEFINITE_ARTICLE_PARAMETER, Constants.NO_INDEFINITE_ARTICLE_PARAMETER, Constants.WORD_TYPE_ADJECTIVE, Constants.NO_WORD_PARAMETER, wordStringLength, lowerCaseWordString_ ) ).result == Constants.RESULT_OK )
												{
												if( ( createdWordItem = wordResult.createdWordItem ) != null )
													{
													if( createReadWord( currentWordOrderNr_, Constants.WORD_TYPE_ADJECTIVE, 0, null, createdWordItem ).result == Constants.RESULT_OK )
														isAdjective = true;
													else
														myWord_.addErrorInItem( 1, moduleNameString_, "I failed to create an adjective read word" );
													}
												else
													myWord_.startErrorInItem( 1, moduleNameString_, "The last created adjective word is undefined" );
												}
											else
												myWord_.addErrorInItem( 1, moduleNameString_, "I failed to create an adjective word" );
											}
										}
									else
										myWord_.addErrorInItem( 1, moduleNameString_, "I failed to check a noun word type in all languages" );
									}
								}
							else
								myWord_.addErrorInItem( 1, moduleNameString_, "I failed to create the word strings" );
							}

						readPosition = nextWordPosition;
						}
					else
						myWord_.startSystemErrorInItem( 1, moduleNameString_, "Word order number overflow! I can't accept more words" );
					}
				while( CommonVariables.result == Constants.RESULT_OK &&
				hasCreatedReadWord_ &&
				readPosition < readSentenceStringLength );
				}
			else
				myWord_.startErrorInItem( 1, moduleNameString_, "The given read sentence string is empty" );
			}
		else
			myWord_.startErrorInItem( 1, moduleNameString_, "The given read sentence string is undefined" );

		readResult.hasCreatedAllReadWords = hasCreatedReadWord_;
		readResult.result = CommonVariables.result;
		return readResult;
		}

	protected ReadResultType getWordInfo( boolean skipDoubleQuotes, int startWordPosition, String wordString )
		{
		ReadResultType readResult = new ReadResultType();
		boolean text = false;
		boolean wordStartedWithDoubleQuote = false;
		int wordStringLength;
		int wordPosition = startWordPosition;

		if( wordString != null )
			{
			wordStringLength = wordString.length();

			if( wordPosition < wordStringLength )
				{
				while( wordPosition < wordStringLength &&
				Character.isWhitespace( wordString.charAt( wordPosition ) ) )
					wordPosition++;

				if( wordPosition < wordStringLength )
					{
					readResult.startWordPosition = wordPosition;

					if( isSymbol( wordString.charAt( wordPosition ) ) )
						{
						wordPosition++;
						readResult.wordLength++;
						}
					else
						{
						if( skipDoubleQuotes &&
						wordString.charAt( wordPosition ) == Constants.SYMBOL_DOUBLE_QUOTE )
							wordStartedWithDoubleQuote = true;

						while( wordPosition < wordStringLength &&

						( text ||
						( !Character.isWhitespace( wordString.charAt( wordPosition ) ) &&
						!isSymbol( wordString.charAt( wordPosition ) ) ) ) )
							{
							if( wordString.charAt( wordPosition ) == Constants.SYMBOL_DOUBLE_QUOTE &&

							( wordPosition == 0 ||
							wordString.charAt( wordPosition - 1 ) != Constants.SYMBOL_BACK_SLASH ) )	// Skip escaped double quote character
								text = !text;

							wordPosition++;
							readResult.wordLength++;
							}

						if( wordStartedWithDoubleQuote &&
						readResult.wordLength > 1 )
							readResult.wordLength--;

						if( skipDoubleQuotes &&
						wordPosition > 1 &&
						readResult.wordLength > 1 &&
						wordString.charAt( wordPosition - 1 ) == Constants.SYMBOL_DOUBLE_QUOTE )
							{
							readResult.wordLength--;
							readResult.startWordPosition++;
							}
						}

					while( wordPosition < wordStringLength &&
					Character.isWhitespace( wordString.charAt( wordPosition ) ) )
						wordPosition++;
					}
				}
			else
				myWord_.startErrorInItem( 1, moduleNameString_, "The given start word position is invalid" );
			}
		else
			myWord_.startErrorInItem( 1, moduleNameString_, "The given word string is undefined" );

		readResult.result = CommonVariables.result;
		readResult.nextWordPosition = wordPosition;
		return readResult;
		}

	protected WordResultType createWord( short previousWordDefiniteArticleParameter, short previousWordIndefiniteArticleParameter, short wordTypeNr, short wordParameter, int wordTypeStringLength, String wordTypeString )
		{
		WordResultType wordResult = new WordResultType();
		boolean isPropernamePrecededByDefiniteArticle;
		boolean wasPreviousWordDefiniteArticle = ( previousWordDefiniteArticleParameter > Constants.NO_DEFINITE_ARTICLE_PARAMETER );
		boolean wasPreviousWordIndefiniteArticle = ( previousWordIndefiniteArticleParameter > Constants.NO_INDEFINITE_ARTICLE_PARAMETER );
		short definiteArticleParameter = Constants.NO_DEFINITE_ARTICLE_PARAMETER;
		short indefiniteArticleParameter = Constants.NO_INDEFINITE_ARTICLE_PARAMETER;
		WordItem createdWordItem;

		if( wordTypeString != null )
			{
			if( wordTypeStringLength > 0 &&
			wordTypeString.length() > 0 )
				{
				if( wordTypeNr > Constants.WORD_TYPE_UNDEFINED )
					{
					if( admin_.wordList == null )
						{
						// Create list
						if( ( admin_.wordList = new WordList( myWord_ ) ) != null )
							admin_.adminList[Constants.ADMIN_WORD_LIST] = admin_.wordList;
						else
							myWord_.startErrorInItem( 1, moduleNameString_, "I failed to create a word list" );
						}

					if( ( wordResult = myWord_.findWordTypeInAllWords( false, wordTypeNr, wordTypeString, null ) ).result == Constants.RESULT_OK )
						{
						if( wordParameter == Constants.NO_WORD_PARAMETER ||
						wordResult.foundWordItem == null ||
						wordResult.foundWordItem.wordParameter() != wordParameter )
							{
							if( ( wordResult = admin_.wordList.createWordItem( wordParameter ) ).result == Constants.RESULT_OK )
								{
								if( ( createdWordItem = wordResult.createdWordItem ) != null )
									{
									if( CommonVariables.firstWordItem == null )
										CommonVariables.firstWordItem = createdWordItem;		// Initialize the first word

									isPropernamePrecededByDefiniteArticle = ( wasPreviousWordDefiniteArticle &&
																			wordTypeNr == Constants.WORD_TYPE_PROPER_NAME );

									if( wordParameter == Constants.WORD_PARAMETER_ARTICLE_DEFINITE_1 ||
									wordParameter == Constants.WORD_PARAMETER_ARTICLE_DEFINITE_2 )
										definiteArticleParameter = wordParameter;
									else
										{
										if( wasPreviousWordDefiniteArticle &&

										( wordTypeNr == Constants.WORD_TYPE_PROPER_NAME ||
										wordTypeNr == Constants.WORD_TYPE_NOUN_SINGULAR ||
										wordTypeNr == Constants.WORD_TYPE_NOUN_PLURAL ) )
											definiteArticleParameter = previousWordDefiniteArticleParameter;
										}

									if( wordParameter == Constants.WORD_PARAMETER_ARTICLE_INDEFINITE_1 ||
									wordParameter == Constants.WORD_PARAMETER_ARTICLE_INDEFINITE_2 )
										indefiniteArticleParameter = wordParameter;
									else
										{
										if( wasPreviousWordIndefiniteArticle &&

										( wordTypeNr == Constants.WORD_TYPE_NOUN_SINGULAR ||
										wordTypeNr == Constants.WORD_TYPE_NOUN_PLURAL ) )
											indefiniteArticleParameter = previousWordIndefiniteArticleParameter;
										}

									if( createdWordItem.addWordType( isPropernamePrecededByDefiniteArticle, definiteArticleParameter, indefiniteArticleParameter, wordTypeNr, wordTypeStringLength, wordTypeString ) != Constants.RESULT_OK )
										myWord_.addErrorInItem( 1, moduleNameString_, "I failed to add a word type to a new word" );
									}
								else
									myWord_.startErrorInItem( 1, moduleNameString_, "The last created word item is undefined" );
								}
							else
								myWord_.addErrorInItem( 1, moduleNameString_, "I failed to create a word item" );
							}
						else
							myWord_.startErrorInItem( 1, moduleNameString_, "The given word type string already exists with the same word parameter" );
						}
					else
						myWord_.addErrorInItem( 1, moduleNameString_, "I failed to find a word type in all words" );
					}
				else
					myWord_.startErrorInItem( 1, moduleNameString_, "The given word type number is undefined" );
				}
			else
				myWord_.startErrorInItem( 1, moduleNameString_, "The given word type string is empty or has no words left anymore" );
			}
		else
			myWord_.startErrorInItem( 1, moduleNameString_, "The given word type string is undefined" );

		wordResult.result = CommonVariables.result;
		return wordResult;
		}
	};

/*************************************************************************
 *
 *	"How joyful are those who fear the Lord-
 *	all who follow his ways!" (Psalm 128:1)
 *
 *************************************************************************/
