/*
 *	Class:			AdminLanguage
 *	Supports class:	AdminItem
 *	Purpose:		To create and assign the grammar and interface languages
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "AdminItem.h"
#include "GeneralizationItem.cpp"
#include "SpecificationItem.cpp"

class AdminLanguage
	{
	// Private constructible variables

	WordItem *foundLanguageWordItem_;

	CommonVariables *commonVariables_;
	AdminItem *admin_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	ResultType findLanguageByName( char *languageNameString )
		{
		WordResultType wordResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findLanguageByName";
		foundLanguageWordItem_ = NULL;

		if( languageNameString != NULL )
			{
			// Initially the language name words are not linked
			// to the language defintion word. So, search in all words.
			if( ( wordResult = myWord_->findWordTypeInAllWords( true, WORD_TYPE_PROPER_NAME, languageNameString, NULL ) ).result == RESULT_OK )
				foundLanguageWordItem_ = wordResult.foundWordItem;
			else
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a language word" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given language name string is undefined" );

		return commonVariables_->result;
		}


	public:
	// Constructor

	AdminLanguage( AdminItem *admin, WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		foundLanguageWordItem_ = NULL;

		admin_ = admin;
		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "AdminLanguage" );

		if( commonVariables_ != NULL )
			{
		if( admin_ != NULL )
			{
			if( myWord_ == NULL )
				strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given admin is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	ResultType authorizeLanguageWord( WordItem *authorizationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "authorizeLanguageWord";
		if( authorizationWordItem != NULL )
			{
			if( authorizationWordItem->assignChangePermissions( this ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to assign my language change permissions to a word" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given authorization word item is undefined" );

		return commonVariables_->result;
		}

	ResultType createGrammarLanguage( char *languageNameString )
		{
		WordResultType wordResult;
		WordItem *grammarLanguageWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "createGrammarLanguage";

		if( findLanguageByName( languageNameString ) == RESULT_OK )
			{
			if( foundLanguageWordItem_ == NULL )
				{
				commonVariables_->currentGrammarLanguageNr++;

				if( ( wordResult = admin_->createWord( NO_DEFINITE_ARTICLE_PARAMETER, NO_INDEFINITE_ARTICLE_PARAMETER, WORD_TYPE_PROPER_NAME, NO_WORD_PARAMETER, strlen( languageNameString ), languageNameString ) ).result == RESULT_OK )
					{
					if( ( grammarLanguageWordItem = wordResult.createdWordItem ) != NULL )
						{
						if( admin_->authorizeLanguageWord( grammarLanguageWordItem ) == RESULT_OK )
							commonVariables_->currentGrammarLanguageWordItem = grammarLanguageWordItem;
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to authorize the created grammar language word" );
						}
					else
						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The last created word item is undefined" );
					}
				else
					{
					commonVariables_->currentGrammarLanguageNr--;		// Restore old grammar language
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create a grammar language word" );
					}
				}
			else
				commonVariables_->currentGrammarLanguageWordItem = foundLanguageWordItem_;
			}
		else
			return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find the grammar language" );

		return commonVariables_->result;
		}

	ResultType createInterfaceLanguage( char *languageNameString )
		{
		WordResultType wordResult;
		WordItem *interfaceLanguageWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "createInterfaceLanguage";

		if( findLanguageByName( languageNameString ) == RESULT_OK )
			{
			if( foundLanguageWordItem_ == NULL )
				{
				commonVariables_->currentGrammarLanguageNr++;

				if( ( wordResult = admin_->createWord( NO_DEFINITE_ARTICLE_PARAMETER, NO_INDEFINITE_ARTICLE_PARAMETER, WORD_TYPE_PROPER_NAME, NO_WORD_PARAMETER, strlen( languageNameString ), languageNameString ) ).result == RESULT_OK )
					{
					if( ( interfaceLanguageWordItem = wordResult.createdWordItem ) != NULL )
						{
						if( admin_->authorizeLanguageWord( interfaceLanguageWordItem ) == RESULT_OK )
							commonVariables_->currentInterfaceLanguageWordItem = interfaceLanguageWordItem;
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to authorize the created interface language word" );
						}
					else
						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The last created word item is undefined" );
					}
				else
					{
					commonVariables_->currentGrammarLanguageNr--;	// Restore old grammar language number
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create an interface language word" );
					}
				}
			else
				commonVariables_->currentInterfaceLanguageWordItem = foundLanguageWordItem_;
			}
		else
			return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find the grammar language" );

		return commonVariables_->result;
		}

	ResultType createLanguageSpecification( WordItem *languageWordItem, WordItem *languageNounWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "createLanguageSpecification";
		if( languageWordItem != NULL )
			{
			if( languageWordItem->isPropername() )
				{
				if( languageNounWordItem != NULL )
					{
					if( admin_->addSpecification( true, false, false, false, false, false, false, false, false, NO_PREPOSITION_PARAMETER, NO_QUESTION_PARAMETER, WORD_TYPE_PROPER_NAME, WORD_TYPE_NOUN_SINGULAR, WORD_TYPE_UNDEFINED, NO_COLLECTION_NR, NO_COLLECTION_NR, NO_COLLECTION_NR, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_CONTEXT_NR, 0, NULL, languageWordItem, languageNounWordItem, NULL, NULL ).result != RESULT_OK )
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a new language specification" );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given language noun word item is undefined" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given language word isn't a proper-name" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given language word item is undefined" );

		return commonVariables_->result;
		}

	ResultType assignGrammarAndInterfaceLanguage( char *languageNameString )
		{
		bool hasFoundLanguage = false;
		SpecificationItem *languageSpecificationItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "assignGrammarAndInterfaceLanguage";

		if( findLanguageByName( languageNameString ) == RESULT_OK )
			{
			if( foundLanguageWordItem_ != NULL )
				{
				if( foundLanguageWordItem_->isGrammarLanguage() )
					{
					hasFoundLanguage = true;

					if( ( languageSpecificationItem = foundLanguageWordItem_->firstAssignmentOrSpecificationButNotAQuestion( true, true, false, false, false, false, false, NO_COLLECTION_NR, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_CONTEXT_NR, commonVariables_->predefinedNounGrammarLanguageWordItem ) ) != NULL )
						commonVariables_->currentGrammarLanguageNr = languageSpecificationItem->grammarLanguageNr();

					if( commonVariables_->currentGrammarLanguageWordItem != foundLanguageWordItem_ )
						{
						if( assignSpecificationWithAuthorization( false, false, false, false, false, false, false, NO_PREPOSITION_PARAMETER, NO_QUESTION_PARAMETER, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, 0, NULL, foundLanguageWordItem_, commonVariables_->predefinedNounGrammarLanguageWordItem, NULL ).result == RESULT_OK )
							commonVariables_->currentGrammarLanguageWordItem = foundLanguageWordItem_;
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to assign the grammar language" );
						}
					}

				if( foundLanguageWordItem_->isInterfaceLanguage() )
					{
					hasFoundLanguage = true;

					if( commonVariables_->currentInterfaceLanguageWordItem != foundLanguageWordItem_ )
						{
						if( assignSpecificationWithAuthorization( false, false, false, false, false, false, false, NO_PREPOSITION_PARAMETER, NO_QUESTION_PARAMETER, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, 0, NULL, foundLanguageWordItem_, admin_->predefinedNounInterfaceLanguageWordItem(), NULL ).result == RESULT_OK )
							commonVariables_->currentInterfaceLanguageWordItem = foundLanguageWordItem_;
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to assign the interface language" );
						}
					}

				if( !hasFoundLanguage )
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given name isn't a grammar nor an interface language" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I couldn't find the requested language" );
			}
		else
			return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find the grammar language" );

		return commonVariables_->result;
		}

	ResultType assignGrammarAndInterfaceLanguage( unsigned short newLanguageNr )
		{
		bool hasFoundLanguage = false;
		GeneralizationItem *currentGeneralizationItem;
		WordItem *generalizationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "assignGrammarAndInterfaceLanguage";

		if( commonVariables_->predefinedNounGrammarLanguageWordItem != NULL )
			{
			if( ( currentGeneralizationItem = commonVariables_->predefinedNounGrammarLanguageWordItem->firstActiveGeneralizationItemOfSpecification() ) != NULL )
				{
				do	{
					if( ( generalizationWordItem = currentGeneralizationItem->generalizationWordItem() ) != NULL )
						{
						if( generalizationWordItem->hasCollectionOrderNr( newLanguageNr ) )
							{
							hasFoundLanguage = true;
							commonVariables_->currentGrammarLanguageWordItem = generalizationWordItem;
							}
						}
					}
				while( !hasFoundLanguage &&
				( currentGeneralizationItem = currentGeneralizationItem->nextGeneralizationItemOfSpecification() ) != NULL );

				if( hasFoundLanguage ||
				newLanguageNr == 1 )	// First language has no collection to another language
					{
					if( commonVariables_->currentGrammarLanguageWordItem != NULL )
						{
						commonVariables_->currentGrammarLanguageNr = newLanguageNr;

						if( assignSpecificationWithAuthorization( false, false, false, false, false, false, false, NO_PREPOSITION_PARAMETER, NO_QUESTION_PARAMETER, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, 0, NULL, commonVariables_->currentGrammarLanguageWordItem, commonVariables_->predefinedNounGrammarLanguageWordItem, NULL ).result == RESULT_OK )
							{
							// Also assign the interface language, if possible
							if( commonVariables_->currentGrammarLanguageWordItem->isInterfaceLanguage() )
								{
								commonVariables_->currentInterfaceLanguageWordItem = commonVariables_->currentGrammarLanguageWordItem;

								if( assignSpecificationWithAuthorization( false, false, false, false, false, false, false, NO_PREPOSITION_PARAMETER, NO_QUESTION_PARAMETER, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, 0, NULL, commonVariables_->currentInterfaceLanguageWordItem, admin_->predefinedNounInterfaceLanguageWordItem(), NULL ).result != RESULT_OK )
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to assign the interface language with authorization" );
								}
							}
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to assign the grammar language with authorization" );
						}
					else
						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The current grammar language word item is undefined" );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I couldn't find the requested language" );
				}
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The predefined grammar language noun word item is undefined" );

		return commonVariables_->result;
		}

	SpecificationResultType addSpecificationWithAuthorization( bool isAssignment, bool isConditional, bool isDeactiveAssignment, bool isArchivedAssignment, bool isExclusive, bool isNegative, bool isPossessive, bool isSelection, bool isSpecificationGeneralization, bool isValueSpecification, unsigned short prepositionParameter, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addSpecificationWithAuthorization";

		if( generalizationWordItem != NULL )
			{
			if( ( specificationResult = generalizationWordItem->addSpecificationInWord( isAssignment, isConditional, isDeactiveAssignment, isArchivedAssignment, isExclusive, isNegative, isPossessive, isSelection, isSpecificationGeneralization, isValueSpecification, prepositionParameter, questionParameter, generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, generalizationCollectionNr, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, nContextRelations, specificationJustificationItem, specificationWordItem, relationWordItem, specificationString, this ) ).result != RESULT_OK )
				myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a specification with authorization" );
			}
		else
			myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		specificationResult.result = commonVariables_->result;
		return specificationResult;
		}

	SpecificationResultType assignSpecificationWithAuthorization( bool isAmbiguousRelationContext, bool isAssignedOrClear, bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, bool isSelfGenerated, unsigned short prepositionParameter, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int originalSentenceNr, unsigned int activeSentenceNr, unsigned int deactiveSentenceNr, unsigned int archiveSentenceNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "assignSpecificationWithAuthorization";

		if( generalizationWordItem != NULL )
			{
			if( ( specificationResult = generalizationWordItem->assignSpecificationInWord( isAmbiguousRelationContext, isAssignedOrClear, isDeactive, isArchived, isNegative, isPossessive, isSelfGenerated, prepositionParameter, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, originalSentenceNr, activeSentenceNr, deactiveSentenceNr, archiveSentenceNr, nContextRelations, specificationJustificationItem, specificationWordItem, specificationString, this ) ).result != RESULT_OK )
				myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to assign a specification with authorization" );
			}
		else
			myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		specificationResult.result = commonVariables_->result;
		return specificationResult;
		}
	};

/*************************************************************************
 *
 *	"The Sovereign Lord has given me his words of wisdom,
 *	so that I know how to comfort the weary.
 *	Morning by morning he wakens me
 *	and opens my understanding to his will." (Psalm 50:4)
 *
 *************************************************************************/
