/*
 *	Class:			CommonVariables
 *	Purpose:		To hold the common variables
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include <stdio.h>
#include <string.h>
#include "Constants.h"

#ifndef COMMONVARIABLES
#define COMMONVARIABLES 1

// Class declarations needed by some compilers, like Code::Blocks
class Presentation;
class ScoreList;
class SelectionList;
class SpecificationItem;
class WordItem;

class CommonVariables
	{
	friend class AdminAssumption;
	friend class AdminAuthorization;
	friend class AdminCleanup;
	friend class AdminCollection;
	friend class AdminConclusion;
	friend class AdminContext;
	friend class AdminGrammar;
	friend class AdminImperative;
	friend class AdminItem;
	friend class AdminJustification;
	friend class AdminLanguage;
	friend class AdminQuery;
	friend class AdminRead;
	friend class AdminReadCreateWords;
	friend class AdminReadSentence;
	friend class AdminSelection;
	friend class AdminSolve;
	friend class AdminSpecification;
	friend class AdminWrite;
	friend class CollectionItem;
	friend class CollectionList;
	friend class ContextItem;
	friend class ContextList;
	friend class FileItem;
	friend class FileList;
	friend class GeneralizationItem;
	friend class GeneralizationList;
	friend class GrammarItem;
	friend class GrammarList;
	friend class InterfaceItem;
	friend class InterfaceList;
	friend class Item;
	friend class JustificationItem;
	friend class JustificationList;
	friend class List;
	friend class ListCleanup;
	friend class ListQuery;
	friend class Presentation;
	friend class ReadItem;
	friend class ReadList;
	friend class ScoreItem;
	friend class ScoreList;
	friend class SelectionItem;
	friend class SelectionList;
	friend class SpecificationItem;
	friend class SpecificationList;
	friend class WordAssignment;
	friend class WordCleanup;
	friend class WordCollection;
	friend class WordItem;
	friend class WordList;
	friend class WordQuery;
	friend class WordQuestion;
	friend class WordSpecification;
	friend class WordType;
	friend class WordTypeItem;
	friend class WordTypeList;
	friend class WordWrite;
	friend class WordWriteSentence;
	friend class WordWriteWords;
	friend class WriteItem;
	friend class WriteList;

	// Protected common variables

	bool hasFoundAnswerToQuestion;
	bool hasFoundMatchingStrings;
	bool hasFoundQuery;
	bool hasFoundWordReference;

	bool hasShownMessage;
	bool hasShownWarning;

	bool isAssignmentChanged;
	bool isFirstAnswerToQuestion;
	bool isQuestionAlreadyAnswered;
	bool isSpecificationConfirmedByUser;
	bool isUserQuestion;

	ResultType result;

	unsigned short matchingWordTypeNr;
	unsigned short queryWordTypeNr;

	unsigned short currentAssignmentLevel;
	unsigned short currentGrammarLanguageNr;
	unsigned short currentUserNr;
	unsigned short currentWriteLevel;

	unsigned int nDeletedItems;
	unsigned int nActiveQueryItems;
	unsigned int nDeactiveQueryItems;
	unsigned int nArchivedQueryItems;
	unsigned int nDeletedQueryItems;

	unsigned int currentSentenceNr;
	unsigned int highestInUseSentenceNr;
	unsigned int myFirstSentenceNr;
	unsigned int removeSentenceNr;

	unsigned int currentItemNr;
	unsigned int removeStartItemNr;

	Presentation *presentation;

	ScoreList *adminScoreList;

	SelectionList *adminConditionList;
	SelectionList *adminActionList;
	SelectionList *adminAlternativeList;

	SpecificationItem *lastShownMoreSpecificSpecificationItem;

	WordItem *currentGrammarLanguageWordItem;
	WordItem *currentInterfaceLanguageWordItem;
	WordItem *firstWordItem;
	WordItem *predefinedNounGrammarLanguageWordItem;
	WordItem *predefinedNounUserWordItem;

	char queryString[MAX_READ_WRITE_STRING_LENGTH];
	char writeSentenceString[MAX_READ_WRITE_STRING_LENGTH];


	public:
	// Constructor

	CommonVariables()
		{
		// Protected common variables

		hasFoundAnswerToQuestion = false;
		hasFoundMatchingStrings = false;
		hasFoundQuery = false;
		hasFoundWordReference = false;

		hasShownMessage = false;
		hasShownWarning = false;

		isAssignmentChanged = false;
		isFirstAnswerToQuestion = false;
		isQuestionAlreadyAnswered = false;
		isSpecificationConfirmedByUser = false;
		isUserQuestion = false;

		result = RESULT_OK;

		matchingWordTypeNr = WORD_TYPE_UNDEFINED;
		queryWordTypeNr = WORD_TYPE_UNDEFINED;

		currentAssignmentLevel = NO_ASSIGNMENT_LEVEL;
		currentGrammarLanguageNr = NO_LANGUAGE_NR;
		currentUserNr = NO_USER_NR;
		currentWriteLevel = NO_WRITE_LEVEL;

		nDeletedItems = 0;
		nActiveQueryItems = 0;
		nDeactiveQueryItems = 0;
		nArchivedQueryItems = 0;
		nDeletedQueryItems = 0;

		currentSentenceNr = 1;	// First sentence
		highestInUseSentenceNr = NO_SENTENCE_NR;
		myFirstSentenceNr = NO_SENTENCE_NR;
		removeSentenceNr = NO_SENTENCE_NR;

		currentItemNr = NO_ITEM_NR;
		removeStartItemNr = NO_ITEM_NR;

		presentation = NULL;

		adminScoreList = NULL;

		adminConditionList = NULL;
		adminActionList = NULL;
		adminAlternativeList = NULL;

		lastShownMoreSpecificSpecificationItem = NULL;

		currentGrammarLanguageWordItem = NULL;
		currentInterfaceLanguageWordItem = NULL;
		firstWordItem = NULL;
		predefinedNounGrammarLanguageWordItem = NULL;
		predefinedNounUserWordItem = NULL;

		strcpy( queryString, EMPTY_STRING );
		strcpy( writeSentenceString, EMPTY_STRING );
		}
	};

#endif

/*************************************************************************
 *
 *	"Honor the Lord for the glory of his name.
 *	Worship the Lord in the splendor of his holiness." (Psalm 29:2)
 *
 *************************************************************************/
