/* License/copyright: Dual licence, read copyright.txt in this package*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>
#include <unistd.h>
#include <time.h>
#include "utils.h"
#include "help.h"
#include "definitions.h"
#include "languages.h"
#include "analyses.h"
#include "abstracts.h"

extern int debug;
extern int verbose;
extern int linewidth;
extern char lang[];
extern long int size_line;
extern long int size_class_name;
extern long int size_nb_class;
extern char file_input[]; //SIZE_WORD
extern char file_output[];

extern int abstract_utf8;
extern int count_silent_bug;

/*
    Generate pseudo-abstracts
    Three algorithms: 
    - extract sentences with the help of keywords from a dictionnary
    - extract sentences with the help of cue expressions
	- simplify deadwood sentences
*/

long int sentencematchclass(
	char *file_abstract,char *file_dico,
	char *text,long int *pos_sentence,
	int nbl,int compress_rate,int rec,char *class_probable,char *title) 
{
/* 
 Make an abstract by extracting the sentences 
 sentence class must match the general class of the text
 p1,classi:freqN,...,classj:freqN,p2,... 
 
 !!!Bug check => Sometimes doesn't work with small text
 !!!Limitation=> Double scan text and dico => slow routine, 
    - The first scan makes an histogram. The histrogram is used to determine 
    a threshold that will limit the number of sentences extracted to the 
    compress_rate required.
    - The second scan extracts sentences with a score above or equal to the 
    threshold.
*/
  FILE *fp,*fp1,*fp2,*fp3;
  char *line; /*line limited at 'size_line' chars*/
  char *str_ptr1,*str_ptr2;
  char word[SIZE_WORD],wordchk[SIZE_WORD+2];
  int *class_sum,*class_diff; //'size_nb_class' classes
  char **classname; //'size_nb_class*size_class_name' chars
  long int i,j,length;
  int cont,val,cnt_suppress,cnt_space;
  char shortline[SHORT_STR];
  int prt_thresh;
  char sentence[SIZE_SENTENCE];
  char linesmart[SIZE_SENTENCE];
  long int pos_char=0; //count chars
  long int k,line_cnt,nb_word,word_cnt; //count lines & words
  long int lg_sentence;
  int offset;
  char ch;
  long int i_best_class,max_class_sum,max_class_diff;
  long int class_threshold=512; //is used with score_table[]
  long int score_table[513]; //score_table[score]=nb_sentences
  long int goal_nbline; //nb lines computed from the compress rate
  unsigned long long prev_hash=0,now_hash=0; //value specific to the sentence 
  char crush_detect='x';
  
  for(i=0;i<513;i++) score_table[i]=0;

  prt_thresh=1;  //class of each line is compared
  
  if (linewidth) clever_print(0,""); //reset static var in fct

  fp=fopen(file_dico,"r"); //dico provides keywords
  if (fp==NULL){
    ERRPOS
    fprintf(stderr,"Unable to open %s ->Exit!\n",file_dico);
    exit(EXIT_FAILURE);
  }
  
  fp2=fopen(file_input,"r"); //temp file -> sentences are extracted from it
  if (fp2==NULL){
    ERRPOS
    fprintf(stderr,"Unable to open %s ->Exit!\n",file_input);
    return(0);
  }
  
  fp3=fopen(file_abstract,"w"); //result file <- abstract is stored here
  if (fp3==NULL){
    ERRPOS
    fprintf(stderr,"Unable to create abstract ->Exit!\n");
    return(0);
  }
  
  /*Search value size_line for dynamic alloc of line*/  
  size_line=SIZE_LINE; //default value
  fseek(fp,0,SEEK_SET);
  for(i=0;i<10;i++) { //search only in the 10 first lines
    if (fgets(shortline,SHORT_STR,fp) == NULL) break; //eof exit loop
    if (shortline[0] == '#') {
      if ((str_ptr1=strstr(shortline,"<LINE_LG:")) != NULL) {
        if ((str_ptr2=strchr(str_ptr1+9,'>')) != NULL) {
	  *str_ptr2='\0';
	  size_line=atoi(str_ptr1+9);
	  if (debug>1) fprintf(stderr,"\nsize_line is set at %li\n",size_line);
  } } } }
  
  /*dynamic alloc*/
  if ((line = (char*)malloc(size_line)) == NULL) errmalloc("sentencematchclass");  
  if ((classname = (char**)malloc(size_nb_class*sizeof(char*))) == NULL) errmalloc("sentenmatchclass");
  for (k=0;k<size_nb_class;k++) if ((classname[k] = (char*)malloc(size_class_name)) == NULL) errmalloc("sentencematchclass");
  if ((class_sum = (int*)malloc(size_nb_class*sizeof(int))) == NULL) errmalloc("sentencematchclass");
  if ((class_diff = (int*)malloc(size_nb_class*sizeof(int))) == NULL) errmalloc("sentencematchclass");
  
  if ((length=strlen(text)) == 0) return 0;
  for(i=0;i<size_nb_class;i++) { class_sum[i]=0; class_diff[i]=0; }
  
  if ((rec & 2) == 2) {
    /* Open the file  */
    fp1=fopen(file_output,"a");
    if (fp1==NULL){
	  ERRPOS
      fprintf(stderr,"Unable to open %s ->Exit!\n",file_input);
      exit(EXIT_FAILURE);
    }
    fprintf(fp1,"\n<Start %s >\n",title);
  }
  if ((rec & 1) == 1) printf("\n<Start %s >\n",title);

  /*do the classname array*/  
  fseek(fp,0,SEEK_SET);
  for(i=0;i<size_nb_class;i++) {
    line[size_line-1]='\0';
    if (fgets(line,size_line,fp) == NULL) break;
    if (line[size_line-1] != '\0') {
	  ERRPOS
	  fprintf(stderr,"Error: size_line %li too small\n",size_line);
	  count_silent_bug++;
	}
    if (line[0] != '#') {
      if ((str_ptr2=strpbrk(line,":")) != NULL) *str_ptr2=0;
      if (strlen(line) < size_class_name) strcpy(word,line);
      else {
	    ERRPOS
	    fprintf(stderr,"Err label too long in sentencematchclass:<%s>\n",line);
	    count_silent_bug++;
	  }
      if ((str_ptr2=strpbrk(line," ")) != NULL) *str_ptr2=0;
      if ((j=atoi(line))!=0) strcpy(classname[j],word);
      else {
	    ERRPOS
	    fprintf(stderr," atoi(line) sentencematchclass:<%s>\n",line);
	    count_silent_bug++;
	  }
    }
  }

  /*analyze start here to detemine the best threshold*/ 
  k=line_cnt=0;
  max_class_sum=0;
  i_best_class=0;
  pos_char=0;
  for(i=0;i<length;i++) {    //scan each char of the text
    if (text[i]=='\n') {     //new word
      for(j=0;i+j+1<length;j++) {   //scan the word
        if (text[j+i+1] != '\n') word[j]=text[j+i+1];  //store the word
          else {   //end of word
            word[j]=0;  //end of chain
            if (strcmp(word,"EOS") != 0) {  //it isn't an end-of-sentence marker
              noplural(word,lang); //plural -> singular
              strcpy(wordchk,"\\"); //first delimiter
              strcat(wordchk,word); //wordchk will be used in the search
              strcat(wordchk,"/"); //last delimiter
              if (debug>1) fprintf(stderr,"%s",wordchk);
              fseek(fp,0,SEEK_SET);
              cont=1;
              /*Now search class : Read each line of the dico*/
              while(cont==1) {
                if (fgets(line,size_line,fp) == NULL) cont=0;
                else if (line[0] != '#') {  
                  /*Search /word/ in the line*/
                  if ((str_ptr1=strstr(strpbrk(line,":"),wordchk)) !=NULL) {
                    /*convert single digit val*/
                    val=chartoi(*(str_ptr1-1));
                    if ((str_ptr2=strpbrk(line," ")) != NULL) *str_ptr2=0;
                    class_sum[atoi(line)]+=val; //score
                    class_diff[atoi(line)]++; //cnt terms found
                  }
                }
              }
            } else {
	      k++;  //k counts line but reset to 0 when == prt_thresh
	      line_cnt++; //no reset  =>line_cnt points the end of each sentence
	    }
            /*now proceed sentence(s)*/
            if (k >= prt_thresh) {
	      if (debug>1) fprintf(stderr,"\n");
	      /*search the highest score*/
              for(k=0;k<size_nb_class;k++) 
                if (class_diff[k]>0) { //if not empty
                  if (max_class_sum < class_sum[k]) {
					max_class_sum=class_sum[k];
					max_class_diff=class_diff[k];
					i_best_class=k;
				  }
			  /*reset cumul for the next sentence*/
			  class_diff[k]=0; 
			  class_sum[k]=0;
                }
	      /* when class with highest score match the class of the text (class_probable)
	      update the histogram score:nb of sentence*/
	      if (strstr(classname[i_best_class],class_probable) != NULL) {
	        if (max_class_sum >= 512) score_table[512]++;
	          else score_table[max_class_sum]++;
              }
              /*reset some var before the next sentence(s)*/
              k=0;    //reset the line_counter
	      max_class_sum=0; //reset highest score
              i_best_class=0; //reset best class
            }
            i=i+j;    //set the index to the next word
            break;     
          } //endelse
      } //endfor j
    } //endif '\n'
  } //endfor i

  /*make a cumulative histogram*/  
  for(i=512;i>0;i--) score_table[i-1]+=score_table[i];
    
  if (debug) {
    fprintf(stderr,"Histogramme - Score/Nb sentences\n");
    for(i=512;i>-1;i--) 
      if (score_table[i]>0) fprintf(stderr,"score_%li: %li\n",i,score_table[i]);
  }

  /*Search the immediate lowest threshold to obtain 
  the expected compression level*/
  if (compress_rate == 0) goal_nbline=nbl;
  else {
	goal_nbline= (line_cnt*compress_rate)/100;
	if (goal_nbline < 2) goal_nbline=2; //only one line cannot be significatif
	if (goal_nbline > nbl) goal_nbline=nbl; //limit max
  }
  for(i=512;i>-1;i--) {  //decrease the threshold
	if (score_table[i] >= goal_nbline) {
	  class_threshold=i;
	  break;
	}	  
  }
 
  if (verbose) {
    if ((rec & 1) == 1) 
      printf("Goal Nb lines:%li  Threshold:%li  Possible Nb lines:%li\n",goal_nbline,class_threshold,score_table[class_threshold]);
    if ((rec & 2) == 2) 
      fprintf(fp1,"Goal Nb lines:%li  Threshold:%li  Possible Nb lines:%li\n",goal_nbline,class_threshold,score_table[class_threshold]);
  }
  
  /*Now we have the threshold, we can search for the most significant sentence*/ 
  k=line_cnt=word_cnt=0;
  max_class_sum=0;
  i_best_class=0;
  pos_char=0;
  for(i=0;i<length;i++) {    //scan each char of the text
    if (text[i]=='\n') {     //new word
      for(j=0;i+j+1<length;j++) {   //scan the word
        if (text[j+i+1] != '\n') word[j]=text[j+i+1];  //store the word
          else {   //end of word
            word[j]=0;  //end of chain
            if (strcmp(word,"EOS") != 0) {  //it isn't an end-of-sentence marker
              noplural(word,lang); //plural -> singular
              strcpy(wordchk,"\\"); //first delimiter
              strcat(wordchk,word); //wordchk will be used in the search
              strcat(wordchk,"/"); //last delimiter
              if (debug>1) fprintf(stderr,"%s",wordchk);
              fseek(fp,0,SEEK_SET);
              cont=1;
              /*Now search class : Read each line of the dico*/
              while(cont==1) {
                if (fgets(line,size_line,fp) == NULL) cont=0;
                else if (line[0] != '#') {  
                  /*Search /word/ in the line*/
                  if ((str_ptr1=strstr(strpbrk(line,":"),wordchk)) !=NULL) {
                    /*convert single digit val*/
                    val=chartoi(*(str_ptr1-1));
                    if ((str_ptr2=strpbrk(line," ")) != NULL) *str_ptr2=0;
                    class_sum[atoi(line)]+=val; //score
                    class_diff[atoi(line)]++; //cnt terms found
                  }
                }
              }
            } else {
	      k++;  //k counts line but reset to 0 when == prt_thresh
	      line_cnt++; //no reset  =>line_cnt points the end of each sentence
	    }
            /*now proceed sentence(s)*/
            if (k >= prt_thresh) {
	      if (debug>1) fprintf(stderr,"\n");
	      /*search the highest score*/
              for(k=0;k<size_nb_class;k++) 
                if (class_diff[k]>0) { //if not empty
                  if (max_class_sum < class_sum[k]) {
		    max_class_sum=class_sum[k];
		    max_class_diff=class_diff[k];
		    i_best_class=k;
		  }
		  /*reset cumul for the next sentence*/
		  class_diff[k]=0; 
		  class_sum[k]=0;
                }
              
	      if (debug) fprintf(stderr,"Best=>%s=%li\n",classname[i_best_class],max_class_sum);
	      
	      /* if class with highest score match class of the text (class_probable)
	      and if this highest score is above or equal to the threshold then 
	      the sentence is supposed significant */
	      if ((strstr(classname[i_best_class],class_probable) != NULL) && (max_class_sum>=class_threshold)) {
                if (debug) fprintf(stderr,"--- Sentence:%li Pos=%li Score:%li ----------\n",line_cnt,pos_sentence[line_cnt-1],max_class_sum);
                /*Extract sentence from ansi7b converted text*/
	        fseek(fp2,pos_sentence[line_cnt-1],SEEK_SET); //on the end of the previous sentence
		//length = end_new_sentence - end_previous_sentence
	        lg_sentence=pos_sentence[line_cnt]-pos_sentence[line_cnt-1];
	        if (lg_sentence > SIZE_SENTENCE) lg_sentence=SIZE_SENTENCE; //cut the sentence if too long
	        *sentence='\0'; //perhaps unuseful
	        offset=0;
		/*--- read char one by one and filter char ---*/
		cnt_suppress=cnt_space=0;
	        while (lg_sentence--) { 
	          if ((ch=fgetc(fp2)) == EOF) break;
		  /*suppress ctrl chars
		    replace '_' with space
		    only one space
		    suppress repetition some chars such as separators*/
		  if ((unsigned char)ch > 31) {
		    if (ch == '_') ch=' ';
		    if (ch == ' ') cnt_space++;
		      else cnt_space=0;
		    if (strchr(" -=+|'\"<>,.;:!^#@*",ch) != NULL) cnt_suppress++;
		      else cnt_suppress=0;
		    if ((cnt_suppress < 3) && (cnt_space < 2)) *(sentence+offset++)=ch;
		  } 
		  else ch=' '; //ctrl char becomes space (extra-space will be removed after)
	        }
		*(sentence+offset)='\0'; //terminate the sentence
		/*Remove space in the end*/
		offset--;
		while (*(sentence+offset) == ' ') {
		  *(sentence+offset)='\0';
		  offset--;
		}
		/*--- Reformate the sentence a little bit ---*/
		/*Remove space in the beginning*/
		while (*sentence == ' ') strcpy(sentence,sentence+1);
		/*Remove underline in the beginning*/
		while (*sentence == '_') strcpy(sentence,sentence+1);
		/*Remove '>' in the beginning*/
		while (*sentence == '>') strcpy(sentence,sentence+1);
		/*Reajust offset*/
		offset=strlen(sentence)-1;
		/*change some final char*/
		if (strchr(":;",*(sentence+offset)) != NULL) *(sentence+offset)='.';
		/*if no end-of-sentence then add '.' */
		if ((strchr(".!?",*(sentence+offset)) == NULL) && (*(sentence+offset) != '"')) {
		  *(sentence+offset+1)='.'; //add a stop
		  *(sentence+offset+2)='\0'; //terminate the sentence
		}
		strcat(sentence," "); //add a space at the end
		
		/*to avoid same sentences twice, the sentence is converted in a value
		 to be compared with the previous value*/
		prev_hash=now_hash;
		now_hash=weakhashsentence(sentence,lang); //specific value of the sentence
		if (debug) fprintf(stderr,"Hash=%16llX %s\n",now_hash,sentence);
		nb_word=now_hash >> 56; //keep only the last 8 bits (nb words)
		 /* not the same sentence again!
		  * more than 3 words
		  * less than 100 words*/
    if (now_hash != prev_hash && nb_word > 3 && nb_word < 100) {
		  word_cnt+=nb_word; //cumul the nb of word
		  /*--- Print routine ---*/
      if (linewidth && rec > 0) {
        /*Try a smart formating - avoid to cut words with clever_print()
        and eventually a conversion to uf8*/
        if (abstract_utf8) char2utf8(linesmart,clever_print(linewidth,sentence));
        else strcpy(linesmart,clever_print(linewidth,sentence));

        if ((rec & 1) == 1) printf("%s",linesmart);
		    if ((rec & 2) == 2) fprintf(fp1,"%s",linesmart);
		    fprintf(fp3,"%s",linesmart);
        }
      else {
        /* or no formating*/
		    if ((rec & 1) == 1) printf("%s",sentence);
		    if ((rec & 2) == 2) fprintf(fp1,"%s",sentence);
		    fprintf(fp3,"%s",sentence);
		  }
    } 
    else {
      fprintf(stderr,"Rejected:Hash=%16llX %s\n",now_hash,sentence);
    }
	        /*--------this sentence is done------------*/
              }
              /*reset some var before the next sentence(s)*/
              k=0;    //reset the line_counter
	      max_class_sum=0; //reset highest score
              i_best_class=0; //reset best class
            }
            i=i+j;    //set the index to the next word
            break;     
          }
      }
    }        
  }
  /*last slice*/
  if (k > 0) {
    if ((rec & 1) == 1) printf("--- Last slice k=%li ---\n",k);
    if ((rec & 2) == 2) fprintf(fp1,"--- Last slice k=%li ---\n",k);
    
    for(k=0;k<size_nb_class;k++) {
      if (class_diff[k]>0) {
        if ((rec & 1) == 1) printf("%s=%i\n",classname[k],class_sum[k]);
        if ((rec & 2) == 2) fprintf(fp1,"%s=%i\n",classname[k],class_sum[k]);
  } } }
  
  if ((rec & 1) ==1) printf("\n<End %s>\n",title);
  if ((rec & 2) ==2) fprintf(fp1,"\n<End %s>\n",title);
  
  if (fclose(fp) != 0) {
    ERRPOS
    fprintf(stderr," fclose fp in abstract");
    count_silent_bug++;
  }
  if ((rec & 2) == 2) if (fclose(fp1) != 0) {
    ERRPOS
    fprintf(stderr," fclose fp1 in abstract");
    count_silent_bug++;
  }
  if (fclose(fp2) != 0) {
    ERRPOS
    fprintf(stderr," fclose fp2 in abstract");
    count_silent_bug++;
  }
  if (fclose(fp3) != 0) {
    ERRPOS
    fprintf(stderr," fclose fp3 in abstract");
    count_silent_bug++;
  }
  free(line);
  for (k=0;k<size_nb_class;k++) free(classname[k]);
  free(classname);
  free(class_sum);
  free(class_diff);
  if (verbose) printf("\nTotal of words extracted:%li \n",word_cnt);
  if (crush_detect!='x') {
    ERRPOS
    fprintf(stderr,"Overflow\n");
    count_silent_bug++;
  }
  return word_cnt;
}

long int sentencematchcue(
	char *file_abstract,char *file_text,char *file_dico,char *text,
	int nbl,int compress_rate,int rec,char *title,char *target) 
{
/*Make an abstract by extracting sentences from the text. 
It's a simplified routine of sentencematchclass(), less sophisticated 
but it runs faster. target/label replace class_probable, it allows to select 
a specific line in the dico.
So cue expressions are extracted in the line of the dico, and we search 
for a match in each sentence of the text, if a match is found the sentence is 
extracted.
=> Keywords weight are not used yet.
Note: The text is loaded in the buffer '*text', so it's content is destroyed.
*/
  FILE *fp,*fp1,*fp2,*fp3;
  char *line; /*line limited at 'size_line' chars*/
  char *str_ptr1,*str_ptr2,*str_ptr3,*str_ptr4;
  char cue_expression[SIZE_SENTENCE];
  char linesmart[SIZE_SENTENCE];
  char label[SIZE_SENTENCE];
  char shortline[SHORT_STR];
  long int i,length;
  int val,lg;
  int prt_thresh;
  int offset;
  char ch;
  int cnt_suppress,cnt_space;
  long int word_cnt=0;
  char crush_detect='x';

  prt_thresh=1;  //class of each line is compared

  fp=fopen(file_dico,"r"); //dico of cue expressions
  if (fp==NULL){
    ERRPOS
    fprintf(stderr," Unable to open %s ->Exit!\n",file_dico);
    exit(EXIT_FAILURE);
  }
  
  fp2=fopen(file_text,"r"); //temporary file
  if (fp2==NULL){
    ERRPOS
    fprintf(stderr,"Unable to open %s ->Exit!\n",file_text);
    count_silent_bug++;
    return(0);
  }
  
  /*
    Load temporary file in text buffer
	That destroy *text, will be better of malloc new buffer
  */
  *text='\0';
  offset=0;
  cnt_suppress=cnt_space=0;
  while ((ch=fgetc(fp2)) != EOF) {
    /*suppress ctrl chars
     replace '_' et \n with space
     only one space
     suppress repetition some chars such as separators*/
    if ((unsigned char)ch > 31) {
      if (ch == '_') ch=' ';
      if (ch == ' ') cnt_space++;
	    else cnt_space=0;
      if (strchr(" -=+|'\"<>,.;:!^#@*",ch) != NULL) cnt_suppress++;
	    else cnt_suppress=0;
      if ((cnt_suppress < 3) && (cnt_space < 2)) *(text+offset++)=ch;
    }
    else if (ch == '\n') *(text+offset++)=' ';
  }
  *(text+offset)='\0';

  fp3=fopen(file_abstract,"w"); //result file
  if (fp3==NULL){
    ERRPOS
    fprintf(stderr,"Unable to create abstract ->Exit!\n");
    count_silent_bug++;
    return(0);
  }
  
  /*Search value size_line for dynamic alloc of line*/  
  size_line=SIZE_LINE; //default value
  fseek(fp,0,SEEK_SET);
  for(i=0;i<10;i++) { //search only in the 10 first lines
    if (fgets(shortline,SHORT_STR,fp) == NULL) break; //eof exit loop
    if (shortline[0] == '#') {
      if ((str_ptr1=strstr(shortline,"<LINE_LG:")) != NULL) {
        if ((str_ptr2=strchr(str_ptr1+9,'>')) != NULL) {
	  *str_ptr2='\0';
	  size_line=atoi(str_ptr1+9);
	  if (debug) fprintf(stderr,"\nsize_line is set at %li\n",size_line);
  } } } }
  
  /*dynamic alloc*/
  if ((line = (char*)malloc(size_line)) == NULL) errmalloc("sentencematchcue");  
  
  if ((length=strlen(text)) == 0) {
  	printf("\nsentencematchcue: no text to proceed!\n");
  	return 0;
  }
  
  if ((rec & 2) == 2) {     // if result must be recorded
    fp1=fopen(file_output,"a");
    if (fp1==NULL){
	  ERRPOS
      fprintf(stderr,"Unable to open %s ->Exit!\n",file_input);
      exit(EXIT_FAILURE);
    }
    fprintf(fp1,"\n<Start %s >\n",title);
  }
  if ((rec & 1) ==1) printf("\n<Start %s >\n",title);

  if (linewidth) clever_print(0,""); //reset static var in fct
  
  if (verbose) printf("Target for cue: %s\n",target);
  /*Extract cue expression from dico*/  
  fseek(fp,0,SEEK_SET);
  line[size_line-2]='\0';
  while (fgets(line,size_line,fp) != NULL) {  //read a line
    if (line[size_line-2] != '\0') {
	  ERRPOS
	  fprintf(stderr," size_line too small\n");
	  count_silent_bug++;
	}
    if (line[0] != '#') { //do not proceed comment
      /*str_ptr2 points the beginning of cue expressions
      store the label of the line of cue*/
      if ((str_ptr2=strpbrk(line,":")) != NULL) *str_ptr2=0;
      if (strlen(line) < size_class_name) strcpy(label,line);
        else {
		  ERRPOS
		  fprintf(stderr,"Error: Label too long in sentencematchclass:<%s>\n",line);
		  count_silent_bug++;
		}
      /*search for the label*/
      if (strstr(label,target) != NULL) goto label_found;
    }
  }
  ERRPOS 
  fprintf(stderr," Bug in sentencematchcue() the label has been not found!\n");
  count_silent_bug++;
  return 0;
  
  label_found:;
  /*We are going to extract sentences*/    
      str_ptr2++; //because it pointed on NULL char
      while ((str_ptr1=strpbrk(str_ptr2,"\\")) != NULL) { //beginning of the cue
		if ((str_ptr2=strpbrk(++str_ptr1,"/")) != NULL) { //end of the cue
			lg=str_ptr2-str_ptr1; //length of the cue
			if (lg > SIZE_SENTENCE) {
				ERRPOS
				fprintf(stderr,"Size Error: cue_expression too long>\n"); 
				count_silent_bug++;
				return 0;
			}
			strncpy(cue_expression,str_ptr1,lg);
			*(cue_expression+lg)='\0';  //end-of-string
			/*Extract weight, a single digit val - in fact not used yet*/
			val=chartoi(*(str_ptr1-2)); //str_ptr1 points the word, val:weight
			if (debug) fprintf(stderr,"----- Search: %s\n",cue_expression);
			/*
			search every cue_expression inside the text
			=> strstr is replaced with str7bstr (first string is converted to
			lowercase and unaccentued char, second string is not converted)
			so cue expressions must be in lowercase without accent.
			*/
			str_ptr4=text;
			/* Note: plural and singular are distint words
			 * dico of cue words must contains the singular, plural, masculine 
			 * and feminine of the same word */
			while ((str_ptr3=str7bstr(str_ptr4,cue_expression,0)) != NULL) {
				/* cue expression found then search the end of the sentence
				 * end of sentence markers are: . ; ! ? " '
				 * end => str_ptr4 */
				if ((str_ptr4=strpbrk(str_ptr3,".;!?\"\'")) != NULL) { 
				/* search beginning of the sentence => str_ptr3 */
				while (str_ptr3-- > text) {
					if (strchr(".;!?\":",*str_ptr3) != NULL) { //end of the previous sentence
						str_ptr3++;
						break;
					}
				}
				*str_ptr4='\0'; //replace '.' with '\0' to delimite the sentence
				word_cnt+=countword(str_ptr3); //cumul the nb of word
				/* print sentence (from str_ptr3 to str_ptr4) */
				if (linewidth && rec > 0) {
					/*smart line formating avoid to cut words*/
					strcpy(linesmart,clever_print(linewidth,str_ptr3));
					if ((rec & 1) == 1) printf("%s.",linesmart);  //in display
					if ((rec & 2) == 2) fprintf(fp1,"%s.",linesmart); //in file
					fprintf(fp3,"%s.",linesmart);  //file abstract
				}
				else {
					/*no line formating*/
					if ((rec & 1) == 1) printf("%s.",str_ptr3);  //in display
					if ((rec & 2) == 2) fprintf(fp1,"%s.",str_ptr3); //in file
					fprintf(fp3,"%s.",str_ptr3);  //file abstract
				}
			  *str_ptr4='.'; //the sentence is printed, so restore the '.' 
			}
	  }//endwhile cue found in text
	  if (debug) fprintf(stderr,"---------------------\n");
	}//endif end of cue
  }//endwhile begin of new cue in dico
    
  
  if ((rec & 1) == 1) printf("\n<End %s>\n",title);
  if ((rec & 2) == 2) fprintf(fp1,"\n<End %s>\n",title);
    
  if (fclose(fp) != 0) {
    ERRPOS
    fprintf(stderr," fclose fp in abstract");
    count_silent_bug++;
  }
  if ((rec & 2) == 2) if (fclose(fp1) != 0) {
    ERRPOS
    fprintf(stderr," fclose fp1 in abstract");
    count_silent_bug++;
  }
  if (fclose(fp2) != 0) {
    ERRPOS
    fprintf(stderr," fclose fp2 in abstract");
    count_silent_bug++;
  }
  if (fclose(fp3) != 0) {
    ERRPOS
    fprintf(stderr," fclose fp3 in abstract");
    count_silent_bug++;
  }
  free(line);
  if (verbose) printf("\nTotal of words extracted:%li \n",word_cnt);
  if (crush_detect!='x') {
    ERRPOS
    fprintf(stderr,"Overflow\n");
    count_silent_bug++;
  }
  return word_cnt;
}

int nobrokenwood(char *file_abstract,char *file_text,char *file_brokenwood,int rec,char *title) {
/* Simplify expressions:
 * replace deadwood expressions with simplier expression
 * remove empty words,
 * remove sentences between brackets
 */
  FILE *fp,*fp1,*fp2,*fp3;
  char *text,*top_text,*space_pos;
  char *line; /*line limited at 'size_line' chars*/
  char *str_ptr1,*str_ptr2,*str_ptr3;
  char shortline[SHORT_STR];
  int i,lg;
  int offset;
  char ch;
  int cnt_suppress,cnt_space,cnt_chr;
  int expression_cnt=0;
  long int size_text=10; //size of the text to simplify + 10 bytes (precaution)
  char crush_detect='x';

  /*
    Load text file in text buffer (previous abstract)
  */  
  fp2=fopen(file_text,"r");
  if (fp2==NULL){
    ERRPOS
    fprintf(stderr,"Unable to open %s ->Exit!\n",file_text);
    count_silent_bug++;
    return(0);
  }
  
  /*Determine the size of the text and alloc enough memory*/
  while ((ch=fgetc(fp2)) != EOF) size_text++;
  if ((text = (char*)malloc(size_text)) == NULL) {
    ERRPOS
    fprintf(stderr,"\nsize_text is set at %li\n",size_text);
    errmalloc("brokenwood");
  }

  fseek(fp2,0,SEEK_SET);
  *text='\0';
  offset=0;
  cnt_suppress=cnt_space=0;
  while ((ch=fgetc(fp2)) != EOF) {
    /*suppress ctrl chars
     replace '_' with space
     only one space
     suppress repetition some chars such as separators
	 lost formating char (\n\t\r) */
    if ((unsigned char)ch > 31) {
      if (ch == '_') ch=' ';
      if (ch == ' ') cnt_space++;
	else cnt_space=0;
      if (strchr(" -=+|'\"<>,.;:!^#@*",ch) != NULL) cnt_suppress++;
	 else cnt_suppress=0;
      if ((cnt_suppress < 3) && (cnt_space < 2)) *(text+offset++)=ch;
    }
  }
  *(text+offset)='\0';
  if (fclose(fp2) != 0) {
    ERRPOS
    fprintf(stderr," fclose fp2 in abstract");
    count_silent_bug++;
  }
  if (*text == '\0') return 0;
  top_text=text;

  fp3=fopen(file_abstract,"w"); //result file
  if (fp3==NULL){
    ERRPOS
    fprintf(stderr,"Unable to create abstract ->Exit!\n");
    count_silent_bug++;
    return(0);
  }
    
  /*open list of expressions with their simplified  equiv*/
  fp=fopen(file_brokenwood,"r");
  if (fp==NULL){
    ERRPOS
    fprintf(stderr," Unable to open %s ->Exit!\n",file_brokenwood);
    exit(EXIT_FAILURE);
  }
  /*Search value size_line for dynamic alloc of line*/  
  size_line=SIZE_LINE; //default value
  fseek(fp,0,SEEK_SET);
  for(i=0;i<10;i++) { //search only in the 10 first lines
    if (fgets(shortline,SHORT_STR,fp) == NULL) break; //eof exit loop
    if (shortline[0] == '#') {
      if ((str_ptr1=strstr(shortline,"<LINE_LG:")) != NULL) {
        if ((str_ptr2=strchr(str_ptr1+9,'>')) != NULL) {
	  *str_ptr2='\0';
	  size_line=atoi(str_ptr1+9);  
  } } } }
  
  /*dynamic alloc*/
  if ((line = (char*)malloc(size_line)) == NULL) {
    fprintf(stderr,"\nsize_line is set at %li\n",size_line);
    errmalloc("brokenwood");
  }
  
  if ((rec & 2) == 2) {     // if result must be recorded
    fp1=fopen(file_output,"a");
    if (fp1==NULL){
	  ERRPOS
      fprintf(stderr,"Unable to open %s ->Exit!\n",file_input);
      exit(EXIT_FAILURE);
    }
    fprintf(fp1,"\n<Start %s >\n",title);
  }
  if ((rec & 1) ==1) printf("\n<Start %s >\n",title);
  
  /*Delete sentences between bracket (...) */
  text=top_text;
  deletebetween(text,'(',')');
  /*Delete sentences between bracket [...] */
  deletebetween(text,'[',']');
  /*Delete sentences between bracket <...> */
  deletebetween(text,'<','>');
  /*Delete sentences between bracket {...} */
  deletebetween(text,'{','}');

  /*Extract expression from the list*/  
  fseek(fp,0,SEEK_SET);
  line[size_line-2]='\0';
  while (fgets(line,size_line,fp) != NULL) {  //read a line
    if (line[size_line-2] != '\0') {
	    ERRPOS
	    fprintf(stderr," size_line too small\n");
	    count_silent_bug++;
	  }
    if (line[0] != '#') { //do not proceed comment
      /*str_ptr2 points the beginning of cue expressions
      Extract one expression*/
      if ((str_ptr1=strpbrk(line,":")) != NULL) {
        *str_ptr1='\0';
        /*search for the expression in the text*/
	      str_ptr2=text;
        while ((str_ptr2=str7bstr(str_ptr2,line,0)) != NULL) {
          expression_cnt++;
		      str_ptr1++;	
		      if ((str_ptr3=strchr(str_ptr1,'\n')) != NULL) *str_ptr3='\0'; //replace \n with \0
		      lg=strlen(str_ptr1);
		      if (lg<strlen(line)) {
		        /*copy the new expression or word*/
		        strncpy(str_ptr2,str_ptr1,lg);
		        /*crunch the diff of size of both expressions*/
		        strcpy(str_ptr2+lg,str_ptr2+strlen(line));
          }
	      }
      }
    }
  }
  
  /*Correct some punctuation incoherence*/
  text=top_text;
  while (*text != '\0') {
    if (strchr(".?!",*text) != NULL) {
	  text++;
	  if (*text=='\0') break;
	  while (*text == ' ') text++;
	  if (*text=='\0') break;
	  if (*text==',' || *text==';') *text=' ';
	}
	text++;
  }
  text=top_text;
  
  /* remove multiple-space */
  cnt_space=0;
  text=top_text;
  while (*text != '\0') {
    if (*text == ' ') {
	  cnt_space++;
	  if (cnt_space == 2) {
	    cnt_space=0;
		strcpy(text,text+1);
		text-=2;
	  }
	} else cnt_space=0;
	text++;
  }  
  text=top_text;
  
  /* Set uppercase */
  *text=toupper(*text);
  while (*text != '\0') {
    if (strchr(".?!",*text)!=NULL) {
	  text++;
	  if (*text == '\0') break;
	  while (*text == ' ') text++;
	  if (*text=='\0') break;
	  if (islower(*text)) *text=toupper(*text);
	}
	text++;
  }
  text=top_text;
  /* line formating */
  if (linewidth) {
    cnt_space=0;
    cnt_chr=0;
    space_pos=text=top_text;
    while (*text != '\0') {
  	  if (cnt_chr >= linewidth) {
	    *space_pos='\n';
	    cnt_chr=0;
	  }
      if (*text == ' ') { 
	    space_pos=text;
	    cnt_space++;  
	  }
	  text++;
	  cnt_chr++;
    }	
    text=top_text;
  }

  /*save text*/
  fp2=fopen(file_text,"w");
  if (fp2==NULL){
    ERRPOS
    fprintf(stderr,"Unable to write %s ->Exit!\n",file_text);
    count_silent_bug++;
    return(0);
  }
  fprintf(fp2,"%s",text);
  if (fclose(fp2) != 0) {
    ERRPOS
    fprintf(stderr," fclose fp2 in abstract");
    count_silent_bug++;
  }
  
  if ((rec & 1) == 1) printf("\n%s\n",text);
  if ((rec & 2) == 2) fprintf(fp1,"\n%s\n",text);
  
  if ((rec & 1) == 1) printf("\n<End %s>\n",title);
  if ((rec & 2) == 2) fprintf(fp1,"\n<End %s>\n",title);
    
  if (fclose(fp) != 0) {
    ERRPOS
    fprintf(stderr," fclose fp in abstract");
    count_silent_bug++;
  }
  if ((rec & 2) == 2) if (fclose(fp1) != 0) {
    ERRPOS
    fprintf(stderr," fclose fp1 in abstract");
    count_silent_bug++;
  }
  if (fclose(fp3) != 0) {
    ERRPOS
    fprintf(stderr," fclose fp3 in abstract");
    count_silent_bug++;
  }
  free(line); free(text);
  if (verbose) printf("\nTotal of expression(s) simplified:%i \n",expression_cnt);
  if (crush_detect!='x') {
    ERRPOS
    fprintf(stderr,"Overflow\n");
    count_silent_bug++;
  }
  return expression_cnt;
}

/*
 *	Combination of sentencematchclass and sentencematchcue
 *	Extract sentences from the list of summaries
 */

long int sentencematchcucl(
	char *file_abstract,char *file_dico1,char *file_dico2,
	char *text,long int *pos_sentence,
	int nbl,int compress_rate,int rec,
	char *class_probable,char *target, char *title)
{
/* 
 Make an abstract by extracting the sentences 
 sentence class must match the general class of the text
 p1,classi:freqN,...,classj:freqN,p2,... 
 
 !!!Bug check => Sometimes doesn't work with small text
 !!!Limitation=> Double scan text and dico => slow routine, 
    - The first scan makes an histogram. The histrogram is used to determine 
    a threshold that will limit the number of sentences extracted to the 
    compress_rate required.
    - The second scan extracts sentences with a score above or equal to the 
    threshold.
 !!! check size sentence, risk of overrun !!!
*/
  FILE *fp01,*fp02,*fp1,*fp2,*fp3;
  char *line; /*line limited at 'size_line' chars*/
  char *lineofcue,*lineofcuebis; /*line limited at 'size_line' chars*/
  char *str_ptr1,*str_ptr2;
  char label[SIZE_SENTENCE]; //of the cue line
  char word[SIZE_WORD],wordchk[SIZE_WORD+2];
  int *class_sum,*class_diff; //'size_nb_class' classes
  char **classname; //'size_nb_class*size_class_name' chars
  long int i,j,length;
  int cont,val,multiply,cnt_suppress,cnt_space;
  char shortline[SHORT_STR];
  int prt_thresh;
  char sentence[SIZE_SENTENCE];
  char linesmart[SIZE_SENTENCE];
  long int pos_char=0; //count chars
  long int k,line_cnt,nb_word,word_cnt; //count lines & words
  long int lg_sentence;
  int offset;
  char ch;
  long int i_best_class,max_class_sum,max_class_diff;
  long int class_threshold=512; //is used with score_table[]
  long int score_table[513]; //score_table[score]=nb_sentences
  long int goal_nbline; //nb lines computed from the compress rate
  unsigned long long prev_hash=0,now_hash=0; //value specific to the sentence 
  char crush_detect='x';
  int cuewordlabel_required=0;
  int found_in_cue,no_found_in_cue;
  char nothing='\0';
  
  for(i=0;i<513;i++) score_table[i]=0;

  prt_thresh=1;  //class of each line is compared
  
  if (linewidth) clever_print(0,""); //reset static var in fct

  fp01=fopen(file_dico1,"r"); //dico provides keywords
  if (fp01==NULL){
    ERRPOS
    fprintf(stderr,"Unable to open %s ->Exit!\n",file_dico1);
    exit(EXIT_FAILURE);
  }
  
  fp02=fopen(file_dico2,"r"); //dico provides cue words
  if (fp02==NULL){
    ERRPOS
    fprintf(stderr,"Unable to open %s ->Exit!\n",file_dico2);
    exit(EXIT_FAILURE);
  }
  
  fp2=fopen(file_input,"r"); //temp file -> sentences are extracted from it
  if (fp2==NULL){
    ERRPOS
    fprintf(stderr,"Unable to open %s ->Exit!\n",file_input);
    return(0);
  }
  
  fp3=fopen(file_abstract,"w"); //result file <- abstract is stored here
  if (fp3==NULL){
    ERRPOS
    fprintf(stderr,"Unable to create abstract ->Exit!\n");
    return(0);
  }
  
  /*Search value size_line for dynamic alloc of line*/  
  size_line=SIZE_LINE; //default value
  fseek(fp01,0,SEEK_SET);
  for(i=0;i<10;i++) { //search only in the 10 first lines
    if (fgets(shortline,SHORT_STR,fp01) == NULL) break; //eof exit loop
    if (shortline[0] == '#') {
      if ((str_ptr1=strstr(shortline,"<LINE_LG:")) != NULL) {
        if ((str_ptr2=strchr(str_ptr1+9,'>')) != NULL) {
	  *str_ptr2='\0';
	  size_line=atoi(str_ptr1+9);
	  if (debug>1) fprintf(stderr,"\nsize_line is set at %li\n",size_line);
  } } } }
  
  /*dynamic alloc*/
  if ((line = (char*)malloc(size_line)) == NULL) errmalloc("sentencematchcucl");
  if ((lineofcue = (char*)malloc(size_line)) == NULL) errmalloc("sentencematchcucl"); 
  if ((classname = (char**)malloc(size_nb_class*sizeof(char*))) == NULL) errmalloc("sentenmatchcucl");
  for (k=0;k<size_nb_class;k++) if ((classname[k] = (char*)malloc(size_class_name)) == NULL) errmalloc("sentencematchcucl");
  if ((class_sum = (int*)malloc(size_nb_class*sizeof(int))) == NULL) errmalloc("sentencematchcucl");
  if ((class_diff = (int*)malloc(size_nb_class*sizeof(int))) == NULL) errmalloc("sentencematchcucl");
  
  if ((length=strlen(text)) == 0) return 0;
  for(i=0;i<size_nb_class;i++) { class_sum[i]=0; class_diff[i]=0; }
  
  if ((rec & 2) == 2) {
    /* Open the output file  */
    fp1=fopen(file_output,"a");
    if (fp1==NULL){
	  ERRPOS
      fprintf(stderr,"Unable to open %s ->Exit!\n",file_input);
      exit(EXIT_FAILURE);
    }
    fprintf(fp1,"\n<Start %s >\n",title);
  }
  if ((rec & 1) == 1) printf("\n<Start %s >\n",title);

  /* do the classname array of the dico */  
  fseek(fp01,0,SEEK_SET);
  for(i=0;i<size_nb_class;i++) {
    line[size_line-1]='\0';
    if (fgets(line,size_line,fp01) == NULL) break;
    if (line[size_line-1] != '\0') {
	  ERRPOS
	  fprintf(stderr,"Error: size_line %li too small\n",size_line);
	  count_silent_bug++;
	}
    if (line[0] != '#') {
      if ((str_ptr2=strpbrk(line,":")) != NULL) *str_ptr2=0;
      if (strlen(line) < size_class_name) strcpy(word,line);
      else {
	    ERRPOS
	    fprintf(stderr,"Err label too long in sentencematchclass:<%s>\n",line);
	    count_silent_bug++;
	  }
      if ((str_ptr2=strpbrk(line," ")) != NULL) *str_ptr2=0;
      if ((j=atoi(line))!=0) strcpy(classname[j],word);
      else {
	    ERRPOS
	    fprintf(stderr," atoi(line) sentencematchclass:<%s>\n",line);
	    count_silent_bug++;
	  }
    }
  }
  
  /* Extract cue expression from dico */
  fseek(fp02,0,SEEK_SET);
  lineofcue[size_line-2]='\0';
  while (fgets(lineofcue,size_line,fp02) != NULL) {  //read a line
    if (lineofcue[size_line-2] != '\0') {
	  ERRPOS
	  fprintf(stderr," size_line too small\n");
	  count_silent_bug++;
	}
    if (lineofcue[0] != '#') { //do not proceed comment
      /*str_ptr2 points the beginning of cue expressions
      store the label of the line of cue*/
      if ((str_ptr2=strpbrk(lineofcue,":")) != NULL) *str_ptr2=0;
      if (strlen(lineofcue) < size_class_name) strcpy(label,lineofcue);
        else {
		  ERRPOS
		  fprintf(stderr,"Error: Label too long in sentencematchclass:<%s>\n",lineofcue);
		  count_silent_bug++;
		}
      /*search for the label*/
      if (strstr(label,target) != NULL) {
		  /* label and target match */
		  lineofcuebis = str_ptr2+1; //just after the label
		  goto label_found;
	  }
    }
  }
  
  if (cuewordlabel_required) {
	  /* clean up and exit*/
	  fprintf(stderr,"The label has been not found.\nNo analysis has been done!\n");
	  count_silent_bug++;
	  free(line);
	  free(lineofcue);
	  for (k=0;k<size_nb_class;k++) free(classname[k]);
	  free(classname);
	  free(class_sum);
	  free(class_diff);
	  return 0; //do not extract because the "cue words rubric" isn't found
  } 
  else {
	  printf("<Rubric %s does not exist>\n",target);
	  lineofcuebis=&nothing; //line is empty
  }
  /*-------------------------*/
  label_found:; //we continue
  
  /* 1st step
   * analyze start here to determine the best threshold
   * each sentences are weighed and an histogram is made
   */ 
  k=line_cnt=0;
  max_class_sum=0;
  i_best_class=0;
  pos_char=0;
  found_in_cue=no_found_in_cue=0;
  
  for(i=0;i<length;i++) {    //scan each char of the text
    if (text[i]=='\n') {     //new word
      for(j=0;i+j+1<length;j++) {   //scan the word
        if (text[j+i+1] != '\n') word[j]=text[j+i+1];  //store the word
          else {   //end of word
            word[j]=0;  //end of chain
            if (strcmp(word,"EOS") != 0) {  //it isn't an end-of-sentence marker
			  /* prepare the word */
              noplural(word,lang); //plural -> singular
              strcpy(wordchk,"\\"); //first delimiter
              strcat(wordchk,word); //wordchk will be used in the search
              strcat(wordchk,"/"); //last delimiter
              if (debug>1) fprintf(stderr,"%s",wordchk);
			  /* search if words in the line cue words 
			   * this line can be empty if there target wasn't founded */
			  if ((str_ptr1=strstr(lineofcuebis,wordchk)) !=NULL) {
				/* word found is the lineofcue, get the multiplier
				 * convert single digit val */
                multiply=chartoi(*(str_ptr1-1));
				found_in_cue++;
              }
			  else {
				  if (cuewordlabel_required) multiply=0;
				    else multiply=1;
				  no_found_in_cue++;
			  }
			  /* start to beginning of the dico */
              fseek(fp01,0,SEEK_SET);
              cont=1;
              /*Now search class : Read each line of the dico*/
              while(cont==1) {
                if (fgets(line,size_line,fp01) == NULL) cont=0;
                else if (line[0] != '#') {  
                  /* Search /word/ in the line from ':' */
                  if ((str_ptr1=strstr(strpbrk(line,":"),wordchk)) !=NULL) {
                    /* convert single digit val and multiply of cue word */
                    val = multiply*chartoi(*(str_ptr1-1));
                    if ((str_ptr2=strpbrk(line," ")) != NULL) *str_ptr2=0;
                    class_sum[atoi(line)]+=val; //score
                    class_diff[atoi(line)]++; //cnt terms found
                  }
                } //endif != '#'
              } //endwhile cont
            } //endif strcmp
			else {
			/* eos found */
				k++;  //k counts line but reset to 0 when == prt_thresh
				line_cnt++; //no reset  =>line_cnt points the end of each sentence
			}
            /*now proceed sentence(s)*/
            if (k >= prt_thresh) {
	      if (debug>1) fprintf(stderr,"\n");
	      /*search the class with the highest score*/
              for(k=0;k<size_nb_class;k++) 
                if (class_diff[k]>0) { //if not empty
                  if (max_class_sum < class_sum[k]) {
		    max_class_sum=class_sum[k];
		    max_class_diff=class_diff[k];
		    i_best_class=k;
		  }
		  /*reset cumul for the next sentence*/
		  class_diff[k]=0; 
		  class_sum[k]=0;
                }
	      /* when class with highest score match the class of the text (class_probable)
	      update the histogram score:nb of sentence*/
	      if (strstr(classname[i_best_class],class_probable) != NULL) {
	        if (max_class_sum >= 512) score_table[512]++;
	          else score_table[max_class_sum]++;
              }
              /*reset some var before the next sentence(s)*/
              k=0;    //reset the line_counter
	      max_class_sum=0; //reset highest score
              i_best_class=0; //reset best class
            }
            i=i+j;    //set the index to the next word
            break;
		     
          }//endelse 'end of word'
      }//endfor i+j+1<length
    }//endif '\n'
  }//endfor i<length

  /* 2nd step
   * make a cumulative histogram
   */  
  for(i=512;i>0;i--) score_table[i-1]+=score_table[i];
    
  if (debug) {
    fprintf(stderr,"Histogramme - Score/Nb sentences\n");
    for(i=512;i>-1;i--) 
      if (score_table[i]>0) fprintf(stderr,"score_%li: %li\n",i,score_table[i]);
  }

  /* 3rd step 
   * Search the immediate lowest threshold to obtain 
   * the expected compression level
   */
  if (compress_rate == 0) goal_nbline=nbl;
  else {
	goal_nbline= (line_cnt*compress_rate)/100;
	if (goal_nbline < 2) goal_nbline=2; //only one line cannot be significatif
	if (goal_nbline > nbl) goal_nbline=nbl; //limit max
  }
  for(i=512;i>-1;i--) {  //decrease the threshold
	if (score_table[i] >= goal_nbline) {
	  class_threshold=i;
	  break;
	}	  
  }

  if (verbose) {
    if ((rec & 1) == 1) 
      printf("Goal Nb lines:%li  Threshold:%li  Possible Nb lines:%li\n",goal_nbline,class_threshold,score_table[class_threshold]);
    if ((rec & 2) == 2) 
      fprintf(fp1,"Goal Nb lines:%li  Threshold:%li  Possible Nb lines:%li\n",goal_nbline,class_threshold,score_table[class_threshold]);
  }
  
  /* 4th step
   * Now we have the threshold, we can search for the most significant sentences
   * each sentences are classified and weighed
   * when the sentence class match the class_probable and the weight > the threshold 
   * the sentence is kept as significant.
   * NOTE: this routine is pretty similar to the 1st step and both are expensive.
   *  => that will save time to classify the sentences during the 1st step
   */ 
  k=line_cnt=word_cnt=0;
  max_class_sum=0;
  i_best_class=0;
  pos_char=0;
  for(i=0;i<length;i++) {    //scan each char of the text
    if (text[i]=='\n') {     //new word
      for(j=0;i+j+1<length;j++) {   //scan the word
        if (text[j+i+1] != '\n') word[j]=text[j+i+1];  //store the word
          else {   //end of word
            word[j]=0;  //end of chain
            if (strcmp(word,"EOS") != 0) {  //it isn't an end-of-sentence marker
              noplural(word,lang); //plural -> singular
              strcpy(wordchk,"\\"); //first delimiter
              strcat(wordchk,word); //wordchk will be used in the search
              strcat(wordchk,"/"); //last delimiter
              if (debug>1) fprintf(stderr,"%s",wordchk);
			  /* search if words in the line cue words 
			   * this line can be empty if there target wasn't founded */
			  if ((str_ptr1=strstr(lineofcuebis,wordchk)) !=NULL) {
				/* word found is the lineofcue, get the multiplier
				 * convert single digit val */
                multiply=chartoi(*(str_ptr1-1));
				found_in_cue++;
              }
			  else {
				  if (cuewordlabel_required) multiply=0;
				    else multiply=1;
				  no_found_in_cue++;
			  }
			  /* start to beginning of the dico */
              fseek(fp01,0,SEEK_SET);
              cont=1;
              /*Now search class : Read each line of the dico*/
              while(cont==1) {
                if (fgets(line,size_line,fp01) == NULL) cont=0;
                else if (line[0] != '#') {  
                  /*Search /word/ in the line*/
                  if ((str_ptr1=strstr(strpbrk(line,":"),wordchk)) !=NULL) {
					/* convert single digit val and multiply of cue word */
                    val = multiply*chartoi(*(str_ptr1-1));
                    if ((str_ptr2=strpbrk(line," ")) != NULL) *str_ptr2=0;
                    class_sum[atoi(line)]+=val; //score
                    class_diff[atoi(line)]++; //cnt terms found
                  }
                }
              }
            } else {
	      k++;  //k counts line but reset to 0 when == prt_thresh
	      line_cnt++; //no reset  =>line_cnt points the end of each sentence
	    }
            /*now proceed sentence(s)*/
            if (k >= prt_thresh) {
	      if (debug>1) fprintf(stderr,"\n");
	      /*search the highest score*/
              for(k=0;k<size_nb_class;k++) 
                if (class_diff[k]>0) { //if not empty
                  if (max_class_sum < class_sum[k]) {
		    max_class_sum=class_sum[k];
		    max_class_diff=class_diff[k];
		    i_best_class=k;
		  }
		  /*reset cumul for the next sentence*/
		  class_diff[k]=0; 
		  class_sum[k]=0;
                }
              
	      if (debug) fprintf(stderr,"Best=>%s=%li\n",classname[i_best_class],max_class_sum);
	      
	      /* if class with highest score match class of the text (class_probable)
	      and if this highest score is above or equal to the threshold then 
	      the sentence is supposed significant */
	      if ((strstr(classname[i_best_class],class_probable) != NULL) && (max_class_sum>=class_threshold)) {
                if (debug) fprintf(stderr,"--- Sentence:%li Pos=%li Score:%li ----------\n",line_cnt,pos_sentence[line_cnt-1],max_class_sum);
                /*Extract sentence from ansi7b converted text*/
	        fseek(fp2,pos_sentence[line_cnt-1],SEEK_SET); //on the end of the previous sentence
		//length = end_new_sentence - end_previous_sentence
	        lg_sentence=pos_sentence[line_cnt]-pos_sentence[line_cnt-1];
	        if (lg_sentence > SIZE_SENTENCE) lg_sentence=SIZE_SENTENCE; //cut the sentence if too long
	        *sentence='\0'; //perhaps unuseful
	        offset=0;
		/*--- read char one by one and filter char ---*/
		cnt_suppress=cnt_space=0;
	        while (lg_sentence--) { 
	          if ((ch=fgetc(fp2)) == EOF) break;
		  /*suppress ctrl chars
		    replace '_' with space
		    only one space
		    suppress repetition some chars such as separators*/
		  if ((unsigned char)ch > 31) {
		    if (ch == '_') ch=' ';
		    if (ch == ' ') cnt_space++;
		      else cnt_space=0;
		    if (strchr(" -=+|'\"<>,.;:!^#@*",ch) != NULL) cnt_suppress++;
		      else cnt_suppress=0;
		    if ((cnt_suppress < 3) && (cnt_space < 2)) *(sentence+offset++)=ch;
		  } 
		  else ch=' '; //ctrl char becomes space (extra-space will be removed after)
	        }
		*(sentence+offset)='\0'; //terminate the sentence
		/*Remove space in the end*/
		offset--;
		while (*(sentence+offset) == ' ') {
		  *(sentence+offset)='\0';
		  offset--;
		}
		/*--- Reformate the sentence a little bit ---*/
		/*Remove space in the beginning*/
		while (*sentence == ' ') strcpy(sentence,sentence+1);
		/*Remove underline in the beginning*/
		while (*sentence == '_') strcpy(sentence,sentence+1);
		/*Remove '>' in the beginning*/
		while (*sentence == '>') strcpy(sentence,sentence+1);
		/*Reajust offset*/
		offset=strlen(sentence)-1;
		/*change some final char*/
		if (strchr(":;",*(sentence+offset)) != NULL) *(sentence+offset)='.';
		/*if no end-of-sentence then add '.' */
		if ((strchr(".!?",*(sentence+offset)) == NULL) && (*(sentence+offset) != '"')) {
		  *(sentence+offset+1)='.'; //add a stop
		  *(sentence+offset+2)='\0'; //terminate the sentence
		}
		strcat(sentence," "); //add a space at the end
		
		/*to avoid same sentences twice, the sentence is converted in a value
		 to be compared with the previous value*/
		prev_hash=now_hash;
		now_hash=weakhashsentence(sentence,lang); //specific value of the sentence
		if (debug) fprintf(stderr,"Hash=%16llX %s\n",now_hash,sentence);
		nb_word=now_hash >> 56; //keep only the last 8 bits (nb words)
		 /* not the same sentence again!
		  * more than 3 words
		  * less than 100 words*/
    if (now_hash != prev_hash && nb_word > 3 && nb_word < 100) {
		  word_cnt+=nb_word; //cumul the nb of word
		  /*--- Print routine ---*/
      if (linewidth && rec > 0) {
        /*Try a smart formating - avoid to cut words with clever_print()
        and eventually a conversion to uf8*/
		clever_print(0,""); //reset static var in fct
        if (abstract_utf8) char2utf8(linesmart,clever_print(linewidth,sentence));
        else strcpy(linesmart,clever_print(linewidth,sentence));

        if ((rec & 1) == 1) printf("\n%s\n",linesmart);
		    if ((rec & 2) == 2) fprintf(fp1,"\n%s\n",linesmart);
		    fprintf(fp3,"\n%s\n",linesmart);
        }
      else {
        /* or no formating*/
		    if ((rec & 1) == 1) printf("%s\n",sentence);
		    if ((rec & 2) == 2) fprintf(fp1,"%s\n",sentence);
		    fprintf(fp3,"%s\n",sentence);
		  }
    } 
    else {
      fprintf(stderr,"Rejected:Hash=%16llX %s\n",now_hash,sentence);
    }
	        /*--------this sentence is done------------*/
              }
              /*reset some var before the next sentence(s)*/
              k=0;    //reset the line_counter
	      max_class_sum=0; //reset highest score
              i_best_class=0; //reset best class
            }
            i=i+j;    //set the index to the next word
            break;     
          }
      }
    }        
  }
  /*last slice*/
  if (k > 0) {
    if ((rec & 1) == 1) printf("--- Last slice k=%li ---\n",k);
    if ((rec & 2) == 2) fprintf(fp1,"--- Last slice k=%li ---\n",k);
    
    for(k=0;k<size_nb_class;k++) {
      if (class_diff[k]>0) {
        if ((rec & 1) == 1) printf("%s=%i\n",classname[k],class_sum[k]);
        if ((rec & 2) == 2) fprintf(fp1,"%s=%i\n",classname[k],class_sum[k]);
  } } }
  
  if ((rec & 1) ==1) printf("\n<End %s>\n",title);
  if ((rec & 2) ==2) fprintf(fp1,"\n<End %s>\n",title);
  
  if (fclose(fp01) != 0) {
    ERRPOS
    fprintf(stderr," fclose fp01 in abstract");
    count_silent_bug++;
  }
    if (fclose(fp02) != 0) {
    ERRPOS
    fprintf(stderr," fclose fp02 in abstract");
    count_silent_bug++;
  }

  if ((rec & 2) == 2) if (fclose(fp1) != 0) {
    ERRPOS
    fprintf(stderr," fclose fp1 in abstract");
    count_silent_bug++;
  }
  if (fclose(fp2) != 0) {
    ERRPOS
    fprintf(stderr," fclose fp2 in abstract");
    count_silent_bug++;
  }
  if (fclose(fp3) != 0) {
    ERRPOS
    fprintf(stderr," fclose fp3 in abstract");
    count_silent_bug++;
  }
  free(line);
  free(lineofcue);
  for (k=0;k<size_nb_class;k++) free(classname[k]);
  free(classname);
  free(class_sum);
  free(class_diff);
  if (verbose) printf("\nTotal of words extracted:%li \n",word_cnt);
  printf("Total of cue words found %i/%i not found\n",found_in_cue,no_found_in_cue);
  if (crush_detect!='x') {
    ERRPOS
    fprintf(stderr,"Overflow\n");
    count_silent_bug++;
  }
  return word_cnt;
}

