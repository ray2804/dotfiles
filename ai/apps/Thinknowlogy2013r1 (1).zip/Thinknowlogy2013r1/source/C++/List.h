/*
 *	Class:		List
 *	Purpose:	Base class to store the items of the knowledge structure
 *	Version:	Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

// List header

#ifndef LIST
#define LIST 1

#include <stdlib.h>
#include "Item.h"

// Class declarations needed by some compilers, like Code::Blocks
class ListCleanup;
class ListQuery;

class List
	{
	// Private constructible variables

	char listChar_;

	Item *activeList_;
	Item *deactiveList_;
	Item *archiveList_;
	Item *deleteList_;

	Item *nextListItem_;

	ListCleanup *listCleanup_;
	ListQuery *listQuery_;

	WordItem *myWord_;

	CommonVariables *commonVariables_;

	char classNameString_[FUNCTION_NAME_LENGTH];
	char superClassNameString_[FUNCTION_NAME_LENGTH];


	private:
	// Private functions

	bool includesThisList( char *queryListString );

	unsigned int highestItemNr();

	ResultType checkForUsage( Item *unusedItem );

	ResultType removeItemFromActiveList( Item *removeItem );
	ResultType removeItemFromDeactiveList( Item *removeItem );
	ResultType removeItemFromArchivedList( Item *removeItem );

	ResultType addItemToDeletedList( bool isAvailableForRollback, Item *newItem );


	public:
	// Constructor

	List();
	~List();


	// Protected error functions

	ResultType addError( const char *functionNameString, const char *moduleNameString, const char *errorString );

	ResultType startError( const char *functionNameString, const char *moduleNameString, const char *errorString );
	ResultType startError( const char *functionNameString, const char *moduleNameString, const char *errorString, unsigned int sentenceNr );
	ResultType startError( const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3 );

	ResultType startSystemError( const char *functionNameString, const char *moduleNameString, const char *errorString );


	// Protected virtual functions

	virtual bool isTemporaryList();

	virtual ResultType findWordReference( WordItem *referenceWordItem );


	// Protected common functions

	void initializeListVariables( char listChar, const char *classNameString, WordItem *myWord, CommonVariables *commonVariables );
	void deleteList();

	bool hasItems();
	bool hasActiveItems();

	bool isAdminList();
	bool isAssignmentList();

	unsigned int highestSentenceNrInList();

	char listChar();

	ResultType addItemToActiveList( Item *newItem );
	ResultType addItemToDeactiveList( Item *newItem );
	ResultType addItemToArchivedList( Item *newItem );

	ResultType activateDeactiveItem( Item *activateItem );
	ResultType deactivateActiveItem( Item *deactivateItem );

	ResultType archiveActiveItem( Item *archiveItem );
	ResultType archiveDeactiveItem( Item *archiveItem );

	ResultType activateArchivedItem( bool isAvailableForRollback, Item *activateItem );
	ResultType deactivateArchivedItem( bool isAvailableForRollback, Item *activateItem );

	ResultType deleteActiveItemsWithCurrentSentenceNr();

	ResultType deleteActiveItem( bool isAvailableForRollback, Item *deleteItem );
	ResultType deleteDeactiveItem( bool isAvailableForRollback, Item *deleteItem );
	ResultType deleteArchivedItem( bool isAvailableForRollback, Item *archiveItem );

	ResultType removeFirstRangeOfDeletedItemsInList();
	ResultType removeItemFromDeletedList( Item *removeItem );

	Item *firstActiveItem();
	Item *firstDeactiveItem();
	Item *firstArchivedItem();
	Item *firstDeletedItem();

	Item *nextListItem();

	WordItem *myWord();

	CommonVariables *commonVariables();


	// Protected cleanup functions

	ResultType getCurrentItemNrInList();
	ResultType getHighestInUseSentenceNrInList( bool includeDeletedItems, unsigned int highestSentenceNr );

	ResultType undoCurrentSentenceInList();
	ResultType redoCurrentSentenceInList();

	ResultType rollbackDeletedRedoInfoInList();
	ResultType deleteRollbackInfoInList();

	ResultType deleteSentencesInList( bool isAvailableForRollback, unsigned int lowestSentenceNr );

	ResultType decrementSentenceNrsInList( unsigned int startSentenceNr );
	ResultType decrementItemNrRangeInList( unsigned int decrementSentenceNr, unsigned int startDecrementItemNr, unsigned int decrementOffset );


	// Protected query functions

	void countQueryInList();
	void clearQuerySelectionsInList();

	ResultType compareStrings( char *searchString, char *sourceString );

	ResultType itemQueryInList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, bool isReferenceQuery, unsigned int querySentenceNr, unsigned int queryItemNr );
	ResultType listQueryInList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *queryListString );
	ResultType wordTypeQueryInList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, unsigned short queryWordTypeNr );
	ResultType parameterQueryInList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, unsigned int queryParameter );
	ResultType wordQueryInList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems );
	ResultType wordReferenceQueryInList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *wordReferenceNameString );
	ResultType stringQueryInList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *queryString );

	ResultType showQueryResultInList( bool showOnlyWords, bool showOnlyWordReferences, bool showOnlyStrings, bool returnQueryToPosition, unsigned short promptTypeNr, unsigned short queryWordTypeNr, size_t queryWidth );
	};
#endif

/*************************************************************************
 *
 *	"I prayed to the Lord, and he answered me.
 *	He freed me from all my fears." (Psalm 34:4)
 *
 *************************************************************************/
