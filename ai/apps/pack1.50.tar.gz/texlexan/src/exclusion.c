/* License/copyright: Dual licences, read copyright.txt in the package*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>
#include <unistd.h>
#include "definitions.h"
#include "utils.h"
#include "exclusion.h"

/*------------- functions ------------*/

long int excludedfromfile(char *path,char *excludedword,int filenum,char *lang,long int n){
/*load file containing exluded or basic words (such as articles...)*/
FILE *fp;
char filename[SIZE_WORD];
char ch;
int i; //cntword

  if (filenum==1) sprintf(filename,"%sexcluded.%s.word",path,lang);
  if (filenum==2) sprintf(filename,"%sbasic.%s.word",path,lang);
 
  if ((fp=fopen(filename,"r")) == NULL) {
    ERRPOS
    fprintf(stderr,"Unable to open %s \n",filename);
    return -1;
  }
  
  excludedword[0]='\n';

  i=1;
  while ((ch=fgetc(fp)) != EOF) {
    /*if comment read a full line eol terminated*/
    if (ch=='#') {
      while (((ch=fgetc(fp)) != EOF) && (ch != '\n')) {}
    } 
    else
    {
      /*change semicolon and slash in eol*/
      if ((ch==';') || (ch=='/')) ch='\n';
      /*prevent duplicate \n*/
      if ((ch == '\n') && (ch == excludedword[i-1])) {}
      else excludedword[i++]=ch;
      if (i==n) {
        excludedword[i]='\0';
		ERRPOS
        fprintf(stderr,"Overflow in excludedfromfile");
        fclose(fp);
        return -1;
      }
    }
  }
  if (excludedword[i-1] != '\n') excludedword[i++]='\n';
  excludedword[i]='\0';
  fclose(fp);
  return i;
}

int exclusion(char *excludedword,char *word) {
/*to increase speed: use hash table*/
char worddelimited[SIZE_WORD];
  worddelimited[0]='\n';
  strcpy(worddelimited,word);
  strcat(worddelimited,"\n");
  if (strstr(excludedword,word) == NULL) return 1;
  return 0;

}
