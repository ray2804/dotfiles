package mysql_contxt::tab;
use base qw(mysql_contxt);
use strict;

sub save{
	my $self = shift;
	$self->{file_save} = shift;

	#--------------------------#
	#   �ǡ����ե�����ν���   #
	
	my $file_data = $self->data_file;
	open (DOUT,">$file_data") or 
		gui_errormsg->open(
			type    => 'file',
			thefile => "$file_data",
		);
	my $n = 1;
	foreach my $i (@{$self->{wList}}){
	print "\rout, $n.";
		# ��ñ�̤ν��פ�绻
		my %line;
		foreach my $t (@{$self->{tani}}){
			my $table = 'ct_'."$t->[0]".'_contxt_'."$i";
			# ʸ�����ʬ��μ�����
			my $r_num_hdl = mysql_exec->select("
				SELECT num
				FROM   $table
				WHERE  word = -1
			",1)->hundle->fetch;
			my $r_num;
			if ($r_num_hdl){
				$r_num = $r_num_hdl->[0];
			} else {
				next;
			}
			# �����ͷ׻��ʳ�껻���Ť��դ���
			my $sth = mysql_exec->select("
				SELECT word, num
				FROM   $table
				WHERE  word > 0
			",1)->hundle;
			while (my $r = $sth->fetch){
				$line{$r->[0]} += ($r->[1] / $r_num) * $t->[1];
			}
			$sth->finish;
		}
		# �񤭽Ф�
		my $line =
			Jcode->new($self->{wName}{$i})->sjis
			.'('
			."$self->{wNum}{$i}"
			.')'
			."\t"
		;
		foreach my $w2 (@{$self->{wList2}}){
			if ($line{$w2}){
				#$line .= sprintf("%.8f",$line{$w2}).',';
				$line .= "$line{$w2}\t";
			} else {
				$line .= "0\t";
			}
		}
		chop $line;
		print DOUT "$line\n";
		++$n;
	}
	print "\n";
	close DOUT;

	$self->_save_finish;
}


#---------------------#
#   1���ܤ��դ�­��   #

sub _save_finish{
	my $self = shift;
	
	use kh_csv;
	my $first_line = "��и�\t";
	foreach my $w2 (@{$self->{wList2}}){
		$first_line .= 'cw: '.kh_csv->value_conv_t($self->{wName2}{$w2})."\t";
	}
	chop $first_line;
	$first_line = Jcode->new($first_line)->sjis;
	
	my $file = $self->data_file;
	my $file_tmp = "$file".".bak";
	
	open (OLD,"$file") or 
		gui_errormsg->open(
			type    => 'file',
			thefile => "$file",
		);
	open (NEW,">$file_tmp") or
		gui_errormsg->open(
			type    => 'file',
			thefile => "$file_tmp",
		);
	print NEW "$first_line\n";
	while (<OLD>){
		print NEW $_;
	}
	close (NEW);
	close (OLD);
	unlink($file);
	rename($file_tmp,$file);

	unless ($::config_obj->os eq 'win32'){
		kh_jchar->to_euc($file);
	}
}

#--------------#
#   ��������   #
#--------------#

sub data_file{
	my $self = shift;
	return $self->{file_save};
}


1;