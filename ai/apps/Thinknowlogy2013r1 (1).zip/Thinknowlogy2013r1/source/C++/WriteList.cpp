/*
 *	Class:			WriteList
 *	Parent class:	List
 *	Purpose:		To temporarily store write items
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "List.h"
#include "WriteItem.cpp"
#include "WriteResultType.cpp"

class WriteList : private List
	{
	friend class WordItem;
	friend class WordWriteSentence;

	// Private deconstructor functions

	void deleteWriteList( WriteItem *searchItem )
		{
		WriteItem *deleteItem;

		while( searchItem != NULL )
			{
			deleteItem = searchItem;
			searchItem = searchItem->nextWriteItem();
			delete deleteItem;
			}
		}


	public:
	// Constructor

	WriteList( WordItem *myWord, CommonVariables *commonVariables )
		{
		initializeListVariables( WORD_WRITE_LIST_SYMBOL, "WriteList", myWord, commonVariables );
		}

	// Deconstructor

	~WriteList()
		{
		deleteWriteList( firstActiveWriteItem() );
		deleteWriteList( (WriteItem *)firstDeactiveItem() );
		deleteWriteList( (WriteItem *)firstArchivedItem() );
		deleteWriteList( (WriteItem *)firstDeletedItem() );
		}


	// Protected virtual functions

	virtual bool isTemporaryList()
		{
		return true;
		}


	// Protected functions

	ResultType checkGrammarItemForUsage( GrammarItem *unusedGrammarItem )
		{
		WriteItem *searchItem = firstActiveWriteItem();
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkGrammarItemForUsage";

		if( unusedGrammarItem != NULL )
			{
			while( searchItem != NULL )
				{
				if( searchItem->startOfChoiceOrOptionGrammarItem() == unusedGrammarItem )
					return startError( functionNameString, NULL, "The start of choice or option grammar item is still in use" );

				searchItem = searchItem->nextWriteItem();
				}
			}
		else
			return startError( functionNameString, NULL, "The given unused grammar item is undefined" );

		return commonVariables()->result;
		}

	ResultType createWriteItem( bool isSkipped, unsigned short grammarLevel, GrammarItem *startOfChoiceOrOptionGrammarItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "createWriteItem";
		if( commonVariables()->currentItemNr < MAX_ITEM_NR )
			{
			if( addItemToActiveList( (Item *)new WriteItem( isSkipped, grammarLevel, startOfChoiceOrOptionGrammarItem, this, myWord(), commonVariables() ) ) != RESULT_OK )
				return addError( functionNameString, NULL, "I failed to add an active write item" );
			}
		else
			return startError( functionNameString, NULL, "The current item number is undefined" );

		return commonVariables()->result;
		}

	WriteItem *firstActiveWriteItem()
		{
		return (WriteItem *)firstActiveItem();
		}
	};

/*************************************************************************
 *
 *	"God says, "At the time I have planned,
 *	I will bring justice against the wicked.
 *	When the earth quackes and its people live in turmoil,
 *	I am the one that keeps its foundations firm." (Psalm 75:2-3)
 *
 *************************************************************************/
