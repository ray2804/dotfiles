package gui_airborne::win32;
use base qw(gui_airborne);
use strict;

1;