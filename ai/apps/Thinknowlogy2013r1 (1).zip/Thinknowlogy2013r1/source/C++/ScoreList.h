/*
 *	Class:			ScoreList
 *	Parent class:	List
 *	Purpose:		To temporarily store score items
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

// Score List header

#ifndef SCORELIST
#define SCORELIST 1

#include "List.h"
#include "ScoreItem.cpp"

class ScoreList : private List
	{
	friend class AdminItem;
	friend class AdminSolve;


	// Private constructible variables

	bool hasBetterScore_;
	bool hasEqualScore_;
	bool hasFoundScore_;

	// Private deconstructor functions

	void deleteScoreList( ScoreItem *searchItem );


	// Private functions

	ResultType markAction( SelectionItem *markSelectionReference );
	ResultType disableAction( bool includeMarkedActions, SelectionItem *disableItem );
	ResultType getBestScore( bool cummulative, unsigned short solveStrategyParameter, unsigned long oldSatisfiedScore, unsigned long newSatisfiedScore, unsigned long oldDissatisfiedScore, unsigned long newDissatisfiedScore, unsigned long oldNotBlockingScore, unsigned long newNotBlockingScore, unsigned long oldBlockingScore, unsigned long newBlockingScore, unsigned long bestOldSatisfiedScore, unsigned long bestNewSatisfiedScore, unsigned long bestOldDissatisfiedScore, unsigned long bestNewDissatisfiedScore, unsigned long bestOldNotBlockingScore, unsigned long bestNewNotBlockingScore, unsigned long bestOldBlockingScore, unsigned long bestNewBlockingScore );

	ScoreItem *firstActiveScoreItem();
	ScoreItem *nextScoreListItem();


	public:
	// Constructor

	ScoreList( WordItem *myWord, CommonVariables *commonVariables );

	// Deconstructor

	~ScoreList();


	// Protected virtual functions

	virtual bool isTemporaryList();


	// Protected functions

	bool hasFoundScore();

	unsigned int numberOfPossibilities();

	ResultType changeAction( SelectionItem *actionSelectionItem );
	ResultType checkSelectionItemForUsage( SelectionItem *unusedSelectionItem );
	ResultType findScore( bool prepareSort, SelectionItem *findScoreItem );

	ResultType deleteScores();

	ResultType checkScores( bool isInverted, unsigned short solveStrategyParameter, unsigned long oldSatisfiedScore, unsigned long newSatisfiedScore, unsigned long oldDissatisfiedScore, unsigned long newDissatisfiedScore, unsigned long oldNotBlockingScore, unsigned long newNotBlockingScore, unsigned long oldBlockingScore, unsigned long newBlockingScore );
	ResultType createScoreItem( bool isChecked, unsigned long oldSatisfiedScore, unsigned long newSatisfiedScore, unsigned long oldDissatisfiedScore, unsigned long newDissatisfiedScore, unsigned long oldNotBlockingScore, unsigned long newNotBlockingScore, unsigned long oldBlockingScore, unsigned long newBlockingScore, SelectionItem *referenceSelectionItem );

	SelectionResultType getBestAction( unsigned short solveStrategyParameter );

	ScoreItem *firstPossibility();
	};
#endif

/*************************************************************************
 *
 *	"Those who look to him for help will be radiant with joy;
 *	no shadow of shame wil darken their faces." (Psalm 34:5)
 *
 *************************************************************************/
