/*
 *	Class:			WordList
 *	Parent class:	List
 *	Purpose:		To store word items
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

class WordList extends List
	{

	// Private assignment methods

	private byte createNewAssignmentLevelInWordList( WordItem searchItem )
		{
		while( CommonVariables.result == Constants.RESULT_OK &&
		searchItem != null )
			{
			searchItem.createNewAssignmentLevel();
			searchItem = searchItem.nextWordItem();
			}

		return CommonVariables.result;
		}


	// Private cleanup methods

	private int highestSentenceNrInWordList( WordItem searchItem )
		{
		int tempSentenceNr;
		int highestSentenceNr = Constants.NO_SENTENCE_NR;

		while( searchItem != null )
			{
			if( ( tempSentenceNr = searchItem.highestSentenceNr() ) > highestSentenceNr )
				highestSentenceNr = tempSentenceNr;

			searchItem = searchItem.nextWordItem();
			}

		return highestSentenceNr;
		}

	private byte getCurrentItemNrInWordList( WordItem searchItem )
		{
		while( searchItem != null )
			{
			if( searchItem.getCurrentItemNrInWord() == Constants.RESULT_OK )
				searchItem = searchItem.nextWordItem();
			else
				return addError( 1, null, "I failed to get the current item number in a word" );
			}

		return CommonVariables.result;
		}

	private byte rollbackDeletedRedoInfoInWordList( WordItem searchItem )
		{
		while( searchItem != null )
			{
			if( searchItem.rollbackDeletedRedoInfo() == Constants.RESULT_OK )
				searchItem = searchItem.nextWordItem();
			else
				return addError( 1, null, "I failed to rollback a deleted item in a word" );
			}

		return CommonVariables.result;
		}

	private byte deleteRollbackInfoInWordList( WordItem searchItem )
		{
		while( searchItem != null )
			{
			if( searchItem.deleteRollbackInfo() == Constants.RESULT_OK )
				searchItem = searchItem.nextWordItem();
			else
				return addError( 1, null, "I failed to delete the rollback info in a word" );
			}

		return CommonVariables.result;
		}

	private byte deleteSentencesInWordList( boolean isAvailableForRollback, int lowestSentenceNr, WordItem searchItem )
		{
		while( searchItem != null )
			{
			if( searchItem.deleteSentencesInWord( isAvailableForRollback, lowestSentenceNr ) == Constants.RESULT_OK )
				searchItem = searchItem.nextWordItem();
			else
				return addError( 1, null, "I failed to delete sentences in a word" );
			}

		return CommonVariables.result;
		}

	private byte removeFirstRangeOfDeletedItemsInWordList( WordItem searchItem )
		{
		while( searchItem != null &&
		CommonVariables.nDeletedItems == 0 )
			{
			if( searchItem.removeFirstRangeOfDeletedItems() == Constants.RESULT_OK )
				searchItem = searchItem.nextWordItem();
			else
				return addError( 1, null, "I failed to remove the first deleted items in a word" );
			}

		return CommonVariables.result;
		}

	private byte getHighestInUseSentenceNrInWordList( boolean includeDeletedItems, boolean includeLanguageAssignments, boolean includeTemporaryLists, int highestSentenceNr, WordItem searchItem )
		{
		while( searchItem != null &&
		CommonVariables.highestInUseSentenceNr < highestSentenceNr )
			{
			if( searchItem.getHighestInUseSentenceNrInWord( includeDeletedItems, includeLanguageAssignments, includeTemporaryLists, highestSentenceNr ) == Constants.RESULT_OK )
				searchItem = searchItem.nextWordItem();
			else
				return addError( 1, null, "I failed to check if the sentence is empty in a word" );
			}

		return CommonVariables.result;
		}

	private byte decrementSentenceNrsInWordList( int startSentenceNr, WordItem searchItem )
		{
		while( searchItem != null )
			{
			if( searchItem.decrementSentenceNrsInWord( startSentenceNr ) == Constants.RESULT_OK )
				searchItem = searchItem.nextWordItem();
			else
				return addError( 1, null, "I failed to decrement the sentence numbers from the current sentence number in a word" );
			}

		return CommonVariables.result;
		}

	private byte decrementItemNrRangeInWordList( int decrementSentenceNr, int decrementItemNr, int decrementOffset, WordItem searchItem )
		{
		while( searchItem != null )
			{
			if( searchItem.decrementItemNrRangeInWord( decrementSentenceNr, decrementItemNr, decrementOffset ) == Constants.RESULT_OK )
				searchItem = searchItem.nextWordItem();
			else
				return addError( 1, null, "I failed to decrement item numbers in a word" );
			}

		return CommonVariables.result;
		}


	// Private query methods

	private void countQueryInWordList( WordItem searchItem )
		{
		while( searchItem != null )
			{
			searchItem.countQuery();
			searchItem = searchItem.nextWordItem();
			}
		}

	private void clearQuerySelectionsInWordList( WordItem searchItem )
		{
		while( searchItem != null )
			{
			searchItem.clearQuerySelections();
			searchItem = searchItem.nextWordItem();
			}
		}

	private byte wordQueryInWordList( boolean isFirstInstruction, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, String wordNameString, WordItem searchItem )
		{
		while( searchItem != null )
			{
			if( searchItem.wordQueryInWord( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordNameString ) == Constants.RESULT_OK )
				searchItem = searchItem.nextWordItem();
			else
				return addError( 1, null, "I failed to query a word" );
			}

		return CommonVariables.result;
		}

	private byte itemQueryInWordList( boolean isFirstInstruction, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, boolean isReferenceQuery, int querySentenceNr, int queryItemNr, WordItem searchItem )
		{
		while( searchItem != null )
			{
			if( searchItem.itemQueryInWord( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, isReferenceQuery, querySentenceNr, queryItemNr ) == Constants.RESULT_OK )
				searchItem = searchItem.nextWordItem();
			else
				return addError( 1, null, "I failed to query item numbers in a word" );
			}

		return CommonVariables.result;
		}

	private byte listQueryInWordList( boolean isFirstInstruction, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, StringBuffer queryListStringBuffer, WordItem searchItem )
		{
		while( searchItem != null )
			{
			if( searchItem.listQueryInWord( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryListStringBuffer ) == Constants.RESULT_OK )
				searchItem = searchItem.nextWordItem();
			else
				return addError( 1, null, "I failed to query lists in a word" );
			}

		return CommonVariables.result;
		}

	private byte wordTypeQueryInWordList( boolean isFirstInstruction, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, short queryWordTypeNr, WordItem searchItem )
		{
		while( searchItem != null )
			{
			if( searchItem.wordTypeQueryInWord( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryWordTypeNr ) == Constants.RESULT_OK )
				searchItem = searchItem.nextWordItem();
			else
				return addError( 1, null, "I failed to query word types in a word" );
			}

		return CommonVariables.result;
		}

	private byte parameterQueryInWordList( boolean isFirstInstruction, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, int queryParameter, WordItem searchItem )
		{
		while( searchItem != null )
			{
			if( isFirstInstruction &&
			searchItem.hasFoundParameter( queryParameter ) )
				searchItem.isSelectedByQuery = true;

//			if( searchItem.isSelectedByQuery )
				{
				if( searchItem.parameterQueryInWord( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryParameter ) != Constants.RESULT_OK )
					return addError( 1, null, "I failed to query parameters in a word" );
				}

			searchItem = searchItem.nextWordItem();
			}

		return CommonVariables.result;
		}

	private byte wordReferenceQueryInWordList( boolean isFirstInstruction, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, String wordReferenceNameString, WordItem searchItem )
		{
		while( searchItem != null )
			{
			if( searchItem.wordReferenceQueryInWord( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordReferenceNameString ) == Constants.RESULT_OK )
				searchItem = searchItem.nextWordItem();
			else
				return addError( 1, null, "I failed to query word references in a word" );
			}

		return CommonVariables.result;
		}

	private byte stringQueryInWordList( boolean isFirstInstruction, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, String queryString, WordItem searchItem )
		{
		while( searchItem != null )
			{
			if( searchItem.stringQueryInWord( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryString ) == Constants.RESULT_OK )
				searchItem = searchItem.nextWordItem();
			else
				return addError( 1, null, "I failed to query strings in a word" );
			}

		return CommonVariables.result;
		}

	private byte showQueryResultInWordList( boolean showOnlyWords, boolean showOnlyWordReferences, boolean showOnlyStrings, boolean returnQueryToPosition, short promptTypeNr, short queryWordTypeNr, int queryWidth, WordItem searchItem )
		{
		while( searchItem != null )
			{
			if( searchItem.showQueryResultInWord( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth ) == Constants.RESULT_OK )
				searchItem = searchItem.nextWordItem();
			else
				return addError( 1, null, "I failed to show the query result in a word" );
			}

		return CommonVariables.result;
		}


	// Private common methods

	private WordItem firstActiveWordItem()
		{
		return (WordItem)firstActiveItem();
		}

	private WordItem firstDeactiveWordItem()
		{
		return (WordItem)firstDeactiveItem();
		}

	private WordItem firstArchivedWordItem()
		{
		return (WordItem)firstArchivedItem();
		}

	private WordItem firstDeletedWordItem()
		{
		return (WordItem)firstDeletedItem();
		}


	// Constructor

	protected WordList( WordItem myWord )
		{
		initializeListVariables( Constants.ADMIN_WORD_LIST_SYMBOL, myWord );
		}


	// Protected assignment methods

	protected byte createNewAssignmentLevelInWordList()
		{
		if( createNewAssignmentLevelInWordList( firstActiveWordItem() ) == Constants.RESULT_OK )
			return createNewAssignmentLevelInWordList( firstDeactiveWordItem() );

		return CommonVariables.result;
		}


	// Protected cleanup methods

	protected int highestSentenceNrInWordList()
		{
		int tempSentenceNr;
		int highestSentenceNr = highestSentenceNrInWordList( firstActiveWordItem() );

		if( ( tempSentenceNr = highestSentenceNrInWordList( firstDeactiveWordItem() ) ) > highestSentenceNr )
			highestSentenceNr = tempSentenceNr;

		if( ( tempSentenceNr = highestSentenceNrInWordList( firstArchivedWordItem() ) ) > highestSentenceNr )
			highestSentenceNr = tempSentenceNr;

		if( ( tempSentenceNr = highestSentenceNrInWordList( firstDeletedWordItem() ) ) > highestSentenceNr )
			highestSentenceNr = tempSentenceNr;

		return highestSentenceNr;
		}

	protected byte getCurrentItemNrInWordList()
		{
		if( getCurrentItemNrInWordList( firstActiveWordItem() ) == Constants.RESULT_OK )
			{
			if( getCurrentItemNrInWordList( firstDeactiveWordItem() ) == Constants.RESULT_OK )
				{
				if( getCurrentItemNrInWordList( firstArchivedWordItem() ) == Constants.RESULT_OK )
					return getCurrentItemNrInWordList( firstDeletedWordItem() );
				}
			}

		return CommonVariables.result;
		}

	protected byte rollbackDeletedRedoInfoInWordList()
		{
		if( rollbackDeletedRedoInfoInWordList( firstActiveWordItem() ) == Constants.RESULT_OK )
			{
			if( rollbackDeletedRedoInfoInWordList( firstDeactiveWordItem() ) == Constants.RESULT_OK )
				{
				if( rollbackDeletedRedoInfoInWordList( firstArchivedWordItem() ) == Constants.RESULT_OK )
					return rollbackDeletedRedoInfoInWordList( firstDeletedWordItem() );
				}
			}

		return CommonVariables.result;
		}

	protected byte deleteRollbackInfoInWordList()
		{
		if( deleteRollbackInfoInWordList( firstActiveWordItem() ) == Constants.RESULT_OK )
			{
			if( deleteRollbackInfoInWordList( firstDeactiveWordItem() ) == Constants.RESULT_OK )
				return deleteRollbackInfoInWordList( firstArchivedWordItem() );
			}

		return CommonVariables.result;
		}

	protected byte deleteSentencesInWordList( boolean isAvailableForRollback, int lowestSentenceNr )
		{
		if( deleteSentencesInWordList( isAvailableForRollback, lowestSentenceNr, firstActiveWordItem() ) == Constants.RESULT_OK )
			{
			if( deleteSentencesInWordList( isAvailableForRollback, lowestSentenceNr, firstDeactiveWordItem() ) == Constants.RESULT_OK )
				{
				if( deleteSentencesInWordList( isAvailableForRollback, lowestSentenceNr, firstArchivedWordItem() ) == Constants.RESULT_OK )
					return deleteSentencesInWordList( isAvailableForRollback, lowestSentenceNr, firstDeletedWordItem() );
				}
			}

		return CommonVariables.result;
		}

	protected byte removeFirstRangeOfDeletedItemsInWordList()
		{
		if( removeFirstRangeOfDeletedItemsInWordList( firstActiveWordItem() ) == Constants.RESULT_OK )
			{
			if( removeFirstRangeOfDeletedItemsInWordList( firstDeactiveWordItem() ) == Constants.RESULT_OK )
				{
				if( removeFirstRangeOfDeletedItemsInWordList( firstArchivedWordItem() ) == Constants.RESULT_OK )
					return removeFirstRangeOfDeletedItemsInWordList( firstDeletedWordItem() );
				}
			}

		return CommonVariables.result;
		}

	protected byte getHighestInUseSentenceNrInWordList( boolean includeDeletedItems, boolean includeLanguageAssignments, boolean includeTemporaryLists, int highestSentenceNr )
		{
		if( getHighestInUseSentenceNrInWordList( includeDeletedItems, includeLanguageAssignments, includeTemporaryLists, highestSentenceNr, firstActiveWordItem() ) == Constants.RESULT_OK )
			{
			if( CommonVariables.highestInUseSentenceNr < highestSentenceNr )
				{
				if( getHighestInUseSentenceNrInWordList( includeDeletedItems, includeLanguageAssignments, includeTemporaryLists, highestSentenceNr, firstDeactiveWordItem() ) == Constants.RESULT_OK )
					{
					if( CommonVariables.highestInUseSentenceNr < highestSentenceNr )
						{
						if( getHighestInUseSentenceNrInWordList( includeDeletedItems, includeLanguageAssignments, includeTemporaryLists, highestSentenceNr, firstArchivedWordItem() ) == Constants.RESULT_OK )
							{
							if( includeDeletedItems &&
							CommonVariables.highestInUseSentenceNr < highestSentenceNr )
								return getHighestInUseSentenceNrInWordList( includeDeletedItems, includeLanguageAssignments, includeTemporaryLists, highestSentenceNr, firstDeletedWordItem() );
							}
						}
					}
				}
			}

		return CommonVariables.result;
		}

	protected byte decrementSentenceNrsInWordList( int startSentenceNr )
		{
		if( decrementSentenceNrsInWordList( startSentenceNr, firstActiveWordItem() ) == Constants.RESULT_OK )
			{
			if( decrementSentenceNrsInWordList( startSentenceNr, firstDeactiveWordItem() ) == Constants.RESULT_OK )
				{
				if( decrementSentenceNrsInWordList( startSentenceNr, firstArchivedWordItem() ) == Constants.RESULT_OK )
					return decrementSentenceNrsInWordList( startSentenceNr, firstDeletedWordItem() );
				}
			}

		return CommonVariables.result;
		}

	protected byte decrementItemNrRangeInWordList( int decrementSentenceNr, int decrementItemNr, int decrementOffset )
		{
		if( decrementItemNrRangeInWordList( decrementSentenceNr, decrementItemNr, decrementOffset, firstActiveWordItem() ) == Constants.RESULT_OK )
			{
			if( decrementItemNrRangeInWordList( decrementSentenceNr, decrementItemNr, decrementOffset, firstDeactiveWordItem() ) == Constants.RESULT_OK )
				{
				if( decrementItemNrRangeInWordList( decrementSentenceNr, decrementItemNr, decrementOffset, firstArchivedWordItem() ) == Constants.RESULT_OK )
					return decrementItemNrRangeInWordList( decrementSentenceNr, decrementItemNr, decrementOffset, firstDeletedWordItem() );
				}
			}

		return CommonVariables.result;
		}


	// Protected query methods

	protected void countQueryInWordList()
		{
		countQueryInWordList( firstActiveWordItem() );
		countQueryInWordList( firstDeactiveWordItem() );
		countQueryInWordList( firstArchivedWordItem() );
		countQueryInWordList( firstDeletedWordItem() );
		}

	protected void clearQuerySelectionsInWordList()
		{
		clearQuerySelectionsInWordList( firstActiveWordItem() );
		clearQuerySelectionsInWordList( firstDeactiveWordItem() );
		clearQuerySelectionsInWordList( firstArchivedWordItem() );
		clearQuerySelectionsInWordList( firstDeletedWordItem() );
		}

	protected byte wordQueryInWordList( boolean isFirstInstruction, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, String wordNameString )
		{
		if( wordQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordNameString, firstActiveWordItem() ) == Constants.RESULT_OK )
			{
			if( wordQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordNameString, firstDeactiveWordItem() ) == Constants.RESULT_OK )
				{
				if( wordQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordNameString, firstArchivedWordItem() ) == Constants.RESULT_OK )
					return wordQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordNameString, firstDeletedWordItem() );
				}
			}

		return CommonVariables.result;
		}

	protected byte itemQueryInWordList( boolean isFirstInstruction, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, boolean isReferenceQuery, int querySentenceNr, int queryItemNr )
		{
		if( itemQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, isReferenceQuery, querySentenceNr, queryItemNr, firstActiveWordItem() ) == Constants.RESULT_OK )
			{
			if( itemQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, isReferenceQuery, querySentenceNr, queryItemNr, firstDeactiveWordItem() ) == Constants.RESULT_OK )
				{
				if( itemQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, isReferenceQuery, querySentenceNr, queryItemNr, firstArchivedWordItem() ) == Constants.RESULT_OK )
					return itemQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, isReferenceQuery, querySentenceNr, queryItemNr, firstDeletedWordItem() );
				}
			}

		return CommonVariables.result;
		}

	protected byte listQueryInWordList( boolean isFirstInstruction, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, StringBuffer queryListStringBuffer )
		{
		if( listQueryInList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryListStringBuffer ) == Constants.RESULT_OK )
			{
			if( listQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryListStringBuffer, firstActiveWordItem() ) == Constants.RESULT_OK )
				{
				if( listQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryListStringBuffer, firstDeactiveWordItem() ) == Constants.RESULT_OK )
					{
					if( listQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryListStringBuffer, firstArchivedWordItem() ) == Constants.RESULT_OK )
						return listQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryListStringBuffer, firstDeletedWordItem() );
					}
				}
			}
		else
			return addError( 1, null, "I failed to query my own list" );

		return CommonVariables.result;
		}

	protected byte wordTypeQueryInWordList( boolean isFirstInstruction, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, short queryWordTypeNr )
		{
		if( wordTypeQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryWordTypeNr, firstActiveWordItem() ) == Constants.RESULT_OK )
			{
			if( wordTypeQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryWordTypeNr, firstDeactiveWordItem() ) == Constants.RESULT_OK )
				{
				if( wordTypeQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryWordTypeNr, firstArchivedWordItem() ) == Constants.RESULT_OK )
					return wordTypeQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryWordTypeNr, firstDeletedWordItem() );
				}
			}

		return CommonVariables.result;
		}

	protected byte parameterQueryInWordList( boolean isFirstInstruction, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, int queryParameter )
		{
		if( parameterQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryParameter, firstActiveWordItem() ) == Constants.RESULT_OK )
			{
			if( parameterQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryParameter, firstDeactiveWordItem() ) == Constants.RESULT_OK )
				{
				if( parameterQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryParameter, firstArchivedWordItem() ) == Constants.RESULT_OK )
					return parameterQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryParameter, firstDeletedWordItem() );
				}
			}

		return CommonVariables.result;
		}

	protected byte wordReferenceQueryInWordList( boolean isFirstInstruction, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, String wordReferenceNameString )
		{
		if( wordReferenceQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordReferenceNameString, firstActiveWordItem() ) == Constants.RESULT_OK )
			{
			if( wordReferenceQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordReferenceNameString, firstDeactiveWordItem() ) == Constants.RESULT_OK )
				{
				if( wordReferenceQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordReferenceNameString, firstArchivedWordItem() ) == Constants.RESULT_OK )
					return wordReferenceQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordReferenceNameString, firstDeletedWordItem() );
				}
			}

		return CommonVariables.result;
		}

	protected byte stringQueryInWordList( boolean isFirstInstruction, boolean isSelectActiveItems, boolean isSelectDeactiveItems, boolean isSelectArchivedItems, boolean isSelectDeletedItems, String queryString )
		{
		if( stringQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryString, firstActiveWordItem() ) == Constants.RESULT_OK )
			{
			if( stringQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryString, firstDeactiveWordItem() ) == Constants.RESULT_OK )
				{
				if( stringQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryString, firstArchivedWordItem() ) == Constants.RESULT_OK )
					return stringQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryString, firstDeletedWordItem() );
				}
			}

		return CommonVariables.result;
		}

	protected byte showQueryResultInWordList( boolean showOnlyWords, boolean showOnlyWordReferences, boolean showOnlyStrings, boolean returnQueryToPosition, short promptTypeNr, short queryWordTypeNr, int queryWidth )
		{
		if( showQueryResultInWordList( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth, firstActiveWordItem() ) == Constants.RESULT_OK )
			{
			if( showQueryResultInWordList( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth, firstDeactiveWordItem() ) == Constants.RESULT_OK )
				{
				if( showQueryResultInWordList( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth, firstArchivedWordItem() ) == Constants.RESULT_OK )
					return showQueryResultInWordList( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth, firstDeletedWordItem() );
				}
			}

		return CommonVariables.result;
		}


	// Protected read word methods

	protected WordResultType createWordItem( short wordParameter )
		{
		WordResultType wordResult = new WordResultType();

		if( CommonVariables.currentItemNr < Constants.MAX_ITEM_NR )
			{
			// Create word
			if( ( wordResult.createdWordItem = new WordItem( wordParameter, this ) ) != null )
				{
				if( addItemToActiveList( (Item)wordResult.createdWordItem ) != Constants.RESULT_OK )
					addError( 1, null, "I failed to add an active word item" );
				}
			else
				startError( 1, null, "I failed to create a word item" );
			}
		else
			startError( 1, null, "The current item number is undefined" );

		wordResult.result = CommonVariables.result;
		return wordResult;
		}
	};

/*************************************************************************
 *
 *	"They share freely and give generously to those in need.
 *	Their good deeds will be remembered forever.
 *	They will have influence and honor." (Psalm 112:9)
 *
 *************************************************************************/
