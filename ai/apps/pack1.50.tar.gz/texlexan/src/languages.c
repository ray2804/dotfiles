/* License/copyright: Dual licence, Read copyright.txt include in the package */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>
#include <unistd.h>
#include <time.h>
#include "utils.h"
#include "help.h"
#include "definitions.h"
#include "languages.h"

extern int debug;

/* ------------ functions of test & conversion -------------- */

/* NOTE:
   if (ch=='\n' || ch=='\r') fprintf(fp2," \n"); 
   add space before a new-line but insert extra-line with
   MS text LF+CR, that should be an issue, else test for LF
   and for CR the next char
*/

int testhtml(char *file_input) {
/* search for <...html...> */
FILE *fp;
int cont,html_flag;
char *str_ptr;
char shortline[SHORT_STR];
int i,j;
char prev_char;

  /* Open files  */
  fp=fopen(file_input,"rb");
  if (fp==NULL){
    ERRPOS
    fprintf(stderr,"Unable to open %s ->Exit!\n",file_input);
    exit(EXIT_FAILURE);
  }
  /* search the <html> tag */
  html_flag=0;
  cont=100; //search for <html...> in the 100 first lines (none empty)
  while (cont--) {
    if (fgets(shortline,SHORT_STR,fp) == NULL) break; //eof exit loop
    /* j is used count none repeatitive char
     * some website have several thousand of line in the beginning
     * filed with a few space chars. */
    i=j=0;
    prev_char=shortline[0];
    i++;
    while (prev_char != '\0') {
    	if (shortline[i] != prev_char) j++;
    	if (j>5) break;
    	prev_char=shortline[i++];
	}
    if (j <= 5) cont++; //don't count blank line
    else if (strlstr(shortline,"<html>") != NULL) {html_flag=1; break;}
	  else if (strlstr(shortline,"<!doctype html") != NULL) {html_flag=1; break;}
		else if ((str_ptr=strlstr(shortline,"<html")) != NULL) {
			if (strchr(str_ptr,'>') != NULL) {
				html_flag=1; 
				break;
			} 
			else while (cont--) {
				/* perhaps the tag is closed on another line, seach '>' */
				if (fgets(shortline,SHORT_STR,fp) == NULL) break;
				if (strchr(str_ptr,'<') != NULL) break; //pb in html source
				if (strchr(str_ptr,'>') != NULL) {
					html_flag=1; 
					break;
				}	
			}
		}
  }
  fclose(fp);
  if (html_flag) return 1;
    else return 0;
}

int testansi7(char *file_input) {
FILE *fp;
long int cont=1,count_ok=0,count_bad=0;
char ch;

  /* Open files  */
  fp=fopen(file_input,"rb");
  if (fp==NULL){
    ERRPOS
    fprintf(stderr,"Unable to open %s ->Exit!\n",file_input);
    exit(EXIT_FAILURE);
  }
  cont=1;
  while (cont) {
    if ((ch=fgetc(fp)) == EOF) break;
    if ((ch & 0x80) == 0x80) count_bad++;
      else count_ok++;
  }
  fclose(fp);
  if (count_bad == 0) return 1;
    else return 0;
}

int teststransi7(char *s) {
long int cont=1,count_ok=0,count_bad=0;
char ch;

  cont=1;
  while (cont) {
    if ((ch=*s++) == '\0') break;
    if ((ch & 0x80) == 0x80) count_bad++;
      else count_ok++;
  }
  if (count_bad == 0) return 1;
    else return 0;
}

/*
Unicode detections / conversions are very simplified here and work
on limited alphanumeric char set 0x20 - 0x7A
*/

int testutf8(char *file_input) {
FILE *fp;
long int cont=1,count_ok=0,count_bad=0;
char previous_byte,current_byte;

  /* Open files  */
  fp=fopen(file_input,"rb");
  if (fp==NULL){
    ERRPOS
    fprintf(stderr,"Unable to open %s ->Exit!\n",file_input);
    exit(EXIT_FAILURE);
  }
  if ((previous_byte=fgetc(fp)) ==EOF) {
    ERRPOS
    fprintf(stderr,"Empty file %s ->Exit!\n",file_input);
    exit(EXIT_FAILURE);
  }
  fseek(fp,0,SEEK_SET);
  /*read the header*/
  if ((fgetc(fp) == 0xEF) && (fgetc(fp) == 0xBB) && (fgetc(fp) == 0xBF)) {
    printf("BOM detected: ");
    return 1;
  }
  fseek(fp,0,SEEK_SET); //no BOM, reset to the begining    
  /*check bytes one by one*/
  previous_byte=fgetc(fp);
  cont=1;
  while (cont) {
    if ((current_byte=fgetc(fp)) == EOF) break; //end of file
    if ((current_byte & 0xC0) == 0x80) {
      if ((previous_byte & 0xC0) == 0xC0) {
        count_ok++;
      } else if ((previous_byte & 0x80) == 0x00) {
        count_bad++;
      }
    } else if ((previous_byte & 0xC0) == 0xC0) {
      count_bad++;
    }
    previous_byte=current_byte;
  }
  fclose(fp);
  if (count_ok>count_bad) {
    printf("Heuristic detection: ");
    return 1;
  } else return 0;
}


int teststrutf8(char *s) {
long int cont=1,count_ok=0,count_bad=0;
char previous_byte,current_byte;

  /*read the header*/
  if ((*s == 0xEF) && (*s+1 == 0xBB) && (*s+2 == 0xBF)) {
    return 1;
  }  
  /*check bytes one by one*/
  previous_byte=*s++;
  cont=1;
  while (cont) {
    if ((current_byte=*s++) == '\0') break; //end of file
    if ((current_byte & 0xC0) == 0x80) {
      if ((previous_byte & 0xC0) == 0xC0) {
        count_ok++;
      } else if ((previous_byte & 0x80) == 0x00) {
        count_bad++;
      }
    } else if ((previous_byte & 0xC0) == 0xC0) {
      count_bad++;
    }
    previous_byte=current_byte;
  }
  if (count_ok>count_bad) {
    return 1;
  } else return 0;
}


int testutf16(char *file_input) {
FILE *fp;
long int cont=1,count_ok=0,count_bad=0;
char previous_byte,current_byte;

  /* Open files  */
  fp=fopen(file_input,"rb");
  if (fp==NULL){
    ERRPOS
    fprintf(stderr,"Unable to open %s ->Exit!\n",file_input);
    exit(EXIT_FAILURE);
  }
  if ((previous_byte=fgetc(fp)) ==EOF) {
    ERRPOS
    fprintf(stderr,"Empty file %s ->Exit!\n",file_input);
    exit(EXIT_FAILURE);
  }
  fseek(fp,0,SEEK_SET);
  /*read the header one by one*/
  if ((fgetc(fp) == 0xFF) && (fgetc(fp) == 0xFE)) {
    printf("BOM detected: ");
    return 1;
  } 
  else {
    fseek(fp,0,SEEK_SET); //reset to the begining
    if ((fgetc(fp) == 0xFE) && (fgetc(fp) == 0xFF)) {
      printf("BOM detected: ");
      return 1;
    }    
  }
  fseek(fp,0,SEEK_SET); //reset to the begining
  /*check bytes*/
  previous_byte=fgetc(fp);
  cont=1;
  while (cont) {
    if ((current_byte=fgetc(fp)) == EOF) break; //end of file reached
    if (previous_byte == '\0') {
      if ((current_byte & 0xC0) == 0xC0) count_ok++;
        else count_bad++;
      if ((previous_byte=fgetc(fp)) == EOF) break; //end of file reached
    }
    previous_byte=current_byte;
  }
  fclose(fp);
  if (count_ok>count_bad) {
    printf("Heuristic detection: ");
    return 1;
  } else return 0;
}

int teststrutf16(char *s) {
long int cont=1,count_ok=0,count_bad=0;
char previous_byte,current_byte;

  /*read the header one by one*/
  if (*s == 0xFF && *s+1 == 0xFE) {
    return 1;
  } 
  else {
    if ((*s == 0xFE) && (*s+1 == 0xFF)) {
      printf("BOM detected: ");
      return 1;
    }    
  }
  /*check bytes*/
  previous_byte=*s++;
  cont=1;
  while (cont) {
    if ((current_byte=*s++) == '\0') break; //end of file reached
    if (previous_byte == '\0') {
      if ((current_byte & 0xC0) == 0xC0) count_ok++;
        else count_bad++;
      if ((previous_byte=*s++) == '\0') break; //end of file reached
    }
    previous_byte=current_byte;
  }
  if (count_ok>count_bad) {
    return 1;
  } else return 0;
}

char *htmltotext(char *file_input, char *file_temp,char *title_str) {
/* Not very sophisticated! 
 * It extracts text between >....<  and the title too.
 * A real html parser will do a better job but I try to limit 
 * the dependencies and only use the std libraries.
*/
FILE *fp1,*fp2;
int errcount=0,imgcount=0,linkcount=0;
int tag=0;
int record=0,script=0,style=0,form=0,link=0,paragraph=0,divise=0,image=0; 
int head=0,body=0;
int title_flag=0;
int charset=1;
char ch;
char text_str[LONG_STR],tag_str[LONG_STR];
int text_i,tag_i;
char *str_ptr,*str_ptr1,*str_ptr2;
char codehtml[10];
int chrn,lg;
static char info[SHORT_STR];
char crush_monitor[]="do not crush me";

  /* Open the file  */
  fp1=fopen(file_input,"r");
  if (fp1==NULL){
    ERRPOS
    fprintf(stderr,"Unable to open %s ->Exit!\n",file_input);
    return(0);
  }
  /* Open the file  */
  fp2=fopen(file_temp,"w");
  if (fp2==NULL){
    ERRPOS
    fprintf(stderr,"Unable to create %s ->Exit!\n",file_temp);
    return(0);
  }
    
  /*read and extract text between > and < */
  ch='\0';
  text_str[0]='\0';
  tag_str[0]='\0';
  text_i=0;
  tag_i=0;
  while ((ch=fgetc(fp1)) != EOF) { //read char/char until end of file
    if (ch=='\n' || ch=='\r' || ch=='\t') ch=' ';
    //fprintf(stderr,"%c",ch);
    switch (ch) {
    case '>': //end of tag
    
      tag_str[tag_i++]='>'; //close the tag
      /*the tag is ending - we can check the tag*/
      tag_str[tag_i]='\0'; //end of string
      
      /*detect some tags*/
      if (strlstr(tag_str,"<script") != NULL) script=1;
      else if (strlstr(tag_str,"<head") != NULL)  head=1;
      else if (strlstr(tag_str,"<title") != NULL) title_flag=1;
      else if (strlstr(tag_str,"<body") != NULL)  body=1;
      else if (strlstr(tag_str,"<style") != NULL)  style=1;
	    else if (strlstr(tag_str,"<form") != NULL)  form=1;
	    else if (strlstr(tag_str,"<img") != NULL) {image=1; imgcount++;}
	    else if (strlstr(tag_str,"<a") != NULL)  {link=1; linkcount++;}
      else if (strlstr(tag_str,"</head") != NULL)  head=0;
      else if (strlstr(tag_str,"</title") != NULL) title_flag=0;
      else if (strlstr(tag_str,"</body") != NULL)  body=0;
	    else if (strlstr(tag_str,"</script") != NULL) script=0;
      else if (strlstr(tag_str,"</style") != NULL) style=0;
	    else if (strlstr(tag_str,"</form") != NULL) form=0;
	    else if (strlstr(tag_str,"</img") != NULL) image=0;
	    else if (strlstr(tag_str,"</a") != NULL) link=0;
	    else if (strlstr(tag_str,"<p>") != NULL) {paragraph=1; fprintf(fp2,"%c",'\n');}
	    else if (strlstr(tag_str,"</p>") != NULL) paragraph=0;
	    else if (strlstr(tag_str,"<div") != NULL) divise=1;
	    else if (strlstr(tag_str,"</div") != NULL) divise=0;
	    else if (strlstr(tag_str,"<br>") != NULL) fprintf(fp2,"%c",'\n');
	  
	    /*Decide if text must be extracted or not*/
	    if (body==1 && paragraph==1 && script==0 && style==0 && form==0) record=1;
	    else if (body==1 && script==0 && style==0 && form==0 && link==0) record=1;
	    else if (head==1 && title_flag) record=1;
	    else record=0;
	    
	    /*Look for the charset in the header*/
	    if (head==1 && (str_ptr1=strlstr(tag_str,"charset=")) != NULL) {
	      if (strlstr(str_ptr1,"utf-8") != NULL) charset=108;
	      else if (strlstr(str_ptr1,"iso-8859-1") != NULL) charset=1;
	      else if (strlstr(str_ptr1,"windows-1252") != NULL) charset=1;
	      else fprintf(stderr,"\nCharset non-implemented: %s\n",str_ptr1);
      }
      
      tag_i=0; //reset index of string
      tag=-1; //tag is fisnished
      break;
      
    case '<': //beginning of tag
      tag_str[tag_i++]='<'; //start the tag
      /*because a new tag begin - we can clean & save the previous text*/
      text_str[text_i]='\0'; //end of string
      if (record) {
        /*no eol - replace \n with space*/
        str_ptr=&text_str[0];
        while ((str_ptr=strchr(str_ptr,'\n')) != NULL) *str_ptr=' ';
	
	
	/* &#val; and &name; are converted in chars   &#xval; is missing*/
    str_ptr=&text_str[0];
    while ((str_ptr=strchr(str_ptr,'&')) != NULL) {
	  str_ptr++;
	  if (*str_ptr == '#') {
	    str_ptr++;
        if ((str_ptr2=strchr(str_ptr,';')) != NULL) {
	      lg=str_ptr2-str_ptr;
	      strncpy(codehtml,str_ptr,lg);
	      codehtml[lg]='\0';
	      chrn=atoi(codehtml);
	      //if (chrn > 127) chrn-=133;
          *(str_ptr-2)=(char)chrn;
          strcpy(str_ptr-1,str_ptr+lg+1); 
	    } 
		else errcount++;
      } 
	  else
	  {
	    if (charset==108) { //utf8
	  	  /* incomplete list   code; lg                       char space=lg */
	      if (strncmp(str_ptr,"quot;",5) == 0) strcpy(str_ptr-1,"\x22     ");
        else if (strncmp(str_ptr,"amp;",4) == 0) strcpy(str_ptr-1,"\x26    ");
        else if (strncmp(str_ptr,"euro;",5) == 0) strcpy(str_ptr-1," Euro ");
        else if (strncmp(str_ptr,"nbsp;",5) == 0) strcpy(str_ptr-1,"      ");
        else if (strncmp(str_ptr,"lt;",3) == 0) strcpy(str_ptr-1,"<   ");
        else if (strncmp(str_ptr,"gt;",3) == 0) strcpy(str_ptr-1,">   ");
        else if (strncmp(str_ptr,"oelig;",6) == 0) strcpy(str_ptr-1,"oe     ");
        else if (strncmp(str_ptr,"cent;",5) == 0) strcpy(str_ptr-1," cent ");
        else if (strncmp(str_ptr,"pound;",6) == 0) strcpy(str_ptr-1," pound ");
        else if (strncmp(str_ptr,"yen;",4) == 0) strcpy(str_ptr-1," yen ");
        else if (strncmp(str_ptr,"copy;",5) == 0) strcpy(str_ptr-1,"\xc2\xa9    ");
        else if (strncmp(str_ptr,"laquo;",6) == 0) strcpy(str_ptr-1,"\xc2\xab     ");
        else if (strncmp(str_ptr,"lsquo;",6) == 0) strcpy(str_ptr-1,"\xc2\xab     ");
        else if (strncmp(str_ptr,"ldquo;",6) == 0) strcpy(str_ptr-1,"\xc2\xab     ");
        else if (strncmp(str_ptr,"reg;",4) == 0) strcpy(str_ptr-1,"\xc2\xae   ");
        else if (strncmp(str_ptr,"deg;",4) == 0) strcpy(str_ptr-1,"\xc2\xb0   ");
        else if (strncmp(str_ptr,"acute;",6) == 0) strcpy(str_ptr-1,"\xc2\xb4     ");
        else if (strncmp(str_ptr,"micro;",6) == 0) strcpy(str_ptr-1,"\xc2\xb5     ");
        else if (strncmp(str_ptr,"cedil;",6) == 0) strcpy(str_ptr-1,"\xc3\xa7     ");
        else if (strncmp(str_ptr,"raquo;",6) == 0) strcpy(str_ptr-1,"\xc3\xbb     ");
        else if (strncmp(str_ptr,"rsquo;",6) == 0) strcpy(str_ptr-1,"\xc3\xbb     ");
        else if (strncmp(str_ptr,"rdquo;",6) == 0) strcpy(str_ptr-1,"\xc3\xbb     ");
        else if (strncmp(str_ptr,"agrave;",7) == 0) strcpy(str_ptr-1,"\xc3\xa0      ");
        else if (strncmp(str_ptr,"aacute;",7) == 0) strcpy(str_ptr-1,"\xc3\xa1      ");
        else if (strncmp(str_ptr,"acirc;",6) == 0) strcpy(str_ptr-1,"\xc3\xa2     ");
        else if (strncmp(str_ptr,"atilde;",7) == 0) strcpy(str_ptr-1,"\xc3\xa3      ");
        else if (strncmp(str_ptr,"auml;",5) == 0) strcpy(str_ptr-1,"\xc3\xa4    ");
        else if (strncmp(str_ptr,"aring;",6) == 0) strcpy(str_ptr-1,"\xc3\xa5     ");
        else if (strncmp(str_ptr,"aelig;",6) == 0) strcpy(str_ptr-1,"ae     ");
        else if (strncmp(str_ptr,"Agrave;",7) == 0) strcpy(str_ptr-1,"\xc3\x80      ");
        else if (strncmp(str_ptr,"Aacute;",7) == 0) strcpy(str_ptr-1,"\xc3\x81      ");
        else if (strncmp(str_ptr,"Acirc;",6) == 0) strcpy(str_ptr-1,"\xc3\x82     ");
        else if (strncmp(str_ptr,"Atilde;",7) == 0) strcpy(str_ptr-1,"\xc3\x83      ");
        else if (strncmp(str_ptr,"Auml;",5) == 0) strcpy(str_ptr-1,"\xc3\x84    ");
        else if (strncmp(str_ptr,"Aring;",6) == 0) strcpy(str_ptr-1,"\xc3\x85     ");
        else if (strncmp(str_ptr,"Aelig;",6) == 0) strcpy(str_ptr-1,"AE    ");
        else if (strncmp(str_ptr,"egrave;",7) == 0) strcpy(str_ptr-1,"\xc3\xa8      ");
        else if (strncmp(str_ptr,"eacute;",7) == 0) strcpy(str_ptr-1,"\xc3\xa9      ");
        else if (strncmp(str_ptr,"ecirc;",6) == 0) strcpy(str_ptr-1,"\xc3\xaa     ");
        else if (strncmp(str_ptr,"euml;",5) == 0) strcpy(str_ptr-1,"\xc3\xab    ");
        else if (strncmp(str_ptr,"Egrave;",7) == 0) strcpy(str_ptr-1,"\xc3\x88      ");
        else if (strncmp(str_ptr,"Eacute;",7) == 0) strcpy(str_ptr-1,"\xc3\x89      ");
        else if (strncmp(str_ptr,"Ecirc;",6) == 0) strcpy(str_ptr-1,"\xc3\x8a     ");
        else if (strncmp(str_ptr,"Euml;",5) == 0) strcpy(str_ptr-1,"\xc3\x8b    ");
        else if (strncmp(str_ptr,"igrave;",7) == 0) strcpy(str_ptr-1,"\xc3\xac      ");
        else if (strncmp(str_ptr,"iacute;",7) == 0) strcpy(str_ptr-1,"\xc3\xad      ");
        else if (strncmp(str_ptr,"icirc;",6) == 0) strcpy(str_ptr-1,"\xc3\xae     ");
        else if (strncmp(str_ptr,"iuml;",5) == 0) strcpy(str_ptr-1,"\xc3\xaf    ");
        else if (strncmp(str_ptr,"Igrave;",7) == 0) strcpy(str_ptr-1,"\xc3\x8c      ");
        else if (strncmp(str_ptr,"Iacute;",7) == 0) strcpy(str_ptr-1,"\xc3\x8d      ");
        else if (strncmp(str_ptr,"Icirc;",6) == 0) strcpy(str_ptr-1,"\xc3\x8e     ");
        else if (strncmp(str_ptr,"Iuml;",5) == 0) strcpy(str_ptr-1,"\xc3\x8f    ");
        else if (strncmp(str_ptr,"ograve;",7) == 0) strcpy(str_ptr-1,"\xc3\xb2      ");
        else if (strncmp(str_ptr,"oacute;",7) == 0) strcpy(str_ptr-1,"\xc3\xb3      ");
        else if (strncmp(str_ptr,"ocirc;",6) == 0) strcpy(str_ptr-1,"\xc3\xb4     ");
        else if (strncmp(str_ptr,"ouml;",5) == 0) strcpy(str_ptr-1,"\xc3\xb5    ");
        else if (strncmp(str_ptr,"Ograve;",7) == 0) strcpy(str_ptr-1,"\xc3\x92      ");
        else if (strncmp(str_ptr,"Oacute;",7) == 0) strcpy(str_ptr-1,"\xc3\x93      ");
        else if (strncmp(str_ptr,"Ocirc;",6) == 0) strcpy(str_ptr-1,"\xc3\x94     ");
        else if (strncmp(str_ptr,"Ouml;",5) == 0) strcpy(str_ptr-1,"\xc3\x95    ");
        else if (strncmp(str_ptr,"bull;",5) == 0) strcpy(str_ptr-1,"      ");
        else if (strncmp(str_ptr,"middot;",7) == 0) strcpy(str_ptr-1,"        ");
        else errcount++;
      }
      else if (charset==1) { //iso-8859-1
	  	  /* incomplete list   code; lg                       char space=lg */
	      if (strncmp(str_ptr,"quot;",5) == 0) strcpy(str_ptr-1,"\"     ");
        else if (strncmp(str_ptr,"amp;",4) == 0) strcpy(str_ptr-1,"&    ");
        else if (strncmp(str_ptr,"euro;",5) == 0) strcpy(str_ptr-1," Euro ");
        else if (strncmp(str_ptr,"nbsp;",5) == 0) strcpy(str_ptr-1,"      ");
        else if (strncmp(str_ptr,"lt;",3) == 0) strcpy(str_ptr-1,"<   ");
        else if (strncmp(str_ptr,"gt;",3) == 0) strcpy(str_ptr-1,">   ");
        else if (strncmp(str_ptr,"oelig;",6) == 0) strcpy(str_ptr-1,"oe     ");
        else if (strncmp(str_ptr,"cent;",5) == 0) strcpy(str_ptr-1," cent ");
        else if (strncmp(str_ptr,"pound;",6) == 0) strcpy(str_ptr-1," pound ");
        else if (strncmp(str_ptr,"yen;",4) == 0) strcpy(str_ptr-1," yen ");
        else if (strncmp(str_ptr,"copy;",5) == 0) strcpy(str_ptr-1,"\169     ");
        else if (strncmp(str_ptr,"laquo;",6) == 0) strcpy(str_ptr-1,"\171      ");
        else if (strncmp(str_ptr,"reg;",4) == 0) strcpy(str_ptr-1,"\174    ");
        else if (strncmp(str_ptr,"deg;",4) == 0) strcpy(str_ptr-1,"\176    ");
        else if (strncmp(str_ptr,"acute;",6) == 0) strcpy(str_ptr-1,"\180      ");
        else if (strncmp(str_ptr,"micro;",6) == 0) strcpy(str_ptr-1,"\181      ");
        else if (strncmp(str_ptr,"cedil;",6) == 0) strcpy(str_ptr-1,"\184      ");
        else if (strncmp(str_ptr,"raquo;",6) == 0) strcpy(str_ptr-1,"\187      ");
        else if (strncmp(str_ptr,"agrave;",7) == 0) strcpy(str_ptr-1,"\224       ");
        else if (strncmp(str_ptr,"aacute;",7) == 0) strcpy(str_ptr-1,"\225       ");
        else if (strncmp(str_ptr,"acirc;",6) == 0) strcpy(str_ptr-1,"\226      ");
        else if (strncmp(str_ptr,"atilde;",7) == 0) strcpy(str_ptr-1,"\227       ");
        else if (strncmp(str_ptr,"auml;",5) == 0) strcpy(str_ptr-1,"\228     ");
        else if (strncmp(str_ptr,"aring;",6) == 0) strcpy(str_ptr-1,"\229      ");
        else if (strncmp(str_ptr,"aelig;",6) == 0) strcpy(str_ptr-1,"ae     ");
        else if (strncmp(str_ptr,"Agrave;",7) == 0) strcpy(str_ptr-1,"\192       ");
        else if (strncmp(str_ptr,"Aacute;",7) == 0) strcpy(str_ptr-1,"\193       ");
        else if (strncmp(str_ptr,"Acirc;",6) == 0) strcpy(str_ptr-1,"\194      ");
        else if (strncmp(str_ptr,"Atilde;",7) == 0) strcpy(str_ptr-1,"\195       ");
        else if (strncmp(str_ptr,"Auml;",5) == 0) strcpy(str_ptr-1,"\196     ");
        else if (strncmp(str_ptr,"Aring;",6) == 0) strcpy(str_ptr-1,"\197      ");
        else if (strncmp(str_ptr,"Aelig;",6) == 0) strcpy(str_ptr-1,"AE     ");
        else if (strncmp(str_ptr,"egrave;",7) == 0) strcpy(str_ptr-1,"\232       ");
        else if (strncmp(str_ptr,"eacute;",7) == 0) strcpy(str_ptr-1,"\233       ");
        else if (strncmp(str_ptr,"ecirc;",6) == 0) strcpy(str_ptr-1,"\234      ");
        else if (strncmp(str_ptr,"euml;",5) == 0) strcpy(str_ptr-1,"\235     ");
        else if (strncmp(str_ptr,"Egrave;",7) == 0) strcpy(str_ptr-1,"\200       ");
        else if (strncmp(str_ptr,"Eacute;",7) == 0) strcpy(str_ptr-1,"\201       ");
        else if (strncmp(str_ptr,"Ecirc;",6) == 0) strcpy(str_ptr-1,"\202      ");
        else if (strncmp(str_ptr,"Euml;",5) == 0) strcpy(str_ptr-1,"\203     ");
        else if (strncmp(str_ptr,"igrave;",7) == 0) strcpy(str_ptr-1,"\236       ");
        else if (strncmp(str_ptr,"iacute;",7) == 0) strcpy(str_ptr-1,"\237       ");
        else if (strncmp(str_ptr,"icirc;",6) == 0) strcpy(str_ptr-1,"\238      ");
        else if (strncmp(str_ptr,"iuml;",5) == 0) strcpy(str_ptr-1,"\239     ");
        else if (strncmp(str_ptr,"Igrave;",7) == 0) strcpy(str_ptr-1,"\204       ");
        else if (strncmp(str_ptr,"Iacute;",7) == 0) strcpy(str_ptr-1,"\205       ");
        else if (strncmp(str_ptr,"Icirc;",6) == 0) strcpy(str_ptr-1,"\206      ");
        else if (strncmp(str_ptr,"Iuml;",5) == 0) strcpy(str_ptr-1,"\207     ");
        else if (strncmp(str_ptr,"ograve;",7) == 0) strcpy(str_ptr-1,"\242       ");
        else if (strncmp(str_ptr,"oacute;",7) == 0) strcpy(str_ptr-1,"\243       ");
        else if (strncmp(str_ptr,"ocirc;",6) == 0) strcpy(str_ptr-1,"\244      ");
        else if (strncmp(str_ptr,"ouml;",5) == 0) strcpy(str_ptr-1,"\245     ");
        else if (strncmp(str_ptr,"Ograve;",7) == 0) strcpy(str_ptr-1,"\210       ");
        else if (strncmp(str_ptr,"Oacute;",7) == 0) strcpy(str_ptr-1,"\211       ");
        else if (strncmp(str_ptr,"Ocirc;",6) == 0) strcpy(str_ptr-1,"\212      ");
        else if (strncmp(str_ptr,"Ouml;",5) == 0) strcpy(str_ptr-1,"\213     ");
        else if (strncmp(str_ptr,"bull;",5) == 0) strcpy(str_ptr-1,"      ");
        else if (strncmp(str_ptr,"middot;",7) == 0) strcpy(str_ptr-1,"        ");
        else errcount++;
      }
	  } 
	}
	/* no contiguous space */
	while (StrToChar(text_str,"  ",' ') > 0);
	/*strip space*/
	StripSpace(text_str);
	/* Record text if not empty
	 * the title is only stored in a var, the text is stored in a file
	 */
	if (text_str[0] != '\0') {
	  if (title_flag) {  //store the title
	    if (strlen(text_str) < SIZE_WORD) strcpy(title_str,text_str);
	    else {
		    ERRPOS
		    fprintf(stderr,"\nIn htmltotext Error 1\n");
		  }
	  }
	  else {
	    fprintf(fp2,"%s ",text_str); //rec in the file
    }
	}
      }
      text_i=0; //reset index of string
      tag=1; //tag is starting
      break;
    default:
      if (record && (tag == -1)) { //rebuild text char/char
        if (text_i < LONG_STR) text_str[text_i++]=ch;
	    else {
	      ERRPOS
	      fprintf(stderr,"In htmltotext Error 2\n");
	    }
      }
      if (tag == 1) { //rebuild tag char/char
	    if (tag_i < LONG_STR) tag_str[tag_i++]=ch;
	    else {
	      ERRPOS
	      fprintf(stderr,"In htmltotext Error 3\n");
	    }
      }
    }
  } 
  fclose(fp1);
  fclose(fp2);
  sprintf(info,"%i error(s), %i image(s),% i link(s)",errcount,imgcount,linkcount);
  if (strcmp(crush_monitor,"do not crush me") != 0) {
    ERRPOS
    fprintf(stderr,"\nMem. crush in htmltotext\n");
  }
  return info;
}

int utf8toansi7b(char *file_input,char *file_temp,char *file_iso) {
/* 
  Convert file UTF8 -> file plain 7bits + file iso 8859
  Double conversion UTF8 in ANSI 7bits and in ISO 8859-1
  ISO 8859-1:fr,es,ca,eur,pt,it,sq,rm,nl,de,da,su,no,fi,fa,is,ga,gl,en
  lake: greek, turkish, russian, tcheck
  
  => to be completed - euro char missing...
  => pb '
*/
FILE *fp1,*fp2,*fp3;
int errcount=0,cont=1;
char ch;
unsigned char byte1,byte2,byte3,byte4;
int iso1,iso2,iso3,iso4,iso5,iso6,iso7,iso8;

  iso1=iso2=iso3=iso4=iso5=iso6=iso7=iso8=0;
  
  /* Open the file  */
  fp1=fopen(file_input,"rb");
  if (fp1==NULL){
    ERRPOS
    fprintf(stderr,"Unable to open %s ->Exit!\n",file_input);
    return(0);
  }
  /* Open the file  */
  fp2=fopen(file_temp,"w");
  if (fp2==NULL){
    ERRPOS
    fprintf(stderr,"Unable to create %s ->Exit!\n",file_temp);
    return(0);
  }
  /* Open the file  */
  fp3=fopen(file_iso,"w");
  if (fp3==NULL){
    ERRPOS
    fprintf(stderr,"Unable to create %s ->Exit!\n",file_temp);
    return(0);
  }
  /*read the header*/
  if ((fgetc(fp1) == 0xEF) && (fgetc(fp1) == 0xBB) && (fgetc(fp1) == 0xBF)) printf("UTF8 BOM skipped - ");
    else fseek(fp1,0,SEEK_SET); //no BOM, reset to the begining
  /*read and convert*/
  ch='\0';
  while (cont) {
    if ((ch=fgetc(fp1)) == EOF) break;
    byte1=byte2=byte3=byte4=0;
    if ((ch & 0xf8) == 0xf0) { //coded 4bytes char
      //get byte 4
      byte4= ch;
      if ((ch=fgetc(fp1)) == EOF) break;
      if ((ch & 0xc0) == 0x80) { //check the 3rdbyte
        //get byte 3
	byte3= ch;
        if ((ch=fgetc(fp1)) == EOF) break;
        if ((ch & 0xc0) == 0x80) { //check the 2ndbyte
	  //get byte 2
	  byte2= ch;
	  if ((ch=fgetc(fp1)) == EOF) break;
          if ((ch & 0xc0) == 0x80) { //check the 1stbyte
	    //get byte 1
	    byte1= ch;
	  } else {errcount++; goto try_next;}
	} else {errcount++; goto try_next;}
      } else {errcount++; goto try_next;}
    } 
    else if ((ch & 0xf0) == 0xe0) //coded 3bytes char
    { 
      //get byte 3
      byte3= ch;
      if ((ch=fgetc(fp1)) == EOF) break;
      if ((ch & 0xc0) == 0x80) { //check the 2ndbyte
        //get byte 2
	byte2= ch;
	if ((ch=fgetc(fp1)) == EOF) break;
        if ((ch & 0xc0) == 0x80) { //check the 1stbyte
	  //get byte 1
	  byte1= ch;
	  // beginning conversion 3 bytes chars
	  if ((byte3==0xe2) && (byte2==0x80) && (byte1==0x99)) {fprintf(fp2,"'"); fprintf(fp3,"'");}
	  //...to be continued
	  // end conversion 3 bytes chars
	} else {errcount++; goto try_next;}
      } else {errcount++; goto try_next;}
    } 
    else if ((ch & 0xe0) == 0xc0)  //coded 2bytes char
    {
      //get byte 2
      byte2= ch;
      if ((ch=fgetc(fp1)) == EOF) break;
      if ((ch & 0xc0) == 0x80) { //check the 1stbyte
        //get byte 1
	byte1= ch;
	// beginning conversion coded 2 bytes chars
	if (byte2==0xc2) {
	  if ((byte1>=0x80) && (byte1<=0xa0)) {fprintf(fp2," "); fprintf(fp3," ");}
	}
	else if (byte2==0xc3) 
	{
	  iso1++;
	  /*fp2 and fp3 must correspond byte for byte =>no ligature ae, oe...*/
	  if ((byte1>=0x80) && (byte1<=0x85)) {fprintf(fp2,"A"); fprintf(fp3,"%c",byte1+0x40);}
	  else if (byte1==0x86) {fprintf(fp2,"AE"); fprintf(fp3,"AE");}
	  else if (byte1==0x87) {fprintf(fp2,"C"); fprintf(fp3,"%c",byte1+0x40);}
	  else if ((byte1>=0x88) && (byte1<=0x8b)) {fprintf(fp2,"E"); fprintf(fp3,"%c",byte1+0x40);}
	  else if ((byte1>=0x8c) && (byte1<=0x8f)) {fprintf(fp2,"I"); fprintf(fp3,"%c",byte1+0x40);}
	  else if (byte1==0x90) {fprintf(fp2,"D"); fprintf(fp3,"%c",byte1+0x40);} //?
	  else if (byte1==0x91) {fprintf(fp2,"N"); fprintf(fp3,"%c",byte1+0x40);} //or gn ?
	  else if ((byte1>=0x92) && (byte1<=0x96)) {fprintf(fp2,"O"); fprintf(fp3,"%c",byte1+0x40);}
	  else if (byte1==0x97) {fprintf(fp2,"*"); fprintf(fp3,"%c",byte1+0x40);}
	  else if (byte1==0x98) {fprintf(fp2,"_"); fprintf(fp3,"%c",byte1+0x40);} //?
	  else if ((byte1>=0x99) && (byte1<=0x9c)) {fprintf(fp2,"U"); fprintf(fp3,"%c",byte1+0x40);} 
	  else if (byte1==0x9d) {fprintf(fp2,"Y"); fprintf(fp3,"%c",byte1+0x40);} //?
	  else if (byte1==0x9e) {fprintf(fp2,"_"); fprintf(fp3,"%c",byte1+0x40);} //?
	  else if (byte1==0x9f) {fprintf(fp2,"_"); fprintf(fp3,"%c",byte1+0x40);}  //?
	  else if ((byte1>=0xa0) && (byte1<=0xa5)) {fprintf(fp2,"a"); fprintf(fp3,"%c",byte1+0x40);}
	  else if (byte1==0xa6) {fprintf(fp2,"ae"); fprintf(fp3,"ae");}
	  else if (byte1==0xa7) {fprintf(fp2,"c"); fprintf(fp3,"%c",byte1+0x40);}
	  else if ((byte1>=0xa8) && (byte1<=0xab)) {fprintf(fp2,"e"); fprintf(fp3,"%c",byte1+0x40);}
	  else if ((byte1>=0xac) && (byte1<=0xaf)) {fprintf(fp2,"i"); fprintf(fp3,"%c",byte1+0x40);}
	  else if (byte1==0xb0) {fprintf(fp2,"d"); fprintf(fp3,"%c",byte1+0x40);} //?
	  else if (byte1==0xb1) {fprintf(fp2,"n"); fprintf(fp3,"%c",byte1+0x40);} //or gn ?
	  else if ((byte1>=0xb2) && (byte1<=0xb6)) {fprintf(fp2,"o"); fprintf(fp3,"%c",byte1+0x40);}
	  else if (byte1==0xb7) {fprintf(fp2,"/"); fprintf(fp3,"%c",byte1+0x40);}
	  else if (byte1==0xb8) {fprintf(fp2,"_"); fprintf(fp3,"%c",byte1+0x40);} //?
	  else if ((byte1>=0xb9) && (byte1<=0xbc)) {fprintf(fp2,"u"); fprintf(fp3,"%c",byte1+0x40);}
	  else if (byte1==0xbd) {fprintf(fp2,"y"); fprintf(fp3,"%c",byte1+0x40);} //?
	  else if (byte1==0xbe) {fprintf(fp2,"_"); fprintf(fp3,"%c",byte1+0x40);} //?
	  else if (byte1==0xbf) {fprintf(fp2,"y"); fprintf(fp3,"%c",byte1+0x40);} //?
	}
	else if (byte2==0xc4) 
	{
	  if ((byte1>=0x80) && (byte1<=0x85)) fprintf(fp2,"a"); //?
	  else if ((byte1>=0x86) && (byte1<=0x8d)) fprintf(fp2,"c"); //?
	  else if ((byte1>=0x8e) && (byte1<=0x91)) fprintf(fp2,"d"); //?
	  else if ((byte1>=0x92) && (byte1<=0x9b)) fprintf(fp2,"e"); //?
	  else if ((byte1>=0x9c) && (byte1<=0xa3)) fprintf(fp2,"g"); //?
	  else if ((byte1>=0xa4) && (byte1<=0xa7)) fprintf(fp2,"h"); //?
	  else if ((byte1>=0xa8) && (byte1<=0xb0)) fprintf(fp2,"i"); //?
	  //...to be continued
	  // end conversion coded 2 bytes chars
	}
      } else {errcount++; goto try_next;}
    } 
    else if ((ch & 0x80) == 0x00)  //coded 1bytes char
    {
      // get byte 1 - no conversion required
      if (ch=='\n' || ch=='\r') {
         // add space before a new-line
        fprintf(fp2," \n");
	    fprintf(fp3," \n");
      }
      else 
      {
	    // record the char (plain ascii)
        fprintf(fp2,"%c",ch);
        fprintf(fp3,"%c",ch);
      }
    }
try_next:;  //when bug skip here and try to resynch
  }
  fclose(fp1);
  fclose(fp2);
  fclose(fp3);
  return errcount;
}

int isotoansi7b(char *file_input,char *file_temp) {
/* Convert file iso -> another file plain 7bits */
FILE *fp1,*fp2;
int errcount=0;
char ch;
  
  /* Open the file  */
  fp1=fopen(file_input,"r");
  if (fp1==NULL){
    ERRPOS
    fprintf(stderr,"Unable to open %s ->Exit!\n",file_input);
    return(0);
  }
  /* Open the file  */
  fp2=fopen(file_temp,"w");
  if (fp2==NULL){
    ERRPOS
    fprintf(stderr,"Unable to create %s ->Exit!\n",file_temp);
    return(0);
  }
  ch='\0';
  while (ch != EOF) {
    ch=fgetc(fp1);
    if ((ch & 0x80) == 0x80) {
      if ((ch == '\xe0') || (ch == '\xe1') || (ch == '\xe2') || (ch == '\xe3') || (ch == '\xe4') || (ch == '\xe5')) fprintf(fp2,"a");
      else if ((ch == '\xe8') || (ch == '\xe9') || (ch == '\xea') || (ch == '\xeb')) fprintf(fp2,"e");
      else if ((ch == '\xf9') || (ch == '\xfa') || (ch == '\xfb') || (ch == '\xfc')) fprintf(fp2,"u");
      else if ((ch == '\xf2') || (ch == '\xf3') || (ch == '\xf4') || (ch == '\xf5') || (ch == '\xf6') || (ch == '\xf7')) fprintf(fp2,"o");
      else if ((ch == '\xec') || (ch == '\xed') || (ch == '\xee') || (ch == '\xef')) fprintf(fp2,"i");
      else if (ch == '\xe7') fprintf(fp2,"c");
      else if (ch == '\xc7') fprintf(fp2,"C");
      else if ((ch == '\xc8') || (ch == '\xc9') || (ch == '\xca') || (ch == '\xcb')) fprintf(fp2,"E");
      else errcount++;
    }  else if (ch=='\n' || ch=='\r') fprintf(fp2," \n"); //add space before a new-line
         else fprintf(fp2,"%c",ch);
  }
  fclose(fp1);
  fclose(fp2);
  return errcount;
}

int plainansi7b(char *file_input,char *file_temp) {
FILE *fp1,*fp2;
int errcount=0;
char ch;
  
  /* Open the file  */
  fp1=fopen(file_input,"r");
  if (fp1==NULL){
    ERRPOS
    fprintf(stderr,"Unable to open %s ->Exit!\n",file_input);
    return(0);
  }
  /* Open the file  */
  fp2=fopen(file_temp,"w");
  if (fp2==NULL){
    ERRPOS
    fprintf(stderr,"Unable to create %s ->Exit!\n",file_temp);
    return(0);
  }
  ch='\0';
  while (ch != EOF) {
    ch=fgetc(fp1);
    if ((ch & 0x80) == 0x80) {
      if ((ch == '\xe0') || (ch == '\xe1') || (ch == '\xe2') || (ch == '\xe3') || (ch == '\xe4') || (ch == '\xe5')) fprintf(fp2,"a");
      else if ((ch == '\xe8') || (ch == '\xe9') || (ch == '\xea') || (ch == '\xeb')) fprintf(fp2,"e");
      else if ((ch == '\xf9') || (ch == '\xfa') || (ch == '\xfb') || (ch == '\xfc')) fprintf(fp2,"u");
      else if ((ch == '\xf2') || (ch == '\xf3') || (ch == '\xf4') || (ch == '\xf5') || (ch == '\xf6') || (ch == '\xf7')) fprintf(fp2,"o");
      else if ((ch == '\xec') || (ch == '\xed') || (ch == '\xee') || (ch == '\xef')) fprintf(fp2,"i");
      else if (ch == '\xe7') fprintf(fp2,"c");
      else if (ch == '\xc7') fprintf(fp2,"C");
      else if ((ch == '\xc8') || (ch == '\xc9') || (ch == '\xca') || (ch == '\xcb')) fprintf(fp2,"E");
      else errcount++;
    } else if (ch=='\n' || ch=='\r') fprintf(fp2," \n"); //add space before a new-line
        else fprintf(fp2,"%c",ch);
  }
  fclose(fp1);
  fclose(fp2);
  return errcount;
}


int strutf8toansi7b(char *s1,char *s2) {
/* 
  Convert file UTF8 -> file plain 7bits + file iso 8859
  Double conversion UTF8 in ANSI 7bits and in ISO 8859-1
  ISO 8859-1:fr,es,ca,eur,pt,it,sq,rm,nl,de,da,su,no,fi,fa,is,ga,gl,en
  lake: greek, turkish, russian, tcheck
  
  => to be completed - euro char missing...
  => pb '
*/
int errcount=0,cont=1;
char ch;
unsigned char byte1,byte2,byte3,byte4;
int iso1,iso2,iso3,iso4,iso5,iso6,iso7,iso8;
char *saved_s2;

  saved_s2=s2;
  iso1=iso2=iso3=iso4=iso5=iso6=iso7=iso8=0;
  
  /*skip the UTF8 BOM if there is one */
  if ((*s1 == 0xEF) && (*s1+1 == 0xBB) && (*s1+2 == 0xBF)) s1+=3;

  /*read and convert*/
  while (cont) {
    if ((ch=*s1++) == '\0') break;
    byte1=byte2=byte3=byte4=0;
    if ((ch & 0xf8) == 0xf0) { //coded 4bytes char
      //get byte 4
      byte4= ch;
      if ((ch=*s1++) == '\0') break;
      if ((ch & 0xc0) == 0x80) { //check the 3rdbyte
        //get byte 3
	byte3= ch;
        if ((ch=*s1++) == '\0') break;
        if ((ch & 0xc0) == 0x80) { //check the 2ndbyte
	  //get byte 2
	  byte2= ch;
	  if ((ch=*s1++) == '\0') break;
          if ((ch & 0xc0) == 0x80) { //check the 1stbyte
	    //get byte 1
	    byte1= ch;
	  } else {errcount++; goto try_next;}
	} else {errcount++; goto try_next;}
      } else {errcount++; goto try_next;}
    } 
    else if ((ch & 0xf0) == 0xe0) //coded 3bytes char
    { 
      //get byte 3
      byte3= ch;
      if ((ch=*s1++) == '\0') break;
      if ((ch & 0xc0) == 0x80) { //check the 2ndbyte
        //get byte 2
	byte2= ch;
	if ((ch=*s1++) == '\0') break;
        if ((ch & 0xc0) == 0x80) { //check the 1stbyte
	  //get byte 1
	  byte1= ch;
	  // beginning conversion 3 bytes chars
	  if ((byte3==0xe2) && (byte2==0x80) && (byte1==0x99)) *s2++='\'';
	  //...to be continued
	  // end conversion 3 bytes chars
	} else {errcount++; goto try_next;}
      } else {errcount++; goto try_next;}
    } 
    else if ((ch & 0xe0) == 0xc0)  //coded 2bytes char
    {
      //get byte 2
      byte2= ch;
      if ((ch=*s1++) == '\0') break;
      if ((ch & 0xc0) == 0x80) { //check the 1stbyte
        //get byte 1
	byte1= ch;
	// beginning conversion coded 2 bytes chars
	if (byte2==0xc2) {
	  if ((byte1>=0x80) && (byte1<=0xa0)) *s2++=' ';
	}
	else if (byte2==0xc3) 
	{
	  iso1++;
	  /*fp2 and fp3 must correspond byte for byte =>no ligature ae, oe...*/
	  if ((byte1>=0x80) && (byte1<=0x85)) *s2++='A';
	  else if (byte1==0x86) { *s2++='A'; *s2++='E'; }
	  else if (byte1==0x87) *s2++='C';
	  else if ((byte1>=0x88) && (byte1<=0x8b)) *s2++='E';
	  else if ((byte1>=0x8c) && (byte1<=0x8f)) *s2++='I';
	  else if (byte1==0x90) *s2++='D';
	  else if (byte1==0x91) *s2++='N';
	  else if ((byte1>=0x92) && (byte1<=0x96)) *s2++='O';
	  else if (byte1==0x97) *s2++='*';
	  else if (byte1==0x98) *s2++='_';
	  else if ((byte1>=0x99) && (byte1<=0x9c)) *s2++='U';
	  else if (byte1==0x9d) *s2++='Y';
	  else if (byte1==0x9e) *s2++='_';
	  else if (byte1==0x9f) *s2++='_';
	  else if ((byte1>=0xa0) && (byte1<=0xa5)) *s2++='a';
	  else if (byte1==0xa6) { *s2++='a'; *s2++='e'; } //ae
	  else if (byte1==0xa7) *s2++='c';
	  else if ((byte1>=0xa8) && (byte1<=0xab)) *s2++='e';
	  else if ((byte1>=0xac) && (byte1<=0xaf)) *s2++='i';
	  else if (byte1==0xb0) *s2++='d';
	  else if (byte1==0xb1) *s2++='n';
	  else if ((byte1>=0xb2) && (byte1<=0xb6)) *s2++='o';
	  else if (byte1==0xb7) *s2++='/';
	  else if (byte1==0xb8) *s2++='_';
	  else if ((byte1>=0xb9) && (byte1<=0xbc)) *s2++='u';
	  else if (byte1==0xbd) *s2++='y';
	  else if (byte1==0xbe) *s2++='_';
	  else if (byte1==0xbf) *s2++='y';
	}
	else if (byte2==0xc4) 
	{
	  if ((byte1>=0x80) && (byte1<=0x85)) *s2++='a'; //?
	  else if ((byte1>=0x86) && (byte1<=0x8d)) *s2++='c'; //?
	  else if ((byte1>=0x8e) && (byte1<=0x91)) *s2++='d'; //?
	  else if ((byte1>=0x92) && (byte1<=0x9b)) *s2++='e'; //?
	  else if ((byte1>=0x9c) && (byte1<=0xa3)) *s2++='g'; //?
	  else if ((byte1>=0xa4) && (byte1<=0xa7)) *s2++='h'; //?
	  else if ((byte1>=0xa8) && (byte1<=0xb0)) *s2++='i'; //?
	  //...to be continued
	  // end conversion coded 2 bytes chars
	}
      } else {errcount++; goto try_next;}
    } 
    else if ((ch & 0x80) == 0x00)  //coded 1bytes char
    {
      // get byte 1 - no conversion required
      if (ch=='\n' || ch=='\r') {
         // add space before a new-line
        *s2++=' '; *s2++='\n';
      }
      else 
      {
	    // record the char (plain ascii)
        *s2++=ch;
      }
    }
try_next:;  //when bug skip here and try to resynch
  }
  *s2='\0';
  s2=saved_s2;
  return errcount;
}


int strisotoansi7b(char *s1,char *s2) {
/* convert a string iso -> another string 7bits */
int errcount=0;
char ch;
char *saved_s2;

  saved_s2=s2;
  while ((ch=*s1) != '\0') {
    if ((ch & 0x80) == 0x80) {
      if ((ch == '\xe0') || (ch == '\xe1') || (ch == '\xe2') || (ch == '\xe3') || (ch == '\xe4') || (ch == '\xe5')) *s2='a';
      else if ((ch == '\xe8') || (ch == '\xe9') || (ch == '\xea') || (ch == '\xeb')) *s2='e';
      else if ((ch == '\xf9') || (ch == '\xfa') || (ch == '\xfb') || (ch == '\xfc')) *s2='u';
      else if ((ch == '\xf2') || (ch == '\xf3') || (ch == '\xf4') || (ch == '\xf5') || (ch == '\xf6') || (ch == '\xf7')) *s2='o';
      else if ((ch == '\xec') || (ch == '\xed') || (ch == '\xee') || (ch == '\xef')) *s2='i';
      else if (ch == '\xe7') *s2='c';
      else if (ch == '\xc7') *s2='C';
      else if ((ch == '\xc8') || (ch == '\xc9') || (ch == '\xca') || (ch == '\xcb')) *s2='E';
      else errcount++;
    }  
	else if (ch=='\n' || ch=='\r') {
		 //add space before a new-line
		*s2=' '; 
		s2++;
		*s2='\n';
	}
    else *s2=ch;
	s1++;
	s2++;
  }
  *s2='\0';
  s2=saved_s2;
  return errcount;
}


char *testlanguage(char *path_dictionary,char *file_input) {
/*- Try to discover the language.
  - Use a list of words belonging a language.
  - Return the language abreviated
  - Doesn't work correctly if text contains several languages.
  Implemented: French: fr, English:en, Spanish:es, Italian:it
  and German:de (list of words needs to be completed)
  Note: this function needs to be rewritten, it works well while there
  aren't too much languages to test.
*/
FILE *fp, *fp1;
char file_testlanguages[SIZE_WORD]="";
long int lg;
char ch,previous_ch;
char word[SIZE_WORD],wordchk[SIZE_WORD+2];
int langue[NB_LANGUAGES];
char list[NB_LANGUAGES][SIZE_WORDSLIST];
char *listword[NB_LANGUAGES];
char *str_ptr;
int i,j,highest,hi,nblanguages;

  sprintf(file_testlanguages,"%s%s",path_dictionary,"languages.word");
  /* Open the test words file  */
  fp1=fopen(file_testlanguages,"r");
  if (fp1==NULL){
    ERRPOS
    fprintf(stderr,"Unable to open %s ->Exit!\n",file_testlanguages);
    return("err");
  }
  /* read each line */
  j=0;
  for (i=0; i<NB_LANGUAGES;i++) {
    langue[j]=0;
    list[j][SIZE_WORDSLIST-1]='X';
    if ( !fgets(list[j],SIZE_WORDSLIST,fp1) )
      break; //probably end of the file, continue after the loop for
    if ( list[j][SIZE_WORDSLIST-1] != 'X' ) {
      ERRPOS
      fprintf(stderr,"Check file %s, line too long ->Exit!\n",file_testlanguages);
      return("err"); //line too long!
    }
    if ( list[j][0] != '#' ) { //skip comment
      if ( (str_ptr=strchr(list[j],':')) ) {
        listword[j]=str_ptr+1; //point the beginning of the word list
        *str_ptr='\0'; //only the language abrev in list[]
        j++;
      }
      else {
        ERRPOS
        fprintf(stderr,"Check file %s ':' missing ->Exit!\n",file_testlanguages);
        return("err"); //':' missing!
      }
    }
  }
  fclose(fp1);
  nblanguages=j;
  
  /* Open the text file  */
  fp=fopen(file_input,"r");
  if (fp==NULL){
    ERRPOS
    fprintf(stderr,"Unable to open %s ->Exit!\n",file_input);
    return("err");
  }
  ch='\0';
  lg=0;
  while (ch != EOF) {
    ch=tolower(fgetc(fp));
    switch (ch) {
    case ' ': 
      if (ch != previous_ch) {
        word[lg++]='/';
        word[lg]='\0';
        strcpy(wordchk,"/");
        strcat(wordchk,word);
        /* Test some basic words typic of a language 
        * It's important to have words specific of language, occuring often and to have the same nb of words for
        * each language, theorical the same probability for each language*/
        for (i=0; i<nblanguages;i++)
          if ( strstr(listword[i],wordchk) )
            langue[i]++;
        lg=0;
      }
      break;
    case EOF: break;
    default:
      if ( lg < SIZE_WORD )
        word[lg++]=ch;
    }
    previous_ch=ch; /*Avoid doublon*/
  } 
  fclose(fp);
  
  if (debug) 
    for (i=0;i<nblanguages;i++)
      fprintf(stderr,"Index:%i Value:%i\n",i,langue[i]);
  
  /* Naive search of the maximun */
  highest=0;
  hi=-1;
  for (i=0;i<nblanguages;i++) {
    if (langue[i] > highest) {
      highest=langue[i];
      hi=i;
    }
  }
  /* return the language abrev. */
  if ( hi > -1 ) {
    static char *lang_abrev;
    lang_abrev=strdup(list[hi]);
    return(lang_abrev);
  }
  /* return default */
  ERRPOS
  fprintf(stderr,"Return default language!\n"); 
  return("en");
}

int chgtosingular(char *word,char *lang) {
/* 
- Chg single word to singular form.
- Apply rules depending of the language (global var lang).
- Return 0 => nothing done  or 1 => chg.
- Languages implemented:
	en, fr, sp, it (partial)
*/
int lg;
char wordchk[SIZE_WORD+2];
/*list of words that don't change*/
static char namecity[]="/vegas/angeles/damas/paris/bahamas/hamas/tunis/andes/alpes/antilles/azores/baleares/carpatos/"; //keep 's' at the end
static char invariable[6][1000]={
  "/yes/was/has/his/gas/thus/this/is/us/bus/tennis/", //en:keep 's'
  "/eux/cieux/mieux/vieux/hiboux/choux/houx/cariboux/sioux/os/dos/temps/corps/dans/", //fr:invariables
	"/crisis/lunes/martes/mierides/jueves/viernes/albatros/extasis/dosis/", //sp:
	"/attaccapanni/verita/carita/bonta/volonta/papa/", //it:parola tronche
	"/tockter/kase/", //ge:
  "" //new language
  };

  /*rules for English*/
  if (strcmp(lang,"en") == 0) { 
    lg=strlen(word);
    if (lg < 3) return 0; //exclude a,i,us,as,is...
    if (word[lg-1] != 's') return 0; //exlude word without final s
    strcpy(wordchk,"/");
    strcat(wordchk,word);
    strcat(wordchk,"/");
    if (strstr(invariable[0],wordchk) != NULL) return 0; //exclude yes,this...
    if (strstr(namecity,wordchk) != NULL) return 0; //exclude names
    if (word[lg-2]=='s' && word[lg-1]=='s') return 0; //exlude ass,bless,class,mass,chess,mess...
    if (word[lg-2]=='e' && word[lg-1]=='s') {
      if (word[lg-3]=='i' && lg > 4) {
        // __ies -> __y
        word[lg-3]='y';
        word[lg-2]='\0';
        return 1;
      }
      else if (word[lg-3] == 'o' && lg > 3) {
        // _oes -> _o
        word[lg-2]='\0';
        return 1;
      } 
      else if (word[lg-3] == 'h' && lg > 4) {
        // __hes -> __h
        word[lg-2]='\0';
        return 1;
      } 
      else if (word[lg-4] == word[lg-3]) {
        // classes -> class
        word[lg-2]='\0';
        return 1;
      }
    }
    word[lg-1]='\0'; //suppress the last char (should be 's')
    return 1;
  }
  /*rules for French*/
  if (strcmp(lang,"fr") == 0) { 
    lg=strlen(word);
    if (lg < 3) return 0; //exclude es, as...
    if (strchr("sx",word[lg-1]) == NULL) return 0; //exlude word without final s or x
    strcpy(wordchk,"/");
    strcat(wordchk,word);
    strcat(wordchk,"/");
    if (strstr(invariable[1],wordchk) != NULL) return 0; //exclude eux,mieux...
    if (strstr(namecity,wordchk) != NULL) return 0; //exclude names
    if (word[lg-2]=='s' && word[lg-1]=='s') return 0; //exlude some engl wrd: chess...
    if (word[lg-2]=='u' && word[lg-1]=='x') {
      if (word[lg-3]=='a' && lg > 2) {
        // aux -> au
        word[lg-1]='\0';
        return 1;
      }
      else if (word[lg-3] == 'e' && lg > 3) {
        // _eux -> _eu
        word[lg-1]='\0';
        return 1;
      } 
      else if (word[lg-3] == 'o' && lg > 3) {
        // _oux -> _ou
        word[lg-1]='\0';
        return 1;
      } 
    } 
    else if (word[lg-1]=='s') {
      word[lg-1]='\0'; //suppress 's'
      return 1;
    }
  }
  /*rules for Spanish*/
  if ( strcmp(lang,"sp") == 0 || strcmp(lang,"es") == 0 ) { 
    lg=strlen(word);
    if (lg < 3) return 0; //exclude as, es...
    if (strchr("sx",word[lg-1]) == NULL) return 0; //exlude word without final s or x
    strcpy(wordchk,"/");
    strcat(wordchk,word);
    strcat(wordchk,"/");
    if (strstr(invariable[2],wordchk) != NULL) return 0; //some words stay plural
    if (strstr(namecity,wordchk) != NULL) return 0; //exclude names
    if (word[lg-2]=='s' && word[lg-1]=='s') return 0; //exlude some engl wrd: chess...
    if (word[lg-2]=='a' && word[lg-1]=='s') {
        // _as -> _a
        word[lg-1]='\0';
        return 1;
    }
    else if (word[lg-2]=='o' && word[lg-1]=='s') {
        // _os -> _o
        word[lg-1]='\0';
        return 1;
    }
    else if (word[lg-3] == 'i' && word[lg-2]=='e' && word[lg-1]=='s' ) {
        // _ies -> _i
        word[lg-2]='\0';
        return 1;
    } 
    else if (strchr("dfghjklmnpqrstvy",word[lg-3])!=NULL && word[lg-2]=='e' && word[lg-1]=='s' ) {
        // _[conson]es -> _[conson]
        word[lg-2]='\0';
        return 1;
    } 
    else if (word[lg-3] == 'c' && word[lg-2]=='e' && word[lg-1]=='s' ) {
        // _ces -> _z
	word[lg-3]='z';
        word[lg-2]='\0';
        return 1;
    } 
  }
  /*rules for Italian - NOT COMPLETE - */
  if (strcmp(lang,"it") == 0) { 
    lg=strlen(word);
    if (syllablescount(word,1) < 2) return 0; //exclude one syllable
    if (strchr("bcdfghjklmnpqrstvwxz",word[lg-1]) == NULL) return 0; //exlude conson final
    strcpy(wordchk,"/");
    strcat(wordchk,word);
    strcat(wordchk,"/");
    if (strstr(invariable[3],wordchk) != NULL) return 0; //some words stay plural
    if (strstr(namecity,wordchk) != NULL) return 0; //exclude names
    if (word[lg-2]=='s' && word[lg-1]=='s') return 0; //exlude some engl wrd: chess...
    if (word[lg-2]=='i' && word[lg-1]=='e') return 0; //exlude _ie ending

    if (word[lg-2]=='h' && word[lg-1]=='i') {
      if (word[lg-3]=='c') {
        // _chi -> _co
        word[lg-2]='o';
        word[lg-1]='\0';
        return 1;
      }
      else if (word[lg-3]=='g') {
        // _ghi -> _go
        word[lg-2]='o';
        word[lg-1]='\0';
        return 1;
      }
    }
    else if (word[lg-2]=='h' && word[lg-1]=='e') {
      if (word[lg-3]=='c') {
        // _che -> _ca
        word[lg-2]='a';
        word[lg-1]='\0';
        return 1;
      }
      else if (word[lg-3]=='g') {
        // _ghe -> _ga
        word[lg-2]='a';
        word[lg-1]='\0';
        return 1;
      }
    }
    else if (word[lg-2] == 'i' && word[lg-1]=='i') {
      // _ii -> _io
      word[lg-1]='o';
      return 1;
    }
    else if (strchr("dfghjklmnpqrstv",word[lg-2])!=NULL && word[lg-1]=='i') {
    // _[consomn]i -> _[consomn]io
      word[lg]='o';
      lg++;
      word[lg]='\n';
      return 1;
    } 
    else if (word[lg-1]=='e') {
      // _e -> _a
      word[lg-1]='a';
      return 1;
    }
    else if (word[lg-1]=='i') { //pb to solve
      // _i -> _o / _e   <= 2 possibilities
      word[lg-1]='o';
      return 1;
    }
  }
  /* rules for German 
   * there're complex and not fully implemented yet */
  if ( strcmp(lang,"ge") == 0 || strcmp(lang,"de") == 0 ) { 
    lg=strlen(word);
    if (lg < 3) return 0; //exclude tiny words.
    strcpy(wordchk,"/");
    strcat(wordchk,word);
    strcat(wordchk,"/");
    if (strstr(invariable[4],wordchk) != NULL) return 0; //exclude listed word
    if (strstr(namecity,wordchk) != NULL) return 0; //exclude names

    if (word[lg-2]=='e' && word[lg-1]=='n') {
      // _en ending
      if (word[lg-8]=='s' && word[lg-7]=='c' 
          && word[lg-6]=='h' && word[lg-5]=='a' 
          && word[lg-4]=='f' && word[lg-3]=='t') {
        // _schaften -> _schaft
        word[lg-2]='\0';
        return 1;
      }
      if (word[lg-5]=='e' && word[lg-4]=='i' && word[lg-3]=='t') {
        if  (word[lg-6]=='h' || word[lg-6]=='k') {
          // _keiten _heiten -> _keit _heit
          word[lg-2]='\0';
          return 1;
        }
      }
      if (word[lg-5]=='u' && word[lg-4]=='n' && word[lg-3]=='g') {
          // _ungen _ung
          word[lg-2]='\0';
          return 1;
      }
      if (word[lg-4]=='e' && word[lg-3]=='i') {
          // _eien _ei
          word[lg-2]='\0';
          return 1;
      }
    }
    
    if (word[lg-1]=='n') {
      // _n ending
      if (word[lg-3]=='e' && (word[lg-2]=='l'|| word[lg-2]=='r')) {
        // _eln _ern -> _el _er
        word[lg-1]='\0';
        return 1;
      }
      if (word[lg-2]=='e') {
        // _en -> _e
        word[lg-1]='\0';
        return 1;
      }
    }
    
    if (word[lg-2]=='e' && word[lg-1]=='r') {
      // _er ending
      if ((word[lg-4]=='a' || word[lg-4]=='l' || word[lg-4]=='n') 
            && word[lg-3]=='d') {
        // _lder -> _ld , _nder -> _nd , _ader -> _ad
        word[lg-2]='\0';
        return 1;
      }
      if (word[lg-4]=='u' && (word[lg-3]=='s' || word[lg-3]=='m')) {
        // _user -> _us  _umer -> _um
        word[lg-2]='\0';
        return 1;
      }
      if (word[lg-4]=='r' && word[lg-3]=='f') {
        // _rfer -> _rf
        word[lg-2]='\0';
        return 1;
      }
      if (word[lg-5]=='c' && word[lg-4]=='h' && word[lg-3]=='t') {
        // _chter -> _cht
        word[lg-2]='\0';
        return 1;
      }
    }
    
    if (word[lg-1]=='e') {
      // _e ending
      if (word[lg-3]=='n' && (word[lg-2]=='s' || word[lg-2]=='t')) {
        // _nse -> _ns , _nte -> _nt
        word[lg-1]='\0';
        return 1;
      }
      if (word[lg-3]=='c' && word[lg-2]=='h') {
        // _che -> _ch
        word[lg-1]='\0';
        return 1;
      }
      if (word[lg-3]=='c' && word[lg-2]=='h') {
        // _che -> _ch
        word[lg-1]='\0';
        return 1;
      }
      if (word[lg-3]=='f' && word[lg-2]=='t') {
        // _fte -> _ft
        word[lg-1]='\0';
        return 1;
      }
      if (word[lg-3]=='s' && word[lg-2]=='s') {
        // _sse -> _ss , _nisse -> _nis
        if (word[lg-5]=='n' && word[lg-4]=='i') 
          word[lg-2]='\0';
        else
          word[lg-1]='\0';
        return 1;
      }
      if (word[lg-3]=='u' && word[lg-2]=='s') {
        // _use -> _us
        word[lg-1]='\0';
        return 1;
      }
      if (word[lg-3]=='a' && word[lg-2]=='g') {
        // _age -> _ag
        word[lg-1]='\0';
        return 1;
      }
      if (word[lg-3]=='r' && word[lg-2]=='d') {
        // _rde -> _rd
        word[lg-1]='\0';
        return 1;
      }
    }
    //missing foreign origin words
  }

  //add another language rules here
  
  return 0; //language not implemented yet - nothing done
}

int noplural(char *word,char *lang) {
/* Used to chg several word separated with '-' to singular.
Actually, chgtosingular converts plural -> singular
Words are splited, converted and reassembled
 extraordinaries-feries-tales => extraordinary-fery-tale */
int nbchange=0;
char *str_ptr1,*str_ptr2;
char wordbis[SIZE_WORD],extract[SIZE_WORD];

  wordbis[0]='\0';
  str_ptr1=word;
  while ((str_ptr2=strchr(str_ptr1,'-')) != NULL) {
    strncpy(extract,str_ptr1,str_ptr2-str_ptr1);
    extract[str_ptr2-str_ptr1]='\0';
    nbchange+=chgtosingular(extract,lang);
    strcat(wordbis,extract);
    strcat(wordbis,"-");
    str_ptr1=str_ptr2+1;
  }  
  strcpy(extract,str_ptr1);
  nbchange+=chgtosingular(extract,lang);
  strcat(wordbis,extract);
  strcpy(word,wordbis);
  return nbchange;
}


int declinate(char *word,char *lang, int index) {
/* 
 => TO DO !!!
- word will contain the verb conjugated, plural, feminine...
- Apply rules depending of the language (var lang).
- Works only with regular term.
- Return the index of the next decination, 0 no other decination, -1 if error
- verb: v_word  adverb: r_word, noun: n_word, adjectif: a_word
- Languages implemented: NONE yet

*/
int lg;
char wordchk[SIZE_WORD+2];
char worddeclin[SIZE_WORD+2];
	lg = strlen(word);
	if (index < 1) return -1;
	if (lg < 3) return -1;
	if (word[1] != '_') return -1;
	if (strcmp(lang,"en") == 0) 
	{
		strcpy(wordchk, word+2);
		strcpy(worddeclin, word+2);
		switch (word[0]) {
			case 'v': 
			/* verb */
				switch (index) {
					case 1:
						strcat(worddeclin,"ed");
						index++;
						break;
					case 2:
						strcat(worddeclin,"ing");
						index=0; //no more
						break;
				}
				break;
			case 'r': 
			/* adverb */
						strcat(worddeclin,"ly");
						index=0; //no more
						break;
			case 'n':
			/* noum */
						strcat(worddeclin,"s");
						index=0; //no more
						break;
			case 'a': 
			/* adjectif */
						index=0;
						break;
			default:
			/* error */
				return -1;
		}
		return index;
	}
	/* error */
	return -1;
}


int strcleanup(char *str) {
/* Useful for email in particularly
   Remove non-alphanumeric
*/
char previous_ch;
int flag_del=0,i=0;

  if (*str != '\0') previous_ch=*str;
  i++;
  while (*(str+i) != '\0') {
    if (*(str+i) == previous_ch && !isalpha(*(str+i))) flag_del=1;
    else {
      flag_del=0;
      break;
    }
    i++;
  }
  if (flag_del) *str='\0';
  return i;
}

int char2utf8(char *s_out, char *s_in) {
/* Very basic conversion 8bits chars to utf8 chars */
int cnt=0;

/* 
   The opposite of utf8toansi7b()
   Only iso8859-1 (latin-1) are converted to utf8 
   Euro char is missing
   So it works only with this languages:
   fr,es,ca,eur,pt,it,sq,rm,nl,de,da,su,no,fi,fa,is,ga,gl,en
   
   lake: greek, turkish, russian, tcheck
*/
  while (*s_in != '\0') {
    if ((unsigned char)*s_in > 0xa0) {
      *s_out++=0xc3;
      *s_out++=(unsigned char)*s_in-0x40;
      s_in++;
      cnt+=2;
    }
    else if ((unsigned char)*s_in < 0x80)
    {
      *s_out++=*s_in++;
      cnt++;
    }
  }
  *s_out='\0';
  return cnt; //length s_out,NULL char not counted
}

float readingtime
    (char *path_dictionary,char * lang,long nbts,long nbtw,long nbtc,long nbl) {
/* Estimate the reading time */
FILE *fp1;
char file_languagestiming[SIZE_WORD]="";
char line[128];
char *str_ptr,*strval;
int i,err=0;
float syllable_timing,word_timing,coma_timing,line_timing;

  sprintf(file_languagestiming,"%s%s",path_dictionary,"languages.chrono");
  /* Open the test words file  */
  fp1=fopen(file_languagestiming,"r");
  if (fp1==NULL){
    ERRPOS
    fprintf(stderr,"Unable to open %s ->Exit!\n",file_languagestiming);
    exit(EXIT_FAILURE); //better to exit
  }
  /* read each line */
  for (i=0; i<NB_LANGUAGES;i++) {
    line[127]='X';
    if ( !fgets(line,128,fp1) )
      break; //probably end of the file, continue after the loop for
    if ( line[127] != 'X' ) {
      ERRPOS
      fprintf(stderr,"Check file %s, line too long ->Exit!\n",file_languagestiming);
      exit(EXIT_FAILURE); //better to exit
    }
    if ( line[0] != '#' ) { //skip comment
      if ( (str_ptr=strchr(line,':')) ) {
        *str_ptr='\0'; //only the language abrev
        if ( strcmp(line,lang) == 0 ) {
          /* language found */
          strval=str_ptr+1; //point the beginning of the timing line
          if ( (str_ptr=strchr(strval,'/')) ) {
            *str_ptr='\0'; //only value
            syllable_timing=atoi(strval);
            strval=str_ptr+1; //after char null 
          }
          else {err=1; ERRPOS}
          if ( (str_ptr=strchr(strval,'/')) ) {
            *str_ptr='\0'; //only value
            word_timing=atoi(strval);
            strval=str_ptr+1; //after char null
          }
          else { err=1; ERRPOS}
          if ( (str_ptr=strchr(strval,'/')) ) {
            *str_ptr='\0'; //only value
            coma_timing=atoi(strval);
            strval=str_ptr+1; //after char null
          }
          else {err=1; ERRPOS}
          if ( (str_ptr=strchr(strval,'\n')) ) {
            *str_ptr='\0'; //only value
            line_timing=atoi(strval);
          }
          else {err=1; ERRPOS}
          if (err) 
            fprintf(stderr,"Error: Structure corrupted in %s\n",file_languagestiming);
          /* return duration */
          return ( (syllable_timing*(float)nbts)+word_timing*(float)nbtw+coma_timing*(float)nbtc+line_timing*(float)nbl )/60000;
        } //end lang found
      } //end line trt
    } //end skip comment
  } //end for
  fprintf(stderr,"Error: Language code not found in %s\n",file_languagestiming);
  return 0; //lang not found
}
