
/* License/copyright: Dual licence, read copyright.txt in the package*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>
#include <unistd.h>
#include <time.h>
#include "utils.h"
#include "help.h"
#include "definitions.h"
#include "languages.h"
#include "analyses.h"
#include "abstracts.h"
#include "keywords.h"
#include "printing.h"

/*---------- Global variables --------*/
extern char file_input[];
extern char file_output[];
extern char file_builddico[];
extern long int size_line; //size of each line read in dico !!!limitation
/* --------- various functions  --------- */
void printing(char *result,int nb,int width,int rec){
/*Print in stdout and/or file*/
FILE *fp;
long int i,j;

  if ((rec & 2) == 2) {
    /* Open the file  */
    fp=fopen(file_output,"a");
    if (fp==NULL){
	  ERRPOS
      fprintf(stderr,"Unable to open %s ->Exit!\n",file_input);
      exit(EXIT_FAILURE);
    }
  }
  if (nb>1) {
    nb--;
    j=nb*width;
    for(i=0;i<j;i+=width) {
      if ((rec & 1) == 1) printf("%s",result+i);
      if ((rec & 2) == 2) fprintf(fp,"%s",result+i);
    }
  } 
  else 
  {
    if ((rec & 1) == 1) printf("%s",result);
    if ((rec & 2) == 2) fprintf(fp,"%s",result);
  }
  
  if ((rec & 2) == 2) if (fclose(fp) != 0) {
    ERRPOS
    fprintf(stderr,"Error fclose fp in printing");
  }
  return;
}

int printsorted(char *result,int nb,int width,int min,float taux,int nbwordterm,int rec,int builddico){
/*  
    Sort, filter and print result in stdout and/or file
    Write keyworder.build (long list of words and group of words found)
    result is returned sorted but not filtered
*/
  long int i;
  int val,max;
  char *word;
  char *str_ptr;
  FILE *fp,*fp1;
  
  if ((word = (char*)malloc(size_line)) == NULL) errmalloc("printsorted");  
  qsort(result,nb,width,str_cmp);
  if ((rec & 2) == 2) {
    /* Open the file  */
    fp=fopen(file_output,"a");
    if (fp==NULL){
	  ERRPOS
      fprintf(stderr,"Unable to open %s ->Exit!\n",file_input);
      exit(EXIT_FAILURE);
    }
  }
  if (builddico) {
    /* Open the file  */
    fp1=fopen(file_builddico,"a");
    if (fp1==NULL){
	  ERRPOS
      fprintf(stderr,"Unable to open %s ->Exit!\n",file_builddico);
      exit(EXIT_FAILURE);
    }
  }
  max=0;
  if ((rec & 1) == 1) printf("< List of significant terms >\n");
  if ((rec & 2) == 2) fprintf(fp,"< List of significant terms >\n");
  if (builddico) fprintf(fp1,"< Begin terms length:%i >\n",nbwordterm);
  for(i=0;i<nb*width;i+=width) {
    /*filter*/
    strcpy(word,result+i);
    if ((str_ptr=strpbrk(word,":")) != NULL) *str_ptr=0;
    val=atoi(word);
    if (val == 0) {
	  ERRPOS
	  fprintf(stderr,"in printsorted:atoi\n");
	}
    else {
      if (max == 0) max=val; //max contains the first and highest val (because result is sorted)
      if (val < (int)(taux*max)) {  //cutoff: we keep the result above taux*max
         if ((rec & 2) == 2) fclose(fp);
         if (builddico) {
           fprintf(fp1,"< End terms >\n");
           fclose(fp1); 
         }
         free(word);
         return 0; //job not finished
      }
      if (val < min) { //we keep the result above min
         if ((rec & 2) == 2) fclose(fp);
         if (builddico) {
           fprintf(fp1,"< End terms >\n");
           fclose(fp1); 
         }
         free(word);
         return 0; //job not finished
      }
      if ((rec & 1) == 1) printf("%s\n",result+i);
      if ((rec & 2) == 2) fprintf(fp,"%s\n",result+i);
      if (builddico) fprintf(fp1,"%s\n",result+i);
    }
  }
  if ((rec & 2) == 2) if (fclose(fp) != 0) {
    ERRPOS
    fprintf(stderr," in printsorted:fclose fp\n");
  }
  if (builddico) {
    fprintf(fp1,"< End terms >\n");
    if (fclose(fp1) != 0) {
	  ERRPOS
	  fprintf(stderr," in printsorted:fclose fp1\n");
	}
  }
  free(word);
  return 1; //done - no pb
}
