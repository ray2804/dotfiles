#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>
#include <unistd.h>
#include <time.h>
#include "help.h"

/* License/copyright: At the end of this file or read copyright.txt */

void help(char *msg) {
  printf("Usage: texlexan [options] file\n");
  printf("Options\n");
  printf("-a <1..99>\t\tPercentage of the text in the abstract, (default 10%%)\n");
  printf("-A <a/b/0..5>\t\tMode for the abstract, 0=no abstract a=auto(default)\n");
  printf("-Ab     \t\tAbstract automatic mode without the classification detailed\n");
  printf("-b      \t\tBuild dictionary base (Rewrite keyworder.build)\n");
  printf("-B      \t\tBuild dictionary base (Append to keyworder.build)\n");
  printf("-c <utf8/iso>\t\tConversion UTF8->ANSI(7bits)\n");
  printf("-c <A_utf8>\t\tAbstracts output in UTF8\n");
  printf("-C <class name>\t\tClass name to add when option -b is used\n");
  printf("-d      \t\tDebug on\n");
  printf("-D \"local=lang.encoding,date1,date2,target=....\"\t -D \"local=us_US.UTF8,2009-12-02,2010-02-14,target=...,...\"\n");
  printf("\t\t\t\t local=*all*  for all the rubrics available.\n");
  printf("-e <article..>\t\tExclude article,conjuction,preposition,verb (or ACPV)\n argument file (or F) for file excluded word\n");
  printf("-E <0/1/target_term>\t\tNo opinion:0, opinion:1, including term:target_term\n");
  printf("-f <folder>\t\tName of the *.dico folder\n");
  printf("-g <1..99>\t\tlength min word\n");
  printf("-h\t\t\tThis help\n");
  printf("-i <file>\t\tinput file name or PIPE\n");
  printf("-k      \t\tThe whole keywords list\n");
  printf("-K      \t\tList filtered single keywords\n");
  printf("-l <en/fr>\t\tlanguage\n");
  printf("-L <0..99>\t\tLevenstein distance (0:strict)\n");
  printf("-m <1..99>\t\tmin repetition same word\n");
  printf("-M <0/1>\t\t 1:detail classes, 0(default) no detail\n");
  printf("-n <1..99>\t\tnumber words\n");
  printf("-o <file>\t\toutput file name\n");
  printf("-p <0/1/2/3>\t\tprint mode None/Display/Record/Display+Record\n");
  printf("-q <0...>\t\tcoef applied to the constants\n");  
  printf("-r <0..99>\t\tRepeat distance, 0:no repetition check\n");
  printf("-R      \t\tDisplay repeated words\n");
  printf("-s      \t\tDo not proceed single keywords\n");
  printf("-S <0..99>\t\tsearch plagiarism 1:strict 99:weak 0:no search\n");
  printf("-t <0...1>\t\tTaux 0.1 to 1.0\n");  
  printf("-u <0..99>\t\tSlices size of the histogram, 0=no histogram(default)\n");
  printf("-v <0/1/2>\t\tVerbose\n");
  printf("-w      \t\tWait for an keybooard entry to exit\n");
  printf("-W <0..99>\t\tLine width (0:none)\n");
  printf("-z <1..99>\t\tMemory allocated, multiple of 1MByte\n");
  if (*msg != '\0') printf("-=- Message -=-\n%s",msg);
  exit(EXIT_FAILURE);
}
