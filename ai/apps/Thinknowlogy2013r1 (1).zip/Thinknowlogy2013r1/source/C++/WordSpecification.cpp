/*
 *	Class:			WordSpecification
 *	Supports class:	WordItem
 *	Purpose:		To create specification structures
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "GeneralizationItem.cpp"
#include "Presentation.cpp"
#include "SpecificationList.cpp"

class WordSpecification
	{
	// Private constructible variables

	bool addSuggestiveQuestionAssumption_;
	bool isConfirmedAssumption_;
	bool isConfirmedAssignment_;
	bool isConfirmedExclusive_;
	bool isCorrectedAssumptionByKnowledge_;
	bool isCorrectedAssumptionByOppositeQuestion_;
	bool isNonExclusiveSpecification_;

	unsigned int generalizationCollectionNr_;

	SpecificationItem *archiveAssignmentItem_;
	SpecificationItem *confirmedSpecificationItem_;
	SpecificationItem *confirmedArchivedSpecificationItem_;
	SpecificationItem *correctedArchivedSpecificationItem_;
	SpecificationItem *correctedSuggestiveQuestionAssumptionSpecificationItem_;
	SpecificationItem *lastShownConflictSpecificationItem_;
	SpecificationItem *sameSimilarRelatedArchivedSpecificationItem_;

	CommonVariables *commonVariables_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	ResultType addGeneralization( unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned short questionParameter, WordItem *specificationWordItem, WordItem *relationWordItem )
		{
		GeneralizationResultType generalizationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addGeneralization";

		if( specificationWordItem != NULL )
			{
			if( ( generalizationResult = specificationWordItem->findGeneralization( false, questionParameter, generalizationWordTypeNr, myWord_ ) ).result == RESULT_OK )
				{
				if( !generalizationResult.hasFoundGeneralization )
					{
					if( specificationWordItem->createGeneralization( false, questionParameter, specificationWordTypeNr, generalizationWordTypeNr, myWord_ ) != RESULT_OK )
						return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to create a generalization item" );
					}

				if( relationWordItem != NULL )
					{
					if( ( generalizationResult = relationWordItem->findGeneralization( true, questionParameter, generalizationWordTypeNr, myWord_ ) ).result == RESULT_OK )
						{
						if( !generalizationResult.hasFoundGeneralization )
							{
							if( relationWordItem->createGeneralization( true, questionParameter, relationWordTypeNr, generalizationWordTypeNr, myWord_ ) != RESULT_OK )
								return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to create a relation generalization item" );
							}
						}
					else
						return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find a relation generalization item" );
					}
				}
			else
				return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find a generalization item" );
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given specification word item is undefined" );

		return commonVariables_->result;
		}

	ResultType archiveOrDeletedSpecification( SpecificationItem *archiveSpecificationItem, SpecificationItem *createdSpecificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "archiveOrDeletedSpecification";
		if( archiveSpecificationItem != NULL )
			{
			if( createdSpecificationItem != NULL )
				{
				if( archiveSpecificationItem->isAssignment() )
					{
					if( archiveAssignmentItem_ == NULL )
						archiveAssignmentItem_ = archiveSpecificationItem;
					else
						return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The archive assignment item is already defined" );
					}
				else
					{
					if( myWord_->archiveOrDeletedSpecification( archiveSpecificationItem, createdSpecificationItem ) != RESULT_OK )
						return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to archive or delete a specification" );
					}
				}
			else
				return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given created specification item is undefined" );
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given archive specification item is undefined" );

		return commonVariables_->result;
		}

	ResultType checkUserQuestion( bool isAssignment, bool isExclusive, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, SpecificationItem *foundSpecificationItem, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString )
		{
		SpecificationResultType specificationResult;
		bool isRelatedQuestion = false;
		bool isSameQuestion = false;
		bool isSimilarQuestion = false;
		bool hasRelationContext = ( relationContextNr > NO_CONTEXT_NR );
		SpecificationItem *tempSpecificationItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkUserQuestion";

		isCorrectedAssumptionByOppositeQuestion_ = false;
		correctedSuggestiveQuestionAssumptionSpecificationItem_ = NULL;

		if( specificationWordItem != NULL )
			{
			commonVariables_->isUserQuestion = true;

			if( foundSpecificationItem != NULL &&
			relationContextNr == foundSpecificationItem->relationContextNr() )
				{
				if( foundSpecificationItem->isAnsweredQuestion() )
					commonVariables_->isQuestionAlreadyAnswered = true;
				else
					{
					if( hasRelationContext &&
					myWord_->isContextCurrentlyUpdatedInAllWords( isPossessive, relationContextNr, specificationWordItem ) )
						commonVariables_->isQuestionAlreadyAnswered = false;
					}
				}

			if( foundSpecificationItem == NULL ||

			( foundSpecificationItem->isOlderSentence() &&

			( foundSpecificationItem->isQuestion() ||
			specificationCollectionNr > NO_COLLECTION_NR ) ) )
				{
				if( foundSpecificationItem != NULL &&
				foundSpecificationItem->isQuestion() )
					addSuggestiveQuestionAssumption_ = true;
				else
					{
					if( ( specificationResult = findRelatedSpecification( false, false, true, isAssignment, isAssignment, isExclusive, isPossessive, questionParameter, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, relationWordItem, specificationString ) ).result == RESULT_OK )
						{
						if( ( foundSpecificationItem = specificationResult.relatedSpecificationItem ) != NULL )
							{
							if( !isExclusive &&
							specificationWordItem->isExclusiveCollection( specificationCollectionNr ) )
								{
								if( foundSpecificationItem->isOlderSentence() )
									{
									if( hasRelationContext )
										{
										if( correctedSuggestiveQuestionAssumptionSpecificationItem_ == NULL )
											{
											if( ( correctedSuggestiveQuestionAssumptionSpecificationItem_ = myWord_->firstAssignmentOrSpecification( true, true, false, true, true, true, foundSpecificationItem->isNegative(), foundSpecificationItem->isPossessive(), true, NO_QUESTION_PARAMETER, foundSpecificationItem->specificationCollectionNr(), foundSpecificationItem->generalizationContextNr(), foundSpecificationItem->specificationContextNr(), foundSpecificationItem->relationContextNr(), foundSpecificationItem->specificationWordItem(), foundSpecificationItem->specificationString() ) ) != NULL )
												{
												if( myWord_->writeSpecification( false, false, true, correctedSuggestiveQuestionAssumptionSpecificationItem_ ) == RESULT_OK )
													{
													isCorrectedAssumptionByOppositeQuestion_ = true;
													correctedArchivedSpecificationItem_ = correctedSuggestiveQuestionAssumptionSpecificationItem_;
													}
												else
													return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a conflicting specification" );
												}
											}
										else
											return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The corrected suggestive question assumption specification item already assigned" );
										}
									}
								else
									{
									if( commonVariables_->presentation->writeInterfaceText( true, PRESENTATION_PROMPT_WARNING, INTERFACE_LISTING_QUESTION_IN_CONFLICT_WITH_ITSELF ) != RESULT_OK )
										return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write an interface warning" );
									}
								}
							}
						}
					else
						return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find a related question" );
					}

				if( foundSpecificationItem != NULL &&
				foundSpecificationItem->isOlderSentence() )
					{
					if( hasRelationContext )
						{
						tempSpecificationItem = myWord_->firstAssignmentOrSpecification( true, true, true, true, true, isNegative, isPossessive, questionParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

						if( tempSpecificationItem != NULL &&
						isExclusive == tempSpecificationItem->isExclusive() &&
						relationContextNr == tempSpecificationItem->relationContextNr() )
							foundSpecificationItem = tempSpecificationItem;
						}

					if( ( isAssignment == foundSpecificationItem->isAssignment() ||
					hasRelationContext != foundSpecificationItem->hasRelationContext() ) &&

					specificationWordItem == foundSpecificationItem->specificationWordItem() )
						{
						if( isExclusive == foundSpecificationItem->isExclusive() &&
						relationContextNr == foundSpecificationItem->relationContextNr() )
							isSameQuestion = true;
						else
							{
							if( foundSpecificationItem->hasRelationContext() &&
							relationContextNr != foundSpecificationItem->relationContextNr() &&

							( !hasRelationContext ||
							!foundSpecificationItem->isMatchingRelationContextNr( false, relationContextNr ) ) )
								isRelatedQuestion = true;
							}
						}
					else
						isSimilarQuestion = true;

					if( isExclusive ||
					isRelatedQuestion ||
					isSameQuestion ||
					isSimilarQuestion )
						{
						if( isExclusive &&
						!foundSpecificationItem->isExclusive() )
							sameSimilarRelatedArchivedSpecificationItem_ = foundSpecificationItem;

						if( isSameQuestion )
							{
							if( commonVariables_->presentation->writeInterfaceText( true, PRESENTATION_PROMPT_NOTIFICATION, ( foundSpecificationItem->isSelfGenerated() ? INTERFACE_QUESTION_I_HAD_THE_SAME_QUESTION_BEFORE : INTERFACE_QUESTION_YOU_HAD_THE_SAME_QUESTION_BEFORE ) ) != RESULT_OK )
								return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write an interface notification" );
							}
						else
							{
							if( myWord_->writeSelectedSpecification( true, foundSpecificationItem ) == RESULT_OK )
								{
								if( strlen( commonVariables_->writeSentenceString ) > 0 )
									{
									if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_NOTIFICATION, ( foundSpecificationItem->isSelfGenerated() ? ( isRelatedQuestion ? INTERFACE_QUESTION_I_HAD_A_RELATED_QUESTION_BEFORE : INTERFACE_QUESTION_I_HAD_A_SIMILAR_QUESTION_BEFORE ) : ( isRelatedQuestion ? INTERFACE_QUESTION_YOU_HAD_A_RELATED_QUESTION_BEFORE : INTERFACE_QUESTION_YOU_HAD_A_SIMILAR_QUESTION_BEFORE ) ) ) == RESULT_OK )
										{
										if( commonVariables_->presentation->writeDiacriticalText( PRESENTATION_PROMPT_WRITE, commonVariables_->writeSentenceString ) != RESULT_OK )
											return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a sentence about the same, a similar or a relation question" );
										}
									else
										return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write an interface notification" );
									}
								else
									return myWord_->startErrorInWord( functionNameString, moduleNameString_, "I couldn't write the found specification sentence" );
								}
							else
								return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write the found specification sentence" );
							}
						}
					else
						{
						if( commonVariables_->lastShownMoreSpecificSpecificationItem != NULL &&
						commonVariables_->lastShownMoreSpecificSpecificationItem->originalSentenceNr() == foundSpecificationItem->originalSentenceNr() )
							{
							if( commonVariables_->presentation->writeInterfaceText( true, PRESENTATION_PROMPT_WARNING, INTERFACE_LISTING_QUESTION_IN_CONFLICT_WITH_ITSELF ) != RESULT_OK )
								return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write an interface warning" );
							}
						else
							{
							if( writeMoreSpecificSpecification( foundSpecificationItem ) != RESULT_OK )
								return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a more specific related question" );
							}
						}
					}
				}
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given specification word item is undefined" );

		return commonVariables_->result;
		}

	ResultType checkUserSpecification( bool isAssignment, bool isDeactiveAssignment, bool isArchivedAssignment, bool isExclusive, bool isNegative, bool isPossessive, bool isSelection, bool isValueSpecification, unsigned short questionParameter, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, SpecificationItem *foundSpecificationItem, WordItem *specificationWordItem, char *specificationString )
		{
		bool hasRelationContext = ( relationContextNr > NO_CONTEXT_NR );
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkUserSpecification";

		if( foundSpecificationItem != NULL )
			{
			if( specificationWordItem != NULL )
				{
				if( foundSpecificationItem->isValueSpecification() == isValueSpecification )
					{
					if( !isAssignment &&
					!isExclusive &&
					foundSpecificationItem->isExclusive() &&
					foundSpecificationItem->isUserSpecification() )
						{
						if( writeMoreSpecificSpecification( foundSpecificationItem ) == RESULT_OK )
							isNonExclusiveSpecification_ = true;
						else
							return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write an notification about a more specific non-exclusive specification" );
						}
					else
						{
						if( !isSelection &&
						hasRelationContext &&
						foundSpecificationItem->isOlderSentence() &&
						!foundSpecificationItem->hasRelationContext() )
							{
							if( writeMoreSpecificSpecification( foundSpecificationItem ) != RESULT_OK )
								return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write an notification about a more specific related specification" );
							}

						if( foundSpecificationItem->hasRelationContext() &&
						foundSpecificationItem->relationContextNr() != relationContextNr &&
						isDeactiveAssignment == foundSpecificationItem->isDeactiveAssignment() &&
						isArchivedAssignment == foundSpecificationItem->isArchivedAssignment() )
							{
							if( myWord_->firstUserSpecification( isNegative, isPossessive, questionParameter, ( isAssignment ? NO_CONTEXT_NR : generalizationContextNr ), ( isAssignment ? NO_CONTEXT_NR : specificationContextNr ), ( isAssignment ? NO_CONTEXT_NR : relationContextNr ), specificationWordItem, specificationString ) == NULL )
								{
								if( myWord_->writeSelectedSpecification( true, foundSpecificationItem ) == RESULT_OK )
									{
									if( strlen( commonVariables_->writeSentenceString ) > 0 )
										{
										if( commonVariables_->presentation->writeInterfaceText( true, PRESENTATION_PROMPT_NOTIFICATION, ( foundSpecificationItem->isSelfGeneratedAssumption() ? ( hasRelationContext ? INTERFACE_LISTING_CONFIRMED_SOME_RELATION_WORDS_OF_MY_ASSUMPTION : INTERFACE_LISTING_CONFIRMED_SPECIFICATION_OF_MY_ASSUMPTION ) : ( hasRelationContext ? INTERFACE_LISTING_CONFIRMED_SOME_RELATION_WORDS_OF_MY_CONCLUSION : INTERFACE_LISTING_CONFIRMED_SPECIFICATION_OF_MY_CONCLUSION ) ) ) == RESULT_OK )
											{
											if( commonVariables_->presentation->writeDiacriticalText( PRESENTATION_PROMPT_WRITE, commonVariables_->writeSentenceString ) == RESULT_OK )
												{
												if( !hasRelationContext )
													confirmedSpecificationItem_ = foundSpecificationItem;

												commonVariables_->isSpecificationConfirmedByUser = true;
												generalizationCollectionNr_ = foundSpecificationItem->generalizationCollectionNr();
												}
											else
												return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a confirmed sentence" );
											}
										else
											return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a confirmation interface text" );
										}
									else
										return myWord_->startErrorInWord( functionNameString, moduleNameString_, "I couldn't write the confirmed self-generated specification sentence" );
									}
								else
									return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write the confirmed self-generated specification sentence" );
								}
							}
						else
							{
							if( hasRelationContext &&
							!foundSpecificationItem->isOlderSentence() &&
							foundSpecificationItem->isUserSpecification() &&
							foundSpecificationItem->relationContextNr() == relationContextNr )
								foundSpecificationItem = myWord_->firstAssignmentOrSpecification( true, true, true, true, true, true, isNegative, isPossessive, true, questionParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );
							else
								foundSpecificationItem = myWord_->firstAssignmentOrSpecification( true, true, true, true, true, isNegative, isPossessive, questionParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

							if( foundSpecificationItem != NULL &&

							( foundSpecificationItem->isSelfGenerated() ||	// Replace a self-generated with a user-entered specification

							( !hasRelationContext &&
							foundSpecificationItem->hasRelationContext() &&
							myWord_->firstAssignmentOrSpecification( true, false, false, true, true, true, isNegative, isPossessive, true, questionParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString ) != NULL ) ) )
								{
								if( myWord_->writeSelectedSpecification( true, foundSpecificationItem ) == RESULT_OK )
									{
									if( strlen( commonVariables_->writeSentenceString ) > 0 )
										{
										if( commonVariables_->presentation->writeInterfaceText( true, PRESENTATION_PROMPT_NOTIFICATION, ( foundSpecificationItem->isSelfGeneratedAssumption() ? INTERFACE_LISTING_MY_ASSUMPTIONS_THAT_ARE_CONFIRMED : INTERFACE_LISTING_MY_CONCLUSIONS_THAT_ARE_CONFIRMED ) ) == RESULT_OK )
											{
											if( commonVariables_->presentation->writeDiacriticalText( PRESENTATION_PROMPT_WRITE, commonVariables_->writeSentenceString ) == RESULT_OK )
												{
												if( foundSpecificationItem->isAssignment() )
													isConfirmedAssignment_ = true;

												if( foundSpecificationItem->isExclusive() )
													isConfirmedExclusive_ = true;

												if( foundSpecificationItem->isSelfGeneratedAssumption() )
													isConfirmedAssumption_ = true;

												commonVariables_->isSpecificationConfirmedByUser = true;
												confirmedArchivedSpecificationItem_ = foundSpecificationItem;
												}
											else
												return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a sentence about the same, a similar or a relation question" );
											}
										else
											return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write an interface notification" );
										}
									else
										return myWord_->startErrorInWord( functionNameString, moduleNameString_, "I couldn't write the found specification sentence" );
									}
								else
									return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write the found specification sentence" );
								}
							}
						}
					}
				else
					return myWord_->startErrorInWord( functionNameString, moduleNameString_, "Value specification conflict! Specification word \"", specificationWordItem->anyWordTypeString(), "\" is already a value specification or it is already a normal specification and you want to make it a value specification" );
				}
			else
				return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given specification word item is undefined" );
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given found specification item is undefined" );

		return commonVariables_->result;
		}

	ResultType checkUserSpecificationOrQuestion( bool isAssignment, bool isDeactiveAssignment, bool isArchivedAssignment, bool isExclusive, bool isNegative, bool isPossessive, bool isSelection, bool isValueSpecification, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString )
		{
		GeneralizationResultType generalizationResult;
		SpecificationResultType specificationResult;
		bool checkQuestion = false;
		bool isQuestion = ( questionParameter > NO_QUESTION_PARAMETER );
		bool hasRelationContext = ( relationContextNr > NO_CONTEXT_NR );
		SpecificationItem *foundSpecificationItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkUserSpecificationOrQuestion";

		isCorrectedAssumptionByKnowledge_ = false;
		correctedSuggestiveQuestionAssumptionSpecificationItem_ = NULL;

		if( specificationWordItem != NULL )
			{
			// Check specification in opposite direction
			if( ( generalizationResult = myWord_->findGeneralization( false, questionParameter, generalizationWordTypeNr, specificationWordItem ) ).result == RESULT_OK )
				{
				if( generalizationResult.hasFoundGeneralization )
					{
					if( checkForSpecificationConflict( false, isExclusive, isNegative, isPossessive, specificationWordTypeNr, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, relationWordItem, specificationString ) != RESULT_OK )
						return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to check for a specification looping conflict" );
					}
				else
					{
					// Check current assignment, specification or question (with relation)
					foundSpecificationItem = myWord_->firstAssignmentOrSpecification( true, true, true, true, true, isNegative, isPossessive, questionParameter, specificationCollectionNr, ( isAssignment ? NO_CONTEXT_NR : generalizationContextNr ), ( isAssignment ? NO_CONTEXT_NR : specificationContextNr ), ( isAssignment ? NO_CONTEXT_NR : relationContextNr ), specificationWordItem, specificationString );

					if( isQuestion &&
					foundSpecificationItem == NULL )
						foundSpecificationItem = myWord_->firstAssignmentOrSpecificationButNotAQuestion( false, true, false, false, false, isNegative, isPossessive, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem );

					if( foundSpecificationItem == NULL )
						{
						// Check current assignment, specification or question (without this relation)
						if( isQuestion &&
						( foundSpecificationItem = myWord_->firstUserSpecification( isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, NO_CONTEXT_NR, specificationWordItem, specificationString ) ) == NULL )
							foundSpecificationItem = myWord_->firstAssignmentOrSpecificationButNotAQuestion( false, true, false, false, false, isNegative, isPossessive, specificationCollectionNr, generalizationContextNr, specificationContextNr, NO_CONTEXT_NR, specificationWordItem );

						if( isQuestion )
							{
							checkQuestion = true;

							if( isAssignment &&
							hasRelationContext &&

							( foundSpecificationItem == NULL ||
							foundSpecificationItem->isSelfGenerated() ) )
								addSuggestiveQuestionAssumption_ = true;
							}
						else
							{
							if( !isExclusive &&										// Exclusive specifications are not conflicting
							!isPossessive &&
							specificationCollectionNr > NO_COLLECTION_NR &&			// Possessive specifications are not conflicting
							generalizationWordTypeNr == WORD_TYPE_PROPER_NAME &&	// Only report conflicts on proper-names
							foundSpecificationItem == NULL )
								{
								if( ( specificationResult = findRelatedSpecification( false, true, false, false, false, false, isPossessive, NO_QUESTION_PARAMETER, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, relationWordItem, specificationString ) ).result == RESULT_OK )
									{
									if( specificationResult.relatedSpecificationItem != NULL &&
									specificationResult.relatedSpecificationItem->isSelfGeneratedAssumption() )
										{
										// Assumption needs to be corrected
										if( correctedSuggestiveQuestionAssumptionSpecificationItem_ == NULL )
											{
											if( myWord_->writeSpecification( false, true, false, specificationResult.relatedSpecificationItem ) == RESULT_OK )
												{
												isCorrectedAssumptionByKnowledge_ = true;
												correctedArchivedSpecificationItem_ = specificationResult.relatedSpecificationItem;
												correctedSuggestiveQuestionAssumptionSpecificationItem_ = specificationResult.relatedSpecificationItem;
												}
											else
												return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a conflicting specification" );
											}
										else
											return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The corrected suggestive question assumption specification item already assigned" );
										}
									else
										{
										if( checkForSpecificationConflict( true, isExclusive, isNegative, isPossessive, specificationWordTypeNr, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, relationWordItem, specificationString ) == RESULT_OK )
											{
											if( !commonVariables_->hasShownWarning &&
											isAssignment &&
											isExclusive &&
											!isNegative &&
											!hasRelationContext &&
											generalizationContextNr == NO_CONTEXT_NR &&
											specificationContextNr == NO_CONTEXT_NR )
												{
												if( commonVariables_->presentation->writeInterfaceText( true, PRESENTATION_PROMPT_NOTIFICATION, INTERFACE_SENTENCE_NOTIFICATION_AMBIGUOUS_SENTENCE_MISSING_RELATION ) != RESULT_OK )
													return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write an interface notification about ambiguity" );
												}
											}
										else
											return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to check for a specification conflict" );
										}
									}
								else
									return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find a related specification" );
								}
							}
						}
					else
						{
						checkQuestion = true;

						if( !hasRelationContext &&
						isAssignment &&
						!isNegative &&
						generalizationContextNr == NO_CONTEXT_NR &&
						specificationContextNr == NO_CONTEXT_NR &&
						foundSpecificationItem->hasRelationContext() )
							{
							if( myWord_->writeSelectedSpecification( true, foundSpecificationItem ) == RESULT_OK )
								{
								if( strlen( commonVariables_->writeSentenceString ) > 0 )
									{
									if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_NOTIFICATION, INTERFACE_SENTENCE_NOTIFICATION_MISSING_RELATION_I_ASSUME_YOU_MEAN ) == RESULT_OK )
										{
										if( commonVariables_->presentation->writeDiacriticalText( PRESENTATION_PROMPT_WRITE, commonVariables_->writeSentenceString ) == RESULT_OK )
											commonVariables_->hasShownMessage = false;
										else
											return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a sentence with an assumption about the relation" );
										}
									else
										return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write an interface notification with an assumption about the relation" );
									}
								else
									return myWord_->startErrorInWord( functionNameString, moduleNameString_, "I couldn't write a sentence with an assumption about the relation" );
								}
							else
								return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a sentence with an assumption about the relation" );
							}
						}

					if( !commonVariables_->hasShownWarning &&
					checkQuestion )
						{
						if( isQuestion )
							{
							if( checkUserQuestion( isAssignment, isExclusive, isNegative, isPossessive, questionParameter, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, foundSpecificationItem, specificationWordItem, relationWordItem, specificationString ) != RESULT_OK )
								return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to check the user question" );
							}
						else
							{
							if( checkUserSpecification( isAssignment, isDeactiveAssignment, isArchivedAssignment, isExclusive, isNegative, isPossessive, isSelection, isValueSpecification, questionParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, foundSpecificationItem, specificationWordItem, specificationString ) != RESULT_OK )
								return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to check the user specification" );
							}
						}
					}
				}
			else
				return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find out if word \"", specificationWordItem->anyWordTypeString(), "\" is one of my generalization words" );
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given specification word item is undefined" );

		return commonVariables_->result;
		}

	ResultType writeMoreSpecificSpecification( SpecificationItem *earlierSpecificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeMoreSpecificSpecification";
		if( earlierSpecificationItem != NULL )
			{
			if( myWord_->writeSelectedSpecification( !earlierSpecificationItem->isExclusive(), earlierSpecificationItem ) == RESULT_OK )
				{
				if( strlen( commonVariables_->writeSentenceString ) > 0 )
					{
					if( commonVariables_->presentation->writeInterfaceText( true, PRESENTATION_PROMPT_NOTIFICATION, ( earlierSpecificationItem->isQuestion() ? ( earlierSpecificationItem->isSelfGenerated() ? INTERFACE_LISTING_YOUR_QUESTION_IS_MORE_SPECIFIC_THAN_MY_QUESTION : INTERFACE_LISTING_THIS_QUESTION_IS_MORE_SPECIFIC_THAN_YOUR_QUESTION ) : ( earlierSpecificationItem->isSelfGenerated() ? ( earlierSpecificationItem->isSelfGeneratedAssumption() ? INTERFACE_LISTING_YOUR_INFO_IS_MORE_SPECIFIC_THAN_MY_ASSUMPTION : INTERFACE_LISTING_YOUR_INFO_IS_MORE_SPECIFIC_THAN_MY_CONCLUSION ) : INTERFACE_LISTING_THIS_INFO_IS_MORE_SPECIFIC_THAN_YOUR_EARLIER_INFO ) ) ) == RESULT_OK )
						{
						if( commonVariables_->presentation->writeDiacriticalText( PRESENTATION_PROMPT_WRITE, commonVariables_->writeSentenceString ) == RESULT_OK )
							commonVariables_->lastShownMoreSpecificSpecificationItem = earlierSpecificationItem;
						else
							return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write the earlier sentence" );
						}
					else
						return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write an interface listing text" );
					}
				else
					return myWord_->startErrorInWord( functionNameString, moduleNameString_, "I couldn't write a selected specification" );
				}
			else
				return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write a selected specification" );
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given more specific specification item is undefined" );

		return commonVariables_->result;
		}

	SpecificationResultType findRelatedSpecificationItem( bool checkAllQuestions, bool checkRelationContext, bool ignoreExclusive, bool isIncludingAnsweredQuestions, bool isAssignment, bool isDeactive, bool isExclusive, bool isPossessive, unsigned short questionParameter, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString )
		{
		SpecificationResultType specificationResult;
		bool isFirstRelatedSpecification = true;
		SpecificationItem *currentSpecificationItem = ( checkAllQuestions ? myWord_->firstSelectedSpecification( isAssignment, ( isAssignment && isDeactive ), false, true ) : myWord_->firstSelectedSpecification( isIncludingAnsweredQuestions, isAssignment, isDeactive, false, questionParameter ) );
		char functionNameString[FUNCTION_NAME_LENGTH] = "findRelatedSpecificationItem";

		if( specificationWordItem != NULL ||
		specificationString != NULL )
			{
			if( currentSpecificationItem != NULL &&

			( specificationCollectionNr > NO_COLLECTION_NR ||
			relationCollectionNr > NO_COLLECTION_NR ) )
				{
				do	{
					if( currentSpecificationItem->isRelatedSpecification( checkRelationContext, ignoreExclusive, isExclusive, isPossessive, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr ) )
						{
						// Found the given specification item
						if( currentSpecificationItem->relationContextNr() == relationContextNr &&
						currentSpecificationItem->specificationWordItem() == specificationWordItem &&

						( specificationString == NULL ||
						currentSpecificationItem->specificationString() == NULL ||
						strcmp( currentSpecificationItem->specificationString(), specificationString ) == 0 ) )
							isFirstRelatedSpecification = false;
						else
							{
							if( relationWordItem == NULL ||		// If the specification has no relation, select the oldest one (the first of a series)
							specificationResult.relatedSpecificationItem == NULL )
								{
								specificationResult.isFirstRelatedSpecification = isFirstRelatedSpecification;
								specificationResult.relatedSpecificationItem = currentSpecificationItem;
								}
							}
						}
					}
				while( ( currentSpecificationItem = ( checkAllQuestions ? currentSpecificationItem->nextSelectedSpecificationItem( isIncludingAnsweredQuestions ) : currentSpecificationItem->nextSpecificationItemWithSameQuestionParameter( isIncludingAnsweredQuestions ) ) ) != NULL );
				}
			}
		else
			myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given specification word item is undefined" );

		specificationResult.result = commonVariables_->result;
		return specificationResult;
		}


	public:
	// Constructor

	WordSpecification( WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		addSuggestiveQuestionAssumption_ = false;
		isConfirmedAssumption_ = false;
		isConfirmedAssignment_ = false;
		isConfirmedExclusive_ = false;
		isCorrectedAssumptionByKnowledge_ = false;
		isCorrectedAssumptionByOppositeQuestion_ = false;
		isNonExclusiveSpecification_ = false;

		generalizationCollectionNr_ = NO_COLLECTION_NR;

		archiveAssignmentItem_ = NULL;
		confirmedSpecificationItem_ = NULL;
		confirmedArchivedSpecificationItem_ = NULL;
		correctedArchivedSpecificationItem_ = NULL;
		correctedSuggestiveQuestionAssumptionSpecificationItem_ = NULL;
		lastShownConflictSpecificationItem_ = NULL;
		sameSimilarRelatedArchivedSpecificationItem_ = NULL;

		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "WordSpecification" );

		if( commonVariables_ != NULL )
			{
		if( myWord_ == NULL )
			strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInWord( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	void clearHasConfirmedAssumption()
		{
		isConfirmedAssumption_ = false;
		}

	void clearLastShownConflictSpecification()
		{
		lastShownConflictSpecificationItem_ = NULL;
		}

	bool addSuggestiveQuestionAssumption()
		{
		return addSuggestiveQuestionAssumption_;
		}

	bool isConfirmedAssumption()
		{
		return isConfirmedAssumption_;
		}

	bool isCorrectedAssumption()
		{
		return ( correctedSuggestiveQuestionAssumptionSpecificationItem_ != NULL );
		}

	bool isCorrectedAssumptionByKnowledge()
		{
		return isCorrectedAssumptionByKnowledge_;
		}

	bool isCorrectedAssumptionByOppositeQuestion()
		{
		return isCorrectedAssumptionByOppositeQuestion_;
		}

	ResultType checkForSpecificationConflict( bool skipCompoundRelatedConflict, bool isExclusive, bool isNegative, bool isPossessive, unsigned short specificationWordTypeNr, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString )
		{
		SpecificationResultType specificationResult;
		bool isInConflictWithItself = false;
		unsigned int compoundSpecificationCollectionNr;
		unsigned int nonCompoundSpecificationCollectionNr;
		SpecificationItem *relatedSpecificationItem;
		SpecificationItem *conflictingSpecificationItem = NULL;
		WordItem *generalizationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkForSpecificationConflict";

		if( specificationWordItem != NULL )
			{
			// Derive conflict
			if( ( specificationResult = findRelatedSpecification( false, true, false, false, false, false, isPossessive, NO_QUESTION_PARAMETER, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, relationWordItem, specificationString ) ).result == RESULT_OK )
				{
				relatedSpecificationItem = specificationResult.relatedSpecificationItem;

				if( relatedSpecificationItem == NULL ||
				relatedSpecificationItem->isNegative() != isNegative )
					{
					// Check for negative assignment or specification (with relation)
					if( ( conflictingSpecificationItem = myWord_->firstAssignmentOrSpecificationButNotAQuestion( false, true, true, true, true, !isNegative, isPossessive, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem ) ) == NULL )
						{
						// Check for negative assignment or specification (without this relation)
						if( ( conflictingSpecificationItem = myWord_->firstAssignmentOrSpecificationButNotAQuestion( false, true, true, true, true, !isNegative, isPossessive, specificationCollectionNr, generalizationContextNr, specificationContextNr, NO_CONTEXT_NR, specificationWordItem ) ) == NULL )
							{
							if( ( conflictingSpecificationItem = specificationWordItem->firstAssignmentOrSpecificationButNotAQuestion( false, true, true, true, true, isNegative, isPossessive, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, myWord_ ) ) == NULL )
								{
								if( ( compoundSpecificationCollectionNr = specificationWordItem->compoundCollectionNr( specificationWordTypeNr ) ) > NO_COLLECTION_NR )
									{
									// Check for already existing compound specification
									if( ( conflictingSpecificationItem = myWord_->firstAssignmentOrSpecificationButNotAQuestion( false, true, true, true, true, isNegative, isPossessive, compoundSpecificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, NULL ) ) == NULL )
										{
										if( !skipCompoundRelatedConflict )
											{
											// Check for related compound collection
											if( ( specificationResult = findRelatedSpecification( true, true, false, false, false, false, isPossessive, NO_QUESTION_PARAMETER, compoundSpecificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, relationWordItem, specificationString ) ).result == RESULT_OK )
												conflictingSpecificationItem = specificationResult.relatedSpecificationItem;
											else
												return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find a related specification" );
											}

										if( conflictingSpecificationItem == NULL &&
										( nonCompoundSpecificationCollectionNr = myWord_->nonCompoundCollectionNrInAllWords( compoundSpecificationCollectionNr ) ) > NO_COLLECTION_NR )
											conflictingSpecificationItem = myWord_->firstAssignmentOrSpecificationButNotAQuestion( false, true, true, true, true, isNegative, isPossessive, nonCompoundSpecificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, NULL );
										}
									}
								}
							}
						}
					}
				else
					{
					if( !isNegative )
						conflictingSpecificationItem = specificationResult.relatedSpecificationItem;
					}

				if( conflictingSpecificationItem != NULL )
					{
					// Process conflict
					if( ( generalizationWordItem = conflictingSpecificationItem->generalizationWordItem() ) != NULL )
						{
						if( ( specificationCollectionNr == NO_COLLECTION_NR ||
						specificationWordItem->isExclusiveCollection( specificationCollectionNr ) ) &&

						conflictingSpecificationItem != lastShownConflictSpecificationItem_ )
							{
							if( generalizationWordItem->writeSelectedSpecification( false, conflictingSpecificationItem ) == RESULT_OK )
								{
								if( strlen( commonVariables_->writeSentenceString ) > 0 )
									{
									if( !isExclusive &&
									specificationCollectionNr > NO_COLLECTION_NR &&
									!conflictingSpecificationItem->isOlderSentence() )
										isInConflictWithItself = true;

									if( commonVariables_->presentation->writeInterfaceText( true, PRESENTATION_PROMPT_WARNING, ( isInConflictWithItself ? INTERFACE_LISTING_SENTENCE_IN_CONFLICT_WITH_ITSELF : INTERFACE_LISTING_CONFLICT ) ) == RESULT_OK )
										{
										if( !isInConflictWithItself )
											{
											if( commonVariables_->presentation->writeDiacriticalText( PRESENTATION_PROMPT_WRITE, commonVariables_->writeSentenceString ) == RESULT_OK )
												lastShownConflictSpecificationItem_ = conflictingSpecificationItem;
											else
												return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write the conflict sentence" );
											}
										}
									else
										return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write an interface warning" );
									}
								else
									return myWord_->startErrorInWord( functionNameString, moduleNameString_, "I couldn't write the conflicting specification sentence" );
								}
							else
								return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to write the conflicting specification sentence" );
							}
						}
					else
						return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The generalization word item of the conflicting specification item is undefined" );
					}
				}
			else
				return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find a related specification" );
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given specification word item is undefined" );

		return commonVariables_->result;
		}

	ResultType recalculateAssumptionsOfInvolvedWords()
		{
		GeneralizationItem *currentGeneralizationItem;
		WordItem *currentGeneralizationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "recalculateAssumptionsOfInvolvedWords";

		if( myWord_->recalculateAssumptionsInWord() == RESULT_OK )
			{
			if( ( currentGeneralizationItem = myWord_->firstActiveGeneralizationItem() ) != NULL )
				{
				do	{
					if( ( currentGeneralizationWordItem = currentGeneralizationItem->generalizationWordItem() ) != NULL )
						{
						if( currentGeneralizationWordItem->recalculateAssumptionsInWord() != RESULT_OK )
							return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to recalculate the assumptions in generalization word \"", currentGeneralizationWordItem->anyWordTypeString(), "\"" );
						}
					else
						return myWord_->startErrorInWord( functionNameString, moduleNameString_, "I found an undefined generalization word" );
					}
				while( ( currentGeneralizationItem = currentGeneralizationItem->nextGeneralizationItem() ) != NULL );
				}
			}
		else
			return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to recalculate my assumptions" );

		return commonVariables_->result;
		}

	ResultType updateSpecificationsInJustificationOfInvolvedWords( SpecificationItem *archiveSpecificationItem, SpecificationItem *replacingSpecificationItem )
		{
		GeneralizationItem *currentGeneralizationItem;
		WordItem *currentGeneralizationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "updateSpecificationItemsInJustificationOfInvolvedWords";

		if( myWord_->updateSpecificationsInJustificationInWord( archiveSpecificationItem, replacingSpecificationItem ) == RESULT_OK )
			{
			if( ( currentGeneralizationItem = myWord_->firstActiveGeneralizationItem() ) != NULL )
				{
				do	{
					if( ( currentGeneralizationWordItem = currentGeneralizationItem->generalizationWordItem() ) != NULL )
						{
						if( currentGeneralizationWordItem->updateSpecificationsInJustificationInWord( archiveSpecificationItem, replacingSpecificationItem ) != RESULT_OK )
							return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to update the justification items in generalization word \"", currentGeneralizationWordItem->anyWordTypeString(), "\"" );
						}
					else
						return myWord_->startErrorInWord( functionNameString, moduleNameString_, "I found an undefined generalization word" );
					}
				while( ( currentGeneralizationItem = currentGeneralizationItem->nextGeneralizationItem() ) != NULL );
				}
			}
		else
			return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to update my justification items" );

		return commonVariables_->result;
		}

	SpecificationResultType addSpecification( bool isAssignment, bool isConditional, bool isDeactiveAssignment, bool isArchivedAssignment, bool isExclusive, bool isNegative, bool isPossessive, bool isSelection, bool isSpecificationGeneralization, bool isValueSpecification, unsigned short prepositionParameter, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString )
		{
		SpecificationResultType specificationResult;
		bool isExclusiveGeneralizationCollection = false;
		bool isQuestion = ( questionParameter > NO_QUESTION_PARAMETER );
		bool isSelfGenerated = ( specificationJustificationItem != NULL );
		unsigned int compoundCollectionNr = NO_COLLECTION_NR;
		unsigned int nonCompoundCollectionNr = NO_COLLECTION_NR;
		SpecificationItem *createdSpecificationItem;
		SpecificationItem *foundSpecificationItem = NULL;
		SpecificationItem *foundArchivedSpecificationItem = NULL;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addSpecification";

		addSuggestiveQuestionAssumption_ = false;
		isConfirmedAssignment_ = false;
		isConfirmedExclusive_ = false;
		isNonExclusiveSpecification_ = false;

		generalizationCollectionNr_ = generalizationCollectionNr;

		archiveAssignmentItem_ = NULL;
		confirmedSpecificationItem_ = NULL;
		confirmedArchivedSpecificationItem_ = NULL;
		correctedArchivedSpecificationItem_ = NULL;
		sameSimilarRelatedArchivedSpecificationItem_ = NULL;

		if( !isExclusive &&
		!isQuestion &&
		myWord_->isNoun() &&
		specificationWordItem != NULL &&
		specificationWordItem->isNoun() &&
		!specificationWordItem->hasCollection( NULL ) )
			{
			if( myWord_->addCollectionByGeneralization( isExclusive, isAssignment, isQuestion, true, specificationWordTypeNr, myWord_, specificationWordItem ).result != RESULT_OK )
				myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to add a collection by generalization of specification word \"", specificationWordItem->anyWordTypeString(), "\"" );
			}

		if( commonVariables_->result == RESULT_OK )
			{
			if( specificationWordItem == NULL )		// Specification string
				specificationCollectionNr = myWord_->collectionNr( specificationWordTypeNr, NULL );
			else
				{
				if( specificationCollectionNr == NO_COLLECTION_NR )
					{
					compoundCollectionNr = specificationWordItem->compoundCollectionNr( specificationWordTypeNr );
					nonCompoundCollectionNr = specificationWordItem->nonCompoundCollectionNr( specificationWordTypeNr );
					specificationCollectionNr = ( ( !isExclusive && nonCompoundCollectionNr > NO_COLLECTION_NR ) || compoundCollectionNr == NO_COLLECTION_NR ? nonCompoundCollectionNr : compoundCollectionNr );
					}
				}

			if( relationWordItem != NULL &&
			relationCollectionNr == NO_COLLECTION_NR )
				relationCollectionNr = relationWordItem->collectionNr( relationWordTypeNr, specificationWordItem );

			if( !isSelfGenerated &&
			specificationWordItem != NULL )
				{
				if( checkUserSpecificationOrQuestion( isAssignment, isDeactiveAssignment, isArchivedAssignment, isExclusive, isNegative, isPossessive, isSelection, isValueSpecification, questionParameter, generalizationWordTypeNr, specificationWordTypeNr, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, relationWordItem, specificationString ) == RESULT_OK )
					{
					if( !isAssignment &&
					isConfirmedAssignment_ )
						isAssignment = true;

					if( generalizationCollectionNr_ == NO_COLLECTION_NR )
						generalizationCollectionNr_ = myWord_->collectionNr( generalizationWordTypeNr, specificationWordItem, NULL );

					if( !isExclusive &&
					generalizationCollectionNr_ > NO_COLLECTION_NR &&
					myWord_->isExclusiveCollection( generalizationCollectionNr_ ) )
						isExclusiveGeneralizationCollection = true;
					}
				else
					myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to check a user specification or question with specification word \"", specificationWordItem->anyWordTypeString(), "\"" );
				}

			if( commonVariables_->result == RESULT_OK &&
			!commonVariables_->hasShownWarning )
				{
				foundSpecificationItem = myWord_->firstAssignmentOrSpecification( false, false, false, false, false, false, ( !isAssignment && isNegative ), isPossessive, isSelfGenerated, questionParameter, specificationCollectionNr, ( isAssignment ? NO_CONTEXT_NR : generalizationContextNr ), ( isAssignment ? NO_CONTEXT_NR : specificationContextNr ), ( isAssignment ? NO_CONTEXT_NR : relationContextNr ), specificationWordItem, specificationString );

				if( foundSpecificationItem == NULL ||

				// Exceptions
				isNonExclusiveSpecification_ ||
				confirmedArchivedSpecificationItem_ != NULL ||
				correctedArchivedSpecificationItem_ != NULL ||
				sameSimilarRelatedArchivedSpecificationItem_ != NULL ||

				// Overwrite non-conditional specification by conditional one
				( isConditional &&
				!foundSpecificationItem->isConditional() ) ||

				// Overwrite non-exclusive specification by exclusive one
				( isExclusive &&
				!foundSpecificationItem->isExclusive() ) ||

				// Overwrite self-generated assignment by user assignment
				( isAssignment &&
				!isSelfGenerated &&
				foundSpecificationItem->isSelfGenerated() ) ||

				// Accept different relation context (e.g. ambiguous specification)
				( ( relationContextNr > NO_CONTEXT_NR &&
				foundSpecificationItem->hasRelationContext() &&
				foundSpecificationItem->relationContextNr() != relationContextNr &&

				( isAssignment ||
				foundSpecificationItem->relationWordItem() == relationWordItem ) ) &&

				( !isSelfGenerated ||
				!foundSpecificationItem->hasFoundSpecificationJustification( specificationJustificationItem ) ) ) ||

				( isQuestion &&
				!isAssignment &&
				!isSelfGenerated &&
				foundSpecificationItem->isExclusive() ) )
					{
					if( foundSpecificationItem != NULL )
						{
						if( !isConditional &&
						foundSpecificationItem->isConditional() )
							isConditional = true;

						if( !isExclusive &&
						!isQuestion &&
						foundSpecificationItem->isExclusive() )
							isExclusive = true;

						if( !isQuestion &&
						!isConfirmedAssignment_ &&
						foundSpecificationItem->isUserSpecification() &&
						foundSpecificationItem != confirmedArchivedSpecificationItem_ &&
						foundSpecificationItem != correctedArchivedSpecificationItem_ &&
						sameSimilarRelatedArchivedSpecificationItem_ != foundSpecificationItem )
							foundArchivedSpecificationItem = foundSpecificationItem;
						}

					if( commonVariables_->result == RESULT_OK )
						{
						if( isExclusive )
							{
							if( isNonExclusiveSpecification_ )
								isExclusive = false;
							}
						else
							{
							if( isConfirmedExclusive_ ||
							isExclusiveGeneralizationCollection ||

							( isConditional &&

							( generalizationCollectionNr_ > NO_COLLECTION_NR ||
							specificationCollectionNr > NO_COLLECTION_NR ) ) )
								isExclusive = true;
							}

						if( ( specificationResult = createSpecification( false, isConditional, false, false, false, isExclusive, ( isAssignment ? false : isNegative ), isPossessive, isSpecificationGeneralization, isValueSpecification, NO_ASSUMPTION_LEVEL, commonVariables_->currentGrammarLanguageNr, prepositionParameter, questionParameter, generalizationWordTypeNr, specificationWordTypeNr, generalizationCollectionNr_, specificationCollectionNr, ( isAssignment ? NO_CONTEXT_NR : generalizationContextNr ), ( isAssignment ? NO_CONTEXT_NR : specificationContextNr ), ( isAssignment ? NO_CONTEXT_NR : relationContextNr ), commonVariables_->currentSentenceNr, ( isAssignment ? 0 : nContextRelations ), specificationJustificationItem, specificationWordItem, specificationString ) ).result == RESULT_OK )
							{
							if( ( createdSpecificationItem = specificationResult.createdSpecificationItem ) != NULL )
								{
								if( confirmedArchivedSpecificationItem_ != NULL )
									{
									if( archiveOrDeletedSpecification( confirmedArchivedSpecificationItem_, createdSpecificationItem ) != RESULT_OK )
										myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to archive or delete a confirmed specification" );
									}

								if( commonVariables_->result == RESULT_OK &&
								correctedArchivedSpecificationItem_ != NULL )
									{
									if( archiveOrDeletedSpecification( correctedArchivedSpecificationItem_, createdSpecificationItem ) != RESULT_OK )
										myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to archive or delete a corrected specification" );
									}

								if( commonVariables_->result == RESULT_OK &&
								sameSimilarRelatedArchivedSpecificationItem_ != NULL )
									{
									if( archiveOrDeletedSpecification( sameSimilarRelatedArchivedSpecificationItem_, createdSpecificationItem ) != RESULT_OK )
										myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to archive or delete a same-similar-related specification" );
									}

								if( commonVariables_->result == RESULT_OK &&
								foundArchivedSpecificationItem != NULL )
									{
									if( archiveOrDeletedSpecification( foundArchivedSpecificationItem, createdSpecificationItem ) != RESULT_OK )
										myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to archive or delete a found specification" );
									}

								if( commonVariables_->result == RESULT_OK &&
								confirmedSpecificationItem_ != NULL )
									{
									if( myWord_->confirmSpecificationButNotRelation( confirmedSpecificationItem_, createdSpecificationItem ) != RESULT_OK )
										myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to confirm a specification, but not its relation(s)" );
									}

								if( commonVariables_->result == RESULT_OK &&
								!isNegative &&
								!isQuestion &&
								specificationWordItem != NULL &&
								correctedSuggestiveQuestionAssumptionSpecificationItem_ == NULL )
									{
									if( myWord_->findPossibleQuestionAndMarkAsAnswered( specificationWordItem->compoundCollectionNr( specificationWordTypeNr ), createdSpecificationItem ) != RESULT_OK )
										myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find a possible question and mark it as been answered" );
									}
								}
							else
								myWord_->startErrorInWord( functionNameString, moduleNameString_, "I couldn't create a specification item" );
							}
						else
							myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to create a specification item" );
						}
					}

				if( commonVariables_->result == RESULT_OK &&
				specificationWordItem != NULL )
					{
					if( addGeneralization( generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, questionParameter, specificationWordItem, relationWordItem ) != RESULT_OK )
						myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to add a generalization" );
					}
				}
			}

		specificationResult.archiveAssignmentItem = archiveAssignmentItem_;
		specificationResult.foundSpecificationItem = foundSpecificationItem;
		specificationResult.result = commonVariables_->result;
		return specificationResult;
		}

	SpecificationResultType createSpecification( bool isAnsweredQuestion, bool isConditional, bool isConcludedAssumption, bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, bool isSpecificationGeneralization, bool isValueSpecification, unsigned short assumptionLevel, unsigned short grammarLanguageNr, unsigned short prepositionParameter, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int originalSentenceNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "createSpecification";

		if( !myWord_->iAmAdmin() )
			{
			if( specificationWordItem == NULL ||
			!specificationWordItem->isNounValue() )
				{
				if( myWord_->specificationList == NULL )
					{
					if( ( myWord_->specificationList = new SpecificationList( WORD_SPECIFICATION_LIST_SYMBOL, myWord_, commonVariables_ ) ) != NULL )
						myWord_->wordList[WORD_SPECIFICATION_LIST] = myWord_->specificationList;
					else
						{
						specificationResult.result = myWord_->startErrorInWord( functionNameString, moduleNameString_, "I failed to create a specification list" );
						return specificationResult;
						}
					}

				return myWord_->specificationList->createSpecificationItem( isAnsweredQuestion, isConditional, isConcludedAssumption, isDeactive, isArchived, isExclusive, isNegative, isPossessive, isSpecificationGeneralization, isValueSpecification, assumptionLevel, grammarLanguageNr, prepositionParameter, questionParameter, generalizationWordTypeNr, specificationWordTypeNr, generalizationCollectionNr, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, originalSentenceNr, nContextRelations, specificationJustificationItem, specificationWordItem, specificationString );
				}
			else
				myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given specification word item is a value word" );
			}
		else
			myWord_->startErrorInWord( functionNameString, moduleNameString_, "The admin does not have specifications" );

		specificationResult.result = commonVariables_->result;
		return specificationResult;
		}

	SpecificationResultType findRelatedSpecification( bool checkRelationContext, SpecificationItem *searchSpecificationItem )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findRelatedSpecification";

		if( searchSpecificationItem != NULL )
			return findRelatedSpecificationItem( false, checkRelationContext, false, searchSpecificationItem->isAnsweredQuestion(), searchSpecificationItem->isAssignment(), searchSpecificationItem->isDeactiveItem(), searchSpecificationItem->isExclusive(), searchSpecificationItem->isPossessive(), searchSpecificationItem->questionParameter(), searchSpecificationItem->specificationCollectionNr(), searchSpecificationItem->relationCollectionNr(), searchSpecificationItem->generalizationContextNr(), searchSpecificationItem->specificationContextNr(), searchSpecificationItem->relationContextNr(), searchSpecificationItem->specificationWordItem(), searchSpecificationItem->relationWordItem(), searchSpecificationItem->specificationString() );

		specificationResult.result = myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given search specification item is undefined" );
		return specificationResult;
		}

	SpecificationResultType findRelatedSpecification( bool checkAllQuestions, bool ignoreExclusive, bool isIncludingAnsweredQuestions, bool includeAssignments, bool includingDeactiveAssignments, bool isExclusive, bool isPossessive, unsigned short questionParameter, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findRelatedSpecification";

		// Either active assignments or specifications
		if( ( specificationResult = findRelatedSpecificationItem( checkAllQuestions, false, ignoreExclusive, isIncludingAnsweredQuestions, includeAssignments, false, isExclusive, isPossessive, questionParameter, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, relationWordItem, specificationString ) ).result == RESULT_OK )
			{
			if( includeAssignments )
				{
				if( includingDeactiveAssignments &&
				specificationResult.relatedSpecificationItem == NULL )
					{
					// Past-tense assignments
					if( ( specificationResult = findRelatedSpecificationItem( checkAllQuestions, false, ignoreExclusive, isIncludingAnsweredQuestions, true, true, isExclusive, isPossessive, questionParameter, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, relationWordItem, specificationString ) ).result != RESULT_OK )
						myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find a related past-tense assigment" );
					}

				if( commonVariables_->result == RESULT_OK &&
				specificationResult.relatedSpecificationItem == NULL )
					{
					// Specifications
					if( ( specificationResult = findRelatedSpecificationItem( checkAllQuestions, false, ignoreExclusive, isIncludingAnsweredQuestions, false, false, isExclusive, isPossessive, questionParameter, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, relationWordItem, specificationString ) ).result != RESULT_OK )
						myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find a related specification as well" );
					}
				}
			}
		else
			myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find a related specification" );

		specificationResult.result = commonVariables_->result;
		return specificationResult;
		}

	SpecificationItem *correctedSuggestiveQuestionAssumptionSpecificationItem()
		{
		return correctedSuggestiveQuestionAssumptionSpecificationItem_;
		}
	};

/*************************************************************************
 *
 *	"Yes, joyful are those who live like this!
 *	Joyful indeed are those whose God is the Lord." (Psalm 144:15)
 *
 *************************************************************************/
