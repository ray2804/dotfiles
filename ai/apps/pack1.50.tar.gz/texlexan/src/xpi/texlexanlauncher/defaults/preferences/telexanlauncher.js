// See http://kb.mozillazine.org/Localize_extension_descriptions
pref("extensions.telexan@jeanpierre.redonnet.description", "chrome://telexanlauncher/locale/telexanlauncher.properties");
