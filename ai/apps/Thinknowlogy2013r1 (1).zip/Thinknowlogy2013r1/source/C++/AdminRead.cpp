/*
 *	Class:			AdminRead
 *	Supports class:	AdminItem
 *	Purpose:		To read the lines from knowledge files
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "AdminItem.h"
#include "FileList.cpp"
#include "Presentation.cpp"

class AdminRead
	{
	// Private constructible variables

	unsigned int previousSentenceNr_;

	CommonVariables *commonVariables_;
	AdminItem *admin_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	bool isGrammarChar( char grammarChar )
		{
		return ( grammarChar == QUERY_WORD_TYPE_CHAR ||
				grammarChar == QUERY_PARAMETER_CHAR ||
				grammarChar == GRAMMAR_WORD_DEFINITION_CHAR );
		}

	bool showLine()
		{
		if( !admin_->isSystemStartingUp() &&
		admin_->fileList != NULL )
			return admin_->fileList->showLine();

		return false;
		}

	FileResultType openFile( bool addSubPath, bool isInfoFile, bool reportErrorIfFileDoesNotExist, const char *defaultSubpathString, const char *fileNameString )
		{
		FileResultType fileResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "openFile";

		if( admin_->fileList != NULL )
			return admin_->fileList->openFile( addSubPath, isInfoFile, reportErrorIfFileDoesNotExist, defaultSubpathString, fileNameString );

		fileResult.result = myWord_->startErrorInItem( functionNameString, moduleNameString_, "The file list isn't created yet" );
		return fileResult;
		}

	ResultType readLanguageFile( bool isGrammarLanguage, char *languageNameString )
		{
		FileResultType fileResult;
		ResultType originalResult;
		size_t position = 0;
		FileItem *openedLanguageFileItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "readLanguageFile";

		if( languageNameString != NULL )
			{
			while( position < strlen( languageNameString ) &&
			( languageNameString[position] == SYMBOL_SLASH ||
			languageNameString[position] == SYMBOL_BACK_SLASH ) )	// Skip directory
				position++;

			if( ( fileResult = openFile( true, false, false, ( isGrammarLanguage ? GRAMMAR_DIRECTORY_NAME_STRING : INTERFACE_DIRECTORY_NAME_STRING ), languageNameString ) ).result == RESULT_OK )
				{
				if( ( openedLanguageFileItem = fileResult.createdFileItem ) != NULL )
					{
					if( isGrammarLanguage )
						{
						if( admin_->createGrammarLanguage( languageNameString ) != RESULT_OK )
							myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create grammar language: \"", languageNameString, "\"" );
						}
					else
						{
						if( admin_->createInterfaceLanguage( languageNameString ) != RESULT_OK )
							myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to create interface language: \"", languageNameString, "\"" );
						}

					if( commonVariables_->result == RESULT_OK )
						{
						if( readAndExecute() != RESULT_OK )
							myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to read and execute the opened language file" );

						originalResult = commonVariables_->result;

						if( closeCurrentFileItem( openedLanguageFileItem ) != RESULT_OK )
							myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to close the language file item" );

						if( originalResult != RESULT_OK )
							commonVariables_->result = originalResult;
						}
					}
				}
			else
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to open the grammar file" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given language name is undefined" );

		return commonVariables_->result;
		}

	ResultType checkCurrentSentenceNr()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkCurrentSentenceNr";
		if( commonVariables_->currentSentenceNr < MAX_SENTENCE_NR )
			{
			if( admin_->dontIncrementCurrentSentenceNr() )
				{
				admin_->clearDontIncrementCurrentSentenceNr();
				previousSentenceNr_--;	// No increment is done. So, the previous sentence number should be one less
				}
			else
				{
				if( commonVariables_->currentSentenceNr + 1 >= admin_->myFirstSentenceNr() )	// Is my sentence
					{
					commonVariables_->currentSentenceNr++;

					if( admin_->currentItemNr() != RESULT_OK )		// Necessary after increment of current sentence number
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get the current item number" );
					}
				else
					return myWord_->startSystemErrorInItem( functionNameString, moduleNameString_, "Integrity violation! The next sentence is already used by another user" );
				}

			if( commonVariables_->currentSentenceNr > NO_SENTENCE_NR &&
			commonVariables_->currentSentenceNr <= admin_->highestSentenceNr() )
				{
				if( admin_->deleteSentences( true, commonVariables_->currentSentenceNr ) != RESULT_OK )
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete the current redo info" );
				}
			}
		else
			return myWord_->startSystemErrorInItem( functionNameString, moduleNameString_, "Sentence number overflow! I can't except anymore input" );

		return commonVariables_->result;
		}

	ResultType executeLine( char *readString )
		{
		ResultType originalResult;
		bool hasSwitchedLanguage = false;
		char functionNameString[FUNCTION_NAME_LENGTH] = "executeLine";

		previousSentenceNr_ = MAX_SENTENCE_NR;

		if( readString != NULL )
			{
			if( strlen( readString ) > 0 &&	// Skip empty line
			readString[0] != COMMENT_CHAR )	// and comment line
				{
				commonVariables_->hasShownMessage = false;
				commonVariables_->isAssignmentChanged = false;

				if( admin_->cleanupDeletedItems() == RESULT_OK )
					{
					previousSentenceNr_ = commonVariables_->currentSentenceNr;

					if( readString[0] == QUERY_CHAR )					// Guide-by-grammar, grammar/interface language or query
						{
						if( strlen( readString ) == 1 )				// Guide-by-grammar
							{
							if( checkCurrentSentenceNr() == RESULT_OK )
								{
								if( admin_->processReadSentence( NULL ) != RESULT_OK )
									myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to process a read sentence" );
								}
							else
								myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check to current sentence number" );
							}
						else
							{
							if( isalpha( readString[1] ) )			// Grammar/interface language
								{
								if( admin_->isSystemStartingUp() )			// Read grammar and/or interface language file
									{
									// First try to read the user-interface language file
									if( readLanguageFile( false, &readString[1] ) == RESULT_OK )
										{
										// Now, try to read the grammar language file
										if( readLanguageFile( true, &readString[1] ) != RESULT_OK )
											myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to read a grammar file" );
										}
									else
										myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to read an interface file" );
									}
								else										// Change interface language
									{
									if( admin_->assignGrammarAndInterfaceLanguage( &readString[1] ) == RESULT_OK )
										hasSwitchedLanguage = true;
									else
										myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to assign the grammar and interface language" );
									}
								}
							else
								{
								if( readString[0] == QUERY_CHAR )		// Query
									{
									admin_->initializeQueryStringPosition();

									if( admin_->executeQuery( false, true, true, PRESENTATION_PROMPT_QUERY, readString ) != RESULT_OK )
										myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to execute query: \"", readString, "\"" );
									}
								}
							}
						}
					else													// Sentence or grammar definition
						{
						if( checkCurrentSentenceNr() == RESULT_OK )
							{
							if( isGrammarChar( readString[0] ) )		// Grammar definition
								{
								if( admin_->addGrammar( readString ) != RESULT_OK )
									myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add grammar: \"", readString, "\"" );
								}
							else											// Sentence
								{
								if( admin_->processReadSentence( readString ) != RESULT_OK )
									myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to process a read sentence" );
								}
							}
						else
							myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check to current sentence number" );
						}

					if( commonVariables_->result != RESULT_SYSTEM_ERROR &&
					!admin_->hasRequestedRestart() )
						{
						if( commonVariables_->result == RESULT_OK &&
						!hasSwitchedLanguage &&
						admin_->hasFoundChange() &&

						( admin_->wasUndoOrRedo() ||		// Execute selections after Undo or Redo
						!commonVariables_->hasShownMessage ) &&
						!commonVariables_->hasShownWarning )
							{
							if( admin_->executeSelections() != RESULT_OK )
								myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to execute selections after reading the sentence" );
							}

						if( commonVariables_->result == RESULT_OK &&
						!hasSwitchedLanguage &&
						!admin_->hasFoundChange() &&
						!admin_->isSystemStartingUp() &&
						!commonVariables_->hasShownMessage &&
						!commonVariables_->hasShownWarning )
							{
							if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_NOTIFICATION, INTERFACE_SENTENCE_NOTIFICATION_I_KNOW ) != RESULT_OK )
								myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface notification" );
							}

						if( commonVariables_->result == RESULT_OK )
							{
							if( admin_->deleteAllTemporaryLists() != RESULT_OK )
								myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete all temporary lists" );
							}

						if( ( commonVariables_->hasShownWarning ||
						commonVariables_->result != RESULT_OK ) &&

						commonVariables_->currentSentenceNr == previousSentenceNr_ + 1 )	// This sentence has items
							{
							originalResult = commonVariables_->result;					// Remember original result
							commonVariables_->result = RESULT_OK;						// Clear current result

							// Deleted current redo info. After this, 'Redo' isn't possible
							if( admin_->deleteSentences( false, commonVariables_->currentSentenceNr ) != RESULT_OK )
								myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to delete the current redo information" );

							if( originalResult != RESULT_OK )
								commonVariables_->result = originalResult;				// Restore original result
							}
						}
					}
				else
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to cleanup the deleted items" );
				}
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given read string is undefined" );

		return commonVariables_->result;
		}

	ResultType closeCurrentFileItem( FileItem *closeFileItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "closeCurrentFileItem";
		if( admin_->fileList != NULL )
			{
			if( admin_->fileList->closeCurrentFile( closeFileItem ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to close a file" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The file list isn't created yet" );

		return commonVariables_->result;
		}


	public:
	// Constructor

	AdminRead( AdminItem *admin, WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		admin_ = admin;
		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "AdminRead" );

		if( commonVariables_ != NULL )
			{
		if( admin_ != NULL )
			{
			if( myWord_ == NULL )
				strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given admin is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	ResultType readStartupFile()
		{
		FileResultType fileResult;
		ResultType originalResult;
		FileItem *openedStartupFileItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "readStartupFile";
		if( admin_->fileList == NULL )
			{
			// Create list
			if( ( admin_->fileList = new FileList( myWord_, commonVariables_ ) ) != NULL )
				admin_->adminList[ADMIN_FILE_LIST] = admin_->fileList;
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I failed to create an admin file list" );
			}

		if( ( fileResult = openFile( true, false, true, STARTUP_DIRECTORY_NAME_STRING, STARTUP_FILE_NAME_STRING ) ).result == RESULT_OK )
			{
			if( ( openedStartupFileItem = fileResult.createdFileItem ) != NULL )
				{
				if( readAndExecute() != RESULT_OK )
					myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to read and execute the opened startup file" );

				originalResult = commonVariables_->result;

				if( closeCurrentFileItem( openedStartupFileItem ) != RESULT_OK )
					myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to close the startup file item" );

				if( originalResult != RESULT_OK )
					commonVariables_->result = originalResult;
				}
			}
		else
			return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to open an example file" );

		return commonVariables_->result;
		}

	ResultType readExamplesFile( char *examplesFileNameString )
		{
		FileResultType fileResult;
		ResultType originalResult;
		FileItem *openedExampleFileItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "readExamplesFile";
		if( examplesFileNameString != NULL )
			{
			if( ( fileResult = openFile( !admin_->isSystemStartingUp(), false, true, EXAMPLES_DIRECTORY_NAME_STRING, examplesFileNameString ) ).result == RESULT_OK )
				{
				if( ( openedExampleFileItem = fileResult.createdFileItem ) != NULL )
					{
					if( readAndExecute() != RESULT_OK )
						myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to read and execute the opened example file" );

					originalResult = commonVariables_->result;

					if( closeCurrentFileItem( openedExampleFileItem ) != RESULT_OK )
						myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to close the example file item" );

					if( originalResult != RESULT_OK )
						commonVariables_->result = originalResult;
					}
				}
			else
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to open an example file" );
			}
		else
			{
			if( commonVariables_->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_WARNING, INTERFACE_IMPERATIVE_WARNING_I_DONT_KNOW_WHICH_FILE_TO_READ ) != RESULT_OK )
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an interface warning" );
			}

		return commonVariables_->result;
		}

	ResultType readAndExecute()
		{
		bool isLineExecuted;
		char readString[MAX_READ_WRITE_STRING_LENGTH] = EMPTY_STRING;
		char functionNameString[FUNCTION_NAME_LENGTH] = "readAndExecute";

		do	{
			isLineExecuted = false;
			strcpy( readString, EMPTY_STRING );

			if( readLine( false, false, false, ( admin_->dontIncrementCurrentSentenceNr() ? commonVariables_->currentSentenceNr : commonVariables_->currentSentenceNr + 1 ), admin_->currentUserName(), readString ) == RESULT_OK )
				{
				if( commonVariables_->presentation->hasReadNewLine() )
					{
					if( executeLine( readString ) == RESULT_OK )
						isLineExecuted = true;
					else
						return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to execute the read line" );
					}
				}
			else
				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to read a line" );
			}
		while( isLineExecuted &&
		!admin_->hasRequestedRestart() &&
		!commonVariables_->hasShownWarning );

		if( admin_->isSystemStartingUp() &&
		commonVariables_->hasShownWarning )
			commonVariables_->result = RESULT_SYSTEM_ERROR;

		return commonVariables_->result;
		}

	ResultType readLine( bool isPassword, bool isQuestion, bool isText, unsigned int promptSentenceNr, char *promptUserNameString, char *readString )
		{
		char promptString[MAX_READ_WRITE_STRING_LENGTH] = EMPTY_STRING;
		char functionNameString[FUNCTION_NAME_LENGTH] = "readLine";

		if( promptSentenceNr > NO_SENTENCE_NR )
			sprintf( promptString, "%u", promptSentenceNr );

		if( promptUserNameString != NULL )
			{
			if( strlen( promptString ) > 0 )
				strcat( promptString, QUERY_SEPARATOR_STRING );

			strcat( promptString, promptUserNameString );
			}

		if( commonVariables_->presentation->readLine( isPassword, isQuestion, isText, showLine(), promptString, readString, ( admin_->fileList == NULL ? NULL : admin_->fileList->currentReadFile() ) ) != RESULT_OK )
			return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to read a line from a file or from input" );

		return commonVariables_->result;
		}

	FileResultType readInfoFile( bool reportErrorIfFileDoesNotExist, char *infoFileNameString )
		{
		FileResultType fileResult;
		ResultType originalResult;
		FileItem *openedInfoFileItem;
		char infoPathString[MAX_READ_WRITE_STRING_LENGTH] = INFO_DIRECTORY_NAME_STRING;
		char functionNameString[FUNCTION_NAME_LENGTH] = "readInfoFile";

		if( infoFileNameString != NULL )
			{
			if( commonVariables_->currentGrammarLanguageWordItem != NULL )
				{
				strcat( infoPathString, commonVariables_->currentGrammarLanguageWordItem->anyWordTypeString() );
				strcat( infoPathString, SLASH_STRING );
				}

			if( ( fileResult = openFile( true, true, reportErrorIfFileDoesNotExist, infoPathString, infoFileNameString ) ).result == RESULT_OK )
				{
				if( ( openedInfoFileItem = fileResult.createdFileItem ) != NULL )
					{
					if( readAndExecute() != RESULT_OK )
						myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to read and execute the opened info file" );

					originalResult = commonVariables_->result;

					if( closeCurrentFileItem( openedInfoFileItem ) != RESULT_OK )
						myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to close the info file item" );

					if( originalResult != RESULT_OK )
						commonVariables_->result = originalResult;
					}
				}
			else
				myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to open the info file" );
			}
		else
			myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given info file name string is undefined" );

		fileResult.result = commonVariables_->result;
		return fileResult;
		}
	};

/*************************************************************************
 *
 *	"Shout to the Lord, all the earth;
 *	break out in praise and sing for joy!" (Psalm 98:4)
 *
 *************************************************************************/
