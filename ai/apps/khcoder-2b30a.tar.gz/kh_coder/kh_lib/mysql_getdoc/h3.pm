package mysql_getdoc::h3;
use base qw(mysql_getdoc);
use strict;


1;
