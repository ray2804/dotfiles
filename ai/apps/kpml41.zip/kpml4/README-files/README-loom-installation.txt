Loom for KPML                May, 2002 (re-checked Jan, 2004)
=============                ================================

This is a short set of instructions for installing Loom for
those who are doing this for using KPML rather than to use
Loom themselves. Some of this information is also relevant
for installations of Loom.

These comments apply to all Loom versions, i.e.: 2.1, 3.0,
4.0

Loom needs to be told where it has been put on your
computer.  To do this you need to set the necessary path
information in 2 files in the top-level Loom distribution:

* compile-loom.lisp
* load-loom.lisp

The change is the same in both files. You need to find the
variable definition near the beginning of the file that
starts:

(defvar *loom-pathname-default* ... )

and replace the "..." with the directory/folder where you have
placed loom. Thus, if the files compile-loom.lisp and load-loom.lisp
happen to have been placed in the folder: C:\Programme\loom2.1\
then you need to change the defvar to be the following:

(defvar *loom-pathname-default* "C:\\Programme\\loom2.1\\")

This must be done in *both* the files compile-loom.lisp and 
load-loom.lisp !!

If you are using Loom on a PC under Windows and Lispworks
(and, indeed, unless you have explicit reasons otherwise,
under Unix too), the following changes are RECOMMENDED 
for your Loom installation:

;;; If you want to put Loom on a different diskdrive, then
;;; the released version of defsystem.lisp with Loom 4
;;; shares bugs with the released versions in Loom 3 and
;;; earlier. Compilation will fail. Simplest fix is to
;;; replace the version of defsystem.lisp with the file
;;; cond-defsystem.lisp in the KPML distribution before
;;; compiling/loading Loom. This should then work at least
;;; for LWW. However you then also need to load the KPML file
;;; <kpml>/Processes/startup/version-utilities.lisp before
;;; compiling/loading Loom! 

THESE CHANGES ARE PROVIDED ALREADY MADE IN THE FOLDER
Processes\kr-interfaces\loom\fix-for-loom4-under-Windows
Copying all of the files in this folder to the top-level
Loom directory will do the trick.

Once this change has been made then you need to compile Loom,
so that when KPML runs it can just load in the compiled Loom
code without any further work. This is necessary, for example,
to load the default version of the Upper Model which is written
in Loom, or to load domain models that are written in Loom.

You compile Loom by issuing from a Lisp listener the Common
Lisp function call (again, assuming that the files are in the
folder assumed above): 

(load "C:\\Programme\\loom2.1\\compile-loom.lisp")

This should run through to completion and the result is a large
number of compiled files under one of the binary subdirectories
of the Loom system. If this runs through to completion, nothing
further must be done with the Loom system, ever. All interaction
between KPML and Loom is done via a small set of knowledge
representation interface functions; LOOM IS NOT PART OF THE 
KPML SYSTEM.

