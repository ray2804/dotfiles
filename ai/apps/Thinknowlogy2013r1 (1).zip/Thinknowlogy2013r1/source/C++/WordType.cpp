/*
 *	Class:			WordType
 *	Supports class:	WordItem
 *	Purpose:		To create word-type structures
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "WordTypeList.cpp"

class WordType
	{
	// Private constructible variables

	char wordItemNameString_[MAX_READ_WRITE_STRING_LENGTH];		// This variable is returned by a function. So, it must be "static".

	CommonVariables *commonVariables_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	public:
	// Constructor

	WordType( WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		strcpy( wordItemNameString_, EMPTY_STRING );

		commonVariables_ = commonVariables;
		myWord_ = myWord;
		strcpy( moduleNameString_, "WordType" );

		if( commonVariables_ != NULL )
			{
		if( myWord_ == NULL )
			strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInWord( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	ResultType addWordType( bool isPropernamePrecededByDefiniteArticle, unsigned short definiteArticleParameter, unsigned short indefiniteArticleParameter, unsigned short wordTypeNr, size_t wordLength, char *wordTypeString )
		{
		WordResultType wordResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addWordType";

		if( !myWord_->iAmAdmin() )
			{
			if( myWord_->wordTypeList == NULL )
				{
				// Create list
				if( ( myWord_->wordTypeList = new WordTypeList( myWord_, commonVariables_ ) ) != NULL )
					myWord_->wordList[WORD_TYPE_LIST] = myWord_->wordTypeList;
				else
					return myWord_->startErrorInWord( functionNameString, moduleNameString_, "I failed to create a word type list" );
				}
			else
				{
				// Find out if already exists
				if( ( wordResult = findWordType( false, wordTypeNr, wordTypeString ) ).result != RESULT_OK )
					return myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find the given word type" );
				}

			if( wordResult.foundWordTypeItem == NULL )		// Word type doesn't exist yet
				return myWord_->wordTypeList->createWordTypeItem( isPropernamePrecededByDefiniteArticle, definiteArticleParameter, indefiniteArticleParameter, wordTypeNr, wordLength, wordTypeString );
			}
		else
			return myWord_->startErrorInWord( functionNameString, moduleNameString_, "The admin does not have word types" );

		return commonVariables_->result;
		}

	WordResultType findWordType( bool checkAllLanguages, unsigned short searchWordTypeNr, char *searchWordString )
		{
		WordResultType wordResult;
		size_t currentWordStringLength;
		size_t searchWordStringLength;
		char *currentWordString;
		WordTypeItem *currentWordTypeItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findWordType";

		if( searchWordString != NULL )
			{
			if( ( searchWordStringLength = strlen( searchWordString ) ) > 0 )
				{
				if( ( currentWordTypeItem = myWord_->activeWordTypeItem( checkAllLanguages, searchWordTypeNr ) ) != NULL )
					{
					do	{
						if( ( currentWordString = currentWordTypeItem->itemString() ) != NULL )	// Could be hidden word type
							{
							if( ( currentWordStringLength = strlen( currentWordString ) ) > 0 )
								{
								if( searchWordStringLength == currentWordStringLength &&
								strcmp( searchWordString, currentWordString ) == 0 )
									wordResult.foundWordTypeItem = currentWordTypeItem;
								}
							else
								myWord_->startErrorInWord( functionNameString, moduleNameString_, "The active word type string is empty" );
							}
						}
					while( commonVariables_->result == RESULT_OK &&
					wordResult.foundWordTypeItem == NULL &&
					( currentWordTypeItem = currentWordTypeItem->nextWordTypeItem( searchWordTypeNr ) ) != NULL );
					}
				}
			else
				myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given search word string is empty" );
			}
		else
			myWord_->startErrorInWord( functionNameString, moduleNameString_, "The given search word string is undefined" );

		wordResult.result = commonVariables_->result;
		return wordResult;
		}

	WordResultType findWordTypeInAllWords( bool checkAllLanguages, unsigned short searchWordTypeNr, char *searchWordString, WordItem *previousWordItem )
		{
		WordResultType wordResult;
		WordItem *currentWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findWordTypeInAllWords";

		if( ( currentWordItem = ( previousWordItem == NULL ? commonVariables_->firstWordItem : previousWordItem->nextWordItem() ) ) != NULL )
			{
			do	{
				if( ( wordResult = currentWordItem->findWordType( checkAllLanguages, searchWordTypeNr, searchWordString ) ).result == RESULT_OK )
					{
					if( wordResult.foundWordTypeItem != NULL )
						wordResult.foundWordItem = currentWordItem;
					}
				else
					myWord_->addErrorInWord( functionNameString, moduleNameString_, "I failed to find a word type in word \"", currentWordItem->anyWordTypeString(), "\"" );
				}
			while( wordResult.foundWordItem == NULL &&
			( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}

		wordResult.result = commonVariables_->result;
		return wordResult;
		}

	char *wordTypeString( bool checkAllLanguages, unsigned short orderNr, unsigned short wordTypeNr )
		{
		char *wordTypeString = ( myWord_->wordTypeList == NULL ? NULL : myWord_->wordTypeList->wordTypeString( checkAllLanguages, orderNr, wordTypeNr ) );

		if( orderNr == NO_ORDER_NR &&
		wordTypeString == NULL )
			{
			sprintf( wordItemNameString_, "%c%u%c%u%c", QUERY_ITEM_START_CHAR, myWord_->creationSentenceNr(), QUERY_SEPARATOR_CHAR, myWord_->itemNr(), QUERY_ITEM_END_CHAR );
			return wordItemNameString_;
			}

		return wordTypeString;
		}
	};

/*************************************************************************
 *
 *	"Let them praise your great and awesome name.
 *	Your name is holy!" (Psalm 99:3)
 *
 *************************************************************************/
