/* License/copyright: Dual license, please read copyright.txt */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>
#include <unistd.h>
#include <time.h>
#include "utils.h"
#include "help.h"
#include "definitions.h"
#include "languages.h"
#include "sentiment.h"

extern int debug;
extern int verbose;
extern int linewidth;
extern char lang[];
extern long int size_line;
extern long int size_class_name;
extern long int size_nb_class;
extern char file_input[]; //SIZE_WORD
extern char file_output[];
extern int count_silent_bug;

/* 
 * Sentiment analysis
*/
int emotion_extract(
	char *file,char *result,long int size_result,
	char *text,long int *pos_sentence,
	int levenstein, char *targetlst, 
	int doemotion, int rec)
{
	FILE *fp1,*fp2;
	char *line;
	int *class_sum,*class_diff; //'size_nb_class' classes 
	int *classaction; //'size_nb_class' 
	char **classname; //'size_nb_class*size_class_name' chars
	char *str_ptr,*str_ptr1,*str_ptr2,*str_ptr3, *str_ptr_next;
	char *wtargetbis;
	char *wtarget_ptr[100]; //max 100 targets
	int cont,i,j,k,index,index_wtarget,val,inverser,multiply,divide;
	int l=-1;
	char word[SIZE_WORD];
	long int result_overflow,nbkey,length,do_sentence;
	long int cumul,gross_cumul,nbsentences;
	long int line_cnt,lg_sentence;
	char *longline;
	char ch;
	int cnt_suppress,cnt_space,offset;
	char sentence[SIZE_SENTENCE];
	char linesmart[SIZE_SENTENCE];
	char wordchk[SIZE_WORD+2];
	char target[SIZE_SENTENCE];
	int size_wtargetbis;
	char *wtarget;
	int do_free_wtarget=0;
	
	if (linewidth) clever_print(0,""); //reset static var in fct
	
	if (debug) fprintf(stderr,"\nSTART SENTENCE ROUTINE\n"); //check pb
	size_wtargetbis=10;
	if (targetlst) {
		
		if (teststransi7(targetlst)) {
			wtarget=targetlst; //duplicate address
		}
		else if (teststrutf8(targetlst)) {
			do_free_wtarget=1;
			if ((wtarget = (char*)malloc( 1.1*strlen(targetlst) )) == NULL) errmalloc("Sentiment Analyze");;
			fprintf(stderr,"targets utf8->7bits, errors:%i\n",strutf8toansi7b(targetlst,wtarget));
		}
		else if (teststrutf16(targetlst)) {
			ERRPOS
			fprintf(stderr,"targets utf16 - no conversion available!\n");
			return 0;
		}
		else {
			fprintf(stderr,"targets supposed iso\n");
			do_free_wtarget=1;
			if ((wtarget = (char*)malloc( 1.1*strlen(targetlst) )) == NULL) errmalloc("Sentiment Analyze");;
			fprintf(stderr,"targets iso->7bits, errors:%i\n",strisotoansi7b(targetlst,wtarget));
		}
		
		/* compute size of wtargetbis ';' count double => '\n'+'\0' */
		str_ptr=wtarget;
		while (*str_ptr != '\0')
		{
			if (*str_ptr == ';') size_wtargetbis+=3;
			else size_wtargetbis++;
			str_ptr++;
		}
	}
	/*dynamic alloc*/
	if ((wtargetbis = (char*)malloc(size_wtargetbis)) == NULL) errmalloc("Sentiment Analyze");;
	if ((longline = (char*)malloc(SIZE_LONGLINE+1)) == NULL) errmalloc("Sentiment Analyze");;
	if ((line = (char*)malloc(size_line)) == NULL) errmalloc("Sentiment Analyze");
	if ((classaction = (int*)malloc(size_nb_class*sizeof(int))) == NULL) errmalloc("Sentiment Analyze");
	if ((classname = (char**)malloc(size_nb_class*sizeof(char*))) == NULL) errmalloc("Sentiment Analyze");
	for (k=0;k<size_nb_class;k++) if ((classname[k] = (char*)malloc(size_class_name)) == NULL) errmalloc("Sentiment Analyze");
	if ((class_sum = (int*)malloc(size_nb_class*sizeof(int))) == NULL) errmalloc("Sentiment Analyze");
	if ((class_diff = (int*)malloc(size_nb_class*sizeof(int))) == NULL) errmalloc("Sentiment Analyze");
	  
	for(i=0;i<size_nb_class;i++) { class_sum[i]=0; class_diff[i]=0; } //set to zero tables of cumuled weight & occurence

	fp1=fopen(file,"r");
	if (fp1==NULL){
	  ERRPOS
	  fprintf(stderr,"Unable to reopen %s ->Exit!\n",file);
	  exit(EXIT_FAILURE);
	}
	
	fp2=fopen(file_input,"r"); //temp file -> sentences are extracted from it
	if (fp2==NULL){
		ERRPOS
		fprintf(stderr,"Unable to open %s ->Exit!\n",file_input);
		exit(EXIT_FAILURE);
	}

	/*build the classname array*/  
	fseek(fp1,0,SEEK_SET);
	for(i=0;i<size_nb_class;i++) {
		line[size_line-2]='\0';
		if (fgets(line,size_line,fp1) == NULL) break; //!!!pb if line>size_line
		if (line[size_line-2] != '\0') {
			ERRPOS
			fprintf(stderr,"Pb size_line too small\n");
			count_silent_bug++;
		}
		if (line[0] != '#') {
			if ((str_ptr2=strpbrk(line,":/")) != NULL) *str_ptr2='\0';
			else {
				ERRPOS
				fprintf(stderr,"':/' not found!\n");
			}
			if (strlen(line) < size_class_name) strcpy(word,line);
			else {
				ERRPOS
				fprintf(stderr,"Label too long in sentiment:<%s>\n",line);
			}
			if ((str_ptr2=strpbrk(line," ")) != NULL) *str_ptr2='\0';
			if ((j=atoi(line))!=0) {
				strcpy(classname[j],word);
				if (strstr(word,"inverser") != NULL) {
					classaction[j]=-1;
				}
				else if (strstr(word,"mitiger") != NULL) {
					classaction[j]=0;
				}
				else if (strstr(word,"enhancer") != NULL) {
					classaction[j]=1;
				}
				else if (strstr(word,"positive") != NULL) {
					classaction[j]=2;
				}
				else if (strstr(word,"negative") != NULL) {
					classaction[j]=3;
				}
				else if (strstr(word,"suborder") != NULL) {
					classaction[j]=-2;
				}
				else classaction[j]=0;
			}
			else {
				ERRPOS
				fprintf(stderr,"atoi(line):<%s>\n",line);
				count_silent_bug++;
			}
		}
	}
	/* Prepare wtarget */
	if (targetlst) {
		/* replace '"' , ' ' , ';' with '\n' 
		 * word and sentence are delimited with '\n' 
		 * ';' marks a word or sentence to search (a target) 
		 * 2 targets are separated with '\0'
		 */
		str_ptr=wtarget;
		*wtargetbis = '\n';
		wtarget_ptr[0]=wtargetbis;
		i=1; j=1;
		while (*str_ptr != '\0') {
			switch (*str_ptr) {
				case ' ':
					*(wtargetbis+i) = '\n';
					i++;
					break;
				case '"':
					*(wtargetbis+i) = '\n';
					i++;
					break;
				case ';':
					*(wtargetbis+i) = '\n';
					i++;
					*(wtargetbis+i) = '\0';
					i++;
					if (j < 100)
						wtarget_ptr[j++]=wtargetbis+i; //on the next '\n'
					else {
						ERRPOS
						count_silent_bug++;
					}
					*(wtargetbis+i) = '\n';
					i++;
					break;
				default:
					*(wtargetbis+i) = *str_ptr;
					i++;
			}
			str_ptr++;
		}
		index_wtarget=j;
		*(wtargetbis+i) = '\n';
		i++;
		*(wtargetbis+i) = '\0';
	}
	/* Below: 
	 * 1- extract each sentence in the text tokenized
	 * 2- look for target words
	 * 3- look for sentiment words 
	 * 4- compute 'sentiment level' of the sentence 
	 * 5- extract the sentence non-tokenized
	 */
	i=j=0;
	gross_cumul=nbsentences=0;
	nbkey=result_overflow=0;
	line_cnt=0;
	str_ptr=text;
	length=strlen(text);
	/* 1- Extract each sentence tokenized */
	while ((str_ptr_next=strstr(str_ptr,"EOS")) != NULL) { //point to the end of the sentence
		do_sentence=1; //set flag
		line_cnt++; //=>line_cnt points the end of each sentence
		if (str_ptr_next-str_ptr > SIZE_LONGLINE) {
			do_sentence=0;
			ERRPOS
			fprintf(stderr,"Sentence too long!\n");
			count_silent_bug++;
		}  
		
		/* Now, we are going to look for target words and sentiments */
		if (do_sentence) {
			multiply=1;
			divide=1;
			inverser=1;
			cumul=0;
			/* Copy the sentence in longline */
			strncpy(longline,str_ptr,str_ptr_next-str_ptr);
			longline[str_ptr_next-str_ptr]='\0';
			cont=1; //read the dico
			/* 2- Search wtarget word */
			if (targetlst) {
				/* if wtargets is not in this sentence, don't read the dico */
				cont=i=0;
				while (i < index_wtarget) {
					/* strict search with strstr */
					if (strstr(longline,wtarget_ptr[i]) != NULL) {
						cont=1; //okay one target found, so read the dico
						l=i;
						break;
					}
					i++;
				}
			}
			
			fseek(fp1,0,SEEK_SET); //read the dico from the beginning
			while(cont) {
				/* Read each line of the dico */
				line[size_line-2]= '\0';
				if (fgets(line,size_line,fp1) == NULL) {
					cont=0; //!!!pb if line>size_line
					break;
				}
				/* skip comment */
				if (line[0] != '#') { 
					if (line[size_line-2] != '\0') {
						ERRPOS
						fprintf(stderr,"pb size_line too small\n");
						count_silent_bug++;
					}
					/* Check the line is a list of lexicons */
					if ((str_ptr1=strstr(line,":/")) !=NULL) {
						/* extract the index */
						if ((str_ptr2=strchr(line,' ')) != NULL) {
							*str_ptr2='\0';
							index=atoi(line);
						}
						/* Extract each lexicon from the dico line 
						 * time costly particularly wordchk preparation */
						while ((str_ptr1=strchr(str_ptr1,'\\')) != NULL) {
							str_ptr1++;
							if ((str_ptr2=strchr(str_ptr1,'/')) != NULL) *str_ptr2='\0';
							else break;
							/* wordchk: /nbla...bla...bla/n */
							strcpy(wordchk,"\n"); //first delimiter
							strcat(wordchk,str_ptr1); //wordchk will be used in the search
							strcat(wordchk,"\n"); //last delimiter
							/* lexicon is in this sentence? (strict search) */
							if ((str_ptr3=strstr(longline,wordchk)) != NULL) {
								val=chartoi(*(str_ptr1-2)); //str_ptr1-2 points le val (1 char)
								switch (classaction[index]) {
									case -2: 
									/* stop propagation */
										multiply=1;
										inverser=1;
										divide=1;
										break;
									case -1: 
									/* inverse the meaning of the opinion-word */
										inverser=-val;
										break;
									case 0:
									/* decrease the opinion-word level */
										divide=val;
										break;
									case 1:	
									/* increase the opinion-word level */
										multiply=val;
										break;
									case 2:	
									/* good opinion */
										cumul+= val*multiply*inverser/divide;
										multiply=1;
										inverser=1;
										divide=1;
										break;
									case 3:	
									/* bad opinion */
										cumul-= val*multiply*inverser/divide;
										multiply=1;
										inverser=1;
										divide=1;
										break;
								}
								if (debug) 
									printf("\nIndex:%i Class:%i Val:%i Cumul:%li Found:%s in:%s\n",
										index,classaction[index],val,cumul,str_ptr1,longline);
							}
							str_ptr1=str_ptr2+1;
						} //end while '\\' (lexicon is done)
					} //end if ":/" (line is done)
				} //end if != '#'
			} //end while cont (dico is done)
			/*** sentence result ***/
			if (cumul) {
				nbsentences++;
				gross_cumul+=cumul;
				/*Extract sentence from ansi7b converted text*/
				fseek(fp2,pos_sentence[line_cnt-1],SEEK_SET); //on the end of the previous sentence
				lg_sentence=pos_sentence[line_cnt]-pos_sentence[line_cnt-1];
				if (lg_sentence > SIZE_SENTENCE) lg_sentence=SIZE_SENTENCE; //cut the sentence if too long
				*sentence='\0'; //perhaps unuseful
				offset=0;
				/*--- read char one by one and filter char ---*/
				cnt_suppress=cnt_space=0;
				while (lg_sentence--) { 
					if ((ch=fgetc(fp2)) == EOF) break;
					/*suppress ctrl chars
					replace '_' with space
					only one space
					suppress repetition some chars such as separators*/
					if ((unsigned char)ch > 31) {
						if (ch == '_') ch=' ';
						if (ch == ' ') cnt_space++;
						else cnt_space=0;
						if (strchr(" -=+|'\"<>,.;:!^#@*",ch) != NULL) cnt_suppress++;
						else cnt_suppress=0;
						if ((cnt_suppress < 3) && (cnt_space < 2)) *(sentence+offset++)=ch;
					} 
					else ch=' '; //ctrl char becomes space (extra-space will be removed after)
				} //end while
				*(sentence+offset)='\0'; //terminate the sentence
				/*Remove space in the end*/
				offset--;
				while (*(sentence+offset) == ' ') {
					*(sentence+offset)='\0';
					offset--;
				}
				/*--- Reformate the sentence a little bit ---*/
				/*Remove space in the beginning*/
				while (*sentence == ' ') strcpy(sentence,sentence+1);
				/* the result! */
				if (l>=0) {
					/* no '\n' */
					strcpy(target,wtarget_ptr[l]);
					target[0]=' ';
					if (strlen(target) >1 && strlen(target) < 40)
						target[strlen(target)-1]='\0';
				}
				else strcpy(target,"All");
				
				if (doemotion == 1)
					printf("Target:%s Opinion:%li for: %s\n",target,cumul,sentence);
				if (doemotion == 2)
				{
					/// this new piece of routine presents sentiments like an abstract
					/// !Need to be tested
					strcat(sentence," "); //add space at the end, check with above can be optimized
					if (linewidth && rec > 0) {
						/*smart line formating avoid to cut words*/
						strcpy(linesmart,clever_print(linewidth,sentence));
						if ((rec & 1) == 1) printf("%s",linesmart);  //in display
						//if ((rec & 2) == 2) fprintf(fp1,"%s",linesmart); //in file
						//fprintf(fp3,"%s",linesmart);  //file abstract
					}
					else {
						/*no line formating*/
						if ((rec & 1) == 1) printf("%s",sentence);  //in display
						//if ((rec & 2) == 2) fprintf(fp1,"%s",str_ptr3); //in file
						//fprintf(fp3,"%s",str_ptr3);  //file abstract
					}
					/// end
				}
				
			} //end if cumul
		} //end if do_sentence (sentence is done)
		str_ptr=str_ptr_next+3; // skip "EOS" and continue to the next sentence
	} //end while "EOS" (text is done)
	printf("\n\n<Opinion level: Cumul:%li and Average:%.1f>\n",gross_cumul,(float)gross_cumul/nbsentences);
	fclose(fp1); 
	/*release memory allocated*/
	free(line);
	for (k=0;k<size_nb_class;k++) free(classname[k]);
	free(classname);
	free(class_sum);
	free(class_diff);     
	free(longline);
	if ( do_free_wtarget ) free(wtarget);
	free(wtargetbis);
	return 0;
}
