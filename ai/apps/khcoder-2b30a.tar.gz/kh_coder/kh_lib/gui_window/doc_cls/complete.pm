package gui_window::doc_cls::complete;
use base qw(gui_window::doc_cls);

1;