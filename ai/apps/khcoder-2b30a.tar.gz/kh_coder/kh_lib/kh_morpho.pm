package kh_morpho;
use kh_morpho::win32;
use kh_morpho::linux;
use kh_project;
use kh_sysconfig;
use kh_dictio;
use strict;

#--------------------#
#   �����ǲ��ϼ¹�   #
#--------------------#

sub run{
	my $class = shift;
	$class .= '::'.$::config_obj->os;
	my %args = @_;
	my $self = {
		t_obj  => $::project_obj,
		target => $::project_obj->file_MorphoIn,
		output => $::project_obj->file_MorphoOut,
		config => $::config_obj,
	};
	bless $self, $class;

	$self->_run;

	return(1);
}


sub target{
	my $self = shift;
	return($self->{target});
}

sub output{
	my $self = shift;
	return($self->{output});
}

sub t_obj{
	my $self = shift;
	return($self->{t_obj});
}

sub config{
	my $self = shift;
	return($self->{config});
}

1;
