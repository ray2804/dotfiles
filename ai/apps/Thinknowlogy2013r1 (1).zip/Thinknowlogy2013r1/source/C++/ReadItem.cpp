/*
 *	Class:			ReadItem
 *	Parent class:	Item
 *	Purpose:		To temporarily store info about the read words of a sentence
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#ifndef READITEM
#define READITEM 1
#include "GrammarItem.cpp"

class ReadItem : private Item
	{
	friend class AdminCleanup;
	friend class AdminContext;
	friend class AdminImperative;
	friend class AdminReadSentence;
	friend class AdminSelection;
	friend class AdminSpecification;
	friend class AdminWrite;
	friend class ReadList;

	// Private loadable variables

	unsigned short wordOrderNr_;
	unsigned short wordParameter_;
	unsigned short wordTypeNr_;
	unsigned short wordTypeLanguageNr_;

	WordItem *readWordItem_;


	protected:
	// Protected constructible variables

	bool isMarkedBySetGrammarParameter;
	bool isUnusedReadItem;
	bool isWordPassingGrammarIntegrityCheck;

	unsigned short grammarParameter;

	GrammarItem *definitionGrammarItem;


	// Protected loadable variables

	char *readString;


	// Constructor

	ReadItem( unsigned short wordOrderNr, unsigned short wordParameter, unsigned short wordTypeNr, unsigned short wordTypeLanguageNr, size_t readStringLength, char *_readString, WordItem *readWordItem, List *myList, WordItem *myWord, CommonVariables *commonVariables )
		{
		initializeItemVariables( NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, "ReadItem", myList, myWord, commonVariables );


		// Private loadable variables

		wordOrderNr_ = wordOrderNr;
		wordParameter_ = wordParameter;
		wordTypeNr_ = wordTypeNr;
		wordTypeLanguageNr_ = wordTypeLanguageNr;

		readWordItem_ = readWordItem;


		// Protected constructible variables

		isMarkedBySetGrammarParameter = false;
		isUnusedReadItem = false;
		isWordPassingGrammarIntegrityCheck = false;

		grammarParameter = NO_GRAMMAR_PARAMETER;

		definitionGrammarItem = NULL;


		// Protected loadable variables

		readString = NULL;

		if( _readString != NULL )
			{
			if( readStringLength < MAX_READ_WRITE_STRING_LENGTH &&
			strlen( _readString ) < MAX_READ_WRITE_STRING_LENGTH )
				{
				if( ( readString = new char[readStringLength + 1] ) != NULL )
					{
					strncpy( readString, _readString, readStringLength );
					readString[readStringLength] = NULL_CHAR;
					}
				else
					startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, NULL, "I failed to create the read string" );
				}
			else
				startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, NULL, "The given read string is too long" );
			}
		}

	~ReadItem()
		{
		if( readString != NULL )
			delete readString;
		}


	// Protected virtual functions

	virtual void showString( bool returnQueryToPosition )
		{
		char statusString[2] = SPACE_STRING;
		statusString[0] = statusChar();

		if( readString != NULL )
			{
			if( commonVariables()->hasFoundQuery )
				strcat( commonVariables()->queryString, ( returnQueryToPosition ? NEW_LINE_STRING : QUERY_SEPARATOR_SPACE_STRING ) );

			if( !isActiveItem() )	// Show status when not active
				strcat( commonVariables()->queryString, statusString );

			commonVariables()->hasFoundQuery = true;
			strcat( commonVariables()->queryString, readString );
			}
		}

	virtual void showWordReferences( bool returnQueryToPosition )
		{
		char *wordString;
		char statusString[2] = SPACE_STRING;
		statusString[0] = statusChar();

		if( readWordItem_ != NULL &&
		( wordString = readWordItem_->wordTypeString( true, NO_ORDER_NR, wordTypeNr_ ) ) != NULL )
			{
			if( commonVariables()->hasFoundQuery )
				strcat( commonVariables()->queryString, ( returnQueryToPosition ? NEW_LINE_STRING : QUERY_SEPARATOR_SPACE_STRING ) );

			if( !isActiveItem() )	// Show status when not active
				strcat( commonVariables()->queryString, statusString );

			commonVariables()->hasFoundQuery = true;
			strcat( commonVariables()->queryString, wordString );
			}
		}

	virtual bool hasFoundParameter( unsigned int queryParameter )
		{
		return ( grammarParameter == queryParameter ||
				wordOrderNr_ == queryParameter ||
				wordParameter_ == queryParameter ||

				( queryParameter == MAX_QUERY_PARAMETER &&

				( grammarParameter > NO_GRAMMAR_PARAMETER ||
				wordOrderNr_ > NO_ORDER_NR ||
				wordParameter_ > NO_WORD_PARAMETER ) ) );
		}

	virtual bool hasFoundReferenceItemById( unsigned int querySentenceNr, unsigned int queryItemNr )
		{
		return ( ( readWordItem_ == NULL ? false :
					( querySentenceNr == NO_SENTENCE_NR ? true : readWordItem_->creationSentenceNr() == querySentenceNr ) &&
					( queryItemNr == NO_ITEM_NR ? true : readWordItem_->itemNr() == queryItemNr ) ) ||

				( definitionGrammarItem == NULL ? false :
					( querySentenceNr == NO_SENTENCE_NR ? true : definitionGrammarItem->creationSentenceNr() == querySentenceNr ) &&
					( queryItemNr == NO_ITEM_NR ? true : definitionGrammarItem->itemNr() == queryItemNr ) ) );
		}

	virtual bool hasFoundWordType( unsigned short queryWordTypeNr )
		{
		return ( wordTypeNr_ == queryWordTypeNr );
		}

	virtual bool isSorted( Item *nextSortItem )
		{
		return ( nextSortItem == NULL ||
				// 1) Descending creationSentenceNr
				creationSentenceNr() > nextSortItem->creationSentenceNr() ||

				// 2) Ascending wordOrderNr_
				( creationSentenceNr() == nextSortItem->creationSentenceNr() &&
				( wordOrderNr_ < ( (ReadItem *)nextSortItem )->wordOrderNr_ ||

				// 3) Descending wordTypeNr_
				( wordOrderNr_ == ( (ReadItem *)nextSortItem )->wordOrderNr_ &&
				wordTypeNr_ > ( (ReadItem *)nextSortItem )->wordTypeNr_ ) ) ) );
		}

	virtual ResultType findMatchingWordReferenceString( char *queryString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "findMatchingWordReferenceString";
		commonVariables()->hasFoundMatchingStrings = false;

		if( readWordItem_ != NULL )
			{
			if( readWordItem_->findMatchingWordReferenceString( queryString ) != RESULT_OK )
				return addErrorInItem( functionNameString, NULL, readString, "I failed to find the word reference for the word reference query" );
			}

		return commonVariables()->result;
		}

	virtual ResultType findWordReference( WordItem *referenceWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "findWordReference";
		commonVariables()->hasFoundWordReference = false;

		if( referenceWordItem != NULL )
			{
			if( readWordItem_ == referenceWordItem )
				commonVariables()->hasFoundWordReference = true;
			}
		else
			return startErrorInItem( functionNameString, NULL, readString, "The given reference word is undefined" );

		return commonVariables()->result;
		}

	virtual char *itemString()
		{
		return readString;
		}

	virtual char *toString( unsigned short queryWordTypeNr )
		{
		char *wordString;
		char *languageNameString = myWord()->grammarLanguageNameString( wordTypeLanguageNr_ );
		char *readWordTypeString = myWord()->wordTypeName( wordTypeNr_ );

		Item::toString( queryWordTypeNr );

		if( isUnusedReadItem )
			{
			strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
			strcat( commonVariables()->queryString, "isUnusedReadItem" );
			}

		if( isWordPassingGrammarIntegrityCheck )
			{
			strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
			strcat( commonVariables()->queryString, "isWordPassingGrammarIntegrityCheck" );
			}

		if( isMarkedBySetGrammarParameter )
			{
			strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
			strcat( commonVariables()->queryString, "isMarkedBySetGrammarParameter" );
			}

		if( wordTypeLanguageNr_ > NO_LANGUAGE_NR )
			{
			if( languageNameString == NULL )
				sprintf( tempString, "%cwordLanguageNr:%u", QUERY_SEPARATOR_CHAR, wordTypeLanguageNr_ );
			else
				sprintf( tempString, "%cwordLanguage:%s", QUERY_SEPARATOR_CHAR, languageNameString );

			strcat( commonVariables()->queryString, tempString );
			}

		if( wordOrderNr_ > NO_ORDER_NR )
			{
			sprintf( tempString, "%cwordOrderNr:%u", QUERY_SEPARATOR_CHAR, wordOrderNr_ );
			strcat( commonVariables()->queryString, tempString );
			}

		if( wordParameter_ > NO_WORD_PARAMETER )
			{
			sprintf( tempString, "%cwordParameter:%u", QUERY_SEPARATOR_CHAR, wordParameter_ );
			strcat( commonVariables()->queryString, tempString );
			}

		if( grammarParameter > NO_GRAMMAR_PARAMETER )
			{
			sprintf( tempString, "%cgrammarParameter:%u", QUERY_SEPARATOR_CHAR, grammarParameter );
			strcat( commonVariables()->queryString, tempString );
			}

		if( readString != NULL )
			{
			sprintf( tempString, "%creadString:%c%s%c", QUERY_SEPARATOR_CHAR, QUERY_STRING_START_CHAR, readString, QUERY_STRING_END_CHAR );
			strcat( commonVariables()->queryString, tempString );
			}

		if( readWordTypeString == NULL )
			sprintf( tempString, "%creadWordType:%c%u", QUERY_SEPARATOR_CHAR, QUERY_WORD_TYPE_CHAR, wordTypeNr_ );
		else
			sprintf( tempString, "%creadWordType:%s%c%u", QUERY_SEPARATOR_CHAR, readWordTypeString, QUERY_WORD_TYPE_CHAR, wordTypeNr_ );

		strcat( commonVariables()->queryString, tempString );

		if( readWordItem_ != NULL )
			{
			sprintf( tempString, "%creadWord%c%u%c%u%c", QUERY_SEPARATOR_CHAR, QUERY_REF_ITEM_START_CHAR, readWordItem_->creationSentenceNr(), QUERY_SEPARATOR_CHAR, readWordItem_->itemNr(), QUERY_REF_ITEM_END_CHAR );
			strcat( commonVariables()->queryString, tempString );

			if( ( wordString = readWordItem_->wordTypeString( true, NO_ORDER_NR, wordTypeNr_ ) ) != NULL )
				{
				sprintf( tempString, "%c%s%c", QUERY_WORD_REFERENCE_START_CHAR, wordString, QUERY_WORD_REFERENCE_END_CHAR );
				strcat( commonVariables()->queryString, tempString );
				}
			}

		if( definitionGrammarItem != NULL )
			{
			sprintf( tempString, "%cdefinitionGrammarItem%c%u%c%u%c", QUERY_SEPARATOR_CHAR, QUERY_REF_ITEM_START_CHAR, definitionGrammarItem->creationSentenceNr(), QUERY_SEPARATOR_CHAR, definitionGrammarItem->itemNr(), QUERY_REF_ITEM_END_CHAR );
			strcat( commonVariables()->queryString, tempString );
			}

		return commonVariables()->queryString;
		}


	// Protected functions

	bool isReadWordSymbol()
		{
		return ( wordTypeNr_ == WORD_TYPE_SYMBOL );
		}

	bool isReadWordNumeral()
		{
		return ( wordTypeNr_ == WORD_TYPE_NUMERAL );
		}

	bool isReadWordAdjective()
		{
		return ( wordTypeNr_ == WORD_TYPE_ADJECTIVE );
		}

	bool isReadWordArticle()
		{
		return ( wordTypeNr_ == WORD_TYPE_ARTICLE );
		}

	bool isReadWordNoun()
		{
		return ( wordTypeNr_ == WORD_TYPE_NOUN_SINGULAR ||
				wordTypeNr_ == WORD_TYPE_NOUN_PLURAL );
		}

	bool isReadWordSingularNoun()
		{
		return ( wordTypeNr_ == WORD_TYPE_NOUN_SINGULAR );
		}

	bool isReadWordPluralNoun()
		{
		return ( wordTypeNr_ == WORD_TYPE_NOUN_PLURAL );
		}

	bool isReadWordDeterminerOrPronoun()
		{
		return ( wordTypeNr_ == WORD_TYPE_PERSONAL_PRONOUN_SINGULAR_SUBJECTIVE ||
				wordTypeNr_ == WORD_TYPE_PERSONAL_PRONOUN_SINGULAR_OBJECTIVE ||

				wordTypeNr_ == WORD_TYPE_POSSESSIVE_DETERMINER_SINGULAR ||
				wordTypeNr_ == WORD_TYPE_POSSESSIVE_PRONOUN_SINGULAR ||

				wordTypeNr_ == WORD_TYPE_PERSONAL_PRONOUN_PLURAL_SUBJECTIVE ||
				wordTypeNr_ == WORD_TYPE_PERSONAL_PRONOUN_PLURAL_OBJECTIVE ||

				wordTypeNr_ == WORD_TYPE_POSSESSIVE_DETERMINER_PLURAL ||
				wordTypeNr_ == WORD_TYPE_POSSESSIVE_PRONOUN_PLURAL );
		}

	bool isReadWordPossessiveDeterminer()
		{
		return ( wordTypeNr_ == WORD_TYPE_POSSESSIVE_DETERMINER_SINGULAR ||
				wordTypeNr_ == WORD_TYPE_POSSESSIVE_DETERMINER_PLURAL );
		}

	bool isReadWordVerb()
		{
		return ( wordTypeNr_ == WORD_TYPE_VERB_SINGULAR ||
				wordTypeNr_ == WORD_TYPE_VERB_PLURAL );
		}

	bool isReadWordText()
		{
		return ( wordTypeNr_ == WORD_TYPE_TEXT );
		}

	bool isAdjectiveAssigned()
		{
		return ( wordParameter_ == WORD_PARAMETER_ADJECTIVE_ASSIGNED );
		}

	bool isAdjectiveAssignedOrClear()
		{
		return ( wordParameter_ == WORD_PARAMETER_ADJECTIVE_CLEAR ||
				wordParameter_ == WORD_PARAMETER_ADJECTIVE_ASSIGNED );
		}

	bool isAdjectiveCalledOrNamed()
		{
		return ( wordParameter_ == WORD_PARAMETER_ADJECTIVE_CALLED_OR_NAMED );
		}

	bool isAdjectivePrevious()
		{
		return ( wordParameter_ == WORD_PARAMETER_ADJECTIVE_PREVIOUS_1 ||
				wordParameter_ == WORD_PARAMETER_ADJECTIVE_PREVIOUS_2 );
		}

	bool isPreposition()
		{
		return ( wordParameter_ == WORD_PARAMETER_PREPOSITION_ABOUT ||
				wordParameter_ == WORD_PARAMETER_PREPOSITION_FOR ||
				wordParameter_ == WORD_PARAMETER_PREPOSITION_FROM ||
				wordParameter_ == WORD_PARAMETER_PREPOSITION_IN ||
				wordParameter_ == WORD_PARAMETER_PREPOSITION_OF ||
				wordParameter_ == WORD_PARAMETER_PREPOSITION_TO );
		}

	bool isVirtualListPreposition()
		{
		return ( wordParameter_ == WORD_PARAMETER_PREPOSITION_FROM ||
				wordParameter_ == WORD_PARAMETER_PREPOSITION_OF ||
				wordParameter_ == WORD_PARAMETER_PREPOSITION_TO );
		}

	bool isPrepositionIn()
		{
		return ( wordParameter_ == WORD_PARAMETER_PREPOSITION_IN );
		}

	bool isNegative()
		{
		return ( wordParameter_ == WORD_PARAMETER_ADJECTIVE_NO ||
				wordParameter_ == WORD_PARAMETER_ADVERB_NOT );
//				wordParameter_ == WORD_PARAMETER_ADVERB_DO_NOT );
		}

	bool isNounJustificationReport()
		{
		return ( wordParameter_ == WORD_PARAMETER_NOUN_JUSTIFICATION_REPORT );
		}

	bool isNounValue()
		{
		return ( wordParameter_ == WORD_PARAMETER_NOUN_VALUE );
		}

	bool isNounFile()
		{
		return ( wordParameter_ == WORD_PARAMETER_NOUN_FILE );
		}

	bool isSeparator()
		{
		return ( wordParameter_ == WORD_PARAMETER_SYMBOL_COMMA ||
				wordParameter_ == WORD_PARAMETER_SYMBOL_COLON ||
				wordParameter_ == WORD_PARAMETER_SYMBOL_EXCLAMATION_MARK ||
				wordParameter_ == WORD_PARAMETER_SYMBOL_QUESTION_MARK );
		}

	bool isUserDefined()
		{
		return ( wordParameter_ == NO_WORD_PARAMETER );
		}

	bool isSelection()
		{
		return ( grammarParameter == GRAMMAR_SELECTION );
		}

	bool isImperative()
		{
		return ( grammarParameter == GRAMMAR_IMPERATIVE );
		}

	bool isGeneralizationWord()
		{
		return ( grammarParameter == GRAMMAR_GENERALIZATION_WORD );
		}

	bool isSpecificationWord()
		{
		return ( grammarParameter == GRAMMAR_SPECIFICATION_WORD );
		}

	bool isRelationWord()
		{
		return ( wordTypeNr_ != WORD_TYPE_ARTICLE &&	// To avoid triggering on the article before a propername preceded-by-defined-article
				grammarParameter == GRAMMAR_RELATION_WORD );
		}

	bool isGeneralizationPart()
		{
		return ( grammarParameter == GRAMMAR_GENERALIZATION_PART ||
				grammarParameter == GRAMMAR_GENERALIZATION_ASSIGNMENT );
		}

	bool isGeneralizationSpecification()
		{
		return ( grammarParameter == GRAMMAR_GENERALIZATION_SPECIFICATION );
		}

	bool isLinkedGeneralizationConjunction()
		{
		return ( grammarParameter == GRAMMAR_LINKED_GENERALIZATION_CONJUNCTION );
		}

	bool isSentenceConjunction()
		{
		return ( grammarParameter == GRAMMAR_SENTENCE_CONJUNCTION );
		}

	bool isVerb()
		{
		return ( grammarParameter == GRAMMAR_VERB );
		}

	bool isQuestionVerb()
		{
		return ( grammarParameter == GRAMMAR_QUESTION_VERB );
		}

	bool hasFoundRelationWordInThisList( WordItem *relationWordItem )
		{
		ReadItem *searchItem = this;

		if( relationWordItem != NULL )
			{
			while( searchItem != NULL )
				{
				if( searchItem->isRelationWord() &&
				searchItem->readWordItem() == relationWordItem )
					return true;

				searchItem = searchItem->nextReadItem();
				}
			}

		return false;
		}

	unsigned short wordOrderNr()
		{
		return wordOrderNr_;
		}

	unsigned short wordParameter()
		{
		return wordParameter_;
		}

	unsigned short wordTypeNr()
		{
		return wordTypeNr_;
		}

	unsigned short wordTypeLanguageNr()
		{
		return wordTypeLanguageNr_;
		}

	char *readWordTypeString()
		{
		if( readWordItem_ != NULL )
			return readWordItem_->activeWordTypeString( wordTypeNr_ );

		return NULL;
		}

	ReadItem *nextReadItem()
		{
		return (ReadItem *)nextItem;
		}

	ReadItem *getFirstRelationWordReadItem()
		{
		ReadItem *searchItem = this;

		while( searchItem != NULL )
			{
			if( searchItem->isRelationWord() )
				return searchItem;

			searchItem = searchItem->nextReadItem();
			}

		return NULL;
		}

	WordItem *readWordItem()
		{
		return readWordItem_;
		}

	WordTypeItem *activeReadWordTypeItem()
		{
		return ( readWordItem_ == NULL ? NULL : readWordItem_->activeWordTypeItem( false, wordTypeNr_ ) );
		}
	};
#endif

/*************************************************************************
 *
 *	"The godly will see these things and be glad,
 *	while the wicked are struck in silent." (Psalm 107:42)
 *
 *************************************************************************/
