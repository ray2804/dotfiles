/*
 *	Class:			JustificationItem
 *	Parent class:	Item
 *	Purpose:		To store info need to write the justification reports
 *					for the self-generated knowledge
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "SpecificationItem.cpp"

	// Private functions

	bool JustificationItem::isSameJustificationType( JustificationItem *referenceJustificationItem )
		{
		return ( referenceJustificationItem != NULL &&
				orderNr == referenceJustificationItem->orderNr &&
				justificationTypeNr_ == referenceJustificationItem->justificationTypeNr() );
		}


	// Constructor

	JustificationItem::JustificationItem( unsigned short justificationTypeNr, unsigned short _orderNr, unsigned int originalSentenceNr, JustificationItem *attachedJustificationItem, SpecificationItem *definitionSpecificationItem, SpecificationItem *anotherDefinitionSpecificationItem, SpecificationItem *specificSpecificationItem, List *myList, WordItem *myWord, CommonVariables *commonVariables )
		{
		initializeItemVariables( originalSentenceNr, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, "JustificationItem", myList, myWord, commonVariables );

		// Private loadable variables

		justificationTypeNr_ = justificationTypeNr;

		attachedJustificationItem_ = attachedJustificationItem;

		definitionSpecificationItem_ = definitionSpecificationItem;
		anotherDefinitionSpecificationItem_ = anotherDefinitionSpecificationItem;
		specificSpecificationItem_ = specificSpecificationItem;

		// Protected constructible variables

		orderNr = _orderNr;

		replacingJustificationItem = NULL;
		}


	// Protected virtual functions

	bool JustificationItem::hasFoundReferenceItemById( unsigned int querySentenceNr, unsigned int queryItemNr )
		{
		return ( ( attachedJustificationItem_ == NULL ? false :
					( querySentenceNr == NO_SENTENCE_NR ? true : attachedJustificationItem_->creationSentenceNr() == querySentenceNr ) &&
					( queryItemNr == NO_ITEM_NR ? true : attachedJustificationItem_->itemNr() == queryItemNr ) ) ||

				( definitionSpecificationItem_ == NULL ? false :
					( querySentenceNr == NO_SENTENCE_NR ? true : definitionSpecificationItem_->creationSentenceNr() == querySentenceNr ) &&
					( queryItemNr == NO_ITEM_NR ? true : definitionSpecificationItem_->itemNr() == queryItemNr ) ) ||

				( anotherDefinitionSpecificationItem_ == NULL ? false :
					( querySentenceNr == NO_SENTENCE_NR ? true : anotherDefinitionSpecificationItem_->creationSentenceNr() == querySentenceNr ) &&
					( queryItemNr == NO_ITEM_NR ? true : anotherDefinitionSpecificationItem_->itemNr() == queryItemNr ) ) ||

				( specificSpecificationItem_ == NULL ? false :
					( querySentenceNr == NO_SENTENCE_NR ? true : specificSpecificationItem_->creationSentenceNr() == querySentenceNr ) &&
					( queryItemNr == NO_ITEM_NR ? true : specificSpecificationItem_->itemNr() == queryItemNr ) ) ||

				( replacingJustificationItem == NULL ? false :
					( querySentenceNr == NO_SENTENCE_NR ? true : replacingJustificationItem->creationSentenceNr() == querySentenceNr ) &&
					( queryItemNr == NO_ITEM_NR ? true : replacingJustificationItem->itemNr() == queryItemNr ) ) );
		}

	ResultType JustificationItem::checkForUsage()
		{
		return myWord()->checkJustificationForUsageInWord( this );
		}

	char *JustificationItem::toString( unsigned short queryWordTypeNr )
		{
		Item::toString( queryWordTypeNr );

		switch( justificationTypeNr_ )
			{
			case JUSTIFICATION_TYPE_GENERALIZATION_ASSUMPTION_BY_GENERALIZATION:
				strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
				strcat( commonVariables()->queryString, "isGeneralizationAssumptionByGeneralization" );
				break;

			case JUSTIFICATION_TYPE_GENERALIZATION_ASSUMPTION_BY_SPECIFICATION:
				strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
				strcat( commonVariables()->queryString, "isGeneralizationAssumptionBySpecification" );
				break;

			case JUSTIFICATION_TYPE_OPPOSITE_POSSESSIVE_CONDITIONAL_SPECIFICATION_ASSUMPTION:
				strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
				strcat( commonVariables()->queryString, "isOppositePossessiveConditionalSpecificationAssumption" );
				break;

			case JUSTIFICATION_TYPE_BACK_FIRED_POSSESSIVE_CONDITIONAL_SPECIFICATION_ASSUMPTION:
				strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
				strcat( commonVariables()->queryString, "isBackFiredPossessiveConditionalSpecificationAssumption" );
				break;

			case JUSTIFICATION_TYPE_SPECIFICATION_SUBSTITUTION_ASSUMPTION:
				strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
				strcat( commonVariables()->queryString, "isSpecificationSubstitutionAssumption" );
				break;

			case JUSTIFICATION_TYPE_EXCLUSIVE_SPECIFICATION_SUBSTITUTION_ASSUMPTION:
				strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
				strcat( commonVariables()->queryString, "isExclusiveSpecificationSubstitutionAssumption" );
				break;

			case JUSTIFICATION_TYPE_SUGGESTIVE_QUESTION_ASSUMPTION:
				strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
				strcat( commonVariables()->queryString, "isSuggestiveQuestionAssumption" );
				break;

			case JUSTIFICATION_TYPE_SPECIFICATION_GENERALIZATION_SUBSTITUTION_CONCLUSION:
				strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
				strcat( commonVariables()->queryString, "isSpecificationGeneralizationConclusion" );
				break;

			case JUSTIFICATION_TYPE_SPECIFICATION_SUBSTITUTION_CONCLUSION:
				strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
				strcat( commonVariables()->queryString, "isSpecificationSubstitutionConclusion" );
				break;

			case JUSTIFICATION_TYPE_POSSESSIVE_REVERSIBLE_CONCLUSION:
				strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
				strcat( commonVariables()->queryString, "isPossessiveReversibleConclusion" );
				break;

			case JUSTIFICATION_TYPE_SPECIFICATION_SUBSTITUTION_QUESTION:
				strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
				strcat( commonVariables()->queryString, "isSpecificationSubstitutionQuestion" );
				break;

			default:
				sprintf( tempString, "%cjustificationType:%u", QUERY_SEPARATOR_CHAR, justificationTypeNr_ );
				strcat( commonVariables()->queryString, tempString );
			}

		sprintf( tempString, "%corderNr:%u", QUERY_SEPARATOR_CHAR, orderNr );
		strcat( commonVariables()->queryString, tempString );

		if( definitionSpecificationItem_ != NULL )
			{
			sprintf( tempString, "%cdefinitionSpecificationItem%c%u%c%u%c", QUERY_SEPARATOR_CHAR, QUERY_REF_ITEM_START_CHAR, definitionSpecificationItem_->creationSentenceNr(), QUERY_SEPARATOR_CHAR, definitionSpecificationItem_->itemNr(), QUERY_REF_ITEM_END_CHAR );
			strcat( commonVariables()->queryString, tempString );
			}

		if( anotherDefinitionSpecificationItem_ != NULL )
			{
			sprintf( tempString, "%canotherDefinitionSpecificationItem%c%u%c%u%c", QUERY_SEPARATOR_CHAR, QUERY_REF_ITEM_START_CHAR, anotherDefinitionSpecificationItem_->creationSentenceNr(), QUERY_SEPARATOR_CHAR, anotherDefinitionSpecificationItem_->itemNr(), QUERY_REF_ITEM_END_CHAR );
			strcat( commonVariables()->queryString, tempString );
			}

		if( specificSpecificationItem_ != NULL )
			{
			sprintf( tempString, "%cspecificSpecificationItem%c%u%c%u%c", QUERY_SEPARATOR_CHAR, QUERY_REF_ITEM_START_CHAR, specificSpecificationItem_->creationSentenceNr(), QUERY_SEPARATOR_CHAR, specificSpecificationItem_->itemNr(), QUERY_REF_ITEM_END_CHAR );
			strcat( commonVariables()->queryString, tempString );
			}

		if( attachedJustificationItem_ != NULL )
			{
			sprintf( tempString, "%cattachedJustificationItem%c%u%c%u%c", QUERY_SEPARATOR_CHAR, QUERY_REF_ITEM_START_CHAR, attachedJustificationItem_->creationSentenceNr(), QUERY_SEPARATOR_CHAR, attachedJustificationItem_->itemNr(), QUERY_REF_ITEM_END_CHAR );
			strcat( commonVariables()->queryString, tempString );
			}

		if( replacingJustificationItem != NULL )
			{
			sprintf( tempString, "%creplacingJustificationItem%c%u%c%u%c", QUERY_SEPARATOR_CHAR, QUERY_REF_ITEM_START_CHAR, replacingJustificationItem->creationSentenceNr(), QUERY_SEPARATOR_CHAR, replacingJustificationItem->itemNr(), QUERY_REF_ITEM_END_CHAR );
			strcat( commonVariables()->queryString, tempString );
			}

		return commonVariables()->queryString;
		}


	// Protected functions

	bool JustificationItem::hasDefinitionSpecification()
		{
		return ( definitionSpecificationItem_ != NULL );
		}

	bool JustificationItem::hasSpecificSpecification()
		{
		return ( specificSpecificationItem_ != NULL );
		}

	bool JustificationItem::hasNewInformation()
		{
		JustificationItem *searchItem = this;

		while( searchItem != NULL )
			{
			if( searchItem->hasCurrentActiveSentenceNr() )
				return true;

			searchItem = searchItem->attachedJustificationItem();
			}

		return false;

		// Recursive alternative:
/*		return ( hasCurrentActiveSentenceNr() ||

				( attachedJustificationItem_ != NULL &&
				attachedJustificationItem_->hasNewInformation() ) );
*/		}

	bool JustificationItem::hasOnlyExclusiveSpecificationSubstitutionAssumptionsWithoutDefinition()
		{
		JustificationItem *searchItem = this;

		while( searchItem != NULL )
			{
			if( searchItem->hasDefinitionSpecification() ||
			searchItem->justificationTypeNr() != JUSTIFICATION_TYPE_EXCLUSIVE_SPECIFICATION_SUBSTITUTION_ASSUMPTION )
				return false;

			searchItem = searchItem->attachedJustificationItem();
			}

		return true;
		}

	bool JustificationItem::isAssumption()
		{
		return ( justificationTypeNr_ == JUSTIFICATION_TYPE_GENERALIZATION_ASSUMPTION_BY_GENERALIZATION ||
				justificationTypeNr_ == JUSTIFICATION_TYPE_GENERALIZATION_ASSUMPTION_BY_SPECIFICATION ||
				justificationTypeNr_ == JUSTIFICATION_TYPE_OPPOSITE_POSSESSIVE_CONDITIONAL_SPECIFICATION_ASSUMPTION ||
				justificationTypeNr_ == JUSTIFICATION_TYPE_BACK_FIRED_POSSESSIVE_CONDITIONAL_SPECIFICATION_ASSUMPTION ||
				justificationTypeNr_ == JUSTIFICATION_TYPE_SPECIFICATION_SUBSTITUTION_ASSUMPTION ||
				justificationTypeNr_ == JUSTIFICATION_TYPE_EXCLUSIVE_SPECIFICATION_SUBSTITUTION_ASSUMPTION ||
				justificationTypeNr_ == JUSTIFICATION_TYPE_SUGGESTIVE_QUESTION_ASSUMPTION );
		}
/*
	bool JustificationItem::isConclusion()
		{
		return ( justificationTypeNr_ == JUSTIFICATION_TYPE_SPECIFICATION_GENERALIZATION_SUBSTITUTION_CONCLUSION ||
				justificationTypeNr_ == JUSTIFICATION_TYPE_SPECIFICATION_SUBSTITUTION_CONCLUSION ||
				justificationTypeNr_ == JUSTIFICATION_TYPE_POSSESSIVE_REVERSIBLE_CONCLUSION ||
				justificationTypeNr_ == JUSTIFICATION_TYPE_SPECIFICATION_SUBSTITUTION_QUESTION );
		}
*/
	bool JustificationItem::isQuestion()
		{
		return ( justificationTypeNr_ == JUSTIFICATION_TYPE_SPECIFICATION_SUBSTITUTION_QUESTION );
		}

	bool JustificationItem::isOppositePossessiveConditionalSpecificationAssumption()
		{
		return ( justificationTypeNr_ == JUSTIFICATION_TYPE_OPPOSITE_POSSESSIVE_CONDITIONAL_SPECIFICATION_ASSUMPTION );
		}

	bool JustificationItem::isPossessiveReversibleConclusion()
		{
		return ( justificationTypeNr_ == JUSTIFICATION_TYPE_POSSESSIVE_REVERSIBLE_CONCLUSION );
		}

	unsigned short JustificationItem::assumptionGrade()
		{
		switch( justificationTypeNr_ )
			{
			case JUSTIFICATION_TYPE_BACK_FIRED_POSSESSIVE_CONDITIONAL_SPECIFICATION_ASSUMPTION:
			case JUSTIFICATION_TYPE_SPECIFICATION_SUBSTITUTION_ASSUMPTION:
			case JUSTIFICATION_TYPE_SPECIFICATION_GENERALIZATION_SUBSTITUTION_CONCLUSION:
			case JUSTIFICATION_TYPE_SPECIFICATION_SUBSTITUTION_CONCLUSION:
			case JUSTIFICATION_TYPE_POSSESSIVE_REVERSIBLE_CONCLUSION:
				return 0;

			case JUSTIFICATION_TYPE_SUGGESTIVE_QUESTION_ASSUMPTION:
				return 2;

			default:
				return 1;
			}
		}

	unsigned short JustificationItem::justificationTypeNr()
		{
		return justificationTypeNr_;
		}

	unsigned int JustificationItem::nJustificationContextRelations( unsigned int relationContextNr, unsigned int nSpecificationRelationWords )
		{
		if( relationContextNr > NO_CONTEXT_NR )
			{
			if( specificSpecificationItem_ != NULL &&
			specificSpecificationItem_->hasRelationContext() &&
			myWord()->isContextSimilarInAllWords( specificSpecificationItem_->relationContextNr(), relationContextNr ) )
				return nSpecificationRelationWords;

			return 1;
			}

		return 0;
		}

	ResultType JustificationItem::attachJustificationItem( JustificationItem *attachedJustificationItem, SpecificationItem *mySpecificationItem )
		{
		bool isMySpecification = false;
		JustificationItem *searchItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "attachJustificationItem";

		if( attachedJustificationItem != NULL )
			{
			if( attachedJustificationItem != this )
				{
				if( mySpecificationItem != NULL )
					{
					if( hasCurrentCreationSentenceNr() )
						{
						if( attachedJustificationItem->isActiveItem() )
							{
							if( attachedJustificationItem_ == NULL )
								{
								if( ( searchItem = mySpecificationItem->specificationJustificationItem() ) != NULL )
									{
									while( searchItem != NULL )
										{
										if( searchItem == this )
											isMySpecification = true;

										if( searchItem == attachedJustificationItem )
											return startErrorInItem( functionNameString, NULL, NULL, "The given attached justification item is already one of the attached justification items of my specification item" );

										searchItem = searchItem->attachedJustificationItem();
										}

									if( isMySpecification )
										attachedJustificationItem_ = attachedJustificationItem;		// Add attached justification item
									else
										return startErrorInItem( functionNameString, NULL, NULL, "The given my specification item isn't my specification item" );
									}
								else
									return startErrorInItem( functionNameString, NULL, NULL, "The given my specification item has no specification justification item" );
								}
							else
								return startErrorInItem( functionNameString, NULL, NULL, "I already have an attached justification item" );
							}
						else
							return startErrorInItem( functionNameString, NULL, NULL, "The given attached justification item isn't active" );
						}
					else
						return startErrorInItem( functionNameString, NULL, NULL, "It isn't allowed to change an older item afterwards" );
					}
				else
					return startErrorInItem( functionNameString, NULL, NULL, "The given my specification item is undefined" );
				}
			else
				return startErrorInItem( functionNameString, NULL, NULL, "The given attached justification item is the same justification item as me" );
			}
		else
			return startErrorInItem( functionNameString, NULL, NULL, "The given attached justification item is undefined" );

		return commonVariables()->result;
		}

	ResultType JustificationItem::changeAttachedJustificationItem( JustificationItem *replacingAttachedJustificationItem )
		{
		bool isExistingJustification = false;
		JustificationItem *searchItem = this;
		char functionNameString[FUNCTION_NAME_LENGTH] = "changeAttachedJustificationItem";

		if( replacingAttachedJustificationItem != NULL )
			{
			if( replacingAttachedJustificationItem->isActiveItem() )
				{
				if( hasCurrentCreationSentenceNr() )
					{
					while( searchItem != NULL &&
					!isExistingJustification )
						{
						// Check me and my attached justifications against the replacing justification to avoid loops
						if( searchItem == replacingAttachedJustificationItem )
							isExistingJustification = true;
						else
							searchItem = searchItem->attachedJustificationItem();
						}

					searchItem = replacingAttachedJustificationItem;

					while( searchItem != NULL &&
					!isExistingJustification )
						{
						// Check replacing justification against this justification to avoid loops
						if( searchItem == this )
							isExistingJustification = true;
						else
							searchItem = searchItem->attachedJustificationItem();
						}

					attachedJustificationItem_ = ( isExistingJustification ? NULL : replacingAttachedJustificationItem );
					}
				else
					return startErrorInItem( functionNameString, NULL, NULL, "It isn't allowed to change an older item afterwards" );
				}
			else
				return startErrorInItem( functionNameString, NULL, NULL, "The given replacing attached justification item isn't active" );
			}
		else
			return startErrorInItem( functionNameString, NULL, NULL, "The given replacing attached justification item is undefined" );

		return commonVariables()->result;
		}

	ResultType JustificationItem::changeDefinitionSpecificationItem( SpecificationItem *replacingSpecificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "changeDefinitionSpecificationItem";
		if( replacingSpecificationItem != NULL )
			{
			if( replacingSpecificationItem->replacingSpecificationItem == NULL )
				{
				if( hasCurrentCreationSentenceNr() )
					definitionSpecificationItem_ = replacingSpecificationItem;
				else
					return startErrorInItem( functionNameString, NULL, NULL, "It isn't allowed to change an older item afterwards" );
				}
			else
				return startErrorInItem( functionNameString, NULL, NULL, "The given replacing specification item has a replacing specification item" );
			}
		else
			return startErrorInItem( functionNameString, NULL, NULL, "The given replacing specification item is undefined" );

		return commonVariables()->result;
		}

	ResultType JustificationItem::changeAnotherDefinitionSpecificationItem( SpecificationItem *replacingSpecificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "changeAnotherDefinitionSpecificationItem";
		if( replacingSpecificationItem != NULL )
			{
			if( replacingSpecificationItem->replacingSpecificationItem == NULL )
				{
				if( hasCurrentCreationSentenceNr() )
					anotherDefinitionSpecificationItem_ = replacingSpecificationItem;
				else
					return startErrorInItem( functionNameString, NULL, NULL, "It isn't allowed to change an older item afterwards" );
				}
			else
				return startErrorInItem( functionNameString, NULL, NULL, "The given replacing specification item has a replacing specification item" );
			}
		else
			return startErrorInItem( functionNameString, NULL, NULL, "The given replacing specification item is undefined" );

		return commonVariables()->result;
		}

	ResultType JustificationItem::changeSpecificSpecificationItem( SpecificationItem *replacingSpecificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "changeSpecificSpecificationItem";
		if( replacingSpecificationItem != NULL )
			{
			if( replacingSpecificationItem->replacingSpecificationItem == NULL )
				{
				if( hasCurrentCreationSentenceNr() )
					specificSpecificationItem_ = replacingSpecificationItem;
				else
					return startErrorInItem( functionNameString, NULL, NULL, "It isn't allowed to change an older item afterwards" );
				}
			else
				return startErrorInItem( functionNameString, NULL, NULL, "The given replacing specification item has a replacing specification item" );
			}
		else
			return startErrorInItem( functionNameString, NULL, NULL, "The given replacing specification item is undefined" );

		return commonVariables()->result;
		}

	SpecificationResultType JustificationItem::getCombinedAssumptionLevel()
		{
		SpecificationResultType specificationResult;
		unsigned int combinedAssumptionLevel = NO_ASSUMPTION_LEVEL;
		char functionNameString[FUNCTION_NAME_LENGTH] = "getCombinedAssumptionLevel";

		if( definitionSpecificationItem_ != NULL &&
		( specificationResult = definitionSpecificationItem_->getAssumptionLevel() ).result == RESULT_OK )
			combinedAssumptionLevel = specificationResult.assumptionLevel;

		if( commonVariables()->result == RESULT_OK &&
		anotherDefinitionSpecificationItem_ != NULL &&
		( specificationResult = anotherDefinitionSpecificationItem_->getAssumptionLevel() ).result == RESULT_OK )
			combinedAssumptionLevel += specificationResult.assumptionLevel;

		if( commonVariables()->result == RESULT_OK &&
		specificSpecificationItem_ != NULL &&
		( specificationResult = specificSpecificationItem_->getAssumptionLevel() ).result == RESULT_OK )
			combinedAssumptionLevel += specificationResult.assumptionLevel;

		if( combinedAssumptionLevel < MAX_LEVEL )
			specificationResult.combinedAssumptionLevel = (unsigned short)combinedAssumptionLevel;
		else
			specificationResult.result = startSystemErrorInItem( functionNameString, NULL, NULL, "Assumption level overflow" );

		return specificationResult;
		}

	JustificationItem *JustificationItem::attachedJustificationItem()
		{
		return attachedJustificationItem_;
		}

	JustificationItem *JustificationItem::predecessorOfOldAttachedJustificationItem( JustificationItem *oldJustificationItem )
		{
		JustificationItem *searchItem = this;

		while( searchItem != NULL )
			{
			if( searchItem->attachedJustificationItem() == oldJustificationItem )
				return searchItem;

			searchItem = searchItem->attachedJustificationItem();
			}

		return NULL;

		// Recursive alternative:
		// return ( attachedJustificationItem_ == NULL ? NULL : attachedJustificationItem_ == oldJustificationItem ? this : attachedJustificationItem_->predecessorOfOldAttachedJustificationItem( oldJustificationItem ) );
		}

	JustificationItem *JustificationItem::nextJustificationItem()
		{
		return (JustificationItem *)nextItem;
		}

	JustificationItem *JustificationItem::nextJustificationItemWithSameTypeAndOrderNr()
		{
		JustificationItem *searchItem = attachedJustificationItem_;

		while( searchItem != NULL )
			{
			if( isSameJustificationType( searchItem ) )
				return searchItem;

			searchItem = searchItem->attachedJustificationItem();
			}

		return NULL;
		}

	JustificationItem *JustificationItem::nextJustificationItemWithDifferentTypeOrOrderNr( JustificationItem *firstJustificationItem )
		{
		JustificationItem *usedTypeJustificationItem;
		JustificationItem *nextTypeJustificationItem = attachedJustificationItem_;

		if( firstJustificationItem != NULL )
			{
			do	{
				// Find next occurrence with different type
				while( nextTypeJustificationItem != NULL &&
				isSameJustificationType( nextTypeJustificationItem ) )
					nextTypeJustificationItem = nextTypeJustificationItem->attachedJustificationItem();

				if( nextTypeJustificationItem != NULL )
					{
					// Check if different type is already used
					usedTypeJustificationItem = firstJustificationItem;

					while( usedTypeJustificationItem != NULL &&
					!usedTypeJustificationItem->isSameJustificationType( nextTypeJustificationItem ) )
						usedTypeJustificationItem = usedTypeJustificationItem->attachedJustificationItem();

					if( usedTypeJustificationItem == nextTypeJustificationItem )
						return nextTypeJustificationItem;
					}
				}
			while( nextTypeJustificationItem != NULL &&
			( nextTypeJustificationItem = nextTypeJustificationItem->attachedJustificationItem() ) != NULL );
			}

		return NULL;
		}

	JustificationItem *JustificationItem::definitionSpecificationWithoutRelationContextJustificationItem( SpecificationItem *definitionSpecificationItem, SpecificationItem *specificSpecificationItem )
		{
		if( definitionSpecificationItem != NULL )
			{
			if( definitionSpecificationItem_ != NULL &&
			!definitionSpecificationItem_->hasRelationContext() &&
			specificSpecificationItem_ == specificSpecificationItem &&
			definitionSpecificationItem_->specificationWordItem() == definitionSpecificationItem->specificationWordItem() )
				return this;

			if( attachedJustificationItem_ != NULL )
				return attachedJustificationItem_->definitionSpecificationWithoutRelationContextJustificationItem( definitionSpecificationItem, specificSpecificationItem );
			}

		return NULL;
		}

	JustificationItem *JustificationItem::foundSpecificSpecificationQuestion()
		{
		if( specificSpecificationItem_ != NULL &&
		specificSpecificationItem_->isQuestion() )
			return this;

		if( attachedJustificationItem_ != NULL )
			return attachedJustificationItem_->foundSpecificSpecificationQuestion();

		return NULL;
		}

	JustificationItem *JustificationItem::selfGeneratedSpecificSpecificationJustificationItem( SpecificationItem *definitionSpecificationItem, SpecificationItem *specificSpecificationItem )
		{
		if( specificSpecificationItem != NULL )
			{
			if( definitionSpecificationItem_ == definitionSpecificationItem &&
			specificSpecificationItem_->isSelfGenerated() &&
			specificSpecificationItem_->specificationWordItem() == specificSpecificationItem->specificationWordItem() )
				return this;

			if( attachedJustificationItem_ != NULL )
				return attachedJustificationItem_->selfGeneratedSpecificSpecificationJustificationItem( definitionSpecificationItem, specificSpecificationItem );
			}

		return NULL;
		}
/*
	JustificationItem *JustificationItem::updatedJustificationItem()
		{
		JustificationItem *searchItem = this;

		while( searchItem->replacingJustificationItem != NULL )
			searchItem = searchItem->replacingJustificationItem;

		return searchItem;
		}
*/
	SpecificationItem *JustificationItem::definitionSpecificationItem()
		{
		return definitionSpecificationItem_;
		}

	SpecificationItem *JustificationItem::anotherDefinitionSpecificationItem()
		{
		return anotherDefinitionSpecificationItem_;
		}

	SpecificationItem *JustificationItem::specificSpecificationItem()
		{
		return specificSpecificationItem_;
		}

/*************************************************************************
 *
 *	"The voice of the Lord is powerful;
 *	the voice of the Lord is majestic." (Psalm 29:4)
 *
 *************************************************************************/
