/* License/copyright: At the end of this file or read copyright.txt */

/*---------- Declarations --------------*/
int smartdecision(char *file,int *abstract_mode,int *abstract_rate,char *target,char *class_probable,int probability,int nb_best_result,int nb_of_words,int nb_of_lines);
int storeforsmartdecision(char *file,int nb_best_result,char *class_probable,int probability,int nb_of_words,int nb_of_lines,int abstract_rate,int nbw_abstract,int mode);
