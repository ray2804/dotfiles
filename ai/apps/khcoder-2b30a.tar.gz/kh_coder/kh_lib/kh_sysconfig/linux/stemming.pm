package kh_sysconfig::linux::stemming;
use base qw(kh_sysconfig::linux);

sub config_morph{
	return 1;
}

sub path_check{
	return 1;
}


1;
__END__
