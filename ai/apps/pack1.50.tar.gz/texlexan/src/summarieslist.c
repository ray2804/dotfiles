/* License/copyright: Dual license, please read copyright.txt */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>
#include <unistd.h>
#include <time.h>
#include "utils.h"
#include "help.h"
#include "definitions.h"
#include "languages.h"
#include "sentiment.h"
#include "summarieslist.h"

extern int debug;
extern int verbose;
extern char lang[];
extern long int size_line;
extern long int size_class_name;
extern long int size_nb_class;
extern char file_input[]; //SIZE_WORD
extern char file_output[];
extern int count_silent_bug;

/* 
 * convert string date in value
*/
time_t convert_date(char *lang, char *strdate) {
	struct tm tm;
	time_t t;
	char *str_ptr;
	char strdatebis[256]; //enough room

	char *strptime(const char *buf, const char *format, struct tm *tm);
	/* just in case! */
	if ( strlen(strdate) > 64 ) {
				fprintf(stderr,"date string too long! %s\n",strdate);
				ERRPOS;
				exit(EXIT_FAILURE);
	}
	/* convert with strptime, try different possibilies */
	if ( (str_ptr=strchr(strdate,'T')) ) *str_ptr=' ';// T separate date and time in iso 8601
	if ( strptime(strdate, "%Y%m%d %H%M%S", &tm ) != NULL) goto jmp_mktime;
	if ( strpbrk(strdate,"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRZTUVWXYZ") == NULL ) {
		/* full numeric */
		if ( strchr(strdate,'-') ) {
			if ( strchr(strdate,':') ) {
				if (strptime(strdate, "%Y-%m-%d %H:%M:%S", &tm) != NULL) goto jmp_mktime; 
			}
			else {
				/* no time */
				strcpy(strdatebis,strdate);
				strcat(strdatebis," 12:00:00");
				if (strptime(strdatebis, "%Y-%m-%d %H:%M:%S", &tm) != NULL) goto  jmp_mktime;
			}
		}
	} 
	else {
		/*letter month */
		if ( strchr(strdate,'-') ) {
			if ( strchr(strdate,':') ) {
				if (strptime(strdate, "%Y-%b-%d %H:%M:%S", &tm) != NULL) goto jmp_mktime; 
			}
			else {
				/* no time */
				strcpy(strdatebis,strdate);
				strcat(strdatebis," 12:00:00");
				if (strptime(strdatebis, "%Y-%b-%d %H:%M:%S", &tm) != NULL) goto  jmp_mktime;
			}
		}
	}
	/* some other possibilities */
	
	/* old format texlexan keep for compatibility to remove in the futur? */
	if ( strchr(strdate,'_') ) {
		char *date_cpy;
		date_cpy=strdup(strdate); //temporary copy
		strutf8toansi7b(date_cpy,strdate);
		free(date_cpy); //no need anymore
		if ( strchr(strdate,'.') ) {
			if (strptime(strdate, "%d%b.%Y_%H%M%S", &tm) != NULL) goto  jmp_mktime;
		}
		else if (strptime(strdate, "%d%b%Y_%H%M%S", &tm) != NULL) goto  jmp_mktime;
	}
	
	//strutf8toansi7b(strdatebis,strdate);
	strcpy(strdatebis,strdate);
	if ( !strchr(strdate,':') ) strcat(strdatebis," 12:00:00");
		
	if (strptime(strdatebis, "%d %b %Y %H:%M:%S", &tm) != NULL)  goto  jmp_mktime;
	if (strptime(strdatebis, "%b %d %Y %H:%M:%S", &tm) != NULL)  goto  jmp_mktime;
	if (strptime(strdatebis, "%Y %b %d %H:%M:%S", &tm) != NULL) goto  jmp_mktime;

jmp_mktime:
	
	if (debug) {
		fprintf(stderr,"\nDate:<%s>\n",strdate);
		fprintf(stderr,"Y:%i M:%i D:%i  HR:%i MN:%i SEC:%i\n",
			tm.tm_year,tm.tm_mon,tm.tm_mday,tm.tm_hour,tm.tm_min,tm.tm_sec);
	}

	tm.tm_isdst = -1; //mktime() will take care of the daylight saving time
	if ( (t = mktime(&tm)) == -1 ) {
		fprintf(stderr,"\nError date conversion!\n");
		fprintf(stderr,"Date:<%s>\n",strdate);
		fprintf(stderr,"Y:%i M:%i D:%i  HR:%i MN:%i SEC:%i\n",
			tm.tm_year,tm.tm_mon,tm.tm_mday,tm.tm_hour,tm.tm_min,tm.tm_sec);
		ERRPOS;
		fprintf(stderr,"\n");
		return 0;
	}
	return t;
}

/*
 *  Split optarg into "lang.encoding,dates" and targets
*/
int split_dates_targets(char *optarg,char *between_dates,char *list_targets) {
	char *str_ptr;
	int lg;
	strcpy(between_dates,optarg);
	if ((str_ptr=strstr(between_dates,"target="))) {
		*str_ptr='\0';
		strcpy(list_targets,str_ptr+7);
	}
	else if ((str_ptr=strstr(between_dates,"targets="))) {
		*str_ptr='\0';
		strcpy(list_targets,str_ptr+8);
	}
	
	lg=strlen(between_dates);
	if (lg==0) {
		fprintf(stderr,"Check the option -D ....\n");
		ERRPOS;
		exit(EXIT_FAILURE);
	} 
	lg--;
	while ( ispunct(between_dates[lg]) || between_dates[lg] == ' ') { 
		between_dates[lg]='\0';
		lg--;
	}
	StripSpace(between_dates);
	StripSpace(list_targets);
	return 1;
}

/* 
 * Get the dates from the argument
*/
int extract_dates(char *optarg,long *startdate,long *enddate) {
	char *lang_locale,*this_locale;
	char *str_ptr1,*str_ptr2;
	char *date1,*date2;
	char *optarg_cpy;
	/* get local */
	this_locale = strdup( setlocale(LC_TIME,NULL) );
	/* format="locale=lang,date1,date2"  
	 * ex. "locale=us_US.UTF8,dec 31 2009,feb 12 2010" */
	/* Extract the language */
	optarg_cpy=strdup(optarg);
	if ( (str_ptr1=strstr(optarg_cpy,"locale=")) ) {
		/* force lang & encoding */
		str_ptr1+=7;
		if ( (str_ptr2=strpbrk(str_ptr1,",; ")) ) {
			*str_ptr2='\0';
			lang_locale = strdup(str_ptr1);
			str_ptr1=str_ptr2+1;
		} 
		else {
			fprintf(stderr,"Malformed argument -D local=....\n");
			ERRPOS;
			exit(EXIT_FAILURE);
		}
	} 
	else {
		/* default lang & encoding */
		lang_locale = strdup("C");
		str_ptr1=optarg_cpy; 
	}
	/* Extract the dates of start & end */
	if ( (str_ptr2=strpbrk(str_ptr1,",;")) ) {  //separate both date
		*str_ptr2='\0';
		str_ptr2++;
	}
	else {
		str_ptr2=str_ptr1; //only one date
		if (verbose) fprintf(stderr,"Warning: The second date cannot be found: -D start_date,stop_date\n");
	}
	
	date1=strdup(str_ptr1);
	date2=strdup(str_ptr2);
	StripSpace(date1);
	StripSpace(date2);
	
	if (setlocale(LC_TIME,lang_locale) == NULL) {
		fprintf(stderr,"language invalide?\n");
		ERRPOS;
	}
	*startdate = (long) convert_date( lang_locale, date1 );
	*enddate = (long) convert_date( lang_locale, date2 );
	
	if (verbose)
		printf("seconds since the Epoch. Start:%ld -> End:%ld\n", *startdate,*enddate);
	
	if (setlocale(LC_TIME,this_locale) == NULL) {
		fprintf(stderr,"Pb setlocale.\n");
		ERRPOS;
	}
	free(this_locale);
	free(lang_locale); 
	free(optarg_cpy);
	free(date1);
	free(date2);
	return 1; //success
}

/*
 *  Extract the summaries between two dates
 */
int extract_summaries(char *file_input,char *file_output,long startdate,long enddate) 
{
	FILE *fp1,*fp2;
	char *line;
	char *str_ptr,*str_ptr1,*str_ptr2;
	char lang_summaries[128]="en_US";
	char encod_summaries[128]="UTF8";
	char vers_summaries[128]="0";
	char lang_locale[256]="C"; //default if <archiveslist:...> is missing
	char date_str[256];
	int cont,flag_summary=0,flag_between_date=0,flag_lang=0,flag_encod=0;
	int nb_summaries_extracted=0;
	long t;

	if ((line = (char*)malloc(size_line)) == NULL) errmalloc("summarieslist");
	/* open the list of summaries */
	fp1=fopen(file_input,"r");
	if (fp1==NULL){
		ERRPOS
		fprintf(stderr,"Unable to open %s ->Exit!\n",file_input);
		exit(EXIT_FAILURE);
	}
	/* create a file of only text */
	fp2=fopen(file_output,"w");
	if (fp2==NULL){
		ERRPOS
		fprintf(stderr,"Unable to create %s ->Exit!\n",file_output);
		exit(EXIT_FAILURE);
	}
	/*** 1st step: Search the language and chars encoding ***/
	fseek(fp1,0,SEEK_SET);
	cont=1;
	while (cont) {
		line[size_line-2]='\0';
		if (fgets(line,size_line,fp1) == NULL) break; //where are at the end
		if (line[size_line-2] != '\0') {
			ERRPOS
			fprintf(stderr,"Pb size_line allocated too small!\n");
			count_silent_bug++;
		}
		if (line[0] != '#') { //skip comment
			/* search tags */
			if ( (str_ptr1=strstr(line,"<archiveslist:")) != NULL ) {
				/* Extract the language & encoding */
				if ( (str_ptr1=strstr(line,"lan=")) != NULL ) {
					strncpy(lang_summaries,str_ptr1+4,100);
					lang_summaries[100]='\0';
					flag_lang++;
					if ( (str_ptr2=strpbrk(lang_summaries,":>")) != NULL ) *str_ptr2='\0';
					else {ERRPOS; exit(EXIT_FAILURE);}
				}
				if ( (str_ptr1=strstr(line,"encod=")) != NULL ) {
					strncpy(encod_summaries,str_ptr1+6,100);
					encod_summaries[100]='\0';
					flag_encod++;
					if ( (str_ptr2=strpbrk(encod_summaries,":>")) != NULL )  *str_ptr2='\0';
					else {ERRPOS; exit(EXIT_FAILURE);} 
				}
				if ( (str_ptr1=strstr(line,"vers=")) != NULL ) {
					strncpy(vers_summaries,str_ptr1,100);
					vers_summaries[100]='\0';
					if ( (str_ptr2=strpbrk(vers_summaries,":>")) != NULL )  *str_ptr2='\0';
					else {ERRPOS; exit(EXIT_FAILURE);} 
				}
				/* we need lang_locale to convert the date properly */
				sprintf(lang_locale,"%s.%s",lang_summaries,encod_summaries);
				break;
			} //endif tag <archiveslist:...>
		} //endif '#'
	} //endwhile
	
	if (verbose) printf("\nclassification.lst file Ver: %s lang.encoding: %s\n",
													vers_summaries,lang_locale);
													
	/* if error or missing tag <archiveslist:...> */
	if (flag_lang != 1 && flag_encod != 1)
	{
		ERRPOS;
		fprintf(stderr,"Check classification.lst file, error with <archiveslist:...>\n");
		count_silent_bug++;			
		fseek(fp1,0,SEEK_SET); //perhaps we're at the end, restart to the top
	}
	
	/*** 2nd step: Extract the text between 2 dates ***/
	cont=1;
	while (cont) {
		line[size_line-2]='\0';
		if (fgets(line,size_line,fp1) == NULL) break; //where are at the end
		if (line[size_line-2] != '\0') {
			ERRPOS
			fprintf(stderr,"Pb size_line allocated too small!\n");
			count_silent_bug++;
		}
		if (line[0] != '#') { //skip comment
			/* search tags */
			str_ptr=line;
			if ( strstr(line,"<Date:") != NULL ) {
				/* Extract both dates separated with '(' */
				/* search char that starts the date string */
				if ( (str_ptr=strchr(line,'(')) ) {
					/* computer friendly compact format
					 * YYYYMMDD HHMMSS */
					strncpy(date_str,str_ptr+1,100);
					*(date_str+100)='\0';
					/* search char that terminates the date string */
					if ( (str_ptr=strchr(date_str,')')) != NULL ) *str_ptr='\0';
					else fprintf(stderr,"Pb! Check tag <Date:...(....)>\n");
					/* Date conversion */
					StripSpace(date_str);
					t = (long) convert_date( lang_locale, date_str );
					if (debug)
						fprintf(stderr,"%s %s secs since Epoch:%ld\n",
										lang_locale,date_str,t);
				}
				else {  
					/* human friendly format 
					 * DD Full_month_letter YYYY HH:MM:SS */
					strncpy(date_str,line+6,100);
					*(date_str+100)='\0';
					/* search chars that terminate the date string */
					if ( (str_ptr=strchr(date_str,'(')) != NULL ) *str_ptr='\0';
						else if ( (str_ptr=strchr(date_str,'>')) != NULL ) *str_ptr='\0';
							else fprintf(stderr,"Pb! Check tag <Date:...>\n");
					/* Date conversion */
					StripSpace(date_str);
					t = (long) convert_date( lang_locale, date_str );
					if (debug)
						fprintf(stderr,"%s %s secs since Epoch:%ld\n",
										lang_locale,date_str,t);
				}
				/* Dates comparison */
				if (t >= startdate) flag_between_date=1; //okay, extract the text
				if (t >= enddate) flag_between_date=0; //do not extract
			}
			else if  ( (str_ptr=strstr(line,"<Start abstract")) != NULL ) {
				if  ( (str_ptr=strstr(str_ptr+15,">")) != NULL ) {
					flag_summary=1; //summary will be available
					nb_summaries_extracted+=flag_between_date;
				}
				else fprintf(stderr,"Pb! Check tag <Start abstract ..>\n");
			}
			else if  ( (str_ptr=strstr(line,"<End abstract")) != NULL ) {
				if  ( (str_ptr=strstr(str_ptr+13,">")) != NULL ) {
					flag_summary=0; //end of the summary
				}
				else fprintf(stderr,"Pb! Check tag <End abstract ..>\n");
			}
			else if (flag_summary && flag_between_date) {
				/* record the line (summary) */
				fprintf(fp2,"%s",line);
			} //endif flag_summary
		} //endif '#'
	} //endwhile cont
	fclose(fp1);
	fclose(fp2);
	free(line);
	return nb_summaries_extracted; //success
}
