/*
 *	Class:			GeneralizationItem
 *	Parent class:	Item
 *	Purpose:		To store info about generalizations of a word,
 *					which are the "parents" of that word,
 *					and is the opposite direction of its specifications
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#ifndef GENERALIZATIONITEM
#define GENERALIZATIONITEM 1
#include <limits.h>
#include "WordItem.h"

class GeneralizationItem : private Item
	{
	friend class AdminAssumption;
	friend class AdminAuthorization;
	friend class AdminCollection;
	friend class AdminConclusion;
	friend class AdminContext;
	friend class AdminLanguage;
	friend class AdminReadCreateWords;
	friend class AdminWrite;
	friend class GeneralizationList;
	friend class WordAssignment;
	friend class WordCollection;
	friend class WordItem;
	friend class WordSpecification;

	// Private loadable variables

	bool isRelation_;

	unsigned short questionParameter_;
	unsigned short specificationWordTypeNr_;
	unsigned short generalizationWordTypeNr_;

	WordItem *generalizationWordItem_;


	protected:
	// Constructor

	GeneralizationItem( bool isRelation, unsigned short questionParameter, unsigned short specificationWordTypeNr, unsigned short generalizationWordTypeNr, WordItem *generalizationWordItem, List *myList, WordItem *myWord, CommonVariables *commonVariables )
		{
		initializeItemVariables( NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, "GeneralizationItem", myList, myWord, commonVariables );

		// Private loadable variables

		isRelation_ = isRelation;

		questionParameter_ = questionParameter;
		specificationWordTypeNr_ = specificationWordTypeNr;
		generalizationWordTypeNr_ = generalizationWordTypeNr;
		generalizationWordItem_ = generalizationWordItem;

		if( generalizationWordItem_ == NULL )
			startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, NULL, "The given generalization word item is undefined" );
		}


	// Protected virtual functions

	virtual void showWordReferences( bool returnQueryToPosition )
		{
		char *wordString;
		char statusString[2] = SPACE_STRING;
		statusString[0] = statusChar();

		if( generalizationWordItem_ != NULL &&
		( wordString = generalizationWordItem_->wordTypeString( true, NO_ORDER_NR, generalizationWordTypeNr_ ) ) != NULL )
			{
			if( commonVariables()->hasFoundQuery )
				strcat( commonVariables()->queryString, ( returnQueryToPosition ? NEW_LINE_STRING : QUERY_SEPARATOR_SPACE_STRING ) );

			if( !isActiveItem() )	// Show status when not active
				strcat( commonVariables()->queryString, statusString );

			commonVariables()->hasFoundQuery = true;
			strcat( commonVariables()->queryString, wordString );
			}
		}

	virtual bool hasFoundParameter( unsigned int queryParameter )
		{
		return ( questionParameter_ == queryParameter ||

				( queryParameter == MAX_QUERY_PARAMETER &&
				questionParameter_ > NO_QUESTION_PARAMETER ) );
		}

	virtual bool hasFoundReferenceItemById( unsigned int querySentenceNr, unsigned int queryItemNr )
		{
		return ( generalizationWordItem_ == NULL ? false :
					( querySentenceNr == NO_SENTENCE_NR ? true : generalizationWordItem_->creationSentenceNr() == querySentenceNr ) &&
					( queryItemNr == NO_ITEM_NR ? true : generalizationWordItem_->itemNr() == queryItemNr ) );
		}

	virtual bool hasFoundWordType( unsigned short queryWordTypeNr )
		{
		return ( specificationWordTypeNr_ == queryWordTypeNr ||
				generalizationWordTypeNr_ == queryWordTypeNr );
		}

	virtual ResultType findMatchingWordReferenceString( char *queryString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "findMatchingWordReferenceString";
		commonVariables()->hasFoundMatchingStrings = false;

		if( generalizationWordItem_ != NULL )
			{
			if( generalizationWordItem_->findMatchingWordReferenceString( queryString ) != RESULT_OK )
				return addErrorInItem( functionNameString, NULL, NULL, "I failed to find a matching word reference string for the generalization word" );
			}

		return commonVariables()->result;
		}

	virtual char *toString( unsigned short queryWordTypeNr )
		{
		char *wordString;
		char *generalizationWordTypeString = myWord()->wordTypeName( generalizationWordTypeNr_ );
		char *specificationWordTypeString = myWord()->wordTypeName( specificationWordTypeNr_ );

		Item::toString( queryWordTypeNr );

		if( isRelation_ )
			{
			strcat( commonVariables()->queryString, QUERY_SEPARATOR_STRING );
			strcat( commonVariables()->queryString, "isRelation" );
			}

		if( questionParameter_ > NO_QUESTION_PARAMETER )
			{
			sprintf( tempString, "%cquestionParameter:%u", QUERY_SEPARATOR_CHAR, questionParameter_ );
			strcat( commonVariables()->queryString, tempString );
			}

		if( specificationWordTypeString == NULL )
			sprintf( tempString, "%cspecificationWordType:%c%u", QUERY_SEPARATOR_CHAR, QUERY_WORD_TYPE_CHAR, specificationWordTypeNr_ );
		else
			sprintf( tempString, "%cspecificationWordType:%s%c%u", QUERY_SEPARATOR_CHAR, specificationWordTypeString, QUERY_WORD_TYPE_CHAR, specificationWordTypeNr_ );

		strcat( commonVariables()->queryString, tempString );

		if( generalizationWordTypeString == NULL )
			sprintf( tempString, "%cgeneralizationWordType:%c%u", QUERY_SEPARATOR_CHAR, QUERY_WORD_TYPE_CHAR, generalizationWordTypeNr_ );
		else
			sprintf( tempString, "%cgeneralizationWordType:%s%c%u", QUERY_SEPARATOR_CHAR, generalizationWordTypeString, QUERY_WORD_TYPE_CHAR, generalizationWordTypeNr_ );

		strcat( commonVariables()->queryString, tempString );

		if( generalizationWordItem_ != NULL )
			{
			sprintf( tempString, "%cgeneralizationWord%c%u%c%u%c", QUERY_SEPARATOR_CHAR, QUERY_REF_ITEM_START_CHAR, generalizationWordItem_->creationSentenceNr(), QUERY_SEPARATOR_CHAR, generalizationWordItem_->itemNr(), QUERY_REF_ITEM_END_CHAR );
			strcat( commonVariables()->queryString, tempString );

			if( ( wordString = generalizationWordItem_->wordTypeString( true, NO_ORDER_NR, generalizationWordTypeNr_ ) ) != NULL )
				{
				sprintf( tempString, "%c%s%c", QUERY_WORD_REFERENCE_START_CHAR, wordString, QUERY_WORD_REFERENCE_END_CHAR );
				strcat( commonVariables()->queryString, tempString );
				}
			}

		return commonVariables()->queryString;
		}


	// Protected functions

	bool isRelation()
		{
		return isRelation_;
		}

	bool isSpecificationNounPlural()
		{
		return ( specificationWordTypeNr_ == WORD_TYPE_NOUN_PLURAL );
		}

	bool isGeneralizationPropername()
		{
		return ( generalizationWordTypeNr_ == WORD_TYPE_PROPER_NAME );
		}

	bool isGeneralizationSingularNoun()
		{
		return ( generalizationWordTypeNr_ == WORD_TYPE_NOUN_SINGULAR );
		}

	bool isGeneralizationPluralNoun()
		{
		return ( generalizationWordTypeNr_ == WORD_TYPE_NOUN_PLURAL );
		}

	unsigned short questionParameter()
		{
		return questionParameter_;
		}

	unsigned short specificationWordTypeNr()
		{
		return specificationWordTypeNr_;
		}

	unsigned short generalizationWordTypeNr()
		{
		return generalizationWordTypeNr_;
		}

	WordItem *generalizationWordItem()
		{
		return generalizationWordItem_;
		}

	GeneralizationItem *getGeneralizationItem( bool includeThisItem, bool isRelation )
		{
		GeneralizationItem *searchItem = ( includeThisItem ? this : nextGeneralizationItem() );

		while( searchItem != NULL )
			{
			if( searchItem->isRelation() == isRelation )
				return searchItem;

			searchItem = searchItem->nextGeneralizationItem();
			}

		return NULL;
		}

	GeneralizationItem *nextGeneralizationItem()
		{
		return (GeneralizationItem *)nextItem;
		}

	GeneralizationItem *nextGeneralizationItemOfSpecification()
		{
		return getGeneralizationItem( false, false );
		}

	GeneralizationItem *nextGeneralizationItemOfRelation()
		{
		return getGeneralizationItem( false, true );
		}

	GeneralizationItem *nextGeneralizationItem( bool isRelation )
		{
		return getGeneralizationItem( false, isRelation );
		}
	};
#endif

/*************************************************************************
 *
 *	"Give thanks to him who made the heavens so skillfully.
 *	His faithful love endures forever." (Psalm 136:5)
 *
 *************************************************************************/
