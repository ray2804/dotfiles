package kpml;
import java.net.*;
import java.io.*;

public class MiniClient {

	public static void main(String[] args) {

		sendKPML (10200, "(s / sail :actor (p / ship))");
	//	sendKPML (10200, ":stop");
	}
	
	public static void sendKPML (Integer port, String string) {
		try { 
		    Socket server = new Socket("localhost", port); 
		    InputStream in = server.getInputStream(); 
		    OutputStream out = server.getOutputStream(); 
		 
		    // Write a newline or carriage return delimited string
		    PrintWriter pout = new PrintWriter( out, true ); 
		    pout.println(string); 
		 
		    // Read a newline or carriage return delimited string 
		    BufferedReader bin = new BufferedReader (new InputStreamReader (in));
		    String response = bin.readLine(); 
		    System.out.println(response);

		    server.close(); 
		}  
		catch (IOException e ) { System.out.println("KPML communication error"); } 
	}

}
