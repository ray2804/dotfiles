/*
 *	Class:		Console
 *	Purpose:	To create the GUI and to process the events
 *	Version:	Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.text.Document;

class Console extends JPanel implements ActionListener, ComponentListener
	{
	// Private non-static components
	private JFileChooser fileChooser_;

	// Private static constants
	private static final long serialVersionUID = -2264899695119545018L;

	// Private static variables
	private static boolean hasSelectedAmbiguityBoston_;
	private static boolean hasSelectedAmbiguityPresidents_;
	private static boolean hasSelectedProgrammingConnect4_;
	private static boolean hasSelectedProgrammingGreeting_;
	private static boolean hasSelectedProgrammingTowerOfHanoi_;
	private static boolean hasSelectedReasoningFamily_;

	private static boolean isActionPerformed_;
	private static boolean isConsoleReady_;

	private static short currentSubMenu_;
	private static short nSubMenuButtons_;

	private static int currentFrameWidth_;
	private static int currentFrameHeight_;
	private static int currentPreferredOutputScrollPaneSize_;
	private static int preferredSubMenuHeight_;

	private static String inputString_;
	private static String errorHeaderString_;
	private static StringBuffer errorStringBuffer_;

	private static WordItem currentInterfaceLanguageWordItem_;

	// Private static components - Output area
	private static JScrollPane outputScrollPane_;
	private static JTextArea outputArea_;

	// Private static components - Panels
	private static JPanel upperPanel_;
	private static JPanel mainMenuPanel_;
	private static JPanel subMenuPanel_;
	private static JPanel inputPanel_;

	// Private static components - Upper menu
	private static JButton upperMenuClearYourMindButton_;
	private static JButton upperMenuRestartButton_;
	private static JButton upperMenuUndoButton_;
	private static JButton upperMenuRedoButton_;
	private static JButton upperMenuSelectExampleFile_;

	private static JLabel upperMenuProgressLabel_;
	private static JProgressBar upperMenuProgressBar_;

	// Private static components - Main menu
	private static JButton mainMenuAmbiguitySubMenuButton_;
	private static JButton mainMenuReadTheFileAmbiguityBostonButton_;
	private static JButton mainMenuReadTheFileAmbiguityPresidentsButton_;

	private static JButton mainMenuProgrammingSubMenuButton_;
	private static JButton mainMenuReadTheFileProgrammingConnect4Button_;
	private static JButton mainMenuReadTheFileProgrammingGreetingButton_;
	private static JButton mainMenuReadTheFileProgrammingTowerOfHanoiButton_;

	private static JButton mainMenuReasoningSubMenuButton_;
	private static JButton mainMenuReadTheFileReasoningFamilyButton_;
	private static JButton mainMenuFamilyDefinitionsSubMenuButton_;
	private static JButton mainMenuFamilyConflictsSubMenuButton_;
	private static JButton mainMenuFamilyJustificationSubMenuButton_;
	private static JButton mainMenuFamilyQuestionsSubMenuButton_;
	private static JButton mainMenuFamilyShowInfoSubMenuButton_;

	private static JButton mainMenuBackButton_;
	private static JButton mainMenuChangeLanguageButton_;
	private static JButton mainMenuHelpButton_;

	// Private static components - Sub menus
	private static JLabel initLabel_;

	private static JButton[] subMenuButtonArray_ = new JButton[Constants.CONSOLE_MAX_NUMBER_OF_SUBMENU_BUTTONS];

	// Private static components - input area
	private static JTextField inputField_;
	private static JPasswordField passwordField_;


	// Private non-static methods

	private void resizeFrameComponents( ComponentEvent componentEvent )
		{
		Component component;

		if( componentEvent != null &&
		( component = componentEvent.getComponent() ) != null )
			resizeFrame( component.getWidth(), component.getHeight() );
		}


	// Private static methods

	private static void waitForConsoleToBeReady()
		{
		short nRetries = Constants.CONSOLE_NUMBER_OF_RETRIES_FOR_CONSOLE_TO_BE_READY;

		while( !isConsoleReady_ )
			{
			if( --nRetries > 0 )
				{
				try {
					Thread.sleep( Constants.CONSOLE_SLEEP_TIME );
					}
				catch( InterruptedException ie )
					{
					ie.printStackTrace();
					}
				}
			else
				isConsoleReady_ = true;		// To avoid starvation, force console to be ready
			}
		}

	private static void setSubMenuButtonText()
		{
		int grammarLanguageStringBufferLength;
		int startPosition;
		int endPosition;
		String currentInterfaceLanguageWordString;
		String grammarLanguageString;

		if( currentInterfaceLanguageWordItem_ != null )
			{
			switch( currentSubMenu_ )
				{
				case Constants.CONSOLE_SUBMENU_PROGRAMMING_CONNECT4:
					subMenuButtonArray_[0].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_PROGRAMMING_CONNECT4_MY_SET_IS_A ) );
					subMenuButtonArray_[1].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_PROGRAMMING_CONNECT4_MY_SET_IS_B ) );
					subMenuButtonArray_[2].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_PROGRAMMING_CONNECT4_MY_SET_IS_C ) );
					subMenuButtonArray_[3].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_PROGRAMMING_CONNECT4_MY_SET_IS_D ) );
					subMenuButtonArray_[4].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_PROGRAMMING_CONNECT4_MY_SET_IS_E ) );
					subMenuButtonArray_[5].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_PROGRAMMING_CONNECT4_MY_SET_IS_F ) );
					subMenuButtonArray_[6].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_PROGRAMMING_CONNECT4_MY_SET_IS_G ) );
					subMenuButtonArray_[7].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_PROGRAMMING_CONNECT4_SHOW_INFO_ABOUT_THE_SET ) );
					subMenuButtonArray_[8].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_PROGRAMMING_CONNECT4_THE_SOLVE_LEVEL_IS_LOW ) );
					subMenuButtonArray_[9].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_PROGRAMMING_CONNECT4_THE_SOLVE_LEVEL_IS_HIGH ) );

					nSubMenuButtons_ = 10;
					break;

				case Constants.CONSOLE_SUBMENU_PROGRAMMING_TOWER_OF_HANOI:
					subMenuButtonArray_[0].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_PROGRAMMING_TOWER_OF_HANOI_EVEN_NUMBER_OF_DISCS ) );
					subMenuButtonArray_[1].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_PROGRAMMING_TOWER_OF_HANOI_ODD_NUMBER_OF_DISCS ) );

					nSubMenuButtons_ = 2;
					break;

				case Constants.CONSOLE_SUBMENU_REASONING_FAMILY_DEFINITIONS:
					subMenuButtonArray_[0].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_JOHN_ANN ) );
					subMenuButtonArray_[1].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_PAUL_IS_A_SON ) );
					subMenuButtonArray_[2].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_JOE_IS_A_SON ) );
					subMenuButtonArray_[3].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_LAURA_IS_A_DAUGHTER ) );

					subMenuButtonArray_[4].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_PAUL_IS_A_SON_OF_JOHN_AND_ANN ) );
					subMenuButtonArray_[5].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_JOE_IS_A_SON_OF_JOHN_AND_ANN ) );
					subMenuButtonArray_[6].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_LAURA_IS_A_DAUGHTER_OF_JOHN_AND_ANN ) );

					subMenuButtonArray_[7].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_JOHN_IS_A_FATHER ) );
					subMenuButtonArray_[8].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_ANN_IS_A_MOTHER ) );

					subMenuButtonArray_[9].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_JOHN_IS_A_PARENT ) );
					subMenuButtonArray_[10].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_ANN_IS_A_PARENT ) );

					subMenuButtonArray_[11].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_JOHN_IS_A_MAN ) );
					subMenuButtonArray_[12].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_ANN_IS_A_WOMAN ) );
					subMenuButtonArray_[13].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_PAUL_IS_A_MAN ) );
					subMenuButtonArray_[14].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_JOE_IS_A_MAN ) );
					subMenuButtonArray_[15].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_LAURA_IS_A_WOMAN ) );

					nSubMenuButtons_ = 16;
					break;

				case Constants.CONSOLE_SUBMENU_REASONING_FAMILY_CONFLICTS:
					subMenuButtonArray_[0].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_CONFLICT_JOHN_IS_A_WOMAN ) );
					subMenuButtonArray_[1].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_CONFLICT_JOHN_IS_THE_MOTHER_PETE ) );
					subMenuButtonArray_[2].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_CONFLICT_ANN_IS_A_SON ) );
					subMenuButtonArray_[3].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_CONFLICT_PAUL_IS_A_DAUGHTER ) );
					subMenuButtonArray_[4].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_CONFLICT_JOE_IS_A_MOTHER ) );

					nSubMenuButtons_ = 5;
					break;

				case Constants.CONSOLE_SUBMENU_REASONING_FAMILY_JUSTIFICATION_REPORT:
					subMenuButtonArray_[0].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_SHOW_JUSTIFICATION_REPORT_FOR_PARENTS ) );
					subMenuButtonArray_[1].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_SHOW_JUSTIFICATION_REPORT_FOR_CHILDREN ) );
					subMenuButtonArray_[2].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_SHOW_JUSTIFICATION_REPORT_FOR_JOHN ) );
					subMenuButtonArray_[3].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_SHOW_JUSTIFICATION_REPORT_FOR_ANN ) );
					subMenuButtonArray_[4].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_SHOW_JUSTIFICATION_REPORT_FOR_PAUL ) );
					subMenuButtonArray_[5].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_SHOW_JUSTIFICATION_REPORT_FOR_JOE ) );
					subMenuButtonArray_[6].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_SHOW_JUSTIFICATION_REPORT_FOR_LAURA ) );

					nSubMenuButtons_ = 7;
					break;

				case Constants.CONSOLE_SUBMENU_REASONING_FAMILY_QUESTIONS:
					subMenuButtonArray_[0].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_QUESTION_IS_JOHN_A_FATHER ) );
					subMenuButtonArray_[1].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_QUESTION_IS_JOHN_A_MOTHER ) );
					subMenuButtonArray_[2].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_QUESTION_IS_JOHN_THE_FATHER_OF_PAUL ) );
					subMenuButtonArray_[3].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_QUESTION_IS_JOHN_THE_MOTHER_OF_PAUL ) );
					subMenuButtonArray_[4].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_QUESTION_IS_PAUL_A_MAN ) );
					subMenuButtonArray_[5].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_QUESTION_IS_PAUL_A_WOMAN ) );
					subMenuButtonArray_[6].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_QUESTION_IS_PAUL_A_MAN_OR_A_WOMAN ) );
					subMenuButtonArray_[7].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_QUESTION_IS_PAUL_A_SON ) );
					subMenuButtonArray_[8].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_QUESTION_IS_PAUL_A_DAUGHTER ) );
					subMenuButtonArray_[9].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_QUESTION_IS_PAUL_A_SON_OR_A_DAUGHTER ) );

					nSubMenuButtons_ = 10;
					break;

				case Constants.CONSOLE_SUBMENU_REASONING_FAMILY_SHOW_INFO:
					subMenuButtonArray_[0].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_SHOW_INFO_ABOUT_JOHN ) );
					subMenuButtonArray_[1].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_SHOW_INFO_ABOUT_ANN ) );
					subMenuButtonArray_[2].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_SHOW_INFO_ABOUT_PAUL ) );
					subMenuButtonArray_[3].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_SHOW_INFO_ABOUT_JOE ) );
					subMenuButtonArray_[4].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_REASONING_FAMILY_SHOW_INFO_ABOUT_LAURA ) );

					nSubMenuButtons_ = 5;
					break;

				case Constants.CONSOLE_SUBMENU_CHANGE_LANGUAGE:
					grammarLanguageStringBufferLength = CommonVariables.interfaceLanguageStringBuffer.length();
					nSubMenuButtons_ = 0;
					startPosition = 0;
					endPosition = 0;

					if( ( currentInterfaceLanguageWordString = currentInterfaceLanguageWordItem_.anyWordTypeString() ) != null )
						{
						while( startPosition < grammarLanguageStringBufferLength &&
						nSubMenuButtons_ + 1 < Constants.CONSOLE_MAX_NUMBER_OF_SUBMENU_BUTTONS )
							{
							if( ( endPosition = CommonVariables.interfaceLanguageStringBuffer.substring( startPosition ).indexOf( Constants.QUERY_SEPARATOR_SPACE_STRING ) ) < 0 )
								endPosition = grammarLanguageStringBufferLength;	// Last language in string

							if( ( grammarLanguageString = CommonVariables.interfaceLanguageStringBuffer.substring( startPosition, endPosition ) ) != null )
								{
								if( !grammarLanguageString.equals( currentInterfaceLanguageWordString ) )	// Skip current language
									subMenuButtonArray_[nSubMenuButtons_++].setText( Constants.CHANGE_LANGUAGE_STRING + grammarLanguageString );
								}

							startPosition = endPosition + Constants.QUERY_SEPARATOR_SPACE_STRING.length();
							}
						}

					break;

				case Constants.CONSOLE_SUBMENU_HELP:
					subMenuButtonArray_[0].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_HELP_SHOW_INFO_ABOUT_THE_LISTS ) );
					subMenuButtonArray_[1].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_HELP_SHOW_INFO_ABOUT_THE_WORD_TYPES ) );
					subMenuButtonArray_[2].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_HELP_SHOW_THE_QUERY_COMMANDS ) );
					subMenuButtonArray_[3].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_HELP_SHOW_THE_COPYRIGHT ) );
					subMenuButtonArray_[4].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_HELP_SHOW_THE_GPLv2_LICENSE ) );
					subMenuButtonArray_[5].setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_HELP_SHOW_THE_WARRANTY ) );

					nSubMenuButtons_ = 6;
					break;
					
				default:
					nSubMenuButtons_ = 0;
				}
			}
		}

	private static void setInterfaceLanguage()
		{
		if( CommonVariables.currentInterfaceLanguageWordItem != null &&
		CommonVariables.currentInterfaceLanguageWordItem != currentInterfaceLanguageWordItem_ )
			{
			currentInterfaceLanguageWordItem_ = CommonVariables.currentInterfaceLanguageWordItem;
			
			// Upper panel buttons
			upperMenuClearYourMindButton_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_UPPER_MENU_CLEAR_YOUR_MIND ) );
			upperMenuRestartButton_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_UPPER_MENU_RESTART ) );
			upperMenuUndoButton_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_UPPER_MENU_UNDO ) );
			upperMenuRedoButton_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_UPPER_MENU_REDO ) );
			upperMenuSelectExampleFile_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_UPPER_MENU_MORE_EXAMPLES ) );

			// Main menu buttons
			mainMenuAmbiguitySubMenuButton_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_MAIN_MENU_AMBIGUITY_SUBMENU ) );
			mainMenuReadTheFileAmbiguityBostonButton_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_MAIN_MENU_READ_THE_FILE_AMBIGUITY_BOSTON ) );
			mainMenuReadTheFileAmbiguityPresidentsButton_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_MAIN_MENU_READ_THE_FILE_AMBIGUITY_PRESIDENTS ) );

			mainMenuProgrammingSubMenuButton_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_MAIN_MENU_PROGRAMMING_SUBMENU ) );
			mainMenuReadTheFileProgrammingConnect4Button_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_MAIN_MENU_READ_THE_FILE_PROGRAMMING_CONNECT4 ) );
			mainMenuReadTheFileProgrammingGreetingButton_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_MAIN_MENU_READ_THE_FILE_PROGRAMMING_GREETING ) );
			mainMenuReadTheFileProgrammingTowerOfHanoiButton_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_MAIN_MENU_READ_THE_FILE_PROGRAMMING_TOWER_OF_HANOI ) );

			mainMenuReasoningSubMenuButton_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_MAIN_MENU_REASONING_SUBMENU ) );
			mainMenuReadTheFileReasoningFamilyButton_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_MAIN_MENU_READ_THE_FILE_REASONING_FAMILY ) );
			mainMenuFamilyDefinitionsSubMenuButton_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_MAIN_MENU_FAMILY_SUBMENU ) );
			mainMenuFamilyConflictsSubMenuButton_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_MAIN_MENU_FAMILY_CONFLICT_SUBMENU ) );
			mainMenuFamilyJustificationSubMenuButton_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_MAIN_MENU_FAMILY_JUSTIFICATION_REPORT_SUBMENU ) );
			mainMenuFamilyQuestionsSubMenuButton_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_MAIN_MENU_FAMILY_QUESTION_SUBMENU ) );
			mainMenuFamilyShowInfoSubMenuButton_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_MAIN_MENU_FAMILY_SHOW_INFO_SUBMENU ) );

			mainMenuBackButton_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_MAIN_MENU_BACK ) );
			mainMenuChangeLanguageButton_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_MAIN_MENU_CHANGE_LANGUAGE ) );
			mainMenuChangeLanguageButton_.setVisible( CommonVariables.interfaceLanguageStringBuffer != null );
			mainMenuHelpButton_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_MAIN_MENU_HELP ) );

			// Sub menu
			initLabel_.setText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_START_MESSAGE ) );
			setSubMenuButtonText();
			}
		}

	private static void enableMenus( boolean enabledNormalButtons, boolean enableSubMenuButtons )
		{
		boolean isChangeLanguage = ( currentSubMenu_ == Constants.CONSOLE_SUBMENU_CHANGE_LANGUAGE );
		boolean isHelp = ( currentSubMenu_ == Constants.CONSOLE_SUBMENU_HELP );
		boolean isInit = ( currentSubMenu_ == Constants.CONSOLE_SUBMENU_INIT );
		
		// Upper menu
		upperMenuClearYourMindButton_.setEnabled( enabledNormalButtons );
		upperMenuRestartButton_.setEnabled( enabledNormalButtons );
		upperMenuUndoButton_.setEnabled( enabledNormalButtons );
		upperMenuRedoButton_.setEnabled( enabledNormalButtons );
		upperMenuSelectExampleFile_.setEnabled( enabledNormalButtons );

			// Main menu
			mainMenuAmbiguitySubMenuButton_.setEnabled( enabledNormalButtons );
			mainMenuAmbiguitySubMenuButton_.setVisible( isChangeLanguage || isHelp || isInit );

			mainMenuProgrammingSubMenuButton_.setEnabled( enabledNormalButtons );
			mainMenuProgrammingSubMenuButton_.setVisible( isChangeLanguage || isHelp || isInit );

			mainMenuReasoningSubMenuButton_.setEnabled( enabledNormalButtons );
			mainMenuReasoningSubMenuButton_.setVisible( isChangeLanguage || isHelp || isInit );

		if( currentSubMenu_ == Constants.CONSOLE_SUBMENU_AMBIGUITY )
			{
			mainMenuReadTheFileAmbiguityBostonButton_.setEnabled( hasSelectedAmbiguityBoston_ ? false : enabledNormalButtons );
			mainMenuReadTheFileAmbiguityBostonButton_.setVisible( true );

			mainMenuReadTheFileAmbiguityPresidentsButton_.setEnabled( hasSelectedAmbiguityPresidents_ ? false : enabledNormalButtons );
			mainMenuReadTheFileAmbiguityPresidentsButton_.setVisible( true );
			}
		else
			{
			mainMenuReadTheFileAmbiguityBostonButton_.setVisible( false );
			mainMenuReadTheFileAmbiguityPresidentsButton_.setVisible( false );
			}

		if( ( currentSubMenu_ == Constants.CONSOLE_SUBMENU_PROGRAMMING ||
		currentSubMenu_ == Constants.CONSOLE_SUBMENU_PROGRAMMING_CONNECT4 ||
		currentSubMenu_ == Constants.CONSOLE_SUBMENU_PROGRAMMING_GREETING ||
		currentSubMenu_ == Constants.CONSOLE_SUBMENU_PROGRAMMING_TOWER_OF_HANOI ) )
			{
			mainMenuReadTheFileProgrammingConnect4Button_.setEnabled( hasSelectedProgrammingConnect4_ ? false : enabledNormalButtons );
			mainMenuReadTheFileProgrammingConnect4Button_.setVisible( true );

			mainMenuReadTheFileProgrammingGreetingButton_.setEnabled( hasSelectedProgrammingGreeting_ ? false : enabledNormalButtons );
			mainMenuReadTheFileProgrammingGreetingButton_.setVisible( true );

			mainMenuReadTheFileProgrammingTowerOfHanoiButton_.setEnabled( hasSelectedProgrammingTowerOfHanoi_ ? false : enabledNormalButtons );
			mainMenuReadTheFileProgrammingTowerOfHanoiButton_.setVisible( true );
			}
		else
			{
			mainMenuReadTheFileProgrammingConnect4Button_.setVisible( false );
			mainMenuReadTheFileProgrammingGreetingButton_.setVisible( false );
			mainMenuReadTheFileProgrammingTowerOfHanoiButton_.setVisible( false );
			}

		if( ( currentSubMenu_ == Constants.CONSOLE_SUBMENU_REASONING ||
		currentSubMenu_ == Constants.CONSOLE_SUBMENU_REASONING_FAMILY_DEFINITIONS ||
		currentSubMenu_ == Constants.CONSOLE_SUBMENU_REASONING_FAMILY_CONFLICTS ||
		currentSubMenu_ == Constants.CONSOLE_SUBMENU_REASONING_FAMILY_JUSTIFICATION_REPORT ||
		currentSubMenu_ == Constants.CONSOLE_SUBMENU_REASONING_FAMILY_QUESTIONS ||
		currentSubMenu_ == Constants.CONSOLE_SUBMENU_REASONING_FAMILY_SHOW_INFO ) )
			{
			mainMenuReadTheFileReasoningFamilyButton_.setEnabled( hasSelectedReasoningFamily_ ? false : enabledNormalButtons );
			mainMenuReadTheFileReasoningFamilyButton_.setVisible( true );

			mainMenuFamilyDefinitionsSubMenuButton_.setEnabled( hasSelectedReasoningFamily_ && currentSubMenu_ != Constants.CONSOLE_SUBMENU_REASONING_FAMILY_DEFINITIONS ? enabledNormalButtons : false );
			mainMenuFamilyDefinitionsSubMenuButton_.setVisible( hasSelectedReasoningFamily_ );

			mainMenuFamilyConflictsSubMenuButton_.setEnabled( hasSelectedReasoningFamily_ && currentSubMenu_ != Constants.CONSOLE_SUBMENU_REASONING_FAMILY_CONFLICTS ? enabledNormalButtons : false );
			mainMenuFamilyConflictsSubMenuButton_.setVisible( hasSelectedReasoningFamily_ );

			mainMenuFamilyJustificationSubMenuButton_.setEnabled( hasSelectedReasoningFamily_ && currentSubMenu_ != Constants.CONSOLE_SUBMENU_REASONING_FAMILY_JUSTIFICATION_REPORT ? enabledNormalButtons : false );
			mainMenuFamilyJustificationSubMenuButton_.setVisible( hasSelectedReasoningFamily_ );

			mainMenuFamilyQuestionsSubMenuButton_.setEnabled( hasSelectedReasoningFamily_ && currentSubMenu_ != Constants.CONSOLE_SUBMENU_REASONING_FAMILY_QUESTIONS ? enabledNormalButtons : false );
			mainMenuFamilyQuestionsSubMenuButton_.setVisible( hasSelectedReasoningFamily_ );

			mainMenuFamilyShowInfoSubMenuButton_.setEnabled( hasSelectedReasoningFamily_ && currentSubMenu_ != Constants.CONSOLE_SUBMENU_REASONING_FAMILY_SHOW_INFO ? enabledNormalButtons : false );
			mainMenuFamilyShowInfoSubMenuButton_.setVisible( hasSelectedReasoningFamily_ );
			}
		else
			{
			mainMenuReadTheFileReasoningFamilyButton_.setVisible( false );

			mainMenuFamilyDefinitionsSubMenuButton_.setVisible( false );
			mainMenuFamilyConflictsSubMenuButton_.setVisible( false );
			mainMenuFamilyJustificationSubMenuButton_.setVisible( false );
			mainMenuFamilyQuestionsSubMenuButton_.setVisible( false );
			mainMenuFamilyShowInfoSubMenuButton_.setVisible( false );
			}
			mainMenuBackButton_.setEnabled( enabledNormalButtons );

			mainMenuBackButton_.setVisible( currentSubMenu_ != Constants.CONSOLE_SUBMENU_INIT && currentSubMenu_ != Constants.CONSOLE_SUBMENU_HELP  );
			mainMenuChangeLanguageButton_.setVisible( currentSubMenu_ == Constants.CONSOLE_SUBMENU_CHANGE_LANGUAGE ? false : enabledNormalButtons );
			mainMenuHelpButton_.setVisible( enabledNormalButtons );

		// Sub menu
		if( currentSubMenu_ != Constants.CONSOLE_SUBMENU_INIT )
			{
			for( short index = 0; index < Constants.CONSOLE_MAX_NUMBER_OF_SUBMENU_BUTTONS; index++ )
				subMenuButtonArray_[index].setEnabled( enableSubMenuButtons );
			}

		resizeFrame( currentFrameWidth_, currentFrameHeight_ );
		}

	private static void setUpperMenuVisible( boolean isVisible )
		{
		upperMenuClearYourMindButton_.setVisible( isVisible );
		upperMenuRestartButton_.setVisible( isVisible );
		upperMenuUndoButton_.setVisible( isVisible );
		upperMenuRedoButton_.setVisible( isVisible );
		upperMenuSelectExampleFile_.setVisible( isVisible );
		}

	private static void setSubMenuVisible( boolean skipChangingCurrentSettingSubMenu, short subMenu )
		{
		if( !skipChangingCurrentSettingSubMenu )
			currentSubMenu_ = subMenu;

		setSubMenuButtonText();
		showProgressStatus( null );

		initLabel_.setVisible( nSubMenuButtons_ == 0 );

		for( short index = 0; index < Constants.CONSOLE_MAX_NUMBER_OF_SUBMENU_BUTTONS; index++ )
			subMenuButtonArray_[index].setVisible( index < nSubMenuButtons_ );
		}

	private static void resizeFrame( int newFrameWidth, int newFrameHeight )
		{
		Document document;
		int preferredOutputScrollPaneSize;

		currentFrameWidth_ = newFrameWidth;
		currentFrameHeight_ = newFrameHeight;
		preferredSubMenuHeight_ = lastVisibleSubMenuButtonY();

		subMenuPanel_.setPreferredSize( new Dimension( 0, preferredSubMenuHeight_ ) );

		preferredOutputScrollPaneSize = ( newFrameHeight - ( preferredSubMenuHeight_ + ( 3 * Constants.CONSOLE_BUTTON_PANE_HEIGHT ) + ( 2 * 5 * Constants.CONSOLE_BORDER_SIZE ) ) );

		if( currentPreferredOutputScrollPaneSize_ != preferredOutputScrollPaneSize )
			{
			outputScrollPane_.setPreferredSize( new Dimension( 0, preferredOutputScrollPaneSize ) );

			currentPreferredOutputScrollPaneSize_ = preferredOutputScrollPaneSize;

			if( isConsoleReady_ )
				{
				// Update output area
				outputArea_.updateUI();

				// Go to end of text in output area
				if( ( document = outputArea_.getDocument() ) != null )
					// Go to end of text in output area
					outputArea_.setCaretPosition( document.getLength() );
				}
			}

		subMenuPanel_.revalidate();
		outputScrollPane_.revalidate();
		}

	private static int lastVisibleSubMenuButtonY()
		{
		int y = ( nSubMenuButtons_ == 0 ? 0 : subMenuButtonArray_[nSubMenuButtons_ - 1].getY() );

		return ( Constants.CONSOLE_BUTTON_PANE_HEIGHT + y );
		}

	private static String getInputString()
		{
		inputString_ = null;

		do	{
			resizeFrame( currentFrameWidth_, currentFrameHeight_ );

			try {
				Thread.sleep( Constants.CONSOLE_SLEEP_TIME );
				}
			catch( InterruptedException ie )
				{
				ie.printStackTrace();
				}
			}
		while( !isActionPerformed_ ||
		inputString_ == null );

		return inputString_;
		}


	// Constructor

	public Console( Dimension frameSize )
		{
		super( new GridBagLayout() );

		// Create output area
		outputArea_ = new JTextArea();
		outputArea_.setEditable( false );
		outputArea_.setLineWrap( true );
		outputArea_.setWrapStyleWord( true );

		// Set a mono-spaced (= non-proportional) font for output area
		outputArea_.setFont( new Font( Constants.CONSOLE_MONO_SPACED_FONT, Font.PLAIN, Constants.CONSOLE_FONT_SIZE ) );

		// Create scroll pane with border for output area
		outputScrollPane_ = new JScrollPane( outputArea_ );
		outputScrollPane_.setVerticalScrollBarPolicy( JScrollPane.VERTICAL_SCROLLBAR_ALWAYS );
		outputScrollPane_.setPreferredSize( new Dimension( 0, frameSize.getSize().height - ( 4 * Constants.CONSOLE_BUTTON_PANE_HEIGHT + 2 * 5 * Constants.CONSOLE_BORDER_SIZE ) ) );
		outputScrollPane_.setBorder(
				BorderFactory.createCompoundBorder(
						BorderFactory.createEmptyBorder( Constants.CONSOLE_BORDER_SIZE, Constants.CONSOLE_BORDER_SIZE, Constants.CONSOLE_BORDER_SIZE, Constants.CONSOLE_BORDER_SIZE ),
						outputScrollPane_.getBorder() ) );

		// Create Upper panel with border
		upperPanel_ = new JPanel();
		GridBagLayout upperPaneGridbag = new GridBagLayout();
		upperPanel_.setLayout( upperPaneGridbag );
		upperPanel_.setPreferredSize( new Dimension( 0, Constants.CONSOLE_BUTTON_PANE_HEIGHT ) );
		upperPanel_.setBorder(
				BorderFactory.createCompoundBorder(
						BorderFactory.createEmptyBorder( Constants.CONSOLE_BORDER_SIZE, Constants.CONSOLE_BORDER_SIZE, Constants.CONSOLE_BORDER_SIZE, Constants.CONSOLE_BORDER_SIZE ),
						upperPanel_.getBorder() ) );

		// Create Main menu with border
		mainMenuPanel_ = new JPanel();
		mainMenuPanel_.setPreferredSize( new Dimension( 0, Constants.CONSOLE_BUTTON_PANE_HEIGHT ) );
		mainMenuPanel_.setBorder(
				BorderFactory.createCompoundBorder(
						BorderFactory.createEmptyBorder( Constants.CONSOLE_BORDER_SIZE, Constants.CONSOLE_BORDER_SIZE, Constants.CONSOLE_BORDER_SIZE, Constants.CONSOLE_BORDER_SIZE ),
						mainMenuPanel_.getBorder() ) );

		// Create Sub menu panel with border
		subMenuPanel_ = new JPanel();
		subMenuPanel_.setPreferredSize( new Dimension( 0, Constants.CONSOLE_BUTTON_PANE_HEIGHT ) );
		subMenuPanel_.setBorder(
				BorderFactory.createCompoundBorder(
						BorderFactory.createEmptyBorder( Constants.CONSOLE_BORDER_SIZE, Constants.CONSOLE_BORDER_SIZE, Constants.CONSOLE_BORDER_SIZE, Constants.CONSOLE_BORDER_SIZE ),
						subMenuPanel_.getBorder() ) );

		// Create Input panel with border
		inputPanel_ = new JPanel();
		GridBagLayout inputPaneGridbag = new GridBagLayout();
		inputPanel_.setLayout( inputPaneGridbag );
		inputPanel_.setPreferredSize( new Dimension( 0, Constants.CONSOLE_BUTTON_PANE_HEIGHT ) );
		inputPanel_.setBorder(
				BorderFactory.createCompoundBorder(
						BorderFactory.createEmptyBorder( Constants.CONSOLE_BORDER_SIZE, Constants.CONSOLE_BORDER_SIZE, Constants.CONSOLE_BORDER_SIZE, Constants.CONSOLE_BORDER_SIZE ),
						inputPanel_.getBorder() ) );

		// Create Upper panel buttons
		upperMenuClearYourMindButton_ = new JButton();
		upperMenuClearYourMindButton_.addActionListener( this );

		upperMenuRestartButton_ = new JButton();
		upperMenuRestartButton_.addActionListener( this );

		upperMenuUndoButton_ = new JButton();
		upperMenuUndoButton_.addActionListener( this );

		upperMenuRedoButton_ = new JButton();
		upperMenuRedoButton_.addActionListener( this );


		upperMenuSelectExampleFile_ = new JButton();
		upperMenuSelectExampleFile_.addActionListener( this );

		// Create the file chooser
		fileChooser_ = new JFileChooser( CommonVariables.currentPathStringBuffer + Constants.EXAMPLES_DIRECTORY_NAME_STRING );

		// Create progress bar
		upperMenuProgressLabel_ = new JLabel();

		upperMenuProgressBar_ = new JProgressBar();
		upperMenuProgressBar_.setVisible( false );
		upperMenuProgressBar_.setStringPainted( true );

		// Create the Main menu buttons
		mainMenuAmbiguitySubMenuButton_ = new JButton();
		mainMenuAmbiguitySubMenuButton_.addActionListener( this );

		mainMenuReadTheFileAmbiguityBostonButton_ = new JButton();
		mainMenuReadTheFileAmbiguityBostonButton_.addActionListener( this );

		mainMenuReadTheFileAmbiguityPresidentsButton_ = new JButton();
		mainMenuReadTheFileAmbiguityPresidentsButton_.addActionListener( this );

		mainMenuProgrammingSubMenuButton_ = new JButton();
		mainMenuProgrammingSubMenuButton_.addActionListener( this );

		mainMenuReadTheFileProgrammingConnect4Button_ = new JButton();
		mainMenuReadTheFileProgrammingConnect4Button_.addActionListener( this );

		mainMenuReadTheFileProgrammingGreetingButton_ = new JButton();
		mainMenuReadTheFileProgrammingGreetingButton_.addActionListener( this );

		mainMenuReadTheFileProgrammingTowerOfHanoiButton_ = new JButton();
		mainMenuReadTheFileProgrammingTowerOfHanoiButton_.addActionListener( this );

		mainMenuReasoningSubMenuButton_ = new JButton();
		mainMenuReasoningSubMenuButton_.addActionListener( this );

		mainMenuReadTheFileReasoningFamilyButton_ = new JButton();
		mainMenuReadTheFileReasoningFamilyButton_.addActionListener( this );

		mainMenuFamilyDefinitionsSubMenuButton_ = new JButton();
		mainMenuFamilyDefinitionsSubMenuButton_.addActionListener( this );

		mainMenuFamilyConflictsSubMenuButton_ = new JButton();
		mainMenuFamilyConflictsSubMenuButton_.addActionListener( this );

		mainMenuFamilyJustificationSubMenuButton_ = new JButton();
		mainMenuFamilyJustificationSubMenuButton_.addActionListener( this );

		mainMenuFamilyQuestionsSubMenuButton_ = new JButton();
		mainMenuFamilyQuestionsSubMenuButton_.addActionListener( this );

		mainMenuFamilyShowInfoSubMenuButton_ = new JButton();
		mainMenuFamilyShowInfoSubMenuButton_.addActionListener( this );

		mainMenuBackButton_ = new JButton();
		mainMenuBackButton_.addActionListener( this );

		mainMenuChangeLanguageButton_ = new JButton();
		mainMenuChangeLanguageButton_.addActionListener( this );

		mainMenuHelpButton_ = new JButton();
		mainMenuHelpButton_.addActionListener( this );

		// Create of Sub menu
		initLabel_ = new JLabel();

		for( short index = 0; index < Constants.CONSOLE_MAX_NUMBER_OF_SUBMENU_BUTTONS; index++ )
			subMenuButtonArray_[index] = new JButton();

		for( short index = 0; index < Constants.CONSOLE_MAX_NUMBER_OF_SUBMENU_BUTTONS; index++ )
			subMenuButtonArray_[index].addActionListener( this );

		// Create Input field
		inputField_ = new JTextField();
		inputField_.setFont( new Font( Constants.CONSOLE_MONO_SPACED_FONT, Font.PLAIN, 13 ) );	// Set a mono-spaced (= non-proportional) font for Input field
		inputField_.addActionListener( this );

		// Create password field
		passwordField_ = new JPasswordField();
		passwordField_.setVisible( false );
		passwordField_.addActionListener( this );

		// Create grid bag constraints
		GridBagConstraints westOrientedConstraints = new GridBagConstraints();
		westOrientedConstraints.gridwidth = GridBagConstraints.WEST;
		westOrientedConstraints.fill = GridBagConstraints.BOTH;
		westOrientedConstraints.weightx = 1.0;
		westOrientedConstraints.weighty = 1.0;

		GridBagConstraints eastOrientedConstraints = new GridBagConstraints();
		eastOrientedConstraints.gridwidth = GridBagConstraints.EAST;
		eastOrientedConstraints.fill = GridBagConstraints.BOTH;
		eastOrientedConstraints.weightx = 1.0;
		eastOrientedConstraints.weighty = 1.0;

		GridBagConstraints remainderOrientedConstraints = new GridBagConstraints();
		remainderOrientedConstraints.gridwidth = GridBagConstraints.REMAINDER;
		remainderOrientedConstraints.fill = GridBagConstraints.BOTH;
		remainderOrientedConstraints.weightx = 1.0;
		remainderOrientedConstraints.weighty = 1.0;

		// Add fields to Upper panel
		upperPanel_.add( upperMenuProgressLabel_, westOrientedConstraints );
		upperPanel_.add( upperMenuProgressBar_, eastOrientedConstraints );

		upperPanel_.add( upperMenuClearYourMindButton_ );
		upperPanel_.add( upperMenuRestartButton_ );
		upperPanel_.add( upperMenuUndoButton_ );
		upperPanel_.add( upperMenuRedoButton_ );
		upperPanel_.add( upperMenuSelectExampleFile_ );

		// Add buttons to Main menu panel
		mainMenuPanel_.add( mainMenuAmbiguitySubMenuButton_ );
		mainMenuPanel_.add( mainMenuReadTheFileAmbiguityBostonButton_ );
		mainMenuPanel_.add( mainMenuReadTheFileAmbiguityPresidentsButton_ );

		mainMenuPanel_.add( mainMenuProgrammingSubMenuButton_ );
		mainMenuPanel_.add( mainMenuReadTheFileProgrammingConnect4Button_ );
		mainMenuPanel_.add( mainMenuReadTheFileProgrammingGreetingButton_ );
		mainMenuPanel_.add( mainMenuReadTheFileProgrammingTowerOfHanoiButton_ );

		mainMenuPanel_.add( mainMenuReasoningSubMenuButton_ );
		mainMenuPanel_.add( mainMenuReadTheFileReasoningFamilyButton_ );
		mainMenuPanel_.add( mainMenuFamilyDefinitionsSubMenuButton_ );
		mainMenuPanel_.add( mainMenuFamilyConflictsSubMenuButton_ );
		mainMenuPanel_.add( mainMenuFamilyJustificationSubMenuButton_ );
		mainMenuPanel_.add( mainMenuFamilyQuestionsSubMenuButton_ );
		mainMenuPanel_.add( mainMenuFamilyShowInfoSubMenuButton_ );

		mainMenuPanel_.add( mainMenuBackButton_ );
		mainMenuPanel_.add( mainMenuChangeLanguageButton_ );
		mainMenuPanel_.add( mainMenuHelpButton_ );

		// Add components to Sub menu panel
		subMenuPanel_.add( initLabel_ );

		for( short index = 0; index < Constants.CONSOLE_MAX_NUMBER_OF_SUBMENU_BUTTONS; index++ )
			subMenuPanel_.add( subMenuButtonArray_[index] );

		// Add Input field to Input panel
		inputPanel_.add( inputField_, remainderOrientedConstraints );
		inputPanel_.add( passwordField_, remainderOrientedConstraints );

		// Add pane and panels to the frame
		add( outputScrollPane_, remainderOrientedConstraints );
		add( upperPanel_, remainderOrientedConstraints );
		add( mainMenuPanel_, remainderOrientedConstraints );
		add( subMenuPanel_, remainderOrientedConstraints );
		add( inputPanel_, remainderOrientedConstraints );
		}


	// Protected static methods

	protected static void restart()
		{
		// Initialize private static variables
		hasSelectedAmbiguityBoston_ = false;
		hasSelectedAmbiguityPresidents_ = false;
		hasSelectedProgrammingConnect4_ = false;
		hasSelectedProgrammingGreeting_ = false;
		hasSelectedProgrammingTowerOfHanoi_ = false;
		hasSelectedReasoningFamily_ = false;

		isActionPerformed_ = false;
//		isConsoleReady_ = false;	// Console is ready on restart. So, it shouldn't be initialized

		preferredSubMenuHeight_ = lastVisibleSubMenuButtonY();
		currentSubMenu_ = Constants.CONSOLE_SUBMENU_INIT;
		nSubMenuButtons_ = 0;

		errorHeaderString_ = null;
		errorStringBuffer_ = null;

		currentInterfaceLanguageWordItem_ = null;

		// Disable menus
		enableMenus( false, false );

		// Initialize Sub menus
		setSubMenuVisible( false, Constants.CONSOLE_SUBMENU_INIT );

		// Clear screen
		outputArea_.setText( Constants.NEW_LINE_STRING );

		// Clear possible restart sentence in Input field
		inputField_.setText( Constants.EMPTY_STRING );

		// Disable Input field
		inputField_.setEnabled( false );
		}

	protected static void writeText( String textString )
		{
		Document document;

		waitForConsoleToBeReady();

		if( textString != null )
			{
					// Show text in output area
					outputArea_.append( textString );
	
					if( ( document = outputArea_.getDocument() ) != null )
						// Go to end of text in output area
						outputArea_.setCaretPosition( document.getLength() );
			}
		else
			{
			addError( "Class Console;\nMethod: writeText;\nError: The given text string is undefined." );
			showError();
			}
		}

	protected static void showProgressStatus( String newStatusString )
		{
		if( newStatusString == null )
			upperMenuProgressLabel_.setVisible( false );
		else
			{
			setUpperMenuVisible( false );

			upperMenuProgressLabel_.setText( newStatusString );
			upperMenuProgressLabel_.setVisible( true );
			}
		}

	protected static void startProgress( int startProgress, int maxProgress, String progressString )
		{
		upperMenuProgressBar_.setValue( startProgress );
		upperMenuProgressBar_.setMaximum( maxProgress );

		showProgressStatus( progressString );
		upperMenuProgressBar_.setVisible( true );
		}

	protected static void showProgress( int currentProgress )
		{
		upperMenuProgressBar_.setValue( currentProgress );
		}

	protected static void clearProgress()
		{
		showProgressStatus( null );
		upperMenuProgressBar_.setVisible( false );
		}

	protected static void showError()
		{
		if( errorStringBuffer_ != null )
			{
			JTextArea errorTextArea = new JTextArea( errorStringBuffer_.toString() );
			errorTextArea.setEditable( false );
			JScrollPane errorScrollPane = new JScrollPane( errorTextArea );
			errorScrollPane.setPreferredSize( new Dimension( Constants.CONSOLE_ERROR_PANE_WIDTH, Constants.CONSOLE_ERROR_PANE_HEIGHT ) );
			JOptionPane.showMessageDialog( null, errorScrollPane, ( errorHeaderString_ == null ? Constants.PRESENTATION_ERROR_INTERNAL_TITLE_STRING : Constants.PRESENTATION_ERROR_INTERNAL_TITLE_STRING + errorHeaderString_ ), JOptionPane.ERROR_MESSAGE );
			errorHeaderString_ = null;
			errorStringBuffer_ = null;
			}
		}

	protected static void addError( String newErrorString )
		{
		if( errorStringBuffer_ == null )
			errorStringBuffer_ = new StringBuffer( newErrorString );
		else
			errorStringBuffer_.append( newErrorString ); 
		}

	protected static void addError( String newHeaderString, String newErrorString )
		{
		errorHeaderString_ = newHeaderString;
		addError( newErrorString ); 
		}

	protected static String getPassword()
		{
		if( errorStringBuffer_ != null )
			showError();

		// Prepare password field
		inputField_.setVisible( false );
		passwordField_.setVisible( true );
		passwordField_.requestFocus();
		passwordField_.setText( Constants.EMPTY_STRING );	// Clear previous password

		inputString_ = getInputString();

		// Hide password field again
		inputField_.setVisible( true );
		passwordField_.setVisible( false );

		return inputString_;
		}

	protected static String readLine( boolean clearInputField )
		{
		if( errorStringBuffer_ != null )
			showError();

		// Set the language of the interface
		setInterfaceLanguage();

		// Prepare Input field
		inputField_.setEnabled( true );
		inputField_.requestFocus();

		if( clearInputField )
			{
				// Select all text in Input field
				inputField_.selectAll();
			}
		else
			{
			// Set Upper menu visible
			setUpperMenuVisible( true );

			// Enable menus again
			enableMenus( true, true );

			// Select all text in Input field
			inputField_.selectAll();
			}

		inputString_ = getInputString();

		// Disable Input field
		inputField_.setEnabled( false );

		return inputString_;
		}


	// Public non-static methods

	public void componentHidden( ComponentEvent componentEvent )
		{
		}

	public void componentMoved( ComponentEvent componentEvent )
		{
		resizeFrameComponents( componentEvent );
		}

	public void componentResized( ComponentEvent componentEvent )
		{
		resizeFrameComponents( componentEvent );
		}

	public void componentShown( ComponentEvent componentEvent )
		{
		isConsoleReady_ = true;
		}

	public void actionPerformed( ActionEvent actionEvent )
		{
		Object actionSource;
		String actionCommandString;

		isActionPerformed_ = false;

		if( currentInterfaceLanguageWordItem_ != null )
			{
			if( ( actionSource = actionEvent.getSource() ) != null )
				{
				if( ( actionCommandString = actionEvent.getActionCommand() ) != null )
					{
					// Disable menus during action
					enableMenus( false, false );

					if( actionSource == passwordField_ )
						inputString_ = String.valueOf( passwordField_.getPassword() );
					else
						{
						if( actionSource == inputField_ )
							inputString_ = inputField_.getText();
						else
							{
							if( actionSource == upperMenuClearYourMindButton_ )
								{
								hasSelectedAmbiguityBoston_ = false;
								hasSelectedAmbiguityPresidents_ = false;
								hasSelectedProgrammingConnect4_ = false;
								hasSelectedProgrammingGreeting_ = false;
								hasSelectedProgrammingTowerOfHanoi_ = false;
								hasSelectedReasoningFamily_ = false;

								setSubMenuVisible( true, Constants.CONSOLE_SUBMENU_INIT );

								inputString_ = actionCommandString;
								}
							else
								{
								if( actionSource == upperMenuRestartButton_ )
									{
									inputString_ = actionCommandString;
									restart();
									}
								else
									{
									if( actionSource == upperMenuSelectExampleFile_ )
										{
										if( fileChooser_.showOpenDialog( this ) == JFileChooser.APPROVE_OPTION &&
										fileChooser_.getSelectedFile() != null &&
										fileChooser_.getSelectedFile().getPath() != null )
											inputString_ = Presentation.convertDiacriticalText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_UPPER_MENU_READ_FILE_ACTION_START ) ) + fileChooser_.getSelectedFile().getPath() + Presentation.convertDiacriticalText( currentInterfaceLanguageWordItem_.interfaceString( Constants.INTERFACE_CONSOLE_UPPER_MENU_READ_FILE_ACTION_END ) );
										else
											{
											// When canceled
											enableMenus( true, true );

											inputField_.setEnabled( true );
											inputField_.requestFocus();
											}
										}
									else
										{
										if( actionSource == mainMenuAmbiguitySubMenuButton_ )
											{
											setSubMenuVisible( false, Constants.CONSOLE_SUBMENU_AMBIGUITY );
											enableMenus( true, true );
											}
										else
											{
											if( actionSource == mainMenuReadTheFileAmbiguityBostonButton_ )
												{
												hasSelectedAmbiguityBoston_ = true;
												inputString_ = actionCommandString;
												}
											else
												{
												if( actionSource == mainMenuReadTheFileAmbiguityPresidentsButton_ )
													{
													hasSelectedAmbiguityPresidents_ = true;
													inputString_ = actionCommandString;
													}
												else
													{
													if( actionSource == mainMenuProgrammingSubMenuButton_ )
														{
														setSubMenuVisible( false, ( hasSelectedProgrammingConnect4_ ? Constants.CONSOLE_SUBMENU_PROGRAMMING_CONNECT4 : Constants.CONSOLE_SUBMENU_PROGRAMMING ) );
														enableMenus( true, true );
														}
													else
														{
														if( actionSource == mainMenuReadTheFileProgrammingConnect4Button_ )
															{
															hasSelectedProgrammingConnect4_ = true;
															setSubMenuVisible( false, Constants.CONSOLE_SUBMENU_PROGRAMMING_CONNECT4 );
															inputString_ = actionCommandString;
															}
														else
															{
															if( actionSource == mainMenuReadTheFileProgrammingGreetingButton_ )
																{
																hasSelectedProgrammingGreeting_ = true;
																setSubMenuVisible( false, Constants.CONSOLE_SUBMENU_PROGRAMMING_GREETING );
																inputString_ = actionCommandString;
																}
															else
																{
																if( actionSource == mainMenuReadTheFileProgrammingTowerOfHanoiButton_ )
																	{
																	hasSelectedProgrammingTowerOfHanoi_ = true;
																	setSubMenuVisible( false, Constants.CONSOLE_SUBMENU_PROGRAMMING_TOWER_OF_HANOI );
																	inputString_ = actionCommandString;
																	}
																else
																	{
																	if( actionSource == mainMenuReasoningSubMenuButton_ )
																		{
																		setSubMenuVisible( false, ( hasSelectedReasoningFamily_ ? Constants.CONSOLE_SUBMENU_REASONING_FAMILY_DEFINITIONS : Constants.CONSOLE_SUBMENU_REASONING ) );
																		enableMenus( true, true );
																		}
																	else
																		{
																		if( actionSource == mainMenuReadTheFileReasoningFamilyButton_ )
																			{
																			hasSelectedReasoningFamily_ = true;
																			setSubMenuVisible( false, Constants.CONSOLE_SUBMENU_REASONING_FAMILY_DEFINITIONS );
																			inputString_ = actionCommandString;
																			}
																		else
																			{
																			if( actionSource == mainMenuFamilyDefinitionsSubMenuButton_ )
																				{
																				setSubMenuVisible( false, Constants.CONSOLE_SUBMENU_REASONING_FAMILY_DEFINITIONS );
																				enableMenus( true, true );
																				}
																			else
																				{
																				if( actionSource == mainMenuFamilyConflictsSubMenuButton_ )
																					{
																					setSubMenuVisible( false, Constants.CONSOLE_SUBMENU_REASONING_FAMILY_CONFLICTS );
																					enableMenus( true, true );
																					}
																				else
																					{
																					if( actionSource == mainMenuFamilyJustificationSubMenuButton_ )
																						{
																						setSubMenuVisible( false, Constants.CONSOLE_SUBMENU_REASONING_FAMILY_JUSTIFICATION_REPORT );
																						enableMenus( true, true );
																						}
																					else
																						{
																						if( actionSource == mainMenuFamilyQuestionsSubMenuButton_ )
																							{
																							setSubMenuVisible( false, Constants.CONSOLE_SUBMENU_REASONING_FAMILY_QUESTIONS );
																							enableMenus( true, true );
																							}
																						else
																							{
																							if( actionSource == mainMenuFamilyShowInfoSubMenuButton_ )
																								{
																								setSubMenuVisible( false, Constants.CONSOLE_SUBMENU_REASONING_FAMILY_SHOW_INFO );
																								enableMenus( true, true );
																								}
																							else
																								{
																								if( actionSource == mainMenuBackButton_ )
																									{
																									setSubMenuVisible( false, Constants.CONSOLE_SUBMENU_INIT );
																									enableMenus( true, true );
																									}
																								else
																									{
																									if( actionSource == mainMenuChangeLanguageButton_ )
																										{
																										setSubMenuVisible( false, Constants.CONSOLE_SUBMENU_CHANGE_LANGUAGE );
																										enableMenus( true, true );
																										}
																									else
																										{
																										if( actionSource == mainMenuHelpButton_ )
																											{
																											setSubMenuVisible( false, Constants.CONSOLE_SUBMENU_HELP );
																											inputString_ = actionCommandString;
																											}
																										else
																												inputString_ = actionCommandString;
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}

						if( inputString_ != null )
							{
							if( actionSource != inputField_ )
								inputField_.setText( inputString_ );

							if( actionSource != upperMenuRestartButton_ )
								writeText( inputString_ + Constants.NEW_LINE_STRING );
							}
						}

					isActionPerformed_ = true;
					}
				else
					{
					addError( "Class Console;\nMethod: actionPerformed;\nError: The action command string is undefined." );
					showError();
					}
				}
			else
				{
				addError( "Class Console;\nMethod: actionPerformed;\nError: The action source is undefined." );
				showError();
				}
			}
		else
			{
			addError( "Class Console;\nMethod: actionPerformed;\nError: The current interface language word is undefined." );
			showError();
			}
		}
	};

/*************************************************************************
 *
 *	"I will love the Lord because he hears my voice
 *	and my prayer for mercy.
 *	Because he bends down to listen,
 *	I will pray as long as I breath!" (Psalm 116:1-2)
 *
 *************************************************************************/
