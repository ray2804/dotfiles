/*
 *	Class:			WordTypeList
 *	Parent class:	List
 *	Purpose:		To store word-type items
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

class WordTypeList extends List
	{
	// Private constructible variables

	private WordTypeItem foundWordTypeItem_;


	// Private methods

	private void showWords( boolean returnQueryToPosition, WordTypeItem searchItem )
		{
		String wordTypeString;

		if( CommonVariables.queryStringBuffer == null )
			CommonVariables.queryStringBuffer = new StringBuffer();

		while( searchItem != null )
			{
			if( ( wordTypeString = searchItem.itemString() ) != null )
				{
				if( CommonVariables.hasFoundQuery ||
				CommonVariables.queryStringBuffer.length() > 0 )
					CommonVariables.queryStringBuffer.append( returnQueryToPosition ? Constants.NEW_LINE_STRING : Constants.QUERY_SEPARATOR_SPACE_STRING );

				CommonVariables.hasFoundQuery = true;

				if( !searchItem.isActiveItem() )	// Don't show status with active items
					CommonVariables.queryStringBuffer.append( searchItem.statusChar() );

				CommonVariables.queryStringBuffer.append( wordTypeString );
				}

			searchItem = searchItem.nextWordTypeItem();
			}
		}

	private String wordTypeString( boolean isCurrentLanguage, short orderNr, short wordTypeNr, WordTypeItem searchItem )
		{
		short currentOrderNr = Constants.NO_ORDER_NR;

		while( searchItem != null )
			{
			if( searchItem.wordTypeNr() == wordTypeNr )
				{
				if( currentOrderNr == orderNr )
					return searchItem.itemString();
				else
					currentOrderNr++;
				}
			else
				{
				if( foundWordTypeItem_ == null )
					foundWordTypeItem_ = searchItem;
				}

			searchItem = ( isCurrentLanguage ? searchItem.nextCurrentLanguageWordTypeItem() : searchItem.nextWordTypeItem() );
			}

		return null;
		}

	private WordTypeItem firstActiveWordTypeItem()
		{
		return (WordTypeItem)firstActiveItem();
		}

	private WordTypeItem firstArchivedWordTypeItem()
		{
		return (WordTypeItem)firstArchivedItem();
		}

	private WordTypeItem firstDeletedWordTypeItem()
		{
		return (WordTypeItem)firstDeletedItem();
		}


	// Constructor

	protected WordTypeList( WordItem myWord )
		{
		foundWordTypeItem_ = null;
		initializeListVariables( Constants.WORD_TYPE_LIST_SYMBOL, myWord );
		}


	// Protected methods

	protected void showWords( boolean returnQueryToPosition )
		{
		showWords( returnQueryToPosition, firstActiveWordTypeItem() );
		showWords( returnQueryToPosition, firstArchivedWordTypeItem() );
		showWords( returnQueryToPosition, firstDeletedWordTypeItem() );
		}

	protected void clearWriteLevel( short currentWriteLevel )
		{
		WordTypeItem searchItem = firstActiveWordTypeItem();

		while( searchItem != null )
			{
			searchItem.clearWriteLevel( currentWriteLevel );
			searchItem = searchItem.nextWordTypeItem();
			}
		}

	protected boolean isCorrectHiddenWordType( short wordTypeNr, String compareString, String authorizationKey )
		{
		WordTypeItem searchItem = firstActiveCurrentLanguageWordTypeItem();

		while( searchItem != null )
			{
			if( searchItem.wordTypeNr() == wordTypeNr &&
			searchItem.isCorrectHiddenWordType( compareString, authorizationKey ) )
				return true;

			searchItem = searchItem.nextCurrentLanguageWordTypeItem();
			}

		return false;
		}

	protected byte hideWordTypeItem( short wordTypeNr, String authorizationKey )
		{
		boolean hasFoundWordType = false;
		WordTypeItem searchItem = firstActiveCurrentLanguageWordTypeItem();

		while( searchItem != null &&
		!hasFoundWordType )
			{
			if( searchItem.wordTypeNr() == wordTypeNr )
				{
				if( searchItem.hideWordType( authorizationKey ) == Constants.RESULT_OK )
					hasFoundWordType = true;
				else
					return addError( 1, null, "I failed to hide a word type" );
				}
			else
				searchItem = searchItem.nextCurrentLanguageWordTypeItem();
			}

		if( !hasFoundWordType )
			return startError( 1, null, "I coundn't find the given word type" );

		return CommonVariables.result;
		}

	protected byte deleteWordType( short wordTypeNr )
		{
		boolean hasFoundWordType = false;
		WordTypeItem searchItem = firstActiveWordTypeItem();

		while( searchItem != null &&
		!hasFoundWordType )
			{
			if( searchItem.wordTypeNr() == wordTypeNr &&
			searchItem.wordTypeLanguageNr() == CommonVariables.currentGrammarLanguageNr )
				{
				if( deleteActiveItem( false, searchItem ) == Constants.RESULT_OK )
					hasFoundWordType = true;
				else
					return addError( 1, null, "I failed to delete an active item" );
				}
			else
				searchItem = searchItem.nextWordTypeItem();
			}

		if( !hasFoundWordType )
			return startError( 1, null, "I coundn't find the given word type" );

		return CommonVariables.result;
		}

	protected byte findMatchingWordReferenceString( String searchString )
		{
		WordTypeItem searchItem = firstActiveWordTypeItem();

		CommonVariables.hasFoundMatchingStrings = false;

		while( !CommonVariables.hasFoundMatchingStrings &&
		searchItem != null )
			{
			if( searchItem.itemString() != null )
				{
				if( compareStrings( searchString, searchItem.itemString() ) == Constants.RESULT_OK )
					{
					if( CommonVariables.hasFoundMatchingStrings )
						CommonVariables.matchingWordTypeNr = searchItem.wordTypeNr();
					}
				else
					return addError( 1, null, "I failed to compare an active word type string with the query string" );
				}

			searchItem = searchItem.nextWordTypeItem();
			}

		searchItem = firstArchivedWordTypeItem();

		while( !CommonVariables.hasFoundMatchingStrings &&
		searchItem != null )
			{
			if( searchItem.itemString() != null )
				{
				if( compareStrings( searchString, searchItem.itemString() ) == Constants.RESULT_OK )
					{
					if( CommonVariables.hasFoundMatchingStrings )
						CommonVariables.matchingWordTypeNr = searchItem.wordTypeNr();
					}
				else
					return addError( 1, null, "I failed to compare a deleted word type string with the query string" );
				}

			searchItem = searchItem.nextWordTypeItem();
			}

		searchItem = firstDeletedWordTypeItem();

		while( !CommonVariables.hasFoundMatchingStrings &&
		searchItem != null )
			{
			if( searchItem.itemString() != null )
				{
				if( compareStrings( searchString, searchItem.itemString() ) == Constants.RESULT_OK )
					{
					if( CommonVariables.hasFoundMatchingStrings )
						CommonVariables.matchingWordTypeNr = searchItem.wordTypeNr();
					}
				else
					return addError( 1, null, "I failed to compare a deleted word type string with the query string" );
				}

			searchItem = searchItem.nextWordTypeItem();
			}

		return CommonVariables.result;
		}

	protected byte markWordTypeAsWritten( short wordTypeNr )
		{
		boolean hasFoundWordTypeNr = false;
		WordTypeItem pluralNounWordTypeItem = null;
		WordTypeItem singularNounWordTypeItem = null;
		WordTypeItem searchItem = firstActiveWordTypeItem();

		if( wordTypeNr > Constants.WORD_TYPE_UNDEFINED &&
		wordTypeNr < Constants.NUMBER_OF_WORD_TYPES )
			{
			while( searchItem != null )
				{
				if( !searchItem.isWordAlreadyWritten() )
					{
					if( searchItem.isWordTypeSingularNoun() )
						singularNounWordTypeItem = searchItem;
					else
						{
						if( searchItem.isWordTypePluralNoun() )
							pluralNounWordTypeItem = searchItem;
						}

					if( searchItem.wordTypeNr() == wordTypeNr )
						{
						if( searchItem.markWordTypeAsWritten() == Constants.RESULT_OK )
							hasFoundWordTypeNr = true;
						else
							return addError( 1, null, "I failed to mark a word as written" );
						}
					}

				searchItem = searchItem.nextWordTypeItem();
				}

			if( hasFoundWordTypeNr )
				{
				if( wordTypeNr == Constants.WORD_TYPE_NOUN_SINGULAR &&	// If singular noun - also set plural noun
				pluralNounWordTypeItem != null )
					{
					if( pluralNounWordTypeItem.markWordTypeAsWritten() != Constants.RESULT_OK )
						return addError( 1, null, "I failed to mark a plural noun word as written" );
					}
				else
					{
					if( wordTypeNr == Constants.WORD_TYPE_NOUN_PLURAL &&	// If plural noun - also set singular noun
					singularNounWordTypeItem != null )
						{
						if( singularNounWordTypeItem.markWordTypeAsWritten() != Constants.RESULT_OK )
							return addError( 1, null, "I failed to mark a singular noun word as written" );
						}
					}
				}
			else
				return startError( 1, null, "I couldn't find the given word type number" );
			}
		else
			return startError( 1, null, "The given word type number is undefined or out of bounds" );

		return CommonVariables.result;
		}

	protected byte createWordTypeItem( boolean isPropernamePrecededByDefiniteArticle, short definiteArticleParameter, short indefiniteArticleParameter, short wordTypeNr, int wordLength, String wordTypeString )
		{
		if( wordTypeNr > Constants.WORD_TYPE_UNDEFINED &&
		wordTypeNr < Constants.NUMBER_OF_WORD_TYPES )
			{
			if( wordTypeString != null )
				{
				if( CommonVariables.currentItemNr < Constants.MAX_ITEM_NR )
					{
					if( addItemToActiveList( (Item)( new WordTypeItem( isPropernamePrecededByDefiniteArticle, definiteArticleParameter, indefiniteArticleParameter, CommonVariables.currentGrammarLanguageNr, wordTypeNr, wordLength, wordTypeString, this, myWord() ) ) ) != Constants.RESULT_OK )
						return addError( 1, null, "I failed to add an active word type item" );
					}
				else
					return startError( 1, null, "The current item number is undefined" );
				}
			else
				return startError( 1, null, "The given wordTypeString is undefined" );
			}
		else
			return startError( 1, null, "The given word type number is undefined or out of bounds" );

		return CommonVariables.result;
		}

	protected WordResultType checkWordTypeForBeenWritten( short wordTypeNr )
		{
		WordResultType wordResult = new WordResultType();
		boolean hasFound = false;
		WordTypeItem searchItem = firstActiveWordTypeItem();

		if( wordTypeNr > Constants.WORD_TYPE_UNDEFINED &&
		wordTypeNr < Constants.NUMBER_OF_WORD_TYPES )
			{
			while( searchItem != null &&
			!hasFound )
				{
				if( searchItem.wordTypeNr() == wordTypeNr )
					{
					hasFound = true;
					wordResult.isWordAlreadyWritten = searchItem.isWordAlreadyWritten();
					}
				else
					searchItem = searchItem.nextWordTypeItem();
				}

			if( !hasFound )
				startError( 1, null, "I couldn't find the given word type number" );
			}
		else
			startError( 1, null, "The given word type number is undefined or out of bounds" );

		wordResult.result = CommonVariables.result;
		return wordResult;
		}

	protected String wordTypeString( boolean checkAllLanguages, short orderNr, short wordTypeNr )
		{
		String foundWordTypeString;

		foundWordTypeItem_ = null;

		// Try to find word type from the current language
		if( ( foundWordTypeString = wordTypeString( true, orderNr, wordTypeNr, firstActiveCurrentLanguageWordTypeItem() ) ) == null )
			{
			if( ( foundWordTypeString = wordTypeString( true, orderNr, wordTypeNr, firstArchivedCurrentLanguageWordTypeItem() ) ) == null )
				{
				if( ( foundWordTypeString = wordTypeString( true, orderNr, wordTypeNr, firstDeletedCurrentLanguageWordTypeItem() ) ) == null )
					{
					// Not found in current language. Now, try all languages
					if( ( checkAllLanguages ||
					myWord().isGrammarLanguage() ) &&

					( foundWordTypeString = wordTypeString( false, orderNr, wordTypeNr, firstActiveWordTypeItem() ) ) == null )
						{
						if( ( foundWordTypeString = wordTypeString( false, orderNr, wordTypeNr, firstArchivedWordTypeItem() ) ) == null )
							foundWordTypeString = wordTypeString( false, orderNr, wordTypeNr, firstDeletedWordTypeItem() );
						}
					}
				}
			}

		return ( foundWordTypeString == null ? ( foundWordTypeItem_ == null ? null : foundWordTypeItem_.itemString() ) : foundWordTypeString );
		}

	protected String activeWordTypeString( boolean checkAllLanguages, short wordTypeNr )
		{
		WordTypeItem foundWordTypeItem;

		if( ( foundWordTypeItem = activeWordTypeItem( checkAllLanguages, wordTypeNr ) ) != null )
			return foundWordTypeItem.itemString();

		return null;
		}

	protected WordTypeItem activeWordTypeItem( boolean checkAllLanguages, short wordTypeNr )
		{
		WordTypeItem searchItem = firstActiveCurrentLanguageWordTypeItem();

		// Check current language first
		while( searchItem != null )
			{
			if( wordTypeNr == Constants.WORD_TYPE_UNDEFINED ||
			searchItem.wordTypeNr() == wordTypeNr )
				return searchItem;

			searchItem = searchItem.nextCurrentLanguageWordTypeItem();
			}

		// Not found in current language, then try all languages
		if( checkAllLanguages ||
		myWord().isGrammarLanguage() )
			{
			searchItem = firstActiveWordTypeItem();

			while( searchItem != null )
				{
				if( wordTypeNr == Constants.WORD_TYPE_UNDEFINED ||
				searchItem.wordTypeNr() == wordTypeNr )
					return searchItem;

				searchItem = searchItem.nextWordTypeItem();
				}
			}

		return null;
		}

	protected WordTypeItem firstActiveCurrentLanguageWordTypeItem()
		{
		WordTypeItem searchItem = firstActiveWordTypeItem();

		while( searchItem != null &&
		searchItem.wordTypeLanguageNr() < CommonVariables.currentGrammarLanguageNr )
			searchItem = searchItem.nextWordTypeItem();

		return searchItem;
		}

	protected WordTypeItem firstArchivedCurrentLanguageWordTypeItem()
		{
		WordTypeItem searchItem = firstArchivedWordTypeItem();

		while( searchItem != null &&
		searchItem.wordTypeLanguageNr() < CommonVariables.currentGrammarLanguageNr )
			searchItem = searchItem.nextWordTypeItem();

		return searchItem;
		}

	protected WordTypeItem firstDeletedCurrentLanguageWordTypeItem()
		{
		WordTypeItem searchItem = firstDeletedWordTypeItem();

		while( searchItem != null &&
		searchItem.wordTypeLanguageNr() < CommonVariables.currentGrammarLanguageNr )
			searchItem = searchItem.nextWordTypeItem();

		return searchItem;
		}
	};

/*************************************************************************
 *
 *	"He lifts the poor from the dust
 *	and needy from the garbage dump.
 *	He sets them among princes,
 *	even princes of his own people!" (Psalm 113:7-8)
 *
 *************************************************************************/
