/*
 *	Class:			InterfaceItem
 *	Parent class:	Item
 *	Purpose:		To store info about the interface messages
 *					in a certain language that can be shown to the user
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include <limits.h>
#include "Item.h"

class InterfaceItem : private Item
	{
	friend class InterfaceList;

	// Private loadable variables

	unsigned short interfaceParameter_;

	char *interfaceString_;


	protected:
	// Protected constructible variables


	// Constructor

	InterfaceItem( unsigned short interfaceParameter, size_t interfaceStringLength, char *interfaceString, List *myList, WordItem *myWord, CommonVariables *commonVariables )
		{
		initializeItemVariables( NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, "InterfaceItem", myList, myWord, commonVariables );

		// Private loadable variables

		interfaceParameter_ = interfaceParameter;
		interfaceString_ = NULL;

		// Protected constructible variables

		if( interfaceString != NULL )
			{
			if( interfaceStringLength < MAX_READ_WRITE_STRING_LENGTH &&
			strlen( interfaceString ) < MAX_READ_WRITE_STRING_LENGTH )
				{
				if( ( interfaceString_ = new char[interfaceStringLength + 1] ) != NULL )
					{
					strncpy( interfaceString_, interfaceString, interfaceStringLength );
					interfaceString_[interfaceStringLength] = NULL_CHAR;
					}
				else
					startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, NULL, "I failed to create the interface string" );
				}
			else
				startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, NULL, "The given interface string is too long" );
			}
		else
			startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, NULL, "The given interface string is undefined" );
		}

	~InterfaceItem()
		{
		if( interfaceString_ != NULL )
			delete interfaceString_;
		}


	// Protected virtual functions

	virtual void showString( bool returnQueryToPosition )
		{
		char statusString[2] = SPACE_STRING;
		statusString[0] = statusChar();

		if( interfaceString_ != NULL )
			{
			if( commonVariables()->hasFoundQuery )
				strcat( commonVariables()->queryString, ( returnQueryToPosition ? NEW_LINE_STRING : QUERY_SEPARATOR_SPACE_STRING ) );

			if( !isActiveItem() )	// Show status when not active
				strcat( commonVariables()->queryString, statusString );

			commonVariables()->hasFoundQuery = true;
			strcat( commonVariables()->queryString, interfaceString_ );
			}
		}

	virtual bool hasFoundParameter( unsigned int queryParameter )
		{
		return ( interfaceParameter_ == queryParameter ||

				( queryParameter == MAX_QUERY_PARAMETER &&
				interfaceParameter_ > NO_INTERFACE_PARAMETER ) );
		}

	virtual char *itemString()
		{
		return interfaceString_;
		}

	virtual char *toString( unsigned short queryWordTypeNr )
		{
		Item::toString( queryWordTypeNr );

		if( interfaceParameter_ > NO_INTERFACE_PARAMETER )
			{
			sprintf( tempString, "%cinterfaceParameter:%u", QUERY_SEPARATOR_CHAR, interfaceParameter_ );
			strcat( commonVariables()->queryString, tempString );
			}

		if( interfaceString_ != NULL )
			{
			sprintf( tempString, "%cinterfaceString:%c%s%c", QUERY_SEPARATOR_CHAR, QUERY_STRING_START_CHAR, interfaceString_, QUERY_STRING_END_CHAR );
			strcat( commonVariables()->queryString, tempString );
			}

		return commonVariables()->queryString;
		}


	// Protected functions

	unsigned short interfaceParameter()
		{
		return interfaceParameter_;
		}

	char *interfaceString()
		{
		return interfaceString_;
		}

	InterfaceItem *nextInterfaceItem()
		{
		return (InterfaceItem *)nextItem;
		}
	};

/*************************************************************************
 *
 *	"O Lord, what are human beings that you should notice them,
 *	mere mortals that you should think about them?" (Psalm 144:3)
 *
 *************************************************************************/
