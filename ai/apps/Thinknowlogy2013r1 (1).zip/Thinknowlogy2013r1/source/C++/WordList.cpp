/*
 *	Class:			WordList
 *	Parent class:	List
 *	Purpose:		To store word items
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#ifndef WORDLIST
#define WORDLIST 1
#include <limits.h>
#include "List.h"
#include "WordItem.h"

class WordList : private List
	{
	friend class AdminCleanup;
	friend class AdminReadCreateWords;


	// Private deconstructor functions

	void deleteWordList( WordItem *searchItem )
		{
		WordItem *deleteItem;

		while( searchItem != NULL )
			{
			deleteItem = searchItem;
			searchItem = searchItem->nextWordItem();
			delete deleteItem;
			}
		}

	// Private assignment functions

	ResultType createNewAssignmentLevelInWordList( WordItem *searchItem )
		{
		while( commonVariables()->result == RESULT_OK &&
		searchItem != NULL )
			{
			searchItem->createNewAssignmentLevel();
			searchItem = searchItem->nextWordItem();
			}

		return commonVariables()->result;
		}


	// Private cleanup functions

	unsigned int highestSentenceNrInWordList( WordItem *searchItem )
		{
		unsigned int tempSentenceNr;
		unsigned int highestSentenceNr = NO_SENTENCE_NR;

		while( searchItem != NULL )
			{
			if( ( tempSentenceNr = searchItem->highestSentenceNr() ) > highestSentenceNr )
				highestSentenceNr = tempSentenceNr;

			searchItem = searchItem->nextWordItem();
			}

		return highestSentenceNr;
		}

	ResultType getCurrentItemNrInWordList( WordItem *searchItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "getCurrentItemNrInWordList";
		while( searchItem != NULL )
			{
			if( searchItem->getCurrentItemNrInWord() == RESULT_OK )
				searchItem = searchItem->nextWordItem();
			else
				return addError( functionNameString, NULL, "I failed to get the current item number in a word" );
			}

		return commonVariables()->result;
		}

	ResultType rollbackDeletedRedoInfoInWordList( WordItem *searchItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "rollbackDeletedRedoInfoInWordList";
		while( searchItem != NULL )
			{
			if( searchItem->rollbackDeletedRedoInfo() == RESULT_OK )
				searchItem = searchItem->nextWordItem();
			else
				return addError( functionNameString, NULL, "I failed to rollback a deleted item in a word" );
			}

		return commonVariables()->result;
		}

	ResultType deleteRollbackInfoInWordList( WordItem *searchItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteRollbackInfoInWordList";
		while( searchItem != NULL )
			{
			if( searchItem->deleteRollbackInfo() == RESULT_OK )
				searchItem = searchItem->nextWordItem();
			else
				return addError( functionNameString, NULL, "I failed to delete the rollback info in a word" );
			}

		return commonVariables()->result;
		}

	ResultType deleteSentencesInWordList( bool isAvailableForRollback, unsigned int lowestSentenceNr, WordItem *searchItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteSentencesInWordList";
		while( searchItem != NULL )
			{
			if( searchItem->deleteSentencesInWord( isAvailableForRollback, lowestSentenceNr ) == RESULT_OK )
				searchItem = searchItem->nextWordItem();
			else
				return addError( functionNameString, NULL, "I failed to delete sentences in a word" );
			}

		return commonVariables()->result;
		}

	ResultType removeFirstRangeOfDeletedItemsInWordList( WordItem *searchItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "removeFirstRangeOfDeletedItemsInWordList";
		while( searchItem != NULL &&
		commonVariables()->nDeletedItems == 0 )
			{
			if( searchItem->removeFirstRangeOfDeletedItems() == RESULT_OK )
				searchItem = searchItem->nextWordItem();
			else
				return addError( functionNameString, NULL, "I failed to remove the first deleted items in a word" );
			}

		return commonVariables()->result;
		}

	ResultType getHighestInUseSentenceNrInWordList( bool includeDeletedItems, bool includeLanguageAssignments, bool includeTemporaryLists, unsigned int highestSentenceNr, WordItem *searchItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "getHighestInUseSentenceNrInWordList";
		while( searchItem != NULL &&
		commonVariables()->highestInUseSentenceNr < highestSentenceNr )
			{
			if( searchItem->getHighestInUseSentenceNrInWord( includeDeletedItems, includeLanguageAssignments, includeTemporaryLists, highestSentenceNr ) == RESULT_OK )
				searchItem = searchItem->nextWordItem();
			else
				return addError( functionNameString, NULL, "I failed to check if the sentence is empty in a word" );
			}

		return commonVariables()->result;
		}

	ResultType decrementSentenceNrsInWordList( unsigned int startSentenceNr, WordItem *searchItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "decrementSentenceNrsInWordList";
		while( searchItem != NULL )
			{
			if( searchItem->decrementSentenceNrsInWord( startSentenceNr ) == RESULT_OK )
				searchItem = searchItem->nextWordItem();
			else
				return addError( functionNameString, NULL, "I failed to decrement the sentence numbers from the current sentence number in a word" );
			}

		return commonVariables()->result;
		}

	ResultType decrementItemNrRangeInWordList( unsigned int decrementSentenceNr, unsigned int decrementItemNr, unsigned int decrementOffset, WordItem *searchItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "decrementItemNrRangeInWordList";
		while( searchItem != NULL )
			{
			if( searchItem->decrementItemNrRangeInWord( decrementSentenceNr, decrementItemNr, decrementOffset ) == RESULT_OK )
				searchItem = searchItem->nextWordItem();
			else
				return addError( functionNameString, NULL, "I failed to decrement item numbers in a word" );
			}

		return commonVariables()->result;
		}


	// Private query functions

	void countQueryInWordList( WordItem *searchItem )
		{
		while( searchItem != NULL )
			{
			searchItem->countQuery();
			searchItem = searchItem->nextWordItem();
			}
		}

	void clearQuerySelectionsInWordList( WordItem *searchItem )
		{
		while( searchItem != NULL )
			{
			searchItem->clearQuerySelections();
			searchItem = searchItem->nextWordItem();
			}
		}

	ResultType wordQueryInWordList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *wordNameString, WordItem *searchItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "wordQueryInWordList";
		while( searchItem != NULL )
			{
			if( searchItem->wordQueryInWord( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordNameString ) == RESULT_OK )
				searchItem = searchItem->nextWordItem();
			else
				return addError( functionNameString, NULL, "I failed to query a word" );
			}

		return commonVariables()->result;
		}

	ResultType itemQueryInWordList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, bool isReferenceQuery, unsigned int querySentenceNr, unsigned int queryItemNr, WordItem *searchItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "itemQueryInWordList";
		while( searchItem != NULL )
			{
			if( searchItem->itemQueryInWord( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, isReferenceQuery, querySentenceNr, queryItemNr ) == RESULT_OK )
				searchItem = searchItem->nextWordItem();
			else
				return addError( functionNameString, NULL, "I failed to query item numbers in a word" );
			}

		return commonVariables()->result;
		}

	ResultType listQueryInWordList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *queryListString, WordItem *searchItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "listQueryInWordList";
		while( searchItem != NULL )
			{
			if( searchItem->listQueryInWord( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryListString ) == RESULT_OK )
				searchItem = searchItem->nextWordItem();
			else
				return addError( functionNameString, NULL, "I failed to query lists in a word" );
			}

		return commonVariables()->result;
		}

	ResultType wordTypeQueryInWordList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, unsigned short queryWordTypeNr, WordItem *searchItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "wordTypeQueryInWordList";
		while( searchItem != NULL )
			{
			if( searchItem->wordTypeQueryInWord( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryWordTypeNr ) == RESULT_OK )
				searchItem = searchItem->nextWordItem();
			else
				return addError( functionNameString, NULL, "I failed to query word types in a word" );
			}

		return commonVariables()->result;
		}

	ResultType parameterQueryInWordList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, unsigned int queryParameter, WordItem *searchItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "parameterQueryInWordList";
		while( searchItem != NULL )
			{
			if( isFirstInstruction &&
			searchItem->hasFoundParameter( queryParameter ) )
				searchItem->isSelectedByQuery = true;

//			if( searchItem->isSelectedByQuery )
				{
				if( searchItem->parameterQueryInWord( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryParameter ) != RESULT_OK )
					return addError( functionNameString, NULL, "I failed to query parameters in a word" );
				}

			searchItem = searchItem->nextWordItem();
			}

		return commonVariables()->result;
		}

	ResultType wordReferenceQueryInWordList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *wordReferenceNameString, WordItem *searchItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "wordReferenceQueryInWordList";
		while( searchItem != NULL )
			{
			if( searchItem->wordReferenceQueryInWord( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordReferenceNameString ) == RESULT_OK )
				searchItem = searchItem->nextWordItem();
			else
				return addError( functionNameString, NULL, "I failed to query word references in a word" );
			}

		return commonVariables()->result;
		}

	ResultType stringQueryInWordList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *queryString, WordItem *searchItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "stringQueryInWordList";
		while( searchItem != NULL )
			{
			if( searchItem->stringQueryInWord( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryString ) == RESULT_OK )
				searchItem = searchItem->nextWordItem();
			else
				return addError( functionNameString, NULL, "I failed to query strings in a word" );
			}

		return commonVariables()->result;
		}

	ResultType showQueryResultInWordList( bool showOnlyWords, bool showOnlyWordReferences, bool showOnlyStrings, bool returnQueryToPosition, unsigned short promptTypeNr, unsigned short queryWordTypeNr, size_t queryWidth, WordItem *searchItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "showQueryResultInWordList";
		while( searchItem != NULL )
			{
			if( searchItem->showQueryResultInWord( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth ) == RESULT_OK )
				searchItem = searchItem->nextWordItem();
			else
				return addError( functionNameString, NULL, "I failed to show the query result in a word" );
			}

		return commonVariables()->result;
		}


	// Private common functions

	WordItem *firstActiveWordItem()
		{
		return (WordItem *)firstActiveItem();
		}

	WordItem *firstDeactiveWordItem()
		{
		return (WordItem *)firstDeactiveItem();
		}

	WordItem *firstArchivedWordItem()
		{
		return (WordItem *)firstArchivedItem();
		}

	WordItem *firstDeletedWordItem()
		{
		return (WordItem *)firstDeletedItem();
		}


	public:
	// Constructor

	WordList( WordItem *myWord, CommonVariables *commonVariables )
		{
		initializeListVariables( ADMIN_WORD_LIST_SYMBOL, "WordList", myWord, commonVariables );
		}

	// Deconstructor

	~WordList()
		{
		deleteWordList( firstActiveWordItem() );
		deleteWordList( firstDeactiveWordItem() );
		deleteWordList( firstArchivedWordItem() );
		deleteWordList( firstDeletedWordItem() );
		}


	// Protected assignment functions

	ResultType createNewAssignmentLevelInWordList()
		{
		if( createNewAssignmentLevelInWordList( firstActiveWordItem() ) == RESULT_OK )
			return createNewAssignmentLevelInWordList( firstDeactiveWordItem() );

		return commonVariables()->result;
		}


	// Protected cleanup functions

	unsigned int highestSentenceNrInWordList()
		{
		unsigned int tempSentenceNr;
		unsigned int highestSentenceNr = highestSentenceNrInWordList( firstActiveWordItem() );

		if( ( tempSentenceNr = highestSentenceNrInWordList( firstDeactiveWordItem() ) ) > highestSentenceNr )
			highestSentenceNr = tempSentenceNr;

		if( ( tempSentenceNr = highestSentenceNrInWordList( firstArchivedWordItem() ) ) > highestSentenceNr )
			highestSentenceNr = tempSentenceNr;

		if( ( tempSentenceNr = highestSentenceNrInWordList( firstDeletedWordItem() ) ) > highestSentenceNr )
			highestSentenceNr = tempSentenceNr;

		return highestSentenceNr;
		}

	ResultType getCurrentItemNrInWordList()
		{
		if( getCurrentItemNrInWordList( firstActiveWordItem() ) == RESULT_OK )
			{
			if( getCurrentItemNrInWordList( firstDeactiveWordItem() ) == RESULT_OK )
				{
				if( getCurrentItemNrInWordList( firstArchivedWordItem() ) == RESULT_OK )
					return getCurrentItemNrInWordList( firstDeletedWordItem() );
				}
			}

		return commonVariables()->result;
		}

	ResultType rollbackDeletedRedoInfoInWordList()
		{
		if( rollbackDeletedRedoInfoInWordList( firstActiveWordItem() ) == RESULT_OK )
			{
			if( rollbackDeletedRedoInfoInWordList( firstDeactiveWordItem() ) == RESULT_OK )
				{
				if( rollbackDeletedRedoInfoInWordList( firstArchivedWordItem() ) == RESULT_OK )
					return rollbackDeletedRedoInfoInWordList( firstDeletedWordItem() );
				}
			}

		return commonVariables()->result;
		}

	ResultType deleteRollbackInfoInWordList()
		{
		if( deleteRollbackInfoInWordList( firstActiveWordItem() ) == RESULT_OK )
			{
			if( deleteRollbackInfoInWordList( firstDeactiveWordItem() ) == RESULT_OK )
				return deleteRollbackInfoInWordList( firstArchivedWordItem() );
			}

		return commonVariables()->result;
		}

	ResultType deleteSentencesInWordList( bool isAvailableForRollback, unsigned int lowestSentenceNr )
		{
		if( deleteSentencesInWordList( isAvailableForRollback, lowestSentenceNr, firstActiveWordItem() ) == RESULT_OK )
			{
			if( deleteSentencesInWordList( isAvailableForRollback, lowestSentenceNr, firstDeactiveWordItem() ) == RESULT_OK )
				{
				if( deleteSentencesInWordList( isAvailableForRollback, lowestSentenceNr, firstArchivedWordItem() ) == RESULT_OK )
					return deleteSentencesInWordList( isAvailableForRollback, lowestSentenceNr, firstDeletedWordItem() );
				}
			}

		return commonVariables()->result;
		}

	ResultType removeFirstRangeOfDeletedItemsInWordList()
		{
		if( removeFirstRangeOfDeletedItemsInWordList( firstActiveWordItem() ) == RESULT_OK )
			{
			if( removeFirstRangeOfDeletedItemsInWordList( firstDeactiveWordItem() ) == RESULT_OK )
				{
				if( removeFirstRangeOfDeletedItemsInWordList( firstArchivedWordItem() ) == RESULT_OK )
					return removeFirstRangeOfDeletedItemsInWordList( firstDeletedWordItem() );
				}
			}

		return commonVariables()->result;
		}

	ResultType getHighestInUseSentenceNrInWordList( bool includeDeletedItems, bool includeLanguageAssignments, bool includeTemporaryLists, unsigned int highestSentenceNr )
		{
		if( getHighestInUseSentenceNrInWordList( includeDeletedItems, includeLanguageAssignments, includeTemporaryLists, highestSentenceNr, firstActiveWordItem() ) == RESULT_OK )
			{
			if( commonVariables()->highestInUseSentenceNr < highestSentenceNr )
				{
				if( getHighestInUseSentenceNrInWordList( includeDeletedItems, includeLanguageAssignments, includeTemporaryLists, highestSentenceNr, firstDeactiveWordItem() ) == RESULT_OK )
					{
					if( commonVariables()->highestInUseSentenceNr < highestSentenceNr )
						{
						if( getHighestInUseSentenceNrInWordList( includeDeletedItems, includeLanguageAssignments, includeTemporaryLists, highestSentenceNr, firstArchivedWordItem() ) == RESULT_OK )
							{
							if( includeDeletedItems &&
							commonVariables()->highestInUseSentenceNr < highestSentenceNr )
								return getHighestInUseSentenceNrInWordList( includeDeletedItems, includeLanguageAssignments, includeTemporaryLists, highestSentenceNr, firstDeletedWordItem() );
							}
						}
					}
				}
			}

		return commonVariables()->result;
		}

	ResultType decrementSentenceNrsInWordList( unsigned int startSentenceNr )
		{
		if( decrementSentenceNrsInWordList( startSentenceNr, firstActiveWordItem() ) == RESULT_OK )
			{
			if( decrementSentenceNrsInWordList( startSentenceNr, firstDeactiveWordItem() ) == RESULT_OK )
				{
				if( decrementSentenceNrsInWordList( startSentenceNr, firstArchivedWordItem() ) == RESULT_OK )
					return decrementSentenceNrsInWordList( startSentenceNr, firstDeletedWordItem() );
				}
			}

		return commonVariables()->result;
		}

	ResultType decrementItemNrRangeInWordList( unsigned int decrementSentenceNr, unsigned int decrementItemNr, unsigned int decrementOffset )
		{
		if( decrementItemNrRangeInWordList( decrementSentenceNr, decrementItemNr, decrementOffset, firstActiveWordItem() ) == RESULT_OK )
			{
			if( decrementItemNrRangeInWordList( decrementSentenceNr, decrementItemNr, decrementOffset, firstDeactiveWordItem() ) == RESULT_OK )
				{
				if( decrementItemNrRangeInWordList( decrementSentenceNr, decrementItemNr, decrementOffset, firstArchivedWordItem() ) == RESULT_OK )
					return decrementItemNrRangeInWordList( decrementSentenceNr, decrementItemNr, decrementOffset, firstDeletedWordItem() );
				}
			}

		return commonVariables()->result;
		}


	// Protected query functions

	void countQueryInWordList()
		{
		countQueryInWordList( firstActiveWordItem() );
		countQueryInWordList( firstDeactiveWordItem() );
		countQueryInWordList( firstArchivedWordItem() );
		countQueryInWordList( firstDeletedWordItem() );
		}

	void clearQuerySelectionsInWordList()
		{
		clearQuerySelectionsInWordList( firstActiveWordItem() );
		clearQuerySelectionsInWordList( firstDeactiveWordItem() );
		clearQuerySelectionsInWordList( firstArchivedWordItem() );
		clearQuerySelectionsInWordList( firstDeletedWordItem() );
		}

	ResultType wordQueryInWordList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *wordNameString )
		{
		if( wordQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordNameString, firstActiveWordItem() ) == RESULT_OK )
			{
			if( wordQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordNameString, firstDeactiveWordItem() ) == RESULT_OK )
				{
				if( wordQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordNameString, firstArchivedWordItem() ) == RESULT_OK )
					return wordQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordNameString, firstDeletedWordItem() );
				}
			}

		return commonVariables()->result;
		}

	ResultType itemQueryInWordList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, bool isReferenceQuery, unsigned int querySentenceNr, unsigned int queryItemNr )
		{
		if( itemQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, isReferenceQuery, querySentenceNr, queryItemNr, firstActiveWordItem() ) == RESULT_OK )
			{
			if( itemQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, isReferenceQuery, querySentenceNr, queryItemNr, firstDeactiveWordItem() ) == RESULT_OK )
				{
				if( itemQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, isReferenceQuery, querySentenceNr, queryItemNr, firstArchivedWordItem() ) == RESULT_OK )
					return itemQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, isReferenceQuery, querySentenceNr, queryItemNr, firstDeletedWordItem() );
				}
			}

		return commonVariables()->result;
		}

	ResultType listQueryInWordList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *queryListString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "listQueryInWordList";
		if( listQueryInList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryListString ) == RESULT_OK )
			{
			if( listQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryListString, firstActiveWordItem() ) == RESULT_OK )
				{
				if( listQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryListString, firstDeactiveWordItem() ) == RESULT_OK )
					{
					if( listQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryListString, firstArchivedWordItem() ) == RESULT_OK )
						return listQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryListString, firstDeletedWordItem() );
					}
				}
			}
		else
			return addError( functionNameString, NULL, "I failed to query my own list" );

		return commonVariables()->result;
		}

	ResultType wordTypeQueryInWordList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, unsigned short queryWordTypeNr )
		{
		if( wordTypeQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryWordTypeNr, firstActiveWordItem() ) == RESULT_OK )
			{
			if( wordTypeQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryWordTypeNr, firstDeactiveWordItem() ) == RESULT_OK )
				{
				if( wordTypeQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryWordTypeNr, firstArchivedWordItem() ) == RESULT_OK )
					return wordTypeQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryWordTypeNr, firstDeletedWordItem() );
				}
			}

		return commonVariables()->result;
		}

	ResultType parameterQueryInWordList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, unsigned int queryParameter )
		{
		if( parameterQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryParameter, firstActiveWordItem() ) == RESULT_OK )
			{
			if( parameterQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryParameter, firstDeactiveWordItem() ) == RESULT_OK )
				{
				if( parameterQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryParameter, firstArchivedWordItem() ) == RESULT_OK )
					return parameterQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryParameter, firstDeletedWordItem() );
				}
			}

		return commonVariables()->result;
		}

	ResultType wordReferenceQueryInWordList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *wordReferenceNameString )
		{
		if( wordReferenceQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordReferenceNameString, firstActiveWordItem() ) == RESULT_OK )
			{
			if( wordReferenceQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordReferenceNameString, firstDeactiveWordItem() ) == RESULT_OK )
				{
				if( wordReferenceQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordReferenceNameString, firstArchivedWordItem() ) == RESULT_OK )
					return wordReferenceQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordReferenceNameString, firstDeletedWordItem() );
				}
			}

		return commonVariables()->result;
		}

	ResultType stringQueryInWordList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *queryString )
		{
		if( stringQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryString, firstActiveWordItem() ) == RESULT_OK )
			{
			if( stringQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryString, firstDeactiveWordItem() ) == RESULT_OK )
				{
				if( stringQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryString, firstArchivedWordItem() ) == RESULT_OK )
					return stringQueryInWordList( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryString, firstDeletedWordItem() );
				}
			}

		return commonVariables()->result;
		}

	ResultType showQueryResultInWordList( bool showOnlyWords, bool showOnlyWordReferences, bool showOnlyStrings, bool returnQueryToPosition, unsigned short promptTypeNr, unsigned short queryWordTypeNr, size_t queryWidth )
		{
		if( showQueryResultInWordList( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth, firstActiveWordItem() ) == RESULT_OK )
			{
			if( showQueryResultInWordList( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth, firstDeactiveWordItem() ) == RESULT_OK )
				{
				if( showQueryResultInWordList( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth, firstArchivedWordItem() ) == RESULT_OK )
					return showQueryResultInWordList( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth, firstDeletedWordItem() );
				}
			}

		return commonVariables()->result;
		}


	// Protected read word functions

	WordResultType createWordItem( unsigned short wordParameter )
		{
		WordResultType wordResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "createWordItem";

		if( commonVariables()->currentItemNr < MAX_ITEM_NR )
			{
			// Create word
			if( ( wordResult.createdWordItem = new WordItem( wordParameter, this, commonVariables() ) ) != NULL )
				{
				if( addItemToActiveList( (Item *)wordResult.createdWordItem ) != RESULT_OK )
					addError( functionNameString, NULL, "I failed to add an active word item" );
				}
			else
				startError( functionNameString, NULL, "I failed to create a word item" );
			}
		else
			startError( functionNameString, NULL, "The current item number is undefined" );

		wordResult.result = commonVariables()->result;
		return wordResult;
		}
	};
#endif

/*************************************************************************
 *
 *	"They share freely and give generously to those in need.
 *	Their good deeds will be remembered forever.
 *	They will have influence and honor." (Psalm 112:9)
 *
 *************************************************************************/
