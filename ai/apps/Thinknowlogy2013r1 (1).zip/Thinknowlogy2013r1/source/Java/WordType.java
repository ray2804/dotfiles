/*
 *	Class:			WordType
 *	Supports class:	WordItem
 *	Purpose:		To create word-type structures
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

class WordType
	{
	// Private constructible variables

	private WordItem myWord_;
	private String moduleNameString_;


	// Constructor

	protected WordType( WordItem myWord )
		{
		String errorString = null;

		myWord_ = myWord;
		moduleNameString_ = this.getClass().getName();

		if( myWord_ == null )
			errorString = "The given my word is undefined";

		if( errorString != null )
			{
			if( myWord_ != null )
				myWord_.startSystemErrorInWord( 1, moduleNameString_, errorString );
			else
				{
				CommonVariables.result = Constants.RESULT_SYSTEM_ERROR;
				Console.addError( "\nClass:" + moduleNameString_ + "\nMethod:\t" + Constants.PRESENTATION_ERROR_CONSTRUCTOR_METHOD_NAME + "\nError:\t\t" + errorString + ".\n" );
				}
			}
		}


	// Protected methods

	protected byte addWordType( boolean isPropernamePrecededByDefiniteArticle, short definiteArticleParameter, short indefiniteArticleParameter, short wordTypeNr, int wordLength, String wordTypeString )
		{
		WordResultType wordResult = new WordResultType();

		if( !myWord_.iAmAdmin() )
			{
			if( myWord_.wordTypeList == null )
				{
				// Create list
				if( ( myWord_.wordTypeList = new WordTypeList( myWord_ ) ) != null )
					myWord_.wordList[Constants.WORD_TYPE_LIST] = myWord_.wordTypeList;
				else
					return myWord_.startErrorInWord( 1, moduleNameString_, "I failed to create a word type list" );
				}
			else
				{
				// Find out if already exists
				if( ( wordResult = findWordType( false, wordTypeNr, wordTypeString ) ).result != Constants.RESULT_OK )
					return myWord_.addErrorInWord( 1, moduleNameString_, "I failed to find the given word type" );
				}

			if( wordResult.foundWordTypeItem == null )		// Word type doesn't exist yet
				return myWord_.wordTypeList.createWordTypeItem( isPropernamePrecededByDefiniteArticle, definiteArticleParameter, indefiniteArticleParameter, wordTypeNr, wordLength, wordTypeString );
			}
		else
			return myWord_.startErrorInWord( 1, moduleNameString_, "The admin does not have word types" );

		return CommonVariables.result;
		}

	protected WordResultType findWordType( boolean checkAllLanguages, short searchWordTypeNr, String searchWordString )
		{
		WordResultType wordResult = new WordResultType();
		int currentWordStringLength;
		int searchWordStringLength;
		String currentWordString;
		WordTypeItem currentWordTypeItem;

		if( searchWordString != null )
			{
			if( ( searchWordStringLength = searchWordString.length() ) > 0 )
				{
				if( ( currentWordTypeItem = myWord_.activeWordTypeItem( checkAllLanguages, searchWordTypeNr ) ) != null )
					{
					do	{
						if( ( currentWordString = currentWordTypeItem.itemString() ) != null )	// Could be hidden word type
							{
							if( ( currentWordStringLength = currentWordString.length() ) > 0 )
								{
								if( searchWordStringLength == currentWordStringLength &&
								searchWordString.equals( currentWordString ) )
									wordResult.foundWordTypeItem = currentWordTypeItem;
								}
							else
								myWord_.startErrorInWord( 1, moduleNameString_, "The active word type string is empty" );
							}
						}
					while( CommonVariables.result == Constants.RESULT_OK &&
					wordResult.foundWordTypeItem == null &&
					( currentWordTypeItem = currentWordTypeItem.nextWordTypeItem( searchWordTypeNr ) ) != null );
					}
				}
			else
				myWord_.startErrorInWord( 1, moduleNameString_, "The given search word string is empty" );
			}
		else
			myWord_.startErrorInWord( 1, moduleNameString_, "The given search word string is undefined" );

		wordResult.result = CommonVariables.result;
		return wordResult;
		}

	protected WordResultType findWordTypeInAllWords( boolean checkAllLanguages, short searchWordTypeNr, String searchWordString, WordItem previousWordItem )
		{
		WordResultType wordResult = new WordResultType();
		WordItem currentWordItem;

		if( ( currentWordItem = ( previousWordItem == null ? CommonVariables.firstWordItem : previousWordItem.nextWordItem() ) ) != null )
			{
			do	{
				if( ( wordResult = currentWordItem.findWordType( checkAllLanguages, searchWordTypeNr, searchWordString ) ).result == Constants.RESULT_OK )
					{
					if( wordResult.foundWordTypeItem != null )
						wordResult.foundWordItem = currentWordItem;
					}
				else
					myWord_.addErrorInWord( 1, moduleNameString_, "I failed to find a word type in word \"" + currentWordItem.anyWordTypeString() + "\"" );
				}
			while( wordResult.foundWordItem == null &&
			( currentWordItem = currentWordItem.nextWordItem() ) != null );
			}

		wordResult.result = CommonVariables.result;
		return wordResult;
		}

	protected String wordTypeString( boolean checkAllLanguages, short orderNr, short wordTypeNr )
		{
		String wordTypeString = ( myWord_.wordTypeList == null ? null : myWord_.wordTypeList.wordTypeString( checkAllLanguages, orderNr, wordTypeNr ) );

		if( orderNr == Constants.NO_ORDER_NR &&
		wordTypeString == null )
			return ( Constants.QUERY_ITEM_START_STRING + myWord_.creationSentenceNr() + Constants.QUERY_SEPARATOR_CHAR + myWord_.itemNr() + Constants.QUERY_ITEM_END_CHAR );

		return wordTypeString;
		}
	};

/*************************************************************************
 *
 *	"Let them praise your great and awesome name.
 *	Your name is holy!" (Psalm 99:3)
 *
 *************************************************************************/
