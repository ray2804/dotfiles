/*
 *	Class:			GrammarItem
 *	Parent class:	Item
 *	Purpose:		To store info about the grammar of a language, which
 *					will be used for reading as well as writing sentences
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

class GrammarItem extends Item
	{
	// Private loadable variables

	private boolean isDefinitionStart_;
	private boolean isNewStart_;
	private boolean isOptionStart_;
	private boolean isChoiceStart_;
	private boolean skipOptionForWriting_;

	private short grammarParameter_;
	private short grammarWordTypeNr_;

	private String grammarString_;


	// Protected constructible variables

	protected boolean isOptionEnd;
	protected boolean isChoiceEnd;
	protected boolean isGrammarItemInUse;

	protected GrammarItem nextDefinitionGrammarItem;

	protected String guideByGrammarString;


	// Protected loadable variables

	protected GrammarItem definitionGrammarItem;


	// Private methods

	private GrammarItem pluralNounEndingGrammarItem( boolean includeThisItem )
		{
		GrammarItem searchItem = ( includeThisItem ? this : nextGrammarItem() );

		while( searchItem != null )
			{
			if( searchItem.isPluralNounEnding() )
				return searchItem;

			searchItem = searchItem.nextGrammarItem();
			}

		return null;
		}


	// Constructor

	protected GrammarItem( boolean isDefinitionStart, boolean isNewStart, boolean isOptionStart, boolean isChoiceStart, boolean skipOptionForWriting, short grammarWordTypeNr, short grammarParameter, int grammarStringLength, String grammarString, GrammarItem _grammarDefinitionWordItem, List myList, WordItem myWord )
		{
		initializeItemVariables( Constants.NO_SENTENCE_NR, Constants.NO_SENTENCE_NR, Constants.NO_SENTENCE_NR, Constants.NO_SENTENCE_NR, myList, myWord );

		// Private loadable variables

		isDefinitionStart_ = isDefinitionStart;
		isNewStart_ = isNewStart;
		isOptionStart_ = isOptionStart;
		isChoiceStart_ = isChoiceStart;
		skipOptionForWriting_ = skipOptionForWriting;

		grammarParameter_ = grammarParameter;
		grammarWordTypeNr_ = grammarWordTypeNr;

		grammarString_ = null;

		if( grammarString != null )
			grammarString_ = grammarString.substring( 0, grammarStringLength );
		else
			startSystemErrorInItem( 1, null, null, "The given grammar string is undefined" );


		// Protected constructible variables

		isOptionEnd = false;
		isChoiceEnd = false;
		isGrammarItemInUse = false;

		nextDefinitionGrammarItem = null;

		guideByGrammarString = null;

		// Protected loadable variables

		definitionGrammarItem = _grammarDefinitionWordItem;
		}


	// Protected virtual methods

	protected void showString( boolean returnQueryToPosition )
		{
		if( CommonVariables.queryStringBuffer == null )
			CommonVariables.queryStringBuffer = new StringBuffer();

		if( grammarString_ != null )
			{
			if( CommonVariables.hasFoundQuery )
				CommonVariables.queryStringBuffer.append( returnQueryToPosition ? Constants.NEW_LINE_STRING : Constants.QUERY_SEPARATOR_SPACE_STRING );

			if( !isActiveItem() )	// Show status when not active
				CommonVariables.queryStringBuffer.append( statusChar() );

			CommonVariables.hasFoundQuery = true;
			CommonVariables.queryStringBuffer.append( grammarString_ );
			}

		if( guideByGrammarString != null )
			{
			if( CommonVariables.hasFoundQuery )
				CommonVariables.queryStringBuffer.append( returnQueryToPosition ? Constants.NEW_LINE_STRING : Constants.QUERY_SEPARATOR_SPACE_STRING );

			if( !isActiveItem() )	// Show status when not active
				CommonVariables.queryStringBuffer.append( statusChar() );

			CommonVariables.hasFoundQuery = true;
			CommonVariables.queryStringBuffer.append( guideByGrammarString );
			}
		}

	protected boolean hasFoundParameter( int queryParameter )
		{
		return ( grammarParameter_ == queryParameter ||

				( queryParameter == Constants.MAX_QUERY_PARAMETER &&
				grammarParameter_ > Constants.NO_GRAMMAR_PARAMETER ) );
		}

	protected boolean hasFoundReferenceItemById( int querySentenceNr, int queryItemNr )
		{
		return ( ( definitionGrammarItem == null ? false :
					( querySentenceNr == Constants.NO_SENTENCE_NR ? true : definitionGrammarItem.creationSentenceNr() == querySentenceNr ) &&
					( queryItemNr == Constants.NO_ITEM_NR ? true : definitionGrammarItem.itemNr() == queryItemNr ) ) ||

				( nextDefinitionGrammarItem == null ? false :
					( querySentenceNr == Constants.NO_SENTENCE_NR ? true : nextDefinitionGrammarItem.creationSentenceNr() == querySentenceNr ) &&
					( queryItemNr == Constants.NO_ITEM_NR ? true : nextDefinitionGrammarItem.itemNr() == queryItemNr ) ) );
		}

	protected boolean hasFoundWordType( short queryWordTypeNr )
		{
		return ( grammarWordTypeNr_ == queryWordTypeNr );
		}

	protected byte checkForUsage()
		{
		return myWord().checkGrammarForUsageInWord( this );
		}

	protected String itemString()
		{
		return grammarString_;
		}

	protected String extraItemString()
		{
		return guideByGrammarString;
		}

	protected StringBuffer toStringBuffer( short queryWordTypeNr )
		{
		String grammarWordTypeString = myWord().wordTypeName( grammarWordTypeNr_ );
		baseToStringBuffer( queryWordTypeNr );

		if( isDefinitionStart_ )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "isDefinitionStart" );

		if( isNewStart_ )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "isNewStart" );

		if( isOptionStart_ )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "isOptionStart" );

		if( isOptionEnd )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "isOptionEnd" );

		if( isChoiceStart_ )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "isChoiceStart" );

		if( isChoiceEnd )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "isChoiceEnd" );

		if( skipOptionForWriting_ )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "skipOptionForWriting" );
/*
		if( isGrammarItemInUse )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "isGrammarItemInUse" );
*/
		if( grammarParameter_ > Constants.NO_GRAMMAR_PARAMETER )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "grammarParameter:" + grammarParameter_ );

		if( grammarWordTypeNr_ > Constants.WORD_TYPE_UNDEFINED )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "grammarWordType:" + ( grammarWordTypeString == null ? Constants.QUERY_WORD_TYPE_STRING + grammarWordTypeNr_ : grammarWordTypeString ) );

		if( grammarString_ != null )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "grammarString:" + Constants.QUERY_STRING_START_CHAR + grammarString_ + Constants.QUERY_STRING_END_CHAR );

		if( guideByGrammarString != null )
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "guideByGrammarString:" + Constants.QUERY_STRING_START_CHAR + guideByGrammarString + Constants.QUERY_STRING_END_CHAR );

		if( definitionGrammarItem != null )
			{
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "definitionGrammarItem" + Constants.QUERY_REF_ITEM_START_CHAR + definitionGrammarItem.creationSentenceNr() + Constants.QUERY_SEPARATOR_CHAR + definitionGrammarItem.itemNr() + Constants.QUERY_REF_ITEM_END_CHAR );
			}

		if( nextDefinitionGrammarItem != null )
			{
			CommonVariables.queryStringBuffer.append( Constants.QUERY_SEPARATOR_STRING + "nextDefinitionGrammarItem" + Constants.QUERY_REF_ITEM_START_CHAR + nextDefinitionGrammarItem.creationSentenceNr() + Constants.QUERY_SEPARATOR_CHAR + nextDefinitionGrammarItem.itemNr() + Constants.QUERY_REF_ITEM_END_CHAR );
			}

		return CommonVariables.queryStringBuffer;
		}


	// Protected methods

	protected boolean isAllowedToEnterNewWord()
		{
		return ( grammarWordTypeNr_ == Constants.WORD_TYPE_PROPER_NAME ||
				grammarWordTypeNr_ == Constants.WORD_TYPE_ADJECTIVE ||
				grammarWordTypeNr_ == Constants.WORD_TYPE_NOUN_SINGULAR ||
				grammarWordTypeNr_ == Constants.WORD_TYPE_NOUN_PLURAL );
		}

	protected boolean isDefinitionStart()
		{
		return isDefinitionStart_;
		}

	protected boolean isNewStart()
		{
		return isNewStart_;
		}

	protected boolean isOptionStart()
		{
		return isOptionStart_;
		}

	protected boolean isChoiceStart()
		{
		return isChoiceStart_;
		}

	protected boolean isGrammarDefinition()
		{
		return ( grammarParameter_ >= Constants.GRAMMAR_SENTENCE );
		}

	protected boolean skipOptionForWriting()
		{
		return skipOptionForWriting_;
		}

	protected boolean isPredefinedWord()
		{
		return ( grammarWordTypeNr_ > Constants.WORD_TYPE_UNDEFINED &&

				grammarParameter_ > Constants.NO_GRAMMAR_PARAMETER &&
				grammarParameter_ < Constants.WORD_PLURAL_NOUN_ENDINGS );
		}

	protected boolean isUserDefinedWord()
		{
		return ( grammarWordTypeNr_ > Constants.WORD_TYPE_UNDEFINED &&
				grammarParameter_ == Constants.NO_GRAMMAR_PARAMETER );
		}

	protected boolean isPluralNounEnding()
		{
		return ( grammarParameter_ == Constants.WORD_PLURAL_NOUN_ENDINGS );
		}

	protected boolean isGrammarStart()
		{
		return ( grammarParameter_ == Constants.GRAMMAR_SENTENCE );
		}

	protected boolean hasWordType()
		{
		return ( grammarWordTypeNr_ > Constants.WORD_TYPE_UNDEFINED );
		}

	protected boolean isSymbol()
		{
		return ( grammarWordTypeNr_ == Constants.WORD_TYPE_SYMBOL );
		}

	protected boolean isWordTypeNumeral()
		{
		return ( grammarWordTypeNr_ == Constants.WORD_TYPE_NUMERAL );
		}

	protected boolean isWordTypeSingularNoun()
		{
		return ( grammarWordTypeNr_ == Constants.WORD_TYPE_NOUN_SINGULAR );
		}

	protected boolean isWordTypePluralNoun()
		{
		return ( grammarWordTypeNr_ == Constants.WORD_TYPE_NOUN_PLURAL );
		}

	protected boolean isWordTypeText()
		{
		return ( grammarWordTypeNr_ == Constants.WORD_TYPE_TEXT );
		}

	protected boolean isIdentical( GrammarItem checkGrammarItem )
		{
		return ( checkGrammarItem != null &&

				isNewStart_ == checkGrammarItem.isNewStart() &&
				isOptionStart_ == checkGrammarItem.isOptionStart() &&
				isOptionEnd == checkGrammarItem.isOptionEnd &&
				isChoiceStart_ == checkGrammarItem.isChoiceStart() &&
				isChoiceEnd == checkGrammarItem.isChoiceEnd &&
				grammarParameter_ == checkGrammarItem.grammarParameter() &&
				grammarWordTypeNr_ == checkGrammarItem.grammarWordTypeNr() &&
				itemNr() == checkGrammarItem.itemNr() &&

				grammarString_ != null &&
				checkGrammarItem.grammarString() != null &&
				grammarString_.equals( checkGrammarItem.grammarString() ) );
		}

	protected boolean isUniqueGrammarDefinition( GrammarItem checkGrammarItem )
		{
		String checkGrammarString;
		GrammarItem searchItem = this;

		if( checkGrammarItem != null &&
		( checkGrammarString = checkGrammarItem.grammarString() ) != null )
			{
			while( searchItem != null )
				{
				if( searchItem.isDefinitionStart() &&
				searchItem != checkGrammarItem &&
				searchItem.grammarString().equals( checkGrammarString ) )
					return false;

				searchItem = searchItem.nextGrammarItem();
				}
			}

		return true;
		}

	protected short definiteArticleParameter()
		{
		if( grammarParameter_ == Constants.WORD_PARAMETER_ARTICLE_DEFINITE_1 ||
		grammarParameter_ == Constants.WORD_PARAMETER_ARTICLE_DEFINITE_2 )
			return grammarParameter_;

		return Constants.NO_DEFINITE_ARTICLE_PARAMETER;
		}

	protected short indefiniteArticleParameter()
		{
		if( grammarParameter_ == Constants.WORD_PARAMETER_ARTICLE_INDEFINITE_1 ||
		grammarParameter_ == Constants.WORD_PARAMETER_ARTICLE_INDEFINITE_2 )
			return grammarParameter_;

		return Constants.NO_INDEFINITE_ARTICLE_PARAMETER;
		}

	protected short grammarParameter()
		{
		return grammarParameter_;
		}

	protected short grammarWordTypeNr()
		{
		return grammarWordTypeNr_;
		}

	protected String grammarString()
		{
		return grammarString_;
		}

	protected GrammarItem nextGrammarItem()
		{
		return (GrammarItem)nextItem;
		}

	protected GrammarItem firstPluralNounEndingGrammarItem()
		{
		return pluralNounEndingGrammarItem( true );
		}

	protected GrammarItem nextPluralNounEndingGrammarItem()
		{
		return pluralNounEndingGrammarItem( false );
		}
	};

/*************************************************************************
 *
 *	"For the Lord is good.
 *	His unfailing love continues forever,
 *	and his faithfulness continues to each generation." (Psalm 100:5)
 *
 *************************************************************************/
