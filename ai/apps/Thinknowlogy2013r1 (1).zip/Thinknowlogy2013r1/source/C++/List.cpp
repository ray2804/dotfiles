/*
 *	Class:		List
 *	Purpose:	Base class to store the items of the knowledge structure
 *	Version:	Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "ListCleanup.cpp"
#include "ListQuery.cpp"

	// Private functions

	bool List::includesThisList( char *queryListString )
		{
		unsigned short index = 0;

		if( queryListString != NULL &&
		strlen( queryListString ) > 0 )
			{
			while( index < strlen( queryListString ) &&
			queryListString[index] != listChar_ )
				index++;

			if( index == strlen( queryListString ) )
				return false;
			}

		return true;
		}

	ResultType List::checkForUsage( Item *unusedItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkForUsage";
		if( unusedItem != NULL )
			return unusedItem->checkForUsage();

		return startError( functionNameString, NULL, "The given unused item is undefined" );
		}

	ResultType List::removeItemFromActiveList( Item *removeItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "removeItemFromActiveList";
		if( removeItem != NULL )
			{
			if( removeItem->myList() == this )
				{
				if( removeItem->isActiveItem() )
					{
					if( removeItem->previousItem == NULL )	// First item in list
						{
						activeList_ = removeItem->nextItem;

						if( removeItem->nextItem != NULL )
							removeItem->nextItem->previousItem = NULL;
						}
					else
						{
						removeItem->previousItem->nextItem = removeItem->nextItem;

						if( removeItem->nextItem != NULL )
							removeItem->nextItem->previousItem = removeItem->previousItem;
						}

					nextListItem_ = removeItem->nextItem;	// Remember next item

					// Disconnect item from active list
					removeItem->previousItem = NULL;
					removeItem->nextItem = NULL;
					}
				else
					return startError( functionNameString, NULL, "The given remove item isn't an active item" );
				}
			else
				return startError( functionNameString, NULL, "The given remove item doesn't belong to my list" );
			}
		else
			return startError( functionNameString, NULL, "The given remove item is undefined" );

		return commonVariables_->result;
		}

	ResultType List::removeItemFromDeactiveList( Item *removeItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "removeItemFromDeactiveList";
		if( removeItem != NULL )
			{
			if( removeItem->myList() == this )
				{
				if( removeItem->isDeactiveItem() )
					{
					if( removeItem->previousItem == NULL )	// First item in list
						{
						deactiveList_ = removeItem->nextItem;

						if( removeItem->nextItem != NULL )
							removeItem->nextItem->previousItem = NULL;
						}
					else
						{
						removeItem->previousItem->nextItem = removeItem->nextItem;

						if( removeItem->nextItem != NULL )
							removeItem->nextItem->previousItem = removeItem->previousItem;
						}

					nextListItem_ = removeItem->nextItem;	// Remember next item

					// Disconnect item from deactive list
					removeItem->previousItem = NULL;
					removeItem->nextItem = NULL;
					}
				else
					return startError( functionNameString, NULL, "The given remove item isn't a deactive item" );
				}
			else
				return startError( functionNameString, NULL, "The given remove item doesn't belong to my list" );
			}
		else
			return startError( functionNameString, NULL, "The given remove item is undefined" );

		return commonVariables_->result;
		}

	ResultType List::removeItemFromArchivedList( Item *removeItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "removeItemFromArchivedList";
		if( removeItem != NULL )
			{
			if( removeItem->myList() == this )
				{
				if( removeItem->isArchivedItem() )
					{
					if( removeItem->previousItem == NULL )	// First item in list
						{
						archiveList_ = removeItem->nextItem;

						if( removeItem->nextItem != NULL )
							removeItem->nextItem->previousItem = NULL;
						}
					else
						{
						removeItem->previousItem->nextItem = removeItem->nextItem;

						if( removeItem->nextItem != NULL )
							removeItem->nextItem->previousItem = removeItem->previousItem;
						}

					nextListItem_ = removeItem->nextItem;	// Remember next item

					// Disconnect item from deactive list
					removeItem->previousItem = NULL;
					removeItem->nextItem = NULL;
					}
				else
					return startError( functionNameString, NULL, "The given remove item isn't an archive item" );
				}
			else
				return startError( functionNameString, NULL, "The given remove item doesn't belong to my list" );
			}
		else
			return startError( functionNameString, NULL, "The given remove item is undefined" );

		return commonVariables_->result;
		}

	ResultType List::addItemToDeletedList( bool isAvailableForRollback, Item *newItem )
		{
		Item *searchItem = deleteList_;
		Item *previousSearchItem = NULL;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addItemToDeletedList";

		if( newItem != NULL )
			{
			if( newItem->myList() == this )
				{
				if( newItem->isDeletedItem() )
					{
					if( newItem->nextItem == NULL )
						{
						// Sort item in list
						while( searchItem != NULL &&
						( searchItem->creationSentenceNr() > newItem->creationSentenceNr() ||	// Sort on descending

						( searchItem->creationSentenceNr() == newItem->creationSentenceNr() &&	// creationSentenceNr and
						searchItem->itemNr() < newItem->itemNr() ) ) )							// ascending itemNr
							{
							previousSearchItem = searchItem;
							searchItem = searchItem->nextItem;
							}

						if( searchItem == NULL ||
						searchItem->creationSentenceNr() != newItem->creationSentenceNr() ||	// Check on duplicates
						searchItem->itemNr() != newItem->itemNr() )								// for integrity
							{
							newItem->previousItem = previousSearchItem;

							if( previousSearchItem == NULL )	// First item in list
								{
								if( deleteList_ != NULL )
									deleteList_->previousItem = newItem;

								newItem->nextItem = deleteList_;
								deleteList_ = newItem;
								}
							else
								{
								if( searchItem != NULL )
									searchItem->previousItem = newItem;

								newItem->nextItem = previousSearchItem->nextItem;
								previousSearchItem->nextItem = newItem;
								}

							newItem->isAvailableForRollback = isAvailableForRollback;
							}
						else
							return startError( functionNameString, NULL, "I found a deleted item with the same identification" );
						}
					else
						return startError( functionNameString, NULL, "The given new item seems to be a part of a list" );
					}
				else
					return startError( functionNameString, NULL, "The given new item isn't a deleted item" );
				}
			else
				return startError( functionNameString, NULL, "The given new item doesn't belong to my list" );
			}
		else
			return startError( functionNameString, NULL, "The given new item is undefined" );

		return commonVariables_->result;
		}


	// Constructor

	List::List()
		{
		// Private constructible variables

		listChar_ = QUERY_NO_LIST_CHAR;

		activeList_ = NULL;
		deactiveList_ = NULL;
		archiveList_ = NULL;
		deleteList_ = NULL;

		nextListItem_ = NULL;

		listCleanup_ = NULL;
		listQuery_ = NULL;

		myWord_ = NULL;
		commonVariables_ = NULL;

		strcpy( classNameString_, EMPTY_STRING );
		strcpy( superClassNameString_, "List" );
		}

	List::~List()
		{
		if( listCleanup_ != NULL )
			delete listCleanup_;
		if( listQuery_ != NULL )
			delete listQuery_;
		}


	// Protected error functions

	ResultType List::addError( const char *functionNameString, const char *moduleNameString, const char *errorString )
		{
		if( commonVariables_ != NULL &&
		commonVariables_->presentation != NULL )
			commonVariables_->presentation->showError( listChar_, ( moduleNameString == NULL ? classNameString_ : moduleNameString ), ( moduleNameString == NULL ? superClassNameString_ : NULL ), NULL, functionNameString, errorString );
		else
			fprintf( stderr, "\nClass:\t%s\nSubclass:\t%s\nFunction:\t%s\nError:\t\t%s.\n", classNameString_, superClassNameString_, functionNameString, errorString );

		return ( commonVariables() == NULL ? RESULT_ERROR : commonVariables()->result );
		}

	ResultType List::startError( const char *functionNameString, const char *moduleNameString, const char *errorString )
		{
		addError( functionNameString, moduleNameString, errorString );

		if( commonVariables_ != NULL )
		commonVariables_->result = RESULT_ERROR;

		return RESULT_ERROR;
		}

	ResultType List::startError( const char *functionNameString, const char *moduleNameString, const char *_errorString, unsigned int errorSentenceNr )
		{
		char errorString[MAX_ERROR_STRING_LENGTH];
		sprintf( errorString, "%s%u", _errorString, errorSentenceNr );
		return startError( functionNameString, moduleNameString, errorString );
		}

	ResultType List::startError( const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3 )
		{
		char errorString[MAX_ERROR_STRING_LENGTH];
		sprintf( errorString, "%s%s%s", errorString1, errorString2, errorString3 );
		return startError( functionNameString, moduleNameString, errorString );
		}

	ResultType List::startSystemError( const char *functionNameString, const char *moduleNameString, const char *errorString )
		{
		addError( functionNameString, moduleNameString, errorString );

		if( commonVariables_ != NULL )
		commonVariables_->result = RESULT_SYSTEM_ERROR;

		return RESULT_SYSTEM_ERROR;
		}


	// Protected virtual functions

	bool List::isTemporaryList()
		{
		return false;
		}

	ResultType List::findWordReference( WordItem *referenceWordItem )
		{
		// This is a virtual function. Therefore the given variables are unreferenced
		char functionNameString[FUNCTION_NAME_LENGTH] = "findWordReference";
		if( commonVariables_ != NULL )
		commonVariables_->hasFoundWordReference = false;
		else
			return startError( functionNameString, NULL, "The common variables is undefined" );
		return commonVariables_->result;
		}


	// Protected common functions

	void List::initializeListVariables( char listChar, const char *classNameString, WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		listChar_ = listChar;
		myWord_ = myWord;
		commonVariables_ = commonVariables;

		if( myWord_ != NULL )
			{
			if( commonVariables_ != NULL )
				{
				if( classNameString != NULL )
					strcpy( classNameString_, classNameString );
				else
					strcpy( errorString, "The given class name string is undefined" );
				}
			else
				strcpy( errorString, "The given common variables is undefined" );
			}
		else
			strcpy( errorString, "The given my word is undefined" );

		if( strlen( errorString ) > 0 )
			startSystemError( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, errorString );
		}

	void List::deleteList()
		{
		Item *nextItem;
		Item *searchItem = deleteList_;

		// Get tail item of delete list
		while( searchItem != NULL &&
		( nextItem = searchItem->nextItem ) != NULL )
			searchItem = nextItem;

		if( searchItem == NULL )
			{
			deleteList_ = activeList_;
			searchItem = activeList_;
			}
		else
			searchItem->nextItem = activeList_;

		activeList_ = NULL;

		// Get tail item of delete list
		while( searchItem != NULL &&
		( nextItem = searchItem->nextItem ) != NULL )
			searchItem = nextItem;

		if( searchItem == NULL )
			{
			deleteList_ = deactiveList_;
			searchItem = deactiveList_;
			}
		else
			searchItem->nextItem = deactiveList_;

		deactiveList_ = NULL;

		// Get tail item of delete list
		while( searchItem != NULL &&
		( nextItem = searchItem->nextItem ) != NULL )
			searchItem = nextItem;

		if( searchItem == NULL )
			deleteList_ = archiveList_;
		else
			searchItem->nextItem = archiveList_;

		archiveList_ = NULL;
		}

	bool List::hasItems()
		{
		return ( activeList_ != NULL ||
				deactiveList_ != NULL ||
				archiveList_ != NULL );
		}

	bool List::hasActiveItems()
		{
		return ( activeList_ != NULL );
		}

	bool List::isAdminList()
		{
		return ( isupper( listChar_ ) != 0 );
		}

	bool List::isAssignmentList()
		{
		return ( listChar_ == WORD_ASSIGNMENT_LIST_SYMBOL );
		}

	unsigned int List::highestSentenceNrInList()
		{
		unsigned int highestSentenceNr = NO_SENTENCE_NR;
		Item *searchItem = activeList_;

		while( searchItem != NULL )
			{
			if( searchItem->creationSentenceNr() > highestSentenceNr )
				highestSentenceNr = searchItem->creationSentenceNr();

			searchItem = searchItem->nextItem;
			}

		searchItem = deactiveList_;

		while( searchItem != NULL )
			{
			if( searchItem->creationSentenceNr() > highestSentenceNr )
				highestSentenceNr = searchItem->creationSentenceNr();

			searchItem = searchItem->nextItem;
			}

		searchItem = archiveList_;

		while( searchItem != NULL )
			{
			if( searchItem->creationSentenceNr() > highestSentenceNr )
				highestSentenceNr = searchItem->creationSentenceNr();

			searchItem = searchItem->nextItem;
			}

		return highestSentenceNr;
		}

	char List::listChar()
		{
		return listChar_;
		}

	ResultType List::addItemToActiveList( Item *newItem )
		{
		Item *searchItem = activeList_;
		Item *previousSearchItem = NULL;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addItemToActiveList";

		if( newItem != NULL )
			{
			if( newItem->myList() == this )
				{
				if( newItem->isActiveItem() )
					{
					if( newItem->nextItem == NULL )
						{
						newItem->setActiveSentenceNr();

						// Sort item in list
						while( searchItem != NULL &&
						!newItem->isSorted( searchItem ) )
							{
							previousSearchItem = searchItem;
							searchItem = searchItem->nextItem;
							}

						if( searchItem == NULL ||
						searchItem->creationSentenceNr() != newItem->creationSentenceNr() ||	// Check on duplicates
						searchItem->itemNr() != newItem->itemNr() )								// for integrity
							{
							newItem->previousItem = previousSearchItem;

							if( previousSearchItem == NULL )	// First item in list
								{
								if( activeList_ != NULL )
									activeList_->previousItem = newItem;

								newItem->nextItem = activeList_;
								activeList_ = newItem;
								}
							else
								{
								if( searchItem != NULL )
									searchItem->previousItem = newItem;

								newItem->nextItem = previousSearchItem->nextItem;
								previousSearchItem->nextItem = newItem;
								}
							}
						else
							return startError( functionNameString, NULL, "I found an active item with the same identification" );
						}
					else
						return startError( functionNameString, NULL, "The given new item seems to be a part of a list" );
					}
				else
					return startError( functionNameString, NULL, "The given new item isn't an active item" );
				}
			else
				return startError( functionNameString, NULL, "The given new item doesn't belong to my list" );
			}
		else
			return startError( functionNameString, NULL, "The given new item is undefined" );

		return commonVariables_->result;
		}

	ResultType List::addItemToDeactiveList( Item *newItem )
		{
		Item *searchItem = deactiveList_;
		Item *previousSearchItem = NULL;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addItemToDeactiveList";

		if( newItem != NULL )
			{
			if( newItem->myList() == this )
				{
				if( newItem->isDeactiveItem() )
					{
					if( newItem->nextItem == NULL )
						{
						newItem->setDeactiveSentenceNr();

						// Sort item in list
						while( searchItem != NULL &&
						!newItem->isSorted( searchItem ) )
							{
							previousSearchItem = searchItem;
							searchItem = searchItem->nextItem;
							}

						if( searchItem == NULL ||
						searchItem->creationSentenceNr() != newItem->creationSentenceNr() ||	// Check on duplicates
						searchItem->itemNr() != newItem->itemNr() )								// for integrity
							{
							newItem->previousItem = previousSearchItem;

							if( previousSearchItem == NULL )	// First item in list
								{
								if( deactiveList_ != NULL )
									deactiveList_->previousItem = newItem;

								newItem->nextItem = deactiveList_;
								deactiveList_ = newItem;
								}
							else
								{
								if( searchItem != NULL )
									searchItem->previousItem = newItem;

								newItem->nextItem = previousSearchItem->nextItem;
								previousSearchItem->nextItem = newItem;
								}
							}
						else
							return startError( functionNameString, NULL, "I found a deactive item with the same identification" );
						}
					else
						return startError( functionNameString, NULL, "The given new item seems to be a part of a list" );
					}
				else
					return startError( functionNameString, NULL, "The given new item isn't a deactive item" );
				}
			else
				return startError( functionNameString, NULL, "The given new item doesn't belong to my list" );
			}
		else
			return startError( functionNameString, NULL, "The given new item is undefined" );

		return commonVariables_->result;
		}

	ResultType List::addItemToArchivedList( Item *newItem )
		{
		Item *searchItem = archiveList_;
		Item *previousSearchItem = NULL;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addItemToArchivedList";

		if( newItem != NULL )
			{
			if( newItem->myList() == this )
				{
				if( newItem->isArchivedItem() )
					{
					if( newItem->nextItem == NULL )
						{
						newItem->setArchivedSentenceNr();

						// Sort item in list
						while( searchItem != NULL &&
						!newItem->isSorted( searchItem ) )
							{
							previousSearchItem = searchItem;
							searchItem = searchItem->nextItem;
							}

						if( searchItem == NULL ||
						searchItem->creationSentenceNr() != newItem->creationSentenceNr() ||	// Check on duplicates
						searchItem->itemNr() != newItem->itemNr() )								// for integrity
							{
							newItem->previousItem = previousSearchItem;

							if( previousSearchItem == NULL )	// First item in list
								{
								if( archiveList_ != NULL )
									archiveList_->previousItem = newItem;

								newItem->nextItem = archiveList_;
								archiveList_ = newItem;
								}
							else
								{
								if( searchItem != NULL )
									searchItem->previousItem = newItem;

								newItem->nextItem = previousSearchItem->nextItem;
								previousSearchItem->nextItem = newItem;
								}
							}
						else
							return startError( functionNameString, NULL, "I found an archive item with the same identification" );
						}
					else
						return startError( functionNameString, NULL, "The given new item seems to be a part of a list" );
					}
				else
					return startError( functionNameString, NULL, "The given new item isn't an archive item" );
				}
			else
				return startError( functionNameString, NULL, "The given new item doesn't belong to my list" );
			}
		else
			return startError( functionNameString, NULL, "The given new item is undefined" );

		return commonVariables_->result;
		}

	ResultType List::activateDeactiveItem( Item *deactiveItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "activateDeactiveItem";
		if( deactiveItem != NULL )
			{
			if( !deactiveItem->hasActiveSentenceNr() ||
			deactiveItem->hasCurrentActiveSentenceNr() ||
			deactiveItem->hasCurrentDeactiveSentenceNr() )
				{
				if( removeItemFromDeactiveList( deactiveItem ) == RESULT_OK )
					{
					deactiveItem->setActiveStatus();

					if( addItemToActiveList( deactiveItem ) != RESULT_OK )
						return addError( functionNameString, NULL, "I failed to add an item to the active list" );
					}
				else
					return addError( functionNameString, NULL, "I failed to remove an item from the deactive list" );
				}
			else
				return startError( functionNameString, NULL, "The active sentence number of the given deactive item is already assigned" );
			}
		else
			return startError( functionNameString, NULL, "The given deactive item is undefined" );

		return commonVariables_->result;
		}

	ResultType List::deactivateActiveItem( Item *activeItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "deactivateActiveItem";
		if( activeItem != NULL )
			{
			if( !activeItem->hasDeactiveSentenceNr() ||
			activeItem->hasCurrentDeactiveSentenceNr() ||
			activeItem->hasCurrentActiveSentenceNr() )
				{
				if( removeItemFromActiveList( activeItem ) == RESULT_OK )
					{
					activeItem->setDeactiveStatus();

					if( addItemToDeactiveList( activeItem ) != RESULT_OK )
						return addError( functionNameString, NULL, "I failed to add an item to the deactive list" );
					}
				else
					return addError( functionNameString, NULL, "I failed to remove an item from the active list" );
				}
			else
				return startError( functionNameString, NULL, "The deactive sentence number of the given active item is already assigned" );
			}
		else
			return startError( functionNameString, NULL, "The given active item is undefined" );

		return commonVariables_->result;
		}

	ResultType List::archiveActiveItem( Item *activeItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "archiveActiveItem";
		if( activeItem != NULL )
			{
			if( removeItemFromActiveList( activeItem ) == RESULT_OK )
				{
				activeItem->setArchivedStatus();
				activeItem->wasActiveBeforeArchiving = true;

				if( addItemToArchivedList( activeItem ) != RESULT_OK )
					return addError( functionNameString, NULL, "I failed to add an item to the archive list" );
				}
			else
				return addError( functionNameString, NULL, "I failed to remove an item from the active list" );
			}
		else
			return startError( functionNameString, NULL, "The given active item is undefined" );

		return commonVariables_->result;
		}

	ResultType List::archiveDeactiveItem( Item *deactiveItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "archiveDeactiveItem";
		if( deactiveItem != NULL )
			{
			if( removeItemFromDeactiveList( deactiveItem ) == RESULT_OK )
				{
				deactiveItem->setArchivedStatus();
				deactiveItem->wasActiveBeforeArchiving = false;

				if( addItemToArchivedList( deactiveItem ) != RESULT_OK )
					return addError( functionNameString, NULL, "I failed to add an item to the archive list" );
				}
			else
				return addError( functionNameString, NULL, "I failed to remove an item from the deactive list" );
			}
		else
			return startError( functionNameString, NULL, "The given deactive item is undefined" );

		return commonVariables_->result;
		}

	ResultType List::activateArchivedItem( bool isAvailableForRollback, Item *archiveItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "activateArchivedItem";
		if( archiveItem != NULL )
			{
			if( isAvailableForRollback ||
			!archiveItem->hasActiveSentenceNr() ||
			archiveItem->hasCurrentActiveSentenceNr() )
				{
				if( removeItemFromArchivedList( archiveItem ) == RESULT_OK )
					{
					archiveItem->setActiveStatus();
					archiveItem->wasActiveBeforeArchiving = false;

					if( addItemToActiveList( archiveItem ) != RESULT_OK )
						return addError( functionNameString, NULL, "I failed to add an item to the active list" );
					}
				else
					return addError( functionNameString, NULL, "I failed to remove an item from the archive list" );
				}
			else
				return startError( functionNameString, NULL, "The active sentence number of the given archive item is already assigned" );
			}
		else
			return startError( functionNameString, NULL, "The given archive item is undefined" );

		return commonVariables_->result;
		}

	ResultType List::deactivateArchivedItem( bool isAvailableForRollback, Item *archiveItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "deactivateArchivedItem";
		if( archiveItem != NULL )
			{
			if( isAvailableForRollback ||
			!archiveItem->hasDeactiveSentenceNr() ||
			archiveItem->hasCurrentDeactiveSentenceNr() )
				{
				if( removeItemFromArchivedList( archiveItem ) == RESULT_OK )
					{
					archiveItem->setDeactiveStatus();
					archiveItem->wasActiveBeforeArchiving = false;

					if( addItemToDeactiveList( archiveItem ) != RESULT_OK )
						return addError( functionNameString, NULL, "I failed to add an item to the deactive list" );
					}
				else
					return addError( functionNameString, NULL, "I failed to remove an item from the archive list" );
				}
			else
				return startError( functionNameString, NULL, "The deactive sentence number of the given archive item is already assigned" );
			}
		else
			return startError( functionNameString, NULL, "The given archive item is undefined" );

		return commonVariables_->result;
		}

	ResultType List::deleteActiveItemsWithCurrentSentenceNr()
		{
		Item *searchItem = activeList_;
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteActiveItemsWithCurrentSentenceNr";

		while( searchItem != NULL )
			{
			if( searchItem->hasCurrentCreationSentenceNr() )
				{
				if( deleteActiveItem( false, searchItem ) == RESULT_OK )
					searchItem = nextListItem_;
				else
					return addError( functionNameString, NULL, "I failed to delete an active item" );
				}
			else
				searchItem = searchItem->nextItem;
			}

		return commonVariables_->result;
		}

	ResultType List::deleteActiveItem( bool isAvailableForRollback, Item *activeItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteActiveItem";
		if( removeItemFromActiveList( activeItem ) == RESULT_OK )
			{
			activeItem->setDeletedStatus();
			activeItem->setDeletedSentenceNr();

			if( addItemToDeletedList( isAvailableForRollback, activeItem ) != RESULT_OK )
				return addError( functionNameString, NULL, "I failed to add an item to the delete list" );
			}
		else
			return addError( functionNameString, NULL, "I failed to remove an item from the active list" );

		return commonVariables_->result;
		}

	ResultType List::deleteDeactiveItem( bool isAvailableForRollback, Item *deactiveItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteDeactiveItem";
		if( removeItemFromDeactiveList( deactiveItem ) == RESULT_OK )
			{
			deactiveItem->setDeletedStatus();
			deactiveItem->setDeletedSentenceNr();

			if( addItemToDeletedList( isAvailableForRollback, deactiveItem ) != RESULT_OK )
				return addError( functionNameString, NULL, "I failed to add an item to the delete list" );
			}
		else
			return addError( functionNameString, NULL, "I failed to remove an item from the deactive list" );

		return commonVariables_->result;
		}

	ResultType List::deleteArchivedItem( bool isAvailableForRollback, Item *archiveItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteArchivedItem";
		if( removeItemFromArchivedList( archiveItem ) == RESULT_OK )
			{
			archiveItem->setDeletedStatus();
			archiveItem->setDeletedSentenceNr();

			if( addItemToDeletedList( isAvailableForRollback, archiveItem ) != RESULT_OK )
				return addError( functionNameString, NULL, "I failed to add an item to the delete list" );
			}
		else
			return addError( functionNameString, NULL, "I failed to remove an item from the archive list" );

		return commonVariables_->result;
		}

	ResultType List::removeFirstRangeOfDeletedItemsInList()
		{
		Item *removeItem = deleteList_;
		Item *previousRemoveItem = NULL;
		char functionNameString[FUNCTION_NAME_LENGTH] = "removeFirstRangeOfDeletedItemsInList";

		if( commonVariables_->nDeletedItems == 0 &&
		commonVariables_->removeSentenceNr == 0 &&
		commonVariables_->removeStartItemNr == 0 )
			{
			while( removeItem != NULL &&										// Skip items that must be kept for rollback
			removeItem->isAvailableForRollback )									// and items of current sentence (if wanted)
				{
				previousRemoveItem = removeItem;
				removeItem = removeItem->nextItem;
				}

			if( removeItem != NULL )											// Found items to remove
				{
				commonVariables_->removeSentenceNr = removeItem->creationSentenceNr();
				commonVariables_->removeStartItemNr = removeItem->itemNr();

				do	{
					if( previousRemoveItem == NULL )
						deleteList_ = deleteList_->nextItem;						// Disconnect deleted list from item
					else
						previousRemoveItem->nextItem = removeItem->nextItem;		// Disconnect deleted list from item

					if( checkForUsage( removeItem ) == RESULT_OK )
						{
						removeItem->nextItem = NULL;								// Disconnect item from deleted list
						delete removeItem;
						removeItem = ( previousRemoveItem == NULL ? deleteList_ : previousRemoveItem->nextItem );
						commonVariables_->nDeletedItems++;
						}
					else
						return addError( functionNameString, NULL, "I failed to check an item for its usage" );
					}
				while( removeItem != NULL &&
				removeItem->creationSentenceNr() == commonVariables_->removeSentenceNr &&							// Same sentence number
				removeItem->itemNr() == commonVariables_->removeStartItemNr + commonVariables_->nDeletedItems );	// Ascending item number
				}
			}
		else
			return startError( functionNameString, NULL, "There is already a range of deleted items" );

		return commonVariables_->result;
		}

	ResultType List::removeItemFromDeletedList( Item *removeItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "removeItemFromDeletedList";
		if( removeItem != NULL )
			{
			if( removeItem->myList() == this )
				{
				if( removeItem->isDeletedItem() )
					{
					if( removeItem->previousItem == NULL )					// First item in list
						{
						deleteList_ = removeItem->nextItem;

						if( removeItem->nextItem != NULL )
							removeItem->nextItem->previousItem = NULL;
						}
					else
						{
						removeItem->previousItem->nextItem = removeItem->nextItem;

						if( removeItem->nextItem != NULL )
							removeItem->nextItem->previousItem = removeItem->previousItem;
						}

					nextListItem_ = removeItem->nextItem;	// Remember next item

					// Disconnect item from deleted list
					removeItem->previousItem = NULL;
					removeItem->nextItem = NULL;
					}
				else
					return startError( functionNameString, NULL, "The given remove item isn't a deleted item" );
				}
			else
				return startError( functionNameString, NULL, "The given remove item doesn't belong to my list" );
			}
		else
			return startError( functionNameString, NULL, "The given remove item is undefined" );

		return commonVariables_->result;
		}

	Item *List::firstActiveItem()
		{
		return activeList_;
		}

	Item *List::firstDeactiveItem()
		{
		return deactiveList_;
		}

	Item *List::firstArchivedItem()
		{
		return archiveList_;
		}

	Item *List::firstDeletedItem()
		{
		return deleteList_;
		}

	Item *List::nextListItem()
		{
		return nextListItem_;
		}

	WordItem *List::myWord()
		{
		return myWord_;
		}

	CommonVariables *List::commonVariables()
		{
		return commonVariables_;
		}


	// Protected cleanup functions

	ResultType List::getCurrentItemNrInList()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "getCurrentItemNrInList";
		if( listCleanup_ == NULL &&
		( listCleanup_ = new ListCleanup( this, commonVariables_ ) ) == NULL )
			return startError( functionNameString, NULL, "I failed to create my list cleanup module" );

		listCleanup_->currentItemNr();
		return commonVariables_->result;
		}

	ResultType List::getHighestInUseSentenceNrInList( bool includeDeletedItems, unsigned int highestSentenceNr )
		{
		unsigned int tempSentenceNr;
		char functionNameString[FUNCTION_NAME_LENGTH] = "getHighestInUseSentenceNrInList";

		if( listCleanup_ == NULL &&
		( listCleanup_ = new ListCleanup( this, commonVariables_ ) ) == NULL )
			return startError( functionNameString, NULL, "I failed to create my list cleanup module" );

		if( ( tempSentenceNr = listCleanup_->highestInUseSentenceNrInList( includeDeletedItems, highestSentenceNr ) ) > commonVariables_->highestInUseSentenceNr )
			commonVariables_->highestInUseSentenceNr = tempSentenceNr;

		return commonVariables_->result;
		}

	ResultType List::undoCurrentSentenceInList()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "undoCurrentSentenceInList";
		if( listQuery_ != NULL ||
		( listQuery_ = new ListQuery( this, commonVariables_ ) ) != NULL )
			return listCleanup_->undoCurrentSentence();

		return startError( functionNameString, NULL, "I failed to create my list query" );
		}

	ResultType List::redoCurrentSentenceInList()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "redoCurrentSentenceInList";
		if( listQuery_ != NULL ||
		( listQuery_ = new ListQuery( this, commonVariables_ ) ) != NULL )
			return listCleanup_->redoCurrentSentence();

		return startError( functionNameString, NULL, "I failed to create my list query" );
		}

	ResultType List::rollbackDeletedRedoInfoInList()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "rollbackDeletedRedoInfoInList";
		if( listCleanup_ == NULL &&
		( listCleanup_ = new ListCleanup( this, commonVariables_ ) ) == NULL )
			return startError( functionNameString, NULL, "I failed to create my list cleanup module" );

		listCleanup_->rollbackDeletedRedoInfo();
		return commonVariables_->result;
		}

	ResultType List::deleteRollbackInfoInList()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteRollbackInfoInList";
		if( listCleanup_ == NULL &&
		( listCleanup_ = new ListCleanup( this, commonVariables_ ) ) == NULL )
			return startError( functionNameString, NULL, "I failed to create my list cleanup module" );

		listCleanup_->deleteRollbackInfo();
		return commonVariables_->result;
		}

	ResultType List::deleteSentencesInList( bool isAvailableForRollback, unsigned int lowestSentenceNr )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteSentencesInList";
		if( listCleanup_ != NULL ||
		( listCleanup_ = new ListCleanup( this, commonVariables_ ) ) != NULL )
			return listCleanup_->deleteSentences( isAvailableForRollback, lowestSentenceNr );

		return startError( functionNameString, NULL, "I failed to create my list cleanup module" );
		}

	ResultType List::decrementSentenceNrsInList( unsigned int startSentenceNr )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "decrementSentenceNrsInList";
		if( listCleanup_ != NULL ||
		( listCleanup_ = new ListCleanup( this, commonVariables_ ) ) != NULL )
			return listCleanup_->decrementSentenceNrs( startSentenceNr );

		return startError( functionNameString, NULL, "I failed to create my list cleanup module" );
		}

	ResultType List::decrementItemNrRangeInList( unsigned int decrementSentenceNr, unsigned int startDecrementItemNr, unsigned int decrementOffset )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "decrementItemNrRangeInList";
		if( listCleanup_ != NULL ||
		( listCleanup_ = new ListCleanup( this, commonVariables_ ) ) != NULL )
			return listCleanup_->decrementItemNrRange( decrementSentenceNr, startDecrementItemNr, decrementOffset );

		return startError( functionNameString, NULL, "I failed to create my list cleanup module" );
		}


	// Protected query functions

	void List::countQueryInList()
		{
		if( listQuery_ != NULL )
			listQuery_->countQuery();
		}

	void List::clearQuerySelectionsInList()
		{
		if( listQuery_ != NULL )
			listQuery_->clearQuerySelections();
		}

	ResultType List::compareStrings( char *searchString, char *sourceString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "compareStrings";
		if( listQuery_ != NULL ||
		( listQuery_ = new ListQuery( this, commonVariables_ ) ) != NULL )
			return listQuery_->compareStrings( searchString, sourceString );

		return startError( functionNameString, NULL, "I failed to create my list query" );
		}

	ResultType List::itemQueryInList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, bool isReferenceQuery, unsigned int querySentenceNr, unsigned int queryItemNr )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "itemQueryInList";
		if( listQuery_ == NULL &&
		( listQuery_ = new ListQuery( this, commonVariables_ ) ) == NULL )
			return startError( functionNameString, NULL, "I failed to create my list query" );

		listQuery_->itemQuery( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, isReferenceQuery, querySentenceNr, queryItemNr );
		return commonVariables_->result;
		}

	ResultType List::listQueryInList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *queryListString )
		{
		bool isListIncludedInQuery = includesThisList( queryListString );
		char functionNameString[FUNCTION_NAME_LENGTH] = "listQueryInList";

		if( isFirstInstruction ||
		!isListIncludedInQuery )
			{
			if( listQuery_ == NULL &&
			( listQuery_ = new ListQuery( this, commonVariables_ ) ) == NULL )
				return startError( functionNameString, NULL, "I failed to create my list query" );

			listQuery_->listQuery( ( isFirstInstruction && isListIncludedInQuery ), isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems );
			}

		return commonVariables_->result;
		}

	ResultType List::wordTypeQueryInList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, unsigned short queryWordTypeNr )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "wordTypeQueryInList";
		if( listQuery_ == NULL &&
		( listQuery_ = new ListQuery( this, commonVariables_ ) ) == NULL )
			return startError( functionNameString, NULL, "I failed to create my list query" );

		listQuery_->wordTypeQuery( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryWordTypeNr );
		return commonVariables_->result;
		}

	ResultType List::parameterQueryInList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, unsigned int queryParameter )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "parameterQueryInList";
		if( listQuery_ == NULL &&
		( listQuery_ = new ListQuery( this, commonVariables_ ) ) == NULL )
			return startError( functionNameString, NULL, "I failed to create my list query" );

		listQuery_->parameterQuery( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryParameter );
		return commonVariables_->result;
		}

	ResultType List::wordQueryInList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "wordQueryInList";
		if( listQuery_ == NULL &&
		( listQuery_ = new ListQuery( this, commonVariables_ ) ) == NULL )
			return startError( functionNameString, NULL, "I failed to create my list query" );

		listQuery_->wordQuery( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems );
		return commonVariables_->result;
		}

	ResultType List::wordReferenceQueryInList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *wordReferenceNameString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "wordReferenceQueryInList";
		if( listQuery_ != NULL ||
		( listQuery_ = new ListQuery( this, commonVariables_ ) ) != NULL )
			return listQuery_->wordReferenceQuery( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordReferenceNameString );

		return startError( functionNameString, NULL, "I failed to create my list query" );
		}

	ResultType List::stringQueryInList( bool isFirstInstruction, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *queryString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "stringQueryInList";
		if( listQuery_ != NULL ||
		( listQuery_ = new ListQuery( this, commonVariables_ ) ) != NULL )
			return listQuery_->stringQuery( isFirstInstruction, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryString );

		return startError( functionNameString, NULL, "I failed to create my list query" );
		}

	ResultType List::showQueryResultInList( bool showOnlyWords, bool showOnlyWordReferences, bool showOnlyStrings, bool returnQueryToPosition, unsigned short promptTypeNr, unsigned short queryWordTypeNr, size_t queryWidth )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "showQueryResultInList";
		if( listQuery_ != NULL ||
		( listQuery_ = new ListQuery( this, commonVariables_ ) ) != NULL )
			return listQuery_->showQueryResult( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth );

		return startError( functionNameString, NULL, "The list query module isn't created yet" );
		}

/*************************************************************************
 *
 *	"But he rescues the poor from trouble
 *	and increases their families like flocks of sheep." (Psalm 107:41)
 *
 *************************************************************************/
