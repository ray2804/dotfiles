/*
 *	Class:			Thinknowlogy
 *	Purpose:		Main class of the Thinknowlogy knowledge technology
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include <iostream>		// Defines 'system' in MS Visual Studio
#include "AdminItem.h"

int main()
	{
	ResultType result = RESULT_OK;
	bool isRestart = false;
	AdminItem *admin = NULL;

	do	{
		result = RESULT_OK;

		// Start the administrator
		if( ( admin = new AdminItem() ) != NULL )
			{
			// Interact with the administrator
			// until a restart or a serious error occurs
			do	{
				result = admin->interact();
				isRestart = admin->hasRequestedRestart();
				}
			while( result == RESULT_OK &&
			!isRestart );

			delete admin;
			}
		else
			{
			fprintf( stderr, "\n\nFunction:\tmain\nError:\t\tI failed to create the administrator.\n" );
			result = RESULT_SYSTEM_ERROR;
			}
		}
	while( result == RESULT_OK &&
	isRestart );

	// Don't close the console application when a startup error occurs,
	// because the user needs to read the error
	if( result != RESULT_OK )
		system( "pause" );		// MS Visual Studio specific
//		while( true );			// Bad alternative

	return result;
	}

/*************************************************************************
 *
 *	"Because the Sovereign Lord helps me,
 *	I will not be disgraced.
 *	Therefore, I have set my face like a stone,
 *	determined to do his will.
 *	And I know that I will not be put to shame." (Psalm 50:7)
 *
 *************************************************************************/
