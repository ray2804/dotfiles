/*      tlastrstr.c
        
        Copyright 2010 jpr <texlexan@gmail.com>
        
        This program is free software; you can redistribute it and/or modify
        it under the terms of the GNU General Public License as published by
        the Free Software Foundation; either version 2 of the License, or
        (at your option) any later version.
        
        This program is distributed in the hope that it will be useful,
        but WITHOUT ANY WARRANTY; without even the implied warranty of
        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
        GNU General Public License for more details.
        
        You should have received a copy of the GNU General Public License
        along with this program; if not, write to the Free Software
        Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
        MA 02110-1301, USA.

        This program is free software; you can redistribute it and/or modify
        it under the terms of the GNU General Public License as published by
        the Free Software Foundation; either version 2 of the License, or
        (at your option) any later version.
        
        This program is distributed in the hope that it will be useful,
        but WITHOUT ANY WARRANTY; without even the implied warranty of
        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
        GNU General Public License for more details.
        
        You should have received a copy of the GNU General Public License
        along with this program; if not, write to the Free Software
        Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
        MA 02110-1301, USA.
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>
#include <unistd.h>
#include <time.h>
#include "tlstrstr.h"
#include "definitions.h"

/*!!!  Not finished-Not working   !!!*/
/*!!! I'm currently working on it !!!*/
/*!!! well... when I have time    !!!*/

/* convert hex (lowcase only) in val */
int hextoi(char *hexa, int lg)
{
  int val=0,c;
  char *s;
  
  s=hexa;
  while (lg)
  {
    s++;
    if( *s>='a' && *s<='f' ){
      c = (int)*s + 10 - 'a';
    }
    else if( *s>='0' && *s<='9' ){
      c = (int)*s - '0';
    }
    else{
      return 0;
    }
    val = 16 * val + c;
    lg--;
  }
  return val;
}

/* compare s1 and s2
 * return 1 if found, O if not, -1 if eol is reached */
int streq(char *s1, char *s2)
{
  while ( *s1 == *s2 ) {
    s1++;
    s2++;
  }
  if ( *s1 == '/' && *s2 == '\0' ) return 1; //found
  if ( *s1 == '\n' ) return -1; // EOL reached
  return 0; //all the other case: not found
}

/* fast search specific texlexan, lazylearner
 * search word inside the line .../S/LW\word/... 
 * S hex 6bytes, pos next group of digram
 * W hex 2bytes, word weight
 * L hex 2bytes, word length */
char *tlastrstr(char *line, char *searched_word)
{
  char *str_ptr1,*str_ptr2,*str_ptr3,*str_ptr4;
  char searched_ch1,searched_ch2;
  long lg_searched_word,length,posnext_digram;
  int okay=1,flag;
  
  lg_searched_word = strlen(searched_word);
  
  /* search the first "/S/" */
  if ( (str_ptr1=strchr(line,'/')) == NULL ) return NULL; //dico error
  str_ptr1++;
  if ( (str_ptr2=strchr(str_ptr1,'/')) == NULL ) return NULL; //dico error
  if ( str_ptr2-str_ptr1  != 6 ) return NULL; //dico erro
  /* position of the next group in case no match */
  posnext_digram=hextoi(str_ptr1,6);
  if ( posnext_digram == 0 ) goto wordbyword;// do word by word
  /* compare first digram (ch1,ch2) */
  str_ptr3 = str_ptr2+6;
  while (okay) {
    str_ptr4 = str_ptr3 + posnext_digram; //point chr after '/'
    if ( *str_ptr3 == searched_ch1 
      && *(str_ptr3+1) == searched_ch2 ) { 
      /* digram found!!!
       compare word now */
      while ( str_ptr3 < str_ptr4 ) {
        flag = streq(str_ptr3,searched_word);
        if ( flag == 1 ) {
          /* word found! :-) */
          return str_ptr3;
        }
        if ( flag == -1 ) // EOL! :-(
        /* length of the word */
        str_ptr2++;
        length=hextoi(str_ptr2,2);
        str_ptr3+=length; //point chr after '/'
      } //endwhile
      /* word not found :-( */
      return NULL;
    }
    /* digram not found */
    str_ptr3=str_ptr4;
    posnext_digram=hextoi(str_ptr3,6);
    if ( posnext_digram == 0 ) break;// do word by word
  } //endwhile
  
  /* we are going to search one by word */
wordbyword:
  flag=0;
  while ( flag > -1 ) {
    flag = streq(str_ptr3,searched_word);
    if ( flag == 1 ) {
      /* word found! :-) */
      return str_ptr3;
    }
  }
  return NULL; //not found
}
