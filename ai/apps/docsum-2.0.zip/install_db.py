#!/usr/bin/python
import sys,getpass

MVDIR = "bin/"
CONFIG_FILENAME="docdbconfig.py"
SQL_FILENAME="install_db.sql"

CONFIG_CONTENTS="""#!/usr/bin/python
##---------------------------------------------------------------------------##
# METADATA TABLE VARIABLES
METADATA_TABLE = 'METADATA'
CHECKSUM_COL = 'CHECKSUM'
PATH_COL = 'PATH'
KEYWORDS_COL = 'KEYWORDS'
METADATA_PK_COL= 'FILE_ID'
METADATA_ACTIVE_COL = 'ACTIVE'

# CONTENTS TABLE VARIABLES
CONTENTS_TABLE = 'CONTENTS'
CONTENT_COL = 'CONTENT'
CONTENT_FK_COL = METADATA_PK_COL
CONTENT_PK_COL = 'CONTENT_ID'

# TOPIC AUDIT TABLE VARIABLES
TOPIC_AUDIT_TABLE = 'AUDIT_USER_TOPIC'
TOPIC_PK_COL = 'TOPIC_ID'
TOPIC_TEXT_COL = 'TOPIC'
TOPIC_COUNT_COL = 'TOPIC_COUNT'

# TABLE DICTIONARIES
METADATA_FIELDS = {CHECKSUM_COL:None,PATH_COL:None,KEYWORDS_COL:None,METADATA_ACTIVE_COL:None}
CONTENTs_FIELDS = {METADATA_PK_COL:None,CONTENT_COL:None}
TOPIC_AUDIT_FIELDS = {TOPIC_PK_COL:None,TOPIC_TEXT_COL:None,TOPIC_COUNT_COL:None}

# PK DICTIONARIES
METADATA_PK = {METADATA_PK_COL:None}
CONTENTs_PK = {CONTENT_PK_COL:None}
TOPiC_AUDIT_PK = {TOPIC_PK_COL:None}

# DATABASE CONNECTION VARIABLES
# user must have (SELECT, INSERT, DELETE, UPDATE) on all tables
DATABASE_NAME = '%s'
DATABASE_USER = '%s'
DATABASE_PASSWD = '%s'
DATABASE_PORT = %s
DATABASE_HOST = '%s'
"""


SQL_AUDIT_USER="""DROP TABLE IF EXISTS `AUDIT_USER_TOPIC`;
CREATE TABLE IF NOT EXISTS `AUDIT_USER_TOPIC` (
  `TOPIC_ID` int(10) unsigned NOT NULL auto_increment,
  `TOPIC` text NOT NULL,
  `TOPIC_COUNT` int(10) unsigned NOT NULL default '1',
  PRIMARY KEY  (`TOPIC_ID`),
  FULLTEXT KEY `TOPIC` (`TOPIC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 PACK_KEYS=0 COMMENT='Tracks the user topic queries' AUTO_INCREMENT=0;"""

SQL_CONTENTS="""DROP TABLE IF EXISTS `CONTENTS`;
CREATE TABLE IF NOT EXISTS `CONTENTS` (
  `CONTENT_ID` int(10) unsigned NOT NULL auto_increment,
  `FILE_ID` int(10) unsigned NOT NULL default '0',
  `CONTENT` text NOT NULL,
  PRIMARY KEY  (`CONTENT_ID`),
  FULLTEXT KEY `CONTENT` (`CONTENT`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=0;"""

SQL_META="""DROP TABLE IF EXISTS `METADATA`;
CREATE TABLE IF NOT EXISTS `METADATA` (
  `FILE_ID` int(10) unsigned NOT NULL auto_increment,
  `CHECKSUM` varchar(32) NOT NULL default '',
  `PATH` text NOT NULL,
  `KEYWORDS` text NOT NULL,
  `ACTIVE` tinyint(1) NOT NULL default 1,
  PRIMARY KEY  (`FILE_ID`),
  UNIQUE KEY `CHECKSUM` (`CHECKSUM`),
  FULLTEXT KEY `KEYWORDS` (`KEYWORDS`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=0;"""

try:
	# try and load the mysqldb module, it is not standard
	# reguires http://sourceforge.net/projects/mysql-python version 1.2.0
	import MySQLdb
	OPT_MODE = True
except ImportError :
	# module not found, will just output rather then
	# executing db actions
	sys.stderr.write("This software requires MySQL-Python module. It does not appear that you have this \
software installed. You can install this software by downloading it at \
http://sourceforge.net/projects/mysql-python. This software will operate in demo mode \
until MySQL-Python is installed.\n\n")
	OPT_MODE = False


def mysql_conn(hostname,portnumber,username,password,database):
	"""Create a database connection"""
	return MySQLdb.connect(host=hostname, 
		port=portnumber, 
		user=username, 
		passwd=password, 
		db=database)
	
if __name__ == '__main__':
	try:
		if OPT_MODE:
			print "MySQLdb is installed."
		config = {}
		
		print "You are now running the docsum database install script. This script will \
not execute any SQL on your database. This script will create the needed SQL to \
setup your database. Once this script has been successfully executed, a database \
admin account must execute the generated SQL."

		print
		print "If you have already installed this application before, and are upgrading,\
it is likely you will not need to do this again. Please see bin/ALTER_METADATA_01_TO_02.sql \
for the needed steps to upgrade. You can quit now if you are upgrading, since this script is not \
required."
		
		print 
		print "Please enter the desired database name for the docsum application."
		config["dbname"] = raw_input( "Enter the desired docsum database name (d167349_INSTALLTEST): ")
		print 
		
		config["host"] = raw_input( "Enter your database hostname (localhost): ")
		config["port"] = raw_input( "Enter your database connection port (3306): ")
		print 
		
		print "Enter a username and password be setup for docsum."
		print "This user will be given SELECT, INSERT, DELETE and UPDATE access."
		config["dcsum_u"] = raw_input( "Enter the docsum database username (d167349rw): ")
		config["dcsum_p"] =  getpass.getpass("Enter %s's desired account password (readwrite): " % config["dcsum_u"])
		print
		
		SQL_GRANT = "GRANT SELECT,INSERT,DELETE,UPDATE ON %s.* TO '%s'@'%s' IDENTIFIED BY '%s';" % (config["dbname"],config["dcsum_u"],config["host"],config["dcsum_p"])
		SQL_CREATDB = "DROP DATABASE IF EXISTS `%s`; CREATE DATABASE `%s`; USE `%s`;" % (config["dbname"],config["dbname"],config["dbname"])

		print "Generating SQL...", 
		qf = open(SQL_FILENAME,'w+')
		qf.write("-- Docsum Generated Install SQL\n")
		qf.write("\n-- Create database\n")
		qf.write("\n%s\n" % SQL_CREATDB)
		qf.write("\n-- Create user\n")
		qf.write("\n%s\n" % SQL_GRANT)
		qf.write("\n-- Create tables\n")
		qf.write("\n%s\n" % SQL_AUDIT_USER)
		qf.write("\n%s\n" % SQL_CONTENTS)
		qf.write("\n%s\n" % SQL_META)
		qf.close()
		print "Done."
		print
		print "Generating configuration file...",	
		cf = open(CONFIG_FILENAME,'w+')
		cf.write(CONFIG_CONTENTS % (config["dbname"],config["dcsum_u"],
				config["dcsum_p"],config["port"],config["host"]))
		cf.close()
		print "Done."
		print
		print "Configuration file has been created: %s" % CONFIG_FILENAME
		print "SQL script has been created: %s" % SQL_FILENAME
		print 
		print "Execute the SQL script using your root account to setup database."
		print "Move configuration file %s to the python source directory: %s" % (CONFIG_FILENAME,MVDIR)
		print 
		
	except KeyboardInterrupt:
		sys.stderr.write("\nExiting installation of docsum...\n")
