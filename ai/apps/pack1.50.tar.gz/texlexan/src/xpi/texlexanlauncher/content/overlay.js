
var telexanlauncher = {
	
  onLoad: function() {
    // initialization code
    this.initialized = true;
    this.strings = document.getElementById("telexanlauncher-strings");
  },
  
  onToolbarButtonCommand: function(e) {  // Will launch texlexan.py
	//get the home directory
	var dirService = Components.classes["@mozilla.org/file/directory_service;1"].getService(Components.interfaces.nsIProperties);
	var homeDirFile = dirService.get("Home", Components.interfaces.nsIFile);
	var homeDir = homeDirFile.path;
	//get the url
	var urlstr = document.getElementById("urlbar").value
	//prepare the process
	var file = Components.classes["@mozilla.org/file/local;1"].createInstance(Components.interfaces.nsILocalFile);
	var process = Components.classes["@mozilla.org/process/util;1"].createInstance(Components.interfaces.nsIProcess);
	var args = ["-fu "+urlstr];
	var path = homeDir + "/texlexan_prog/texlexan.py"; // non-portable!!!
	file.initWithPath(path);
	process.init(file);
	process.run(false, args, args.length);
  }

};
window.addEventListener("load", function(e) { telexanlauncher.onLoad(e); }, false);
