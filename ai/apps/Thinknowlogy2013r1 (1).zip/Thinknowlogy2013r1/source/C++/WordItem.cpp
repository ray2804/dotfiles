/*
 *	Class:			WordItem
 *	Parent class:	Item
 *	Purpose:		To store and process word information
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "ContextList.cpp"
#include "GeneralizationList.cpp"
#include "GrammarList.cpp"
#include "InterfaceList.cpp"
#include "JustificationList.cpp"
#include "ScoreList.h"
#include "SelectionList.h"
#include "WordAssignment.cpp"
#include "WordCleanup.cpp"
#include "WordCollection.cpp"
#include "WordQuery.cpp"
#include "WordQuestion.cpp"
#include "WordSpecification.cpp"
#include "WordType.cpp"
#include "WordWrite.cpp"
#include "WordWriteSentence.cpp"
#include "WordWriteWords.cpp"

	// Private common functions

	char *WordItem::userNameInWord( unsigned short userNr )
		{
		GeneralizationItem *currentGeneralizationItem;
		char *userName = nameByCollectionOrderNr( userNr );

		if( userNr == 1 &&		// No user collection - only one user available
		userName == NULL &&		// No name by collection found
		( currentGeneralizationItem = firstActiveGeneralizationItemOfSpecification() ) != NULL )
			{
			do	{
				if( currentGeneralizationItem->isGeneralizationPropername() )
					return currentGeneralizationItem->generalizationWordItem()->anyWordTypeString();
				}
			while( ( currentGeneralizationItem = currentGeneralizationItem->nextGeneralizationItemOfSpecification() ) != NULL );
			}

		return userName;
		}

	char *WordItem::grammarLanguageNameStringInWord( unsigned short languageNr )
		{
		GeneralizationItem *currentGeneralizationItem;
		WordItem *generalizationWordItem;
		char *languageName = nameByCollectionOrderNr( languageNr );

		if( languageNr == 1 &&		// No language collection - only one language available
		languageName == NULL &&		// No name by collection found
		( currentGeneralizationItem = firstActiveGeneralizationItemOfSpecification() ) != NULL )
			{
			do	{
				if( ( generalizationWordItem = currentGeneralizationItem->generalizationWordItem() ) != NULL )
					{
					if( generalizationWordItem->isGrammarLanguage() )
						return currentGeneralizationItem->generalizationWordItem()->anyWordTypeString();
					}
				}
			while( ( currentGeneralizationItem = currentGeneralizationItem->nextGeneralizationItemOfSpecification() ) != NULL );
			}

		return languageName;
		}


	// Private assignment functions

	SpecificationItem *WordItem::firstAssignment( bool isDeactive, bool isArchived, bool isQuestion )
		{
		if( assignmentList != NULL )
			return assignmentList->firstAssignmentItem( false, isDeactive, isArchived, isQuestion );

		return NULL;
		}

	SpecificationItem *WordItem::firstDeactiveAssignment( bool isIncludingAnsweredQuestions, unsigned short questionParameter )
		{
		if( assignmentList != NULL )
			return assignmentList->firstAssignmentItem( isIncludingAnsweredQuestions, true, false, questionParameter );

		return NULL;
		}

	SpecificationItem *WordItem::firstArchivedAssignment( bool isIncludingAnsweredQuestions, unsigned short questionParameter )
		{
		if( assignmentList != NULL )
			return assignmentList->firstAssignmentItem( isIncludingAnsweredQuestions, false, true, questionParameter );

		return NULL;
		}


	// Private collection functions

	unsigned short WordItem::highestCollectionOrderNrInWord( unsigned int collectionNr )
		{
		if( collectionList != NULL &&
		collectionNr > NO_COLLECTION_NR )
			return collectionList->highestCollectionOrderNr( collectionNr );

		return NO_ORDER_NR;
		}

	unsigned int WordItem::collectionNrByCompoundGeneralizationWordInWord( unsigned short collectionWordTypeNr, WordItem *compoundGeneralizationWordItem )
		{
		if( collectionList != NULL )
			return collectionList->collectionNrByCompoundGeneralizationWord( collectionWordTypeNr, compoundGeneralizationWordItem );

		return NO_COLLECTION_NR;
		}

	unsigned int WordItem::collectionNrByCommonWordInWord( unsigned short collectionWordTypeNr, WordItem *commonWordItem )
		{
		if( collectionList != NULL )
			return collectionList->collectionNrByCommonWord( collectionWordTypeNr, commonWordItem );

		return NO_COLLECTION_NR;
		}

	unsigned int WordItem::highestCollectionNrInWord()
		{
		if( collectionList != NULL )
			return collectionList->highestCollectionNr();

		return NO_COLLECTION_NR;
		}

	unsigned int WordItem::nonCompoundCollectionNrInWord( unsigned int compoundCollectionNr )
		{
		if( compoundCollectionNr > NO_CONTEXT_NR &&
		collectionList != NULL )
			return collectionList->nonCompoundCollectionNr( compoundCollectionNr );

		return NO_COLLECTION_NR;
		}


	// Private context functions

	bool WordItem::isContextCurrentlyUpdatedInWord( bool isPossessive, unsigned int contextNr, WordItem *specificationWordItem )
		{
		if( contextList != NULL )
			return contextList->isContextCurrentlyUpdated( isPossessive, contextNr, specificationWordItem );

		return false;
		}

	bool WordItem::isContextSimilarInWord( unsigned int firstContextNr, unsigned int secondContextNr )
		{
		if( contextList != NULL &&
		firstContextNr > NO_CONTEXT_NR &&
		secondContextNr > NO_CONTEXT_NR )
			return ( contextList->hasContext( firstContextNr ) == contextList->hasContext( secondContextNr ) );

		return true;
		}

	bool WordItem::isContextSubsetInWord( unsigned int fullSetContextNr, unsigned int subsetContextNr )
		{
		if( contextList != NULL )
			return contextList->isContextSubset( fullSetContextNr, subsetContextNr );

		return false;
		}

	ContextItem *WordItem::contextItemInWord( unsigned int contextNr )
		{
		if( contextList != NULL )
			return contextList->contextItem( contextNr );

		return NULL;
		}


	// Private grammar functions

	char *WordItem::grammarStringInWord( unsigned short wordTypeNr )
		{
		if( grammarList != NULL )
			return grammarList->grammarStringInList( wordTypeNr );

		return NULL;
		}


	// Private query functions

	char *WordItem::nameByCollectionOrderNr( unsigned short collectionOrderNr )
		{
		GeneralizationItem *currentGeneralizationItem;
		WordItem *currentGeneralizationWordItem;

		if( ( currentGeneralizationItem = firstActiveGeneralizationItemOfSpecification() ) != NULL )
			{
			do	{
				if( ( currentGeneralizationWordItem = currentGeneralizationItem->generalizationWordItem() ) != NULL )
					{
					if( currentGeneralizationWordItem->hasCollectionOrderNr( collectionOrderNr ) )
						return currentGeneralizationWordItem->anyWordTypeString();
					}
				}
			while( ( currentGeneralizationItem = currentGeneralizationItem->nextGeneralizationItemOfSpecification() ) != NULL );
			}

		return NULL;
		}


	// Private question functions

	SpecificationItem *WordItem::firstAnsweredQuestion( bool isAssignment, bool isDeactiveAssignment, bool isArchivedAssignment, unsigned short questionParameter )
		{
		if( isAssignment )
			{
			if( assignmentList != NULL )
				return assignmentList->firstAssignmentItem( true, isDeactiveAssignment, isArchivedAssignment, questionParameter );
			}
		else
			{
			if( specificationList != NULL )
				return specificationList->firstActiveSpecificationItem( true, questionParameter );
			}

		return NULL;
		}

	SpecificationItem *WordItem::firstQuestionSpecification( bool isIncludingAnsweredQuestions, unsigned short questionParameter )
		{
		if( questionParameter > NO_QUESTION_PARAMETER &&
		specificationList != NULL )
			return specificationList->firstActiveSpecificationItem( isIncludingAnsweredQuestions, questionParameter );

		return NULL;
		}


	// Private specification functions

	ResultType WordItem::checkSpecificationForUsageInWord( SpecificationItem *unusedSpecificationItem )
		{
		if( assignmentList != NULL &&
		assignmentList->checkSpecificationItemForUsage( false, false, unusedSpecificationItem ) == RESULT_OK )
			{
			if( assignmentList->checkSpecificationItemForUsage( true, false, unusedSpecificationItem ) == RESULT_OK )
				assignmentList->checkSpecificationItemForUsage( false, true, unusedSpecificationItem );
			}

		if( commonVariables_->result == RESULT_OK &&
		specificationList != NULL )
			specificationList->checkSpecificationItemForUsage( false, false, unusedSpecificationItem );

		if( commonVariables_->result == RESULT_OK &&
		justificationList != NULL )
			justificationList->checkSpecificationItemForUsage( unusedSpecificationItem );

		return commonVariables_->result;
		}


	// Constructor for AdminItem

	WordItem::WordItem()
		{
		// Private constructible variables

		changeKey_ = NULL;

		wordAssignment_ = NULL;
		wordCleanup_ = NULL;
		wordCollection_ = NULL;
		wordQuery_ = NULL;
		wordQuestion_ = NULL;
		wordSpecification_ = NULL;
		wordType_ = NULL;
		wordWrite_ = NULL;
		wordWriteSentence_ = NULL;
		wordWriteWords_ = NULL;

		// Private loadable variables

		wordParameter_ = NO_WORD_PARAMETER;

		// Protected constructible variables

		isWordCheckedForSolving = false;

		assignmentList = NULL;
		collectionList = NULL;
		contextList = NULL;
		generalizationList = NULL;
		grammarList = NULL;
		interfaceList = NULL;
		justificationList = NULL;
		writeList = NULL;
		specificationList = NULL;
		wordTypeList = NULL;

		for( unsigned short wordListNr = 0; wordListNr < NUMBER_OF_WORD_LISTS; wordListNr++ )
			wordList[wordListNr] = NULL;
		}


	// Constructor

	WordItem::WordItem( unsigned short wordParameter, List *myList, CommonVariables *commonVariables )
		{
		initializeItemVariables( NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, "WordItem", myList, this, commonVariables );

		// Private constructible variables

		changeKey_ = NULL;

		wordAssignment_ = NULL;
		wordCleanup_ = NULL;
		wordCollection_ = NULL;
		wordQuery_ = NULL;
		wordQuestion_ = NULL;
		wordSpecification_ = NULL;
		wordType_ = NULL;
		wordWrite_ = NULL;
		wordWriteSentence_ = NULL;
		wordWriteWords_ = NULL;

		// Private loadable variables

		wordParameter_ = wordParameter;

		// Protected constructible variables

		isWordCheckedForSolving = false;

		assignmentList = NULL;
		collectionList = NULL;
		contextList = NULL;
		generalizationList = NULL;
		grammarList = NULL;
		interfaceList = NULL;
		justificationList = NULL;
		writeList = NULL;
		specificationList = NULL;
		wordTypeList = NULL;

		for( unsigned short wordListNr = 0; wordListNr < NUMBER_OF_WORD_LISTS; wordListNr++ )
			wordList[wordListNr] = NULL;
		}

	WordItem::~WordItem()
		{
		if( wordAssignment_ != NULL )
			delete wordAssignment_;
		if( wordCleanup_ != NULL )
			delete wordCleanup_;
		if( wordCollection_ != NULL )
			delete wordCollection_;
		if( wordQuery_ != NULL )
			delete wordQuery_;
		if( wordQuestion_ != NULL )
			delete wordQuestion_;
		if( wordSpecification_ != NULL )
			delete wordSpecification_;
		if( wordType_ != NULL )
			delete wordType_;
		if( wordWrite_ != NULL )
			delete wordWrite_;
		if( wordWriteSentence_ != NULL )
			delete wordWriteSentence_;
		if( wordWriteWords_ != NULL )
			delete wordWriteWords_;

		if( assignmentList != NULL )
			delete assignmentList;
		if( collectionList != NULL )
			delete collectionList;
		if( contextList != NULL )
			delete contextList;
		if( generalizationList != NULL )
			delete generalizationList;
		if( grammarList != NULL )
			delete grammarList;
		if( interfaceList != NULL )
			delete interfaceList;
		if( justificationList != NULL )
			delete justificationList;
		if( writeList != NULL )
			delete writeList;
		if( specificationList != NULL )
			delete specificationList;
		if( wordTypeList != NULL )
			delete wordTypeList;
		}


	// Protected functions

	ResultType WordItem::addErrorInWord( const char *functionNameString, const char *moduleNameString, const char *errorString )
		{
		return addErrorInItem( functionNameString, moduleNameString, anyWordTypeString(), errorString );
		}

	ResultType WordItem::addErrorInWord( const char *functionNameString, const char *moduleNameString, const char *errorString1, unsigned int number1 )
		{
		sprintf( tempString, "%s%u", errorString1, number1 );
		return addErrorInWord( functionNameString, moduleNameString, tempString );
		}

	ResultType WordItem::addErrorInWord( const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3 )
		{
		sprintf( tempString, "%s%s%s", errorString1, errorString2, errorString3 );
		return addErrorInWord( functionNameString, moduleNameString, tempString );
		}

	ResultType WordItem::addErrorInWord( const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3, const char *errorString4, const char *errorString5 )
		{
		sprintf( tempString, "%s%s%s%s%s", errorString1, errorString2, errorString3, errorString4, errorString5 );
		return addErrorInWord( functionNameString, moduleNameString, tempString );
		}

	ResultType WordItem::addErrorInWord( char listChar, const char *functionNameString, const char *moduleNameString, const char *errorString )
		{
		return addErrorInItem( listChar, functionNameString, moduleNameString, anyWordTypeString(), errorString );
		}

	ResultType WordItem::startErrorInWord( const char *functionNameString, const char *moduleNameString, const char *errorString )
		{
		return startErrorInItem( functionNameString, moduleNameString, anyWordTypeString(), errorString );
		}

	ResultType WordItem::startErrorInWord( const char *functionNameString, const char *moduleNameString, const char *errorString1, unsigned int number1 )
		{
		sprintf( tempString, "%s%u", errorString1, number1 );
		return startErrorInWord( functionNameString, moduleNameString, tempString );
		}

	ResultType WordItem::startErrorInWord( const char *functionNameString, const char *moduleNameString, const char *errorString1, const char *errorString2, const char *errorString3 )
		{
		sprintf( tempString, "%s%s%s", errorString1, errorString2, errorString3 );
		return startErrorInWord( functionNameString, moduleNameString, tempString );
		}

	ResultType WordItem::startSystemErrorInWord( const char *functionNameString, const char *moduleNameString, const char *errorString )
		{
		return startSystemErrorInItem( functionNameString, moduleNameString, anyWordTypeString(), errorString );
		}


	// Protected virtual item functions

	void WordItem::showWords( bool returnQueryToPosition )
		{
		if( wordTypeList != NULL &&
		isSelectedByQuery )
			wordTypeList->showWords( returnQueryToPosition );
		}

	bool WordItem::hasFoundParameter( unsigned int queryParameter )
		{
		return ( wordParameter_ == queryParameter ||

				( queryParameter == MAX_QUERY_PARAMETER &&
				wordParameter_ > NO_WORD_PARAMETER ) );
		}

	ResultType WordItem::checkForUsage()
		{
		if( assignmentList != NULL &&
		assignmentList->checkWordItemForUsage( false, false, this ) == RESULT_OK )
			{
			if( assignmentList->checkWordItemForUsage( true, false, this ) == RESULT_OK )
				assignmentList->checkWordItemForUsage( false, true, this );
			}

		if( commonVariables_->result == RESULT_OK &&
		collectionList != NULL )
			collectionList->checkWordItemForUsage( this );

		if( commonVariables_->result == RESULT_OK &&
		contextList != NULL )
			contextList->checkWordItemForUsage( this );

		if( commonVariables_->result == RESULT_OK &&
		generalizationList != NULL )
			generalizationList->checkWordItemForUsage( this );

		if( commonVariables_->result == RESULT_OK &&
		specificationList != NULL )
			specificationList->checkWordItemForUsage( false, false, this );

		if( commonVariables_->result == RESULT_OK &&
		commonVariables_->adminConditionList != NULL )
			commonVariables_->adminConditionList->checkWordItemForUsage( this );

		if( commonVariables_->result == RESULT_OK &&
		commonVariables_->adminActionList != NULL )
			commonVariables_->adminActionList->checkWordItemForUsage( this );

		if( commonVariables_->result == RESULT_OK &&
		commonVariables_->adminAlternativeList != NULL )
			commonVariables_->adminAlternativeList->checkWordItemForUsage( this );

		return commonVariables_->result;
		}

	bool WordItem::isSorted( Item *nextSortItem )
		{
		return ( nextSortItem == NULL ||
				// Ascending creationSentenceNr
				creationSentenceNr() < nextSortItem->creationSentenceNr() );
		}

	ResultType WordItem::findMatchingWordReferenceString( char *searchString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "findMatchingWordReferenceString";
		if( wordTypeList != NULL )
			return wordTypeList->findMatchingWordReferenceString( searchString );

		return startErrorInWord( functionNameString, NULL, "The word type list isn't created yet" );
		}

	char *WordItem::toString( unsigned short queryWordTypeNr )
		{
		if( wordQuery_ != NULL )
			return wordQuery_->toString( queryWordTypeNr );

		return NULL;
		}


	// Protected common functions

	bool WordItem::hasItems()
		{
		for( unsigned short wordListNr = 0; wordListNr < NUMBER_OF_WORD_LISTS; wordListNr++ )
			{
			if( wordList[wordListNr] != NULL &&
			wordList[wordListNr]->hasItems() )
				return true;
			}

		return false;
		}

	bool WordItem::iAmAdmin()
		{
		return ( myList() == NULL );
		}

	bool WordItem::isAdjectiveAssignedOrClear()
		{
		return ( wordParameter_ == WORD_PARAMETER_ADJECTIVE_CLEAR ||
				wordParameter_ == WORD_PARAMETER_ADJECTIVE_ASSIGNED );
		}

	bool WordItem::isAdjectiveCalledOrNamed()
		{
		return ( wordParameter_ == WORD_PARAMETER_ADJECTIVE_CALLED_OR_NAMED );
		}

	bool WordItem::isAdjectiveClear()
		{
		return ( wordParameter_ == WORD_PARAMETER_ADJECTIVE_CLEAR );
		}

	bool WordItem::isAdjectiveNo()
		{
		return ( wordParameter_ == WORD_PARAMETER_ADJECTIVE_NO );
		}

	bool WordItem::isAdjectiveComparison()
		{
		return ( isAdjectiveComparisonLess() ||
				isAdjectiveComparisonEqual() ||
				isAdjectiveComparisonMore() );
		}

	bool WordItem::isAdjectiveComparisonLess()
		{
		return ( wordParameter_ == WORD_PARAMETER_ADJECTIVE_EARLIER ||
				wordParameter_ == WORD_PARAMETER_ADJECTIVE_LESS ||
				wordParameter_ == WORD_PARAMETER_ADJECTIVE_LOWER ||
				wordParameter_ == WORD_PARAMETER_ADJECTIVE_SMALLER );
		}

	bool WordItem::isAdjectiveComparisonEqual()
		{
		return ( wordParameter_ == WORD_PARAMETER_ADJECTIVE_EQUAL ||
				wordParameter_ == WORD_PARAMETER_ADJECTIVE_SAME );
		}

	bool WordItem::isAdjectiveComparisonMore()
		{
		return ( wordParameter_ == WORD_PARAMETER_ADJECTIVE_BIGGER ||
				wordParameter_ == WORD_PARAMETER_ADJECTIVE_HIGHER ||
				wordParameter_ == WORD_PARAMETER_ADJECTIVE_LARGER ||
				wordParameter_ == WORD_PARAMETER_ADJECTIVE_LATER ||
				wordParameter_ == WORD_PARAMETER_ADJECTIVE_MORE );
		}

	bool WordItem::isAdjectiveOdd()
		{
		return ( wordParameter_ == WORD_PARAMETER_ADJECTIVE_ODD );
		}

	bool WordItem::isAdjectiveEven()
		{
		return ( wordParameter_ == WORD_PARAMETER_ADJECTIVE_EVEN );
		}

	bool WordItem::isAdjectiveOddOrEven()
		{
		return ( isAdjectiveOdd() ||
				isAdjectiveEven() );
		}

	bool WordItem::isNounDeveloper()
		{
		return ( wordParameter_ == WORD_PARAMETER_NOUN_DEVELOPER );
		}

	bool WordItem::isNounHead()
		{
		return ( wordParameter_ == WORD_PARAMETER_NOUN_HEAD );
		}

	bool WordItem::isNounTail()
		{
		return ( wordParameter_ == WORD_PARAMETER_NOUN_TAIL );
		}

	bool WordItem::isNounNumber()
		{
		return ( wordParameter_ == WORD_PARAMETER_NOUN_NUMBER );
		}

	bool WordItem::isNounPassword()
		{
		return ( wordParameter_ == WORD_PARAMETER_NOUN_PASSWORD );
		}

	bool WordItem::isNounUser()
		{
		return ( wordParameter_ == WORD_PARAMETER_NOUN_USER );
		}

	bool WordItem::isNounValue()
		{
		return ( wordParameter_ == WORD_PARAMETER_NOUN_VALUE );
		}

	bool WordItem::isBasicVerb()
		{
		return ( wordParameter_ == WORD_PARAMETER_SINGULAR_VERB_IS ||
				wordParameter_ == WORD_PARAMETER_SINGULAR_VERB_WAS ||
				wordParameter_ == WORD_PARAMETER_SINGULAR_VERB_CAN_BE ||
				wordParameter_ == WORD_PARAMETER_SINGULAR_VERB_HAS ||
				wordParameter_ == WORD_PARAMETER_SINGULAR_VERB_HAD ||
//				wordParameter_ == WORD_PARAMETER_SINGULAR_VERB_HAD );
				wordParameter_ == WORD_PARAMETER_SINGULAR_VERB_CAN_HAVE );
		}

	bool WordItem::isVerbImperativeLogin()
		{
		return ( wordParameter_ == WORD_PARAMETER_SINGULAR_VERB_IMPERATIVE_LOGIN );
		}

	bool WordItem::isPredefinedWord()
		{
		return ( wordParameter_ > NO_WORD_PARAMETER );
		}

	bool WordItem::isUserDefinedWord()
		{
		return ( wordParameter_ == NO_WORD_PARAMETER );
		}

	bool WordItem::isNounWordType( unsigned short wordTypeNr )
		{
		return ( wordTypeNr == WORD_TYPE_NOUN_SINGULAR ||
				wordTypeNr == WORD_TYPE_NOUN_PLURAL );
		}

	bool WordItem::needsAuthorizationForChanges()
		{
		return ( changeKey_ != NULL );
		}

	unsigned short WordItem::wordParameter()
		{
		return wordParameter_;
		}

	ResultType WordItem::assignChangePermissions( void *changeKey )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "assignChangePermissions";
		if( changeKey_ == NULL )
			changeKey_ = changeKey;
		else
			{
			if( changeKey_ != changeKey )
				return startErrorInWord( functionNameString, NULL, "The change key is already assigned" );
			}

		return commonVariables_->result;
		}

	char WordItem::wordListChar( unsigned short wordListNr )
		{
		switch( wordListNr )
			{
			case WORD_ASSIGNMENT_LIST:
				return WORD_ASSIGNMENT_LIST_SYMBOL;

			case WORD_COLLECTION_LIST:
				return WORD_COLLECTION_LIST_SYMBOL;

			case WORD_GENERALIZATION_LIST:
				return WORD_GENERALIZATION_LIST_SYMBOL;

			case WORD_INTERFACE_LANGUAGE_LIST:
				return WORD_INTERFACE_LANGUAGE_LIST_SYMBOL;

			case WORD_JUSTIFICATION_LIST:
				return WORD_JUSTIFICATION_LIST_SYMBOL;

			case WORD_GRAMMAR_LANGUAGE_LIST:
				return WORD_GRAMMAR_LANGUAGE_LIST_SYMBOL;

			case WORD_WRITE_LIST:
				return WORD_WRITE_LIST_SYMBOL;

			case WORD_SPECIFICATION_LIST:
				return WORD_SPECIFICATION_LIST_SYMBOL;

			case WORD_TYPE_LIST:
				return WORD_TYPE_LIST_SYMBOL;

			case WORD_CONTEXT_LIST:
				return WORD_CONTEXT_LIST_SYMBOL;
			}

		return SYMBOL_QUESTION_MARK;
		}

	char *WordItem::grammarLanguageNameString( unsigned short wordTypeNr )
		{
		if( commonVariables_->predefinedNounGrammarLanguageWordItem != NULL )
			return commonVariables_->predefinedNounGrammarLanguageWordItem->grammarLanguageNameStringInWord( wordTypeNr );

		return NULL;
		}

	char *WordItem::userName( unsigned short userNr )
		{
		if( commonVariables_->predefinedNounUserWordItem != NULL )
			return commonVariables_->predefinedNounUserWordItem->userNameInWord( userNr );

		return NULL;
		}

	char *WordItem::wordTypeName( unsigned short wordTypeNr )
		{
		if( commonVariables_->currentGrammarLanguageWordItem != NULL )
			return commonVariables_->currentGrammarLanguageWordItem->grammarStringInWord( wordTypeNr );

		return NULL;
		}

	WordItem *WordItem::predefinedWordItem( unsigned short wordParameter )
		{
		WordItem *currentWordItem = commonVariables_->firstWordItem;	// Do in all words

		if( wordParameter > NO_WORD_PARAMETER )
			{
			while( currentWordItem != NULL )
				{
				if( currentWordItem->wordParameter() == wordParameter )
					return currentWordItem;

				currentWordItem = currentWordItem->nextWordItem();
				}
			}

		return NULL;
		}

	WordItem *WordItem::nextWordItem()
		{
		return (WordItem *)nextItem;
		}


	// Protected assignment functions

	unsigned int WordItem::numberOfActiveAssignments()
		{
		if( assignmentList != NULL )
			return assignmentList->numberOfActiveAssignments();

		return 0;
		}

	ResultType WordItem::createNewAssignmentLevel()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "createNewAssignmentLevel";
		if( wordAssignment_ != NULL ||
		// Create supporting module
		( wordAssignment_ = new WordAssignment( this, commonVariables_ ) ) != NULL )
			return wordAssignment_->createNewAssignmentLevel();

		return startErrorInWord( functionNameString, NULL, "I failed to create my word assignment module" );
		}

	ResultType WordItem::deleteAssignmentLevelInWord()
		{
		if( assignmentList != NULL )
			return assignmentList->deleteAssignmentLevelInList();

		return commonVariables_->result;
		}

	ResultType WordItem::deactivateActiveAssignment( SpecificationItem *activeItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "deactivateActiveAssignment";
		if( wordAssignment_ != NULL )
			return wordAssignment_->deactivateActiveAssignment( activeItem );

		return startErrorInWord( functionNameString, NULL, "The word assignment module isn't created yet" );
		}

	ResultType WordItem::archiveDeactiveAssignment( SpecificationItem *deactiveItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "archiveDeactivateAssignment";
		if( wordAssignment_ != NULL )
			return wordAssignment_->archiveDeactiveAssignment( deactiveItem );

		return startErrorInWord( functionNameString, NULL, "The word assignment module isn't created yet" );
		}

	SpecificationResultType WordItem::getAssignmentOrderNr( unsigned short collectionWordTypeNr )
		{
		SpecificationResultType specificationResult;

		if( wordAssignment_ != NULL )
			return wordAssignment_->getAssignmentOrderNr( collectionWordTypeNr );

		return specificationResult;
		}

	SpecificationResultType WordItem::getAssignmentWordParameter()
		{
		SpecificationResultType specificationResult;

		if( wordAssignment_ != NULL )
			return wordAssignment_->getAssignmentWordParameter();

		return specificationResult;
		}

	SpecificationResultType WordItem::assignSpecificationInWord( bool isAmbiguousRelationContext, bool isAssignedOrClear, bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, bool isSelfGenerated, unsigned short prepositionParameter, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int originalSentenceNr, unsigned int activeSentenceNr, unsigned int deactiveSentenceNr, unsigned int archiveSentenceNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *specificationWordItem, char *specificationString, void *changeKey )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "assignSpecificationInWord";

		if( isAuthorizedForChanges( changeKey ) )
			{
			if( specificationWordItem == NULL ||
			specificationWordItem->isAuthorizedForChanges( changeKey ) )
				{
				if( wordAssignment_ != NULL ||
				// Create supporting module
				( wordAssignment_ = new WordAssignment( this, commonVariables_ ) ) != NULL )
					return wordAssignment_->assignSpecification( isAmbiguousRelationContext, isAssignedOrClear, isDeactive, isArchived, isNegative, isPossessive, isSelfGenerated, prepositionParameter, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, originalSentenceNr, activeSentenceNr, deactiveSentenceNr, archiveSentenceNr, nContextRelations, specificationJustificationItem, specificationWordItem, specificationString );

				startErrorInWord( functionNameString, NULL, "I failed to create my word assignment module" );
				}
			else
				startErrorInWord( functionNameString, NULL, "You are not authorized to assign the given specification" );
			}
		else
			startErrorInWord( functionNameString, NULL, "You are not authorized to assign this word" );

		specificationResult.result = commonVariables_->result;
		return specificationResult;
		}

	SpecificationResultType WordItem::findAssignmentByRelationContext( bool isIncludingAnsweredQuestions, bool isDeactive, bool isArchived, bool isPossessive, unsigned short questionParameter, WordItem *relationContextWordItem )
		{
		SpecificationResultType specificationResult;

		if( assignmentList != NULL )
			return assignmentList->findAssignmentItemByRelationContext( isIncludingAnsweredQuestions, isDeactive, isArchived, isPossessive, questionParameter, relationContextWordItem );

		return specificationResult;
		}

	SpecificationResultType WordItem::createAssignment( bool isAnsweredQuestion, bool isConcludedAssumption, bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, bool isValueSpecification, unsigned short assignmentLevel, unsigned short assumptionLevel, unsigned short grammarLanguageNr, unsigned short prepositionParameter, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int originalSentenceNr, unsigned int activeSentenceNr, unsigned int deactiveSentenceNr, unsigned int archiveSentenceNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "createSpecification";

		if( wordAssignment_ != NULL )
			return wordAssignment_->createAssignment( isAnsweredQuestion, isConcludedAssumption, isDeactive, isArchived, isExclusive, isNegative, isPossessive, isValueSpecification, assignmentLevel, assumptionLevel, grammarLanguageNr, prepositionParameter, questionParameter, generalizationWordTypeNr, specificationWordTypeNr, generalizationCollectionNr, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, originalSentenceNr, activeSentenceNr, deactiveSentenceNr, archiveSentenceNr, nContextRelations, specificationJustificationItem, specificationWordItem, specificationString );

		specificationResult.result = startErrorInWord( functionNameString, NULL, "The word assignment module isn't created yet" );
		return specificationResult;
		}

	SpecificationItem *WordItem::firstActiveNumeralAssignment()
		{
		if( assignmentList != NULL )
			return assignmentList->firstNumeralAssignmentItem( false, false, false, false );

		return NULL;
		}

	SpecificationItem *WordItem::firstActiveStringAssignment()
		{
		if( assignmentList != NULL )
			return assignmentList->firstStringAssignmentItem( false, false, false, false );

		return NULL;
		}

	SpecificationItem *WordItem::firstActiveAssignmentButNotAQuestion()
		{
		if( assignmentList != NULL )
			return assignmentList->firstAssignmentItem( false, false, false, false );

		return NULL;
		}

	SpecificationItem *WordItem::lastActiveAssignmentButNotAQuestion()
		{
		if( assignmentList != NULL )
			return assignmentList->lastAssignmentItem( false, false, false, false );

		return NULL;
		}

	SpecificationItem *WordItem::firstActiveAssignment( bool isQuestion )
		{
		if( assignmentList != NULL )
			return assignmentList->firstAssignmentItem( false, false, false, isQuestion );

		return NULL;
		}

	SpecificationItem *WordItem::firstActiveAssignment( bool isIncludingAnsweredQuestions, unsigned short questionParameter )
		{
		if( assignmentList != NULL )
			return assignmentList->firstAssignmentItem( isIncludingAnsweredQuestions, false, false, questionParameter );

		return NULL;
		}

	SpecificationItem *WordItem::firstActiveAssignment( bool isDifferentRelationContext, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		if( assignmentList != NULL )
			return assignmentList->firstAssignmentItem( false, false, isDifferentRelationContext, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

		return NULL;
		}

	SpecificationItem *WordItem::firstAssignment( bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		if( assignmentList != NULL )
			return assignmentList->firstAssignmentItem( false, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

		return NULL;
		}

	SpecificationItem *WordItem::firstAssignment( bool includeActiveItems, bool includeDeactiveItems, bool includeArchivedItems, bool isNegative, bool isPossessive, bool isSelfGenerated, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		if( assignmentList != NULL )
			return assignmentList->firstAssignmentItem( includeActiveItems, includeDeactiveItems, includeArchivedItems, isNegative, isPossessive, isSelfGenerated, questionParameter, generalizationContextNr, specificationContextNr, specificationWordItem, specificationString );

		return NULL;
		}

	SpecificationItem *WordItem::firstAssignment( bool includeActiveItems, bool includeDeactiveItems, bool includeArchivedItems, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		if( assignmentList != NULL )
			return assignmentList->firstAssignmentItem( includeActiveItems, includeDeactiveItems, includeArchivedItems, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

		return NULL;
		}

	SpecificationItem *WordItem::firstAssignment( bool includeActiveItems, bool includeDeactiveItems, bool includeArchivedItems, bool isNegative, bool isPossessive, bool isSelfGenerated, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		if( assignmentList != NULL )
			return assignmentList->firstAssignmentItem( includeActiveItems, includeDeactiveItems, includeArchivedItems, isNegative, isPossessive, isSelfGenerated, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

		return NULL;
		}


	// Protected cleanup functions

	void WordItem::deleteWriteList()
		{
		if( writeList != NULL )
			writeList->deleteList();
		}

	unsigned int WordItem::highestSentenceNr()
		{
		unsigned int tempSentenceNr;
		unsigned int highestSentenceNr = NO_SENTENCE_NR;

		for( unsigned short wordListNr = 0; wordListNr < NUMBER_OF_WORD_LISTS; wordListNr++ )
			{
			if( wordList[wordListNr] != NULL &&
			( tempSentenceNr = wordList[wordListNr]->highestSentenceNrInList() ) > highestSentenceNr )
				highestSentenceNr = tempSentenceNr;
			}

		return highestSentenceNr;
		}

	ResultType WordItem::getCurrentItemNrInWord()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "getCurrentItemNrInWord";
		if( wordCleanup_ != NULL ||
		// Create supporting module
		( wordCleanup_ = new WordCleanup( this, commonVariables_ ) ) != NULL )
			return wordCleanup_->currentItemNr();

		return startErrorInWord( functionNameString, NULL, "I failed to create my word cleanup module" );
		}

	ResultType WordItem::getHighestInUseSentenceNrInWord( bool includeDeletedItems, bool includeLanguageAssignments, bool includeTemporaryLists, unsigned int highestSentenceNr )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "getHighestInUseSentenceNrInWord";
		if( wordCleanup_ != NULL ||
		// Create supporting module
		( wordCleanup_ = new WordCleanup( this, commonVariables_ ) ) != NULL )
			return wordCleanup_->getHighestInUseSentenceNr( includeDeletedItems, includeLanguageAssignments, includeTemporaryLists, highestSentenceNr );

		return startErrorInWord( functionNameString, NULL, "I failed to create my word cleanup module" );
		}

	ResultType WordItem::deleteRollbackInfo()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteRollbackInfoInWord";
		if( wordCleanup_ != NULL ||
		// Create supporting module
		( wordCleanup_ = new WordCleanup( this, commonVariables_ ) ) != NULL )
			return wordCleanup_->deleteRollbackInfo();

		return startErrorInWord( functionNameString, NULL, "I failed to create my word cleanup module" );
		}

	ResultType WordItem::deleteSentencesInWord( bool isAvailableForRollback, unsigned int lowestSentenceNr )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteSentencesInWord";
		if( wordCleanup_ != NULL ||
		// Create supporting module
		( wordCleanup_ = new WordCleanup( this, commonVariables_ ) ) != NULL )
			return wordCleanup_->deleteSentences( isAvailableForRollback, lowestSentenceNr );

		return startErrorInWord( functionNameString, NULL, "I failed to create my word cleanup module" );
		}

	ResultType WordItem::rollbackDeletedRedoInfo()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "rollbackDeletedRedoInfoInWord";
		if( wordCleanup_ != NULL ||
		// Create supporting module
		( wordCleanup_ = new WordCleanup( this, commonVariables_ ) ) != NULL )
			return wordCleanup_->rollbackDeletedRedoInfo();

		return startErrorInWord( functionNameString, NULL, "I failed to create my word cleanup module" );
		}

	ResultType WordItem::undoCurrentSentence()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "undoCurrentSentenceInWord";
		if( wordCleanup_ != NULL ||
		// Create supporting module
		( wordCleanup_ = new WordCleanup( this, commonVariables_ ) ) != NULL )
			return wordCleanup_->undoCurrentSentence();

		return startErrorInWord( functionNameString, NULL, "I failed to create my word cleanup module" );
		}

	ResultType WordItem::redoCurrentSentence()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "redoCurrentSentenceInWord";
		if( wordCleanup_ != NULL ||
		// Create supporting module
		( wordCleanup_ = new WordCleanup( this, commonVariables_ ) ) != NULL )
			return wordCleanup_->redoCurrentSentence();

		return startErrorInWord( functionNameString, NULL, "I failed to create my word cleanup module" );
		}

	ResultType WordItem::removeFirstRangeOfDeletedItems()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "removeFirstRangeOfDeletedItemsInWord";
		if( wordCleanup_ != NULL ||
		// Create supporting module
		( wordCleanup_ = new WordCleanup( this, commonVariables_ ) ) != NULL )
			return wordCleanup_->removeFirstRangeOfDeletedItems();

		return startErrorInWord( functionNameString, NULL, "I failed to create my word cleanup module" );
		}

	ResultType WordItem::decrementSentenceNrsInWord( unsigned int startSentenceNr )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "decrementSentenceNrsInWord";
		if( wordCleanup_ != NULL ||
		// Create supporting module
		( wordCleanup_ = new WordCleanup( this, commonVariables_ ) ) != NULL )
			return wordCleanup_->decrementSentenceNrs( startSentenceNr );

		return startErrorInWord( functionNameString, NULL, "I failed to create my word cleanup module" );
		}

	ResultType WordItem::decrementItemNrRangeInWord( unsigned int startSentenceNr, unsigned int decrementItemNr, unsigned int decrementOffset )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "decrementItemNrRangeInWord";
		if( wordCleanup_ != NULL ||
		// Create supporting module
		( wordCleanup_ = new WordCleanup( this, commonVariables_ ) ) != NULL )
			return wordCleanup_->decrementItemNrRange( startSentenceNr, decrementItemNr, decrementOffset );

		return startErrorInWord( functionNameString, NULL, "I failed to create my word cleanup module" );
		}


	// Protected collection functions

	bool WordItem::hasCollections()
		{
		return ( collectionList != NULL );
		}

	bool WordItem::hasCollection( WordItem *commonWordItem )
		{
		if( collectionList != NULL )
			return collectionList->hasCollectionItem( commonWordItem );

		return false;
		}

	bool WordItem::hasCollectionNr( unsigned int collectionNr )
		{
		if( collectionList != NULL )
			return collectionList->hasCollectionNr( collectionNr );

		return false;
		}

	bool WordItem::hasCollectionOrderNr( unsigned int collectionOrderNr )
		{
		if( collectionList != NULL )
			return collectionList->hasCollectionOrderNr( collectionOrderNr );

		return false;
		}

	bool WordItem::hasFoundCollection( unsigned int collectionNr, WordItem *collectionWordItem, WordItem *commonWordItem, WordItem *compoundGeneralizationWordItem )
		{
		if( collectionList != NULL )
			return collectionList->hasFoundCollection( collectionNr, collectionWordItem, commonWordItem, compoundGeneralizationWordItem );

		return false;
		}

	bool WordItem::isCompoundCollection( unsigned int collectionNr )
		{
		if( collectionList != NULL )
			return collectionList->isCompoundCollection( collectionNr );

		return false;
		}

	bool WordItem::isCompoundCollection( unsigned int collectionNr, WordItem *commonWordItem )
		{
		if( collectionList != NULL )
			return collectionList->isCompoundCollection( collectionNr, commonWordItem );

		return false;
		}

	bool WordItem::isCollectedCommonWord( WordItem *commonWordItem )
		{
		if( collectionList != NULL )
			return collectionList->isCollectedCommonWord( commonWordItem );

		return false;
		}

	bool WordItem::isExclusiveCollection( unsigned int collectionNr )
		{
		if( collectionList != NULL )
			return collectionList->isExclusiveCollection( collectionNr );

		return false;
		}

	unsigned short WordItem::collectionOrderNrByWordTypeNr( unsigned short collectionWordTypeNr )
		{
		if( collectionList != NULL )
			return collectionList->collectionOrderNrByWordTypeNr( collectionWordTypeNr );

		return NO_ORDER_NR;
		}

	unsigned short WordItem::collectionOrderNr( unsigned int collectionNr, WordItem *collectionWordItem, WordItem *commonWordItem )
		{
		if( collectionList != NULL )
			return collectionList->collectionOrderNr( collectionNr, collectionWordItem, commonWordItem );

		return NO_ORDER_NR;
		}

	unsigned short WordItem::highestCollectionOrderNrInAllWords( unsigned int collectionNr )
		{
		unsigned short tempCollectionOrderNr;
		unsigned short highestCollectionOrderNr = NO_ORDER_NR;
		WordItem *currentWordItem;

		if( collectionNr > NO_COLLECTION_NR &&
		( currentWordItem = commonVariables_->firstWordItem ) != NULL )		// Do in all words
			{
			do	{
				if( ( tempCollectionOrderNr = currentWordItem->highestCollectionOrderNrInWord( collectionNr ) ) > highestCollectionOrderNr )
					highestCollectionOrderNr = tempCollectionOrderNr;
				}
			while( ( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}

		return highestCollectionOrderNr;
		}

	unsigned int WordItem::collectionNr( unsigned short collectionWordTypeNr )
		{
		if( collectionList != NULL )
			return collectionList->collectionNr( collectionWordTypeNr );

		return NO_COLLECTION_NR;
		}

	unsigned int WordItem::collectionNr( unsigned short collectionWordTypeNr, WordItem *commonWordItem )
		{
		if( collectionList != NULL )
			return collectionList->collectionNr( collectionWordTypeNr, commonWordItem );

		return NO_COLLECTION_NR;
		}

	unsigned int WordItem::collectionNr( unsigned short collectionWordTypeNr, WordItem *commonWordItem, WordItem *compoundGeneralizationWordItem )
		{
		if( collectionList != NULL )
			return collectionList->collectionNr( collectionWordTypeNr, commonWordItem, compoundGeneralizationWordItem );

		return NO_COLLECTION_NR;
		}

	unsigned int WordItem::compoundCollectionNr( unsigned short collectionWordTypeNr )
		{
		if( collectionList != NULL )
			return collectionList->compoundCollectionNr( collectionWordTypeNr );

		return NO_COLLECTION_NR;
		}

	unsigned int WordItem::nonCompoundCollectionNr( unsigned short collectionWordTypeNr )
		{
		if( collectionList != NULL )
			return collectionList->nonCompoundCollectionNr( collectionWordTypeNr );

		return NO_COLLECTION_NR;
		}

	unsigned int WordItem::nonCompoundCollectionNrInAllWords( unsigned int compoundCollectionNr )
		{
		unsigned int nonCompoundCollectionNr;
		WordItem *currentWordItem;

		if( ( currentWordItem = commonVariables_->firstWordItem ) != NULL )
			{
			do	{
				if( ( nonCompoundCollectionNr = currentWordItem->nonCompoundCollectionNrInWord( compoundCollectionNr ) ) > NO_COLLECTION_NR )
					return nonCompoundCollectionNr;
				}
			while( ( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}

		return NO_COLLECTION_NR;
		}

	unsigned int WordItem::collectionNrInAllWords( unsigned int contextNr )
		{
		ContextItem *foundContextItem;
		WordItem *currentWordItem;

		if( contextNr > NO_CONTEXT_NR &&
		( currentWordItem = commonVariables_->firstWordItem ) != NULL )		// Do in all words
			{
			do	{
				if( ( foundContextItem = currentWordItem->contextItemInWord( contextNr ) ) != NULL )
					return currentWordItem->collectionNrByCommonWordInWord( foundContextItem->contextWordTypeNr(), foundContextItem->specificationWordItem() );
				}
			while( ( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}

		return NO_COLLECTION_NR;
		}

	unsigned int WordItem::collectionNrInAllWords( unsigned short collectionWordTypeNr, WordItem *compoundGeneralizationWordItem )
		{
		unsigned int collectionNr;
		WordItem *currentWordItem;

		if( collectionWordTypeNr > WORD_TYPE_UNDEFINED &&
		compoundGeneralizationWordItem != NULL &&
		( currentWordItem = commonVariables_->firstWordItem ) != NULL )		// Do in all words
			{
			do	{
				if( ( collectionNr = currentWordItem->collectionNrByCompoundGeneralizationWordInWord( collectionWordTypeNr, compoundGeneralizationWordItem ) ) > NO_COLLECTION_NR )
					return collectionNr;
				}
			while( ( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}

		return NO_COLLECTION_NR;
		}

	unsigned int WordItem::highestCollectionNrInAllWords()
		{
		unsigned int tempCollectionNr;
		unsigned int highestCollectionNr = NO_COLLECTION_NR;
		WordItem *currentWordItem;

		if( ( currentWordItem = commonVariables_->firstWordItem ) != NULL )		// Do in all words
			{
			do	{
				if( ( tempCollectionNr = currentWordItem->highestCollectionNrInWord() ) > highestCollectionNr )
					highestCollectionNr = tempCollectionNr;
				}
			while( ( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}

		return highestCollectionNr;
		}

	CollectionResultType WordItem::addCollectionByGeneralization( bool isExclusive, bool isExclusiveGeneralization, bool isQuestion, bool tryGeneralizations, unsigned short collectionWordTypeNr, WordItem *generalizationWordItem, WordItem *collectionWordItem )
		{
		CollectionResultType collectionResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addCollectionByGeneralization";

		if( wordCollection_ != NULL ||
		// Create supporting module
		( wordCollection_ = new WordCollection( this, commonVariables_ ) ) != NULL )
			return wordCollection_->addCollectionByGeneralization( isExclusive, isExclusiveGeneralization, isQuestion, tryGeneralizations, collectionWordTypeNr, generalizationWordItem, collectionWordItem );

		collectionResult.result = startErrorInWord( functionNameString, NULL, "I failed to create my word collection module" );
		return collectionResult;
		}

	CollectionResultType WordItem::findCollection( bool isAllowingDifferentCommonWord, WordItem *collectionWordItem, WordItem *commonWordItem )
		{
		CollectionResultType collectionResult;

		if( collectionList != NULL )
			return collectionList->findCollectionItem( isAllowingDifferentCommonWord, collectionWordItem, commonWordItem );

		return collectionResult;
		}

	ResultType WordItem::addCollection( bool isExclusive, bool isSpecificationGeneralization, unsigned short collectionWordTypeNr, unsigned short commonWordTypeNr, unsigned int collectionNr, WordItem *collectionWordItem, WordItem *commonWordItem, WordItem *compoundGeneralizationWordItem, char *collectionString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "addCollection";
		if( wordCollection_ != NULL ||
		// Create supporting module
		( wordCollection_ = new WordCollection( this, commonVariables_ ) ) != NULL )
			return wordCollection_->addCollection( isExclusive, isSpecificationGeneralization, collectionWordTypeNr, commonWordTypeNr, collectionNr, collectionWordItem, commonWordItem, compoundGeneralizationWordItem, collectionString );

		return startErrorInWord( functionNameString, NULL, "I failed to create my word collection module" );
		}

	WordItem *WordItem::commonWordItem( unsigned int collectionNr, WordItem *compoundGeneralizationWordItem )
		{
		if( collectionList != NULL )
			return collectionList->commonWordItem( collectionNr, compoundGeneralizationWordItem );

		return NULL;
		}

	WordItem *WordItem::compoundCollectionWordItem( unsigned int collectionNr, WordItem *notThisCommonWordItem )
		{
		if( collectionList != NULL )
			return collectionList->compoundCollectionWordItem( collectionNr, notThisCommonWordItem );

		return NULL;
		}


	// Protected context functions

	void WordItem::clearContextWriteLevelInWord( unsigned short currentWriteLevel, unsigned int contextNr )
		{
		if( contextList != NULL )
			contextList->clearContextWriteLevel( currentWriteLevel, contextNr );
		}

	bool WordItem::hasContextInWord( bool isPossessive, unsigned int contextNr, WordItem *specificationWordItem )
		{
		if( contextList != NULL )
			return contextList->hasContext( isPossessive, contextNr, specificationWordItem );

		return false;
		}

	bool WordItem::isContextCurrentlyUpdatedInAllWords( bool isPossessive, unsigned int contextNr, WordItem *specificationWordItem )
		{
		WordItem *currentWordItem;

		if( contextNr > NO_CONTEXT_NR &&
		( currentWordItem = commonVariables_->firstWordItem ) != NULL )		// Do in all words
			{
			do	{
				if( currentWordItem->isContextCurrentlyUpdatedInWord( isPossessive, contextNr, specificationWordItem ) )
					return true;
				}
			while( ( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}

		return false;
		}

	bool WordItem::isContextSimilarInAllWords( unsigned int firstContextNr, unsigned int secondContextNr )
		{
		WordItem *currentWordItem;

		if( firstContextNr > NO_CONTEXT_NR &&
		secondContextNr > NO_CONTEXT_NR &&
		( currentWordItem = commonVariables()->firstWordItem ) != NULL )	// Do in all words
			{
			do	{
				if( !currentWordItem->isContextSimilarInWord( firstContextNr, secondContextNr ) )
					return false;
				}
			while( ( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}

		return true;
		}

	bool WordItem::isContextSubsetInAllWords( unsigned int fullSetContextNr, unsigned int subsetContextNr )
		{
		WordItem *currentWordItem;

		if( subsetContextNr == NO_CONTEXT_NR ||
		fullSetContextNr == subsetContextNr )
			return true;

		if( fullSetContextNr > NO_CONTEXT_NR &&
		( currentWordItem = commonVariables_->firstWordItem ) != NULL )		// Do in all words
			{
			do	{
				if( currentWordItem->isContextSubsetInWord( fullSetContextNr, subsetContextNr ) )
					return true;
				}
			while( ( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}

		return false;
		}

	unsigned short WordItem::contextWordTypeNrInWord( unsigned int contextNr )
		{
		ContextItem *foundContextItem;

		if( contextNr > NO_CONTEXT_NR &&
		( foundContextItem = contextItemInWord( contextNr ) ) != NULL )		// Do in all words
			return foundContextItem->contextWordTypeNr();

		return WORD_TYPE_UNDEFINED;
		}

	unsigned short WordItem::contextWordTypeNrInAllWords( unsigned int contextNr )
		{
		unsigned short contextWordTypeNr;
		WordItem *currentWordItem;

		if( contextNr > NO_CONTEXT_NR &&
		( currentWordItem = commonVariables_->firstWordItem ) != NULL )		// Do in all words
			{
			do	{
				if( ( contextWordTypeNr = currentWordItem->contextWordTypeNrInWord( contextNr ) ) > WORD_TYPE_UNDEFINED )
					return contextWordTypeNr;
				}
			while( ( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}

		return WORD_TYPE_UNDEFINED;
		}

	unsigned int WordItem::contextNrInWord( bool isPossessive, unsigned short contextWordTypeNr, WordItem *specificationWordItem )
		{
		if( contextList != NULL )
			return contextList->contextNr( isPossessive, contextWordTypeNr, specificationWordItem );

		return NO_CONTEXT_NR;
		}

	unsigned int WordItem::highestContextNrInWord()
		{
		if( contextList != NULL )
			return contextList->highestContextNr();

		return NO_CONTEXT_NR;
		}

	unsigned int WordItem::nContextWords( bool isPossessive, unsigned int contextNr, WordItem *specificationWordItem )
		{
		unsigned int nContextWords = 0;
		WordItem *currentWordItem;

		if( contextNr > NO_CONTEXT_NR &&
		specificationWordItem != NULL &&
		( currentWordItem = commonVariables_->firstWordItem ) != NULL )		// Do in all words
			{
			do	{
				if( currentWordItem->hasContextInWord( isPossessive, contextNr, specificationWordItem ) )
					nContextWords++;
				}
			while( ( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}

		return nContextWords;
		}

	ResultType WordItem::addContext( bool isPossessive, unsigned short contextWordTypeNr, unsigned short specificationWordTypeNr, unsigned int contextNr, WordItem *specificationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "addContext";
		if( !iAmAdmin() )
			{
			if( contextList == NULL )
				{
				// Create list
				if( ( contextList = new ContextList( this, commonVariables_ ) ) != NULL )
					wordList[WORD_CONTEXT_LIST] = contextList;
				else
					return startErrorInWord( functionNameString, NULL, "I failed to create a context list" );
				}

			return contextList->addContext( isPossessive, contextWordTypeNr, specificationWordTypeNr, contextNr, specificationWordItem );
			}
		else
			return startErrorInWord( functionNameString, NULL, "The admin does not have context" );
		}

	ContextItem *WordItem::firstActiveContext()
		{
		if( contextList != NULL )
			return contextList->firstActiveContextItem();

		return NULL;
		}

	ContextItem *WordItem::contextItemInWord( bool isPossessive, unsigned short contextWordTypeNr, WordItem *specificationWordItem )
		{
		if( contextList != NULL )
			return contextList->contextItem( isPossessive, contextWordTypeNr, specificationWordItem );

		return NULL;
		}

	ContextItem *WordItem::contextItemInWord( bool isPossessive, unsigned short contextWordTypeNr, unsigned int contextNr, WordItem *specificationWordItem )
		{
		if( contextList != NULL )
			return contextList->contextItem( isPossessive, contextWordTypeNr, contextNr, specificationWordItem );

		return NULL;
		}

	WordItem *WordItem::contextWordInAllWords( bool isPossessive, unsigned int contextNr, WordItem *specificationWordItem, WordItem *previousWordItem )
		{
		WordItem *currentWordItem;

		if( contextNr > NO_CONTEXT_NR &&
		( currentWordItem = ( previousWordItem == NULL ? commonVariables_->firstWordItem : previousWordItem->nextWordItem() ) ) != NULL )
			{
			do	{
				if( currentWordItem->hasContextInWord( isPossessive, contextNr, specificationWordItem ) )
					return currentWordItem;
				}
			while( ( currentWordItem = currentWordItem->nextWordItem() ) != NULL );
			}

		return NULL;
		}


	// Protected generalization functions

	GeneralizationResultType WordItem::findGeneralization( bool isRelation, unsigned short questionParameter, unsigned short generalizationWordTypeNr, WordItem *generalizationWordItem )
		{
		GeneralizationResultType generalizationResult;

		if( generalizationList != NULL )
			return generalizationList->findGeneralizationItem( isRelation, questionParameter, generalizationWordTypeNr, generalizationWordItem );

		return generalizationResult;
		}

	ResultType WordItem::createGeneralization( bool isRelation, unsigned short questionParameter, unsigned short specificationWordTypeNr, unsigned short generalizationWordTypeNr, WordItem *generalizationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "createGeneralization";
		if( !iAmAdmin() )
			{
			if( generalizationList == NULL )
				{
				// Create list
				if( ( generalizationList = new GeneralizationList( this, commonVariables_ ) ) != NULL )
					wordList[WORD_GENERALIZATION_LIST] = generalizationList;
				else
					return startErrorInWord( functionNameString, NULL, "I failed to create a generalization list" );
				}

			return generalizationList->createGeneralizationItem( isRelation, questionParameter, specificationWordTypeNr, generalizationWordTypeNr, generalizationWordItem );
			}
		else
			return startErrorInWord( functionNameString, NULL, "The admin doesn't have generalizations" );
		}

	GeneralizationItem *WordItem::firstActiveGeneralizationItem()
		{
		if( generalizationList != NULL )
			return generalizationList->firstActiveGeneralizationItem();

		return NULL;
		}

	GeneralizationItem *WordItem::firstActiveGeneralizationItemOfSpecification()
		{
		if( generalizationList != NULL )
			return generalizationList->firstActiveGeneralizationItem( false );

		return NULL;
		}

	GeneralizationItem *WordItem::firstActiveGeneralizationItemOfRelation()
		{
		if( generalizationList != NULL )
			return generalizationList->firstActiveGeneralizationItem( true );

		return NULL;
		}


	// Protected grammar functions

	void WordItem::setOptionEnd()
		{
		if( grammarList != NULL )
			grammarList->setOptionEnd();
		}

	void WordItem::setChoiceEnd( unsigned int choiceEndItemNr )
		{
		if( grammarList != NULL )
			grammarList->setChoiceEnd( choiceEndItemNr );
		}

	bool WordItem::isGrammarLanguage()
		{
		return ( grammarList != NULL );
		}

	bool WordItem::needToCheckGrammar()
		{
		if( grammarList != NULL )
			return grammarList->needToCheckGrammar();

		return false;
		}

	unsigned short WordItem::guideByGrammarStringWordTypeNr( char *guideByGrammarString )
		{
		if( grammarList != NULL )
			return grammarList->guideByGrammarStringWordTypeNr( guideByGrammarString );

		return WORD_TYPE_UNDEFINED;
		}

	unsigned int WordItem::numberOfActiveGrammarLanguages()
		{
		unsigned int nLanguages = 0;
		GeneralizationItem *currentGeneralizationItem;
		WordItem *generalizationWordItem;

		if( commonVariables()->predefinedNounGrammarLanguageWordItem != NULL &&
		( currentGeneralizationItem = commonVariables()->predefinedNounGrammarLanguageWordItem->firstActiveGeneralizationItemOfSpecification() ) != NULL )
			{
			do	{
				if( ( generalizationWordItem = currentGeneralizationItem->generalizationWordItem() ) != NULL )
					{
					if( generalizationWordItem->isGrammarLanguage() )
						nLanguages++;
					}
				}
			while( ( currentGeneralizationItem = currentGeneralizationItem->nextGeneralizationItemOfSpecification() ) != NULL );
			}

		return nLanguages;
		}

	GrammarResultType WordItem::createGrammar( bool isDefinitionStart, bool isNewStart, bool isOptionStart, bool isChoiceStart, bool skipOptionForWriting, unsigned short wordTypeNr, unsigned short grammarParameter, size_t grammarStringLength, char *grammarString, GrammarItem *definitionGrammarItem )
		{
		GrammarResultType grammarResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "createGrammar";

		if( !iAmAdmin() )
			{
			if( grammarList == NULL )
				{
				if( ( grammarList = new GrammarList( this, commonVariables_ ) ) != NULL )
					wordList[WORD_GRAMMAR_LANGUAGE_LIST] = grammarList;
				else
					{
					grammarResult.result = startErrorInWord( functionNameString, NULL, "I failed to create a grammar list" );
					return grammarResult;
					}
				}

			return grammarList->createGrammarItem( isDefinitionStart, isNewStart, isOptionStart, isChoiceStart, skipOptionForWriting, wordTypeNr, grammarParameter, grammarStringLength, grammarString, definitionGrammarItem );
			}
		else
			startErrorInWord( functionNameString, NULL, "The admin doesn't have grammar" );

		grammarResult.result = commonVariables()->result;
		return grammarResult;
		}

	GrammarResultType WordItem::findGrammar( bool ignoreValue, unsigned short grammarParameter, size_t grammarStringLength, char *grammarString )
		{
		GrammarResultType grammarResult;

		if( grammarList != NULL )
			return grammarList->findGrammarItem( ignoreValue, grammarParameter, grammarStringLength, grammarString );

		return grammarResult;
		}

	GrammarResultType WordItem::removeDuplicateGrammarDefinition()
		{
		GrammarResultType grammarResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "removeDuplicateGrammarDefinitionInWord";

		if( grammarList != NULL )
			return grammarList->removeDuplicateGrammarDefinition();

		grammarResult.result = startErrorInWord( functionNameString, NULL, "The grammar list isn't created yet" );
		return grammarResult;
		}

	ResultType WordItem::checkGrammar()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkGrammarInWord";
		if( grammarList != NULL )
			return grammarList->checkGrammar();

		return startErrorInWord( functionNameString, NULL, "The grammar list isn't created yet" );
		}

	ResultType WordItem::checkGrammarForUsageInWord( GrammarItem *unusedGrammarItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkJustificationForUsageInWord";
		if( grammarList != NULL )
			{
			if( grammarList->checkGrammarItemForUsage( unusedGrammarItem ) == RESULT_OK )
				{
				if( writeList != NULL )
					return writeList->checkGrammarItemForUsage( unusedGrammarItem );
				}
			}
		else
			return startErrorInWord( functionNameString, NULL, "The grammar list isn't created yet" );

		return commonVariables_->result;
		}

	ResultType WordItem::linkLaterDefinedGrammarWords()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "linkLaterDefinedGrammarWordsInWord";
		if( grammarList != NULL )
			return grammarList->linkLaterDefinedGrammarWords();

		return startErrorInWord( functionNameString, NULL, "The grammar list isn't created yet" );
		}

	GrammarItem *WordItem::firstPluralNounEndingGrammarItem()
		{
		GrammarItem *firstGrammarItem;

		if( grammarList != NULL &&
		( firstGrammarItem = grammarList->firstActiveGrammarItem() ) != NULL )
			return firstGrammarItem->firstPluralNounEndingGrammarItem();

		return NULL;
		}

	GrammarItem *WordItem::startOfGrammarItem()
		{
		if( grammarList != NULL )
			return grammarList->startOfGrammarItem();

		return NULL;
		}

	char *WordItem::getGuideByGrammarString( GrammarItem *startGrammarItem )
		{
		if( grammarList != NULL )
			return grammarList->getGuideByGrammarString( startGrammarItem );

		return NULL;
		}


	// Protected interface functions

	bool WordItem::isInterfaceLanguage()
		{
		return ( interfaceList != NULL );
		}

	ResultType WordItem::checkInterface( unsigned short interfaceParameter, char *interfaceString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkInterface";
		if( !iAmAdmin() )
			{
			if( interfaceList == NULL )
				{
				// Create list
				if( ( interfaceList = new InterfaceList( this, commonVariables_ ) ) != NULL )
					wordList[WORD_INTERFACE_LANGUAGE_LIST] = interfaceList;
				else
					return startErrorInWord( functionNameString, NULL, "I failed to create an interface list" );
				}

			return interfaceList->checkInterface( interfaceParameter, interfaceString );
			}
		else
			return startErrorInWord( functionNameString, NULL, "The admin doesn't have interfacing" );
		}

	ResultType WordItem::createInterface( unsigned short interfaceParameter, size_t interfaceStringLength, char *interfaceString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "createInterface";
		if( interfaceList != NULL )
			return interfaceList->createInterfaceItem( interfaceParameter, interfaceStringLength, interfaceString );

		return startErrorInWord( functionNameString, NULL, "The interface list isn't created yet" );
		}

	const char *WordItem::interfaceString( unsigned short interfaceParameter )
		{
		if( interfaceList != NULL )
			return interfaceList->interfaceString( interfaceParameter );

		return INTERFACE_STRING_NOT_AVAILABLE;
		}


	// Protected justification functions

	bool WordItem::needToRecalculateAssumptionsAfterwards()
		{
		if( justificationList != NULL )
			return justificationList->needToRecalculateAssumptionsAfterwards();

		return false;
		}

	JustificationResultType WordItem::addJustification( bool forceToCreateJustification, unsigned short justificationTypeNr, unsigned short orderNr, unsigned int originalSentenceNr, JustificationItem *attachedJustificationItem, SpecificationItem *definitionSpecificationItem, SpecificationItem *anotherDefinitionSpecificationItem, SpecificationItem *specificSpecificationItem )
		{
		JustificationResultType justificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addJustification";

		if( !iAmAdmin() )
			{
			if( justificationList == NULL )
				{
				if( ( justificationList = new JustificationList( myWord(), commonVariables_ ) ) != NULL )
					wordList[WORD_JUSTIFICATION_LIST] = justificationList;
				else
					{
					justificationResult.result = startErrorInWord( functionNameString, NULL, "I failed to create a justification list" );
					return justificationResult;
					}
				}

			return justificationList->addJustificationItem( forceToCreateJustification, true, justificationTypeNr, orderNr, originalSentenceNr, attachedJustificationItem, definitionSpecificationItem, anotherDefinitionSpecificationItem, specificSpecificationItem );
			}
		else
			startErrorInWord( functionNameString, NULL, "The admin does not have justification" );

		justificationResult.result = commonVariables()->result;
		return justificationResult;
		}

	JustificationResultType WordItem::checkForConfirmedJustifications( bool isExclusiveGeneralization, unsigned short justificationTypeNr, JustificationItem *specificationJustificationItem, SpecificationItem *definitionSpecificationItem, SpecificationItem *specificSpecificationItem, WordItem *specificationWordItem )
		{
		JustificationResultType justificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkForConfirmedJustifications";
		if( justificationList != NULL )
			return justificationList->checkForConfirmedJustificationItems( isExclusiveGeneralization, justificationTypeNr, specificationJustificationItem, definitionSpecificationItem, specificSpecificationItem, specificationWordItem );

		justificationResult.result = startErrorInWord( functionNameString, NULL, "The justification list isn't created yet" );
		return justificationResult;
		}

	ResultType WordItem::attachJustification( JustificationItem *attachJustificationItem, SpecificationItem *currentSpecificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "attachJustification";
		if( justificationList != NULL )
			return justificationList->attachJustificationItem( attachJustificationItem, currentSpecificationItem );

		return startErrorInWord( functionNameString, NULL, "The justification list isn't created yet" );
		}

	ResultType WordItem::archiveJustification( bool isExclusiveGeneralization, JustificationItem *oldJustificationItem, JustificationItem *replacingJustificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "archiveJustification";
		if( justificationList != NULL )
			return justificationList->archiveJustificationItem( false, isExclusiveGeneralization, oldJustificationItem, replacingJustificationItem );

		return startErrorInWord( functionNameString, NULL, "The justification list isn't created yet" );
		}

	ResultType WordItem::checkSpecificationForUsageOfInvolvedWords( SpecificationItem *unusedSpecificationItem )
		{
		GeneralizationItem *currentGeneralizationItem;
		WordItem *currentGeneralizationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkSpecificationForUsageOfInvolvedWords";

		if( justificationList != NULL )
			justificationList->checkSpecificationItemForUsage( unusedSpecificationItem );

		if( commonVariables_->result == RESULT_OK )
			{
			if( checkSpecificationForUsageInWord( unusedSpecificationItem ) == RESULT_OK )
				{
				if( ( currentGeneralizationItem = firstActiveGeneralizationItem() ) != NULL )
					{
					do	{
						if( ( currentGeneralizationWordItem = currentGeneralizationItem->generalizationWordItem() ) != NULL )
							{
							if( currentGeneralizationWordItem->checkSpecificationForUsageInWord( unusedSpecificationItem ) != RESULT_OK )
								return addErrorInWord( functionNameString, NULL, "I failed to check the specifications in generalization word \"", currentGeneralizationWordItem->anyWordTypeString(), "\" for its usage" );
							}
						else
							return startErrorInWord( functionNameString, NULL, "I found an undefined generalization word" );
						}
					while( ( currentGeneralizationItem = currentGeneralizationItem->nextGeneralizationItem() ) != NULL );
					}
				}
			else
				return addErrorInWord( functionNameString, NULL, "I failed to check my specifications" );
			}

		return commonVariables_->result;
		}

	ResultType WordItem::updateSpecificationsInJustificationInWord( SpecificationItem *oldSpecificationItem, SpecificationItem *replacingSpecificationItem )
		{
		if( justificationList != NULL )
			{
			if( justificationList->updateSpecificationsInJustificationItems( true, oldSpecificationItem, replacingSpecificationItem ) == RESULT_OK )
				return justificationList->updateSpecificationsInJustificationItems( false, oldSpecificationItem, replacingSpecificationItem );
			}

		return commonVariables_->result;
		}


	// Protected query functions

	void WordItem::countQuery()
		{
		if( wordQuery_ != NULL )
			wordQuery_->countQuery();
		}

	void WordItem::clearQuerySelections()
		{
		if( wordQuery_ != NULL )
			wordQuery_->clearQuerySelections();
		}

	ResultType WordItem::itemQueryInWord( bool isSelectOnFind, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, bool isReferenceQuery, unsigned int querySentenceNr, unsigned int queryItemNr )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "itemQueryInWord";
		if( wordQuery_ != NULL ||
		// Create supporting module
		( wordQuery_ = new WordQuery( this, commonVariables_ ) ) != NULL )
			return wordQuery_->itemQuery( isSelectOnFind, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, isReferenceQuery, querySentenceNr, queryItemNr );

		return startErrorInWord( functionNameString, NULL, "I failed to create my word query module" );
		}

	ResultType WordItem::listQueryInWord( bool isSelectOnFind, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *queryListString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "listQueryInWord";
		if( wordQuery_ != NULL ||
		// Create supporting module
		( wordQuery_ = new WordQuery( this, commonVariables_ ) ) != NULL )
			return wordQuery_->listQuery( isSelectOnFind, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryListString );

		return startErrorInWord( functionNameString, NULL, "I failed to create my word query module" );
		}

	ResultType WordItem::wordTypeQueryInWord( bool isSelectOnFind, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, unsigned short queryWordTypeNr )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "wordTypeQueryInWord";
		if( wordQuery_ != NULL ||
		// Create supporting module
		( wordQuery_ = new WordQuery( this, commonVariables_ ) ) != NULL )
			return wordQuery_->wordTypeQuery( isSelectOnFind, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryWordTypeNr );

		return startErrorInWord( functionNameString, NULL, "I failed to create my word query module" );
		}

	ResultType WordItem::parameterQueryInWord( bool isSelectOnFind, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, unsigned int queryParameter )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "parameterQueryInWord";
		if( wordQuery_ != NULL ||
		// Create supporting module
		( wordQuery_ = new WordQuery( this, commonVariables_ ) ) != NULL )
			return wordQuery_->parameterQuery( isSelectOnFind, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryParameter );

		return startErrorInWord( functionNameString, NULL, "I failed to create my word query module" );
		}

	ResultType WordItem::wordQueryInWord( bool isSelectOnFind, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *wordNameString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "wordQueryInWord";
		if( wordQuery_ != NULL ||
		// Create supporting module
		( wordQuery_ = new WordQuery( this, commonVariables_ ) ) != NULL )
			return wordQuery_->wordQuery( isSelectOnFind, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordNameString );

		return startErrorInWord( functionNameString, NULL, "I failed to create my word query module" );
		}

	ResultType WordItem::wordReferenceQueryInWord( bool isSelectOnFind, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *wordReferenceNameString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "wordReferenceQueryInWord";
		if( wordQuery_ != NULL ||
		// Create supporting module
		( wordQuery_ = new WordQuery( this, commonVariables_ ) ) != NULL )
			return wordQuery_->wordReferenceQuery( isSelectOnFind, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, wordReferenceNameString );

		return startErrorInWord( functionNameString, NULL, "I failed to create my word query module" );
		}

	ResultType WordItem::stringQueryInWord( bool isSelectOnFind, bool isSelectActiveItems, bool isSelectDeactiveItems, bool isSelectArchivedItems, bool isSelectDeletedItems, char *queryString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "stringQueryInWord";
		if( wordQuery_ != NULL ||
		// Create supporting module
		( wordQuery_ = new WordQuery( this, commonVariables_ ) ) != NULL )
			return wordQuery_->stringQuery( isSelectOnFind, isSelectActiveItems, isSelectDeactiveItems, isSelectArchivedItems, isSelectDeletedItems, queryString );

		return startErrorInWord( functionNameString, NULL, "I failed to create my word query module" );
		}

	ResultType WordItem::showQueryResultInWord( bool showOnlyWords, bool showOnlyWordReferences, bool showOnlyStrings, bool returnQueryToPosition, unsigned short promptTypeNr, unsigned short queryWordTypeNr, size_t queryWidth )
		{
		if( wordQuery_ != NULL )
			return wordQuery_->showQueryResult( showOnlyWords, showOnlyWordReferences, showOnlyStrings, returnQueryToPosition, promptTypeNr, queryWordTypeNr, queryWidth );

		return commonVariables_->result;
		}


	// Protected question functions

	ResultType WordItem::findAnswerToNewUserQuestion()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "findAnswerToNewUserQuestionInWord";
		if( wordQuestion_ != NULL ||
		// Create supporting module
		( wordQuestion_ = new WordQuestion( this, commonVariables_ ) ) != NULL )
			return wordQuestion_->findAnswerToNewUserQuestion();

		return startErrorInWord( functionNameString, NULL, "I failed to create my word question module" );
		}

	ResultType WordItem::findPossibleQuestionAndMarkAsAnswered( unsigned int compoundSpecificationCollectionNr, SpecificationItem *answerSpecificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "findPossibleQuestionAndMarkAsAnswered";
		if( wordQuestion_ != NULL ||
		// Create supporting module
		( wordQuestion_ = new WordQuestion( this, commonVariables_ ) ) != NULL )
			return wordQuestion_->findPossibleQuestionAndMarkAsAnswered( compoundSpecificationCollectionNr, answerSpecificationItem );

		return startErrorInWord( functionNameString, NULL, "I failed to create my word question module" );
		}

	ResultType WordItem::writeAnswerToQuestion( bool isNegativeAnswer, bool isPositiveAnswer, SpecificationItem *questionSpecificationItem, SpecificationItem *answerSpecificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeAnswerToQuestion";
		if( wordQuestion_ != NULL )
			return wordQuestion_->writeAnswerToQuestion( isNegativeAnswer, isPositiveAnswer, false, questionSpecificationItem, answerSpecificationItem );

		return startErrorInWord( functionNameString, NULL, "The word question module isn't created yet" );
		}

	SpecificationResultType WordItem::findQuestionToAdjustedByCompoundCollection( bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeAnswerToQuestion";

		if( wordQuestion_ != NULL )
			return wordQuestion_->findQuestionToAdjustedByCompoundCollection( isNegative, isPossessive, questionParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem );

		specificationResult.result = startErrorInWord( functionNameString, NULL, "The word question module isn't created yet" );
		return specificationResult;
		}


	// Protected selection functions

	ResultType WordItem::checkSelectionForUsageInWord( SelectionItem *unusedSelectionItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkSelectionForUsageInWord";
		if( commonVariables_->adminScoreList != NULL )
			{
			if( commonVariables_->adminScoreList->checkSelectionItemForUsage( unusedSelectionItem ) != RESULT_OK )
				return addErrorInWord( functionNameString, NULL, "The admin score list isn't created yet" );
			}

		if( commonVariables_->adminConditionList != NULL )
			{
			if( commonVariables_->adminConditionList->checkSelectionItemForUsage( unusedSelectionItem ) != RESULT_OK )
				return addErrorInWord( functionNameString, NULL, "The admin condition list isn't created yet" );
			}

		if( commonVariables_->adminActionList != NULL )
			{
			if( commonVariables_->adminActionList->checkSelectionItemForUsage( unusedSelectionItem ) != RESULT_OK )
				return addErrorInWord( functionNameString, NULL, "The admin action list isn't created yet" );
			}

		if( commonVariables_->adminAlternativeList != NULL )
			{
			if( commonVariables_->adminAlternativeList->checkSelectionItemForUsage( unusedSelectionItem ) != RESULT_OK )
				return addErrorInWord( functionNameString, NULL, "The admin alternative list isn't created yet" );
			}

		return commonVariables_->result;
		}


	// Protected specification functions

	void WordItem::clearLastCheckedAssumptionLevelItemNrInWord()
		{
		if( assignmentList != NULL )
			{
			assignmentList->clearLastCheckedAssumptionLevelItemNr( false, false );
			assignmentList->clearLastCheckedAssumptionLevelItemNr( true, false );
			assignmentList->clearLastCheckedAssumptionLevelItemNr( false, true );
			}

		if( specificationList != NULL )
			specificationList->clearLastCheckedAssumptionLevelItemNr( false, false );
		}

	void WordItem::clearHasConfirmedAssumption()
		{
		if( wordSpecification_ != NULL )
			wordSpecification_->clearHasConfirmedAssumption();
		}

	void WordItem::clearLastShownConflictSpecification()
		{
		if( wordSpecification_ != NULL )
			wordSpecification_->clearLastShownConflictSpecification();
		}

	bool WordItem::addSuggestiveQuestionAssumption()
		{
		if( wordSpecification_ != NULL )
			return wordSpecification_->addSuggestiveQuestionAssumption();

		return false;
		}

	bool WordItem::isConfirmedAssumption()
		{
		if( wordSpecification_ != NULL )
			return wordSpecification_->isConfirmedAssumption();

		return false;
		}

	bool WordItem::hasPossessiveSpecificationButNotAQuestion()
		{
		if( specificationList != NULL )
			return specificationList->hasPossessiveSpecificationItemButNotAQuestion();

		return false;
		}

	bool WordItem::isAuthorizedForChanges( void *changeKey )
		{
		return ( changeKey_ == NULL ||
				changeKey_ == changeKey );
		}

	bool WordItem::isCorrectedAssumption()
		{
		if( wordSpecification_ != NULL )
			return wordSpecification_->isCorrectedAssumption();

		return false;
		}

	bool WordItem::isCorrectedAssumptionByKnowledge()
		{
		if( wordSpecification_ != NULL )
			return wordSpecification_->isCorrectedAssumptionByKnowledge();

		return false;
		}

	bool WordItem::isCorrectedAssumptionByOppositeQuestion()
		{
		if( wordSpecification_ != NULL )
			return wordSpecification_->isCorrectedAssumptionByOppositeQuestion();

		return false;
		}

	ResultType WordItem::archiveOrDeletedSpecification( SpecificationItem *oldSpecificationItem, SpecificationItem *replacingSpecificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "archiveOrDeletedSpecification";
		if( oldSpecificationItem != NULL )
			{
			if( oldSpecificationItem->isAssignment() )
				{
				if( assignmentList != NULL )
					return assignmentList->archiveOrDeletedSpecificationItem( oldSpecificationItem, replacingSpecificationItem );

				return startErrorInWord( functionNameString, NULL, "The assignment list isn't created yet" );
				}
			else
				{
				if( specificationList != NULL )
					return specificationList->archiveOrDeletedSpecificationItem( oldSpecificationItem, replacingSpecificationItem );

				return startErrorInWord( functionNameString, NULL, "The specification list isn't created yet" );
				}
			}
		else
			return startErrorInWord( functionNameString, NULL, "The given old specification item is undefined" );
		}

	ResultType WordItem::checkForSpecificationConflict( bool skipCompoundRelatedConflict, bool isExclusive, bool isNegative, bool isPossessive, unsigned short specificationWordTypeNr, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkForSpecificationConflict";
		if( wordSpecification_ != NULL )
			return wordSpecification_->checkForSpecificationConflict( skipCompoundRelatedConflict, isExclusive, isNegative, isPossessive, specificationWordTypeNr, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, relationWordItem, specificationString );

		return startErrorInWord( functionNameString, NULL, "The word specification module isn't created yet" );
		}

	ResultType WordItem::checkJustificationForUsageInWord( JustificationItem *unusedJustificationItem )
		{
		if( assignmentList != NULL &&
		assignmentList->checkJustificationItemForUsage( false, false, unusedJustificationItem ) == RESULT_OK )
			{
			if( assignmentList->checkJustificationItemForUsage( true, false, unusedJustificationItem ) == RESULT_OK )
				assignmentList->checkJustificationItemForUsage( false, true, unusedJustificationItem );
			}

		if( commonVariables_->result == RESULT_OK &&
		specificationList != NULL )
			specificationList->checkJustificationItemForUsage( false, false, unusedJustificationItem );

		if( commonVariables_->result == RESULT_OK &&
		justificationList != NULL )
			justificationList->checkJustificationItemForUsage( unusedJustificationItem );

		return commonVariables_->result;
		}

	ResultType WordItem::collectGeneralizationAndSpecifications( bool isExclusiveGeneralization, bool isGeneralizationCollection, bool isQuestion, unsigned int collectionNr )
		{
		if( assignmentList != NULL &&
		assignmentList->collectGeneralizationAndSpecifications( false, false, isExclusiveGeneralization, isGeneralizationCollection, isQuestion, collectionNr ) == RESULT_OK )
			{
			if( assignmentList->collectGeneralizationAndSpecifications( true, false, isExclusiveGeneralization, isGeneralizationCollection, isQuestion, collectionNr ) == RESULT_OK )
				assignmentList->collectGeneralizationAndSpecifications( false, true, isExclusiveGeneralization, isGeneralizationCollection, isQuestion, collectionNr );
			}

		if( commonVariables_->result == RESULT_OK &&
		specificationList != NULL )
			return specificationList->collectGeneralizationAndSpecifications( false, false, isExclusiveGeneralization, isGeneralizationCollection, isQuestion, collectionNr );

		return commonVariables_->result;
		}

	ResultType WordItem::confirmSpecificationButNotRelation( SpecificationItem *confirmedSpecificationItem, SpecificationItem *confirmationSpecificationItem )
		{
		if( assignmentList != NULL )
			{
			if( assignmentList->confirmSpecificationButNotRelation( false, false, confirmedSpecificationItem, confirmationSpecificationItem ) == RESULT_OK )
				{
				if( assignmentList->confirmSpecificationButNotRelation( true, false, confirmedSpecificationItem, confirmationSpecificationItem ) == RESULT_OK )
					assignmentList->confirmSpecificationButNotRelation( false, true, confirmedSpecificationItem, confirmationSpecificationItem );
				}
			}

		if( commonVariables_->result == RESULT_OK &&
		specificationList != NULL )
			specificationList->confirmSpecificationButNotRelation( false, false, confirmedSpecificationItem, confirmationSpecificationItem );

		return commonVariables_->result;
		}

	ResultType WordItem::recalculateAssumptionsInWord()
		{
		if( assignmentList != NULL &&
		specificationList->recalculateAssumptions( false, false ) == RESULT_OK )
			{
			if( specificationList->recalculateAssumptions( true, false ) == RESULT_OK )
				specificationList->recalculateAssumptions( false, true );
			}

		if( commonVariables_->result == RESULT_OK &&
		specificationList != NULL )
			return specificationList->recalculateAssumptions( false, false );

		return commonVariables_->result;
		}

	ResultType WordItem::recalculateAssumptionsOfInvolvedWords()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "recalculateAssumptionsOfInvolvedWords";
		if( wordSpecification_ != NULL )
			return wordSpecification_->recalculateAssumptionsOfInvolvedWords();

		return startErrorInWord( functionNameString, NULL, "The word specification module isn't created yet" );
		}

	ResultType WordItem::replaceOlderSpecifications( unsigned int oldRelationContextNr, SpecificationItem *replacingSpecificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "replaceOlderSpecifications";
		if( specificationList != NULL )
			return specificationList->replaceOlderSpecificationItems( oldRelationContextNr, replacingSpecificationItem );

		return startErrorInWord( functionNameString, NULL, "The specification list isn't created yet" );
		}

	ResultType WordItem::updateJustificationInSpecifications( bool isExclusive, bool isExclusiveGeneralization, JustificationItem *oldJustificationItem, JustificationItem *replacingJustificationItem )
		{
		if( assignmentList != NULL )
			{
			if( assignmentList->updateJustificationInSpecificationItems( isExclusive, isExclusiveGeneralization, false, false, oldJustificationItem, replacingJustificationItem ) == RESULT_OK )
				{
				if( assignmentList->updateJustificationInSpecificationItems( isExclusive, isExclusiveGeneralization, true, false, oldJustificationItem, replacingJustificationItem ) == RESULT_OK )
					assignmentList->updateJustificationInSpecificationItems( isExclusive, isExclusiveGeneralization, false, true, oldJustificationItem, replacingJustificationItem );
				}
			}

		if( commonVariables_->result == RESULT_OK &&
		specificationList != NULL )
			return specificationList->updateJustificationInSpecificationItems( isExclusive, isExclusiveGeneralization, false, false, oldJustificationItem, replacingJustificationItem );

		return commonVariables_->result;
		}

	ResultType WordItem::updateSpecificationsInJustificationOfInvolvedWords( SpecificationItem *oldSpecificationItem, SpecificationItem *replacingSpecificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "updateSpecificationsInJustificationOfInvolvedWords";
		if( wordSpecification_ != NULL )
			return wordSpecification_->updateSpecificationsInJustificationOfInvolvedWords( oldSpecificationItem, replacingSpecificationItem );

		return startErrorInWord( functionNameString, NULL, "The word specification module isn't created yet" );
		}

	SpecificationResultType WordItem::addSpecificationInWord( bool isAssignment, bool isConditional, bool isDeactiveAssignment, bool isArchivedAssignment, bool isExclusive, bool isNegative, bool isPossessive, bool isSelection, bool isSpecificationGeneralization, bool isValueSpecification, unsigned short prepositionParameter, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString, void *changeKey )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addSpecificationInWord";

		if( isAuthorizedForChanges( changeKey ) )
			{
			if( specificationWordItem == NULL ||
			specificationWordItem->isAuthorizedForChanges( changeKey ) )
				{
				if( wordSpecification_ != NULL ||
				// Create supporting module
				( wordSpecification_ = new WordSpecification( this, commonVariables_ ) ) != NULL )
					return wordSpecification_->addSpecification( isAssignment, isConditional, isDeactiveAssignment, isArchivedAssignment, isExclusive, isNegative, isPossessive, isSelection, isSpecificationGeneralization, isValueSpecification, prepositionParameter, questionParameter, generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, generalizationCollectionNr, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, nContextRelations, specificationJustificationItem, specificationWordItem, relationWordItem, specificationString );

				startErrorInWord( functionNameString, NULL, "I failed to create my word specification module" );
				}
			else
				startErrorInWord( functionNameString, NULL, "You are not authorized to add the given specification" );
			}
		else
			startErrorInWord( functionNameString, NULL, "You are not authorized to add this word" );

		specificationResult.result = commonVariables_->result;
		return specificationResult;
		}

	SpecificationResultType WordItem::createSpecification( bool isAnsweredQuestion, bool isConditional, bool isConcludedAssumption, bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, bool isSpecificationGeneralization, bool isValueSpecification, unsigned short assumptionLevel, unsigned short grammarLanguageNr, unsigned short prepositionParameter, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int originalSentenceNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "createSpecification";

		if( wordSpecification_ != NULL )
			return wordSpecification_->createSpecification( isAnsweredQuestion, isConditional, isConcludedAssumption, isDeactive, isArchived, isExclusive, isNegative, isPossessive, isSpecificationGeneralization, isValueSpecification, assumptionLevel, grammarLanguageNr, prepositionParameter, questionParameter, generalizationWordTypeNr, specificationWordTypeNr, generalizationCollectionNr, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, originalSentenceNr, nContextRelations, specificationJustificationItem, specificationWordItem, specificationString );

		specificationResult.result = startErrorInWord( functionNameString, NULL, "The word specification module isn't created yet" );
		return specificationResult;
		}

	SpecificationResultType WordItem::findRelatedSpecification( bool checkRelationContext, SpecificationItem *searchSpecificationItem )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findRelatedSpecification";

		if( wordSpecification_ != NULL )
			return wordSpecification_->findRelatedSpecification( checkRelationContext, searchSpecificationItem );

		specificationResult.result = startErrorInWord( functionNameString, NULL, "The word specification module isn't created yet" );
		return specificationResult;
		}

	SpecificationResultType WordItem::findRelatedSpecification( bool includeAssignments, bool includingDeactiveAssignments, bool isExclusive, bool isPossessive, unsigned short questionParameter, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findRelatedSpecification";

		if( wordSpecification_ != NULL )
			return wordSpecification_->findRelatedSpecification( false, false, false, includeAssignments, includingDeactiveAssignments, isExclusive, isPossessive, questionParameter, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, relationWordItem, specificationString );

		specificationResult.result = startErrorInWord( functionNameString, NULL, "The word specification module isn't created yet" );
		return specificationResult;
		}

	SpecificationResultType WordItem::findSpecification( bool includeAssignments, bool includingDeactiveAssignments, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, WordItem *specificationWordItem, WordItem *relationWordItem )
		{
		SpecificationResultType specificationResult;

		if( includeAssignments &&
		assignmentList != NULL )
			specificationResult = assignmentList->findSpecificationItem( includingDeactiveAssignments, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, specificationWordItem, relationWordItem );

		if( commonVariables_->result == RESULT_OK &&
		specificationResult.foundSpecificationItem == NULL &&
		specificationList != NULL )
			return specificationList->findSpecificationItem( false, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, specificationWordItem, relationWordItem );

		specificationResult.result = commonVariables_->result;
		return specificationResult;
		}

	SpecificationItem *WordItem::firstActiveQuestionSpecification()
		{
		if( specificationList != NULL )
			return specificationList->firstActiveSpecificationItem( false, true );

		return NULL;
		}

	SpecificationItem *WordItem::firstAssignmentOrSpecification( bool isPossessive, unsigned short questionParameter, unsigned int relationContextNr, WordItem *specificationWordItem )
		{
		SpecificationItem *foundSpecificationItem = NULL;

		if( assignmentList != NULL )
			foundSpecificationItem = assignmentList->firstActiveSpecificationItem( isPossessive, questionParameter, relationContextNr, specificationWordItem );

		if( foundSpecificationItem == NULL &&
		specificationList != NULL )
			return specificationList->firstActiveSpecificationItem( isPossessive, questionParameter, relationContextNr, specificationWordItem );

		return foundSpecificationItem;
		}

	SpecificationItem *WordItem::firstAssignmentOrSpecification( bool includeAssignments, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem )
		{
		SpecificationItem *foundSpecificationItem = NULL;

		if( includeAssignments &&
		assignmentList != NULL )
			foundSpecificationItem = assignmentList->firstSpecificationItem( false, false, false, false, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, NULL );

		if( foundSpecificationItem == NULL &&
		specificationList != NULL )
			return specificationList->firstSpecificationItem( false, false, false, false, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, NULL );

		return foundSpecificationItem;
		}

	SpecificationItem *WordItem::firstAssignmentOrSpecification( bool isAllowingEmptyContextResult, bool isIncludingAnsweredQuestions, bool includeAssignments, bool includeDeactiveItems, bool includeArchivedItems, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationItem *foundSpecificationItem = NULL;

		if( includeAssignments &&
		assignmentList != NULL )
			foundSpecificationItem = assignmentList->firstSpecificationItem( isAllowingEmptyContextResult, isIncludingAnsweredQuestions, includeDeactiveItems, includeArchivedItems, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

		if( foundSpecificationItem == NULL &&
		specificationList != NULL )
			return specificationList->firstSpecificationItem( isAllowingEmptyContextResult, isIncludingAnsweredQuestions, includeDeactiveItems, includeArchivedItems, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

		return foundSpecificationItem;
		}

	SpecificationItem *WordItem::firstAssignmentOrSpecification( bool isAllowingEmptyContextResult, bool isIncludingAnsweredQuestions, bool includeAssignments, bool includeDeactiveAssignments, bool includeArchivedAssignments, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationItem *foundSpecificationItem = NULL;

		if( includeAssignments &&
		assignmentList != NULL )
			foundSpecificationItem = assignmentList->findSpecificationItem( isAllowingEmptyContextResult, isIncludingAnsweredQuestions, includeDeactiveAssignments, includeArchivedAssignments, isNegative, isPossessive, questionParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

		if( foundSpecificationItem == NULL &&
		specificationList != NULL )
			return specificationList->findSpecificationItem( isAllowingEmptyContextResult, isIncludingAnsweredQuestions, false, false, isNegative, isPossessive, questionParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

		return foundSpecificationItem;
		}

	SpecificationItem *WordItem::firstAssignmentOrSpecification( bool isAllowingDifferentLanguage, bool isAllowingEmptyContextResult, bool isIncludingAnsweredQuestions, bool includeAssignments, bool includeDeactiveItems, bool includeArchivedItems, bool isNegative, bool isPossessive, bool isSelfGenerated, unsigned short questionParameter, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationItem *foundSpecificationItem = NULL;

		if( includeAssignments &&
		assignmentList != NULL )
			foundSpecificationItem = assignmentList->firstSpecificationItem( isAllowingDifferentLanguage, isAllowingEmptyContextResult, isIncludingAnsweredQuestions, includeDeactiveItems, includeArchivedItems, isNegative, isPossessive, isSelfGenerated, questionParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

		if( foundSpecificationItem == NULL &&
		specificationList != NULL )
			return specificationList->firstSpecificationItem( isAllowingDifferentLanguage, isAllowingEmptyContextResult, isIncludingAnsweredQuestions, includeDeactiveItems, includeArchivedItems, isNegative, isPossessive, isSelfGenerated, questionParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

		return foundSpecificationItem;
		}

	SpecificationItem *WordItem::firstAssumptionSpecification( bool includeAssignments, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, WordItem *specificationWordItem )
		{
		SpecificationItem *foundSpecificationItem = NULL;

		if( includeAssignments &&
		assignmentList != NULL )
			foundSpecificationItem = assignmentList->firstAssumptionSpecificationItem( false, false, true, true, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, specificationWordItem );

		if( foundSpecificationItem == NULL &&
		specificationList != NULL )
			return specificationList->firstAssumptionSpecificationItem( false, false, false, false, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, specificationWordItem );

		return foundSpecificationItem;
		}

	SpecificationItem *WordItem::firstSelectedSpecification( bool isAssignment, bool isDeactiveAssignment, bool isArchivedAssignment, bool isQuestion )
		{
		return ( isAssignment ? firstAssignment( isDeactiveAssignment, isArchivedAssignment, isQuestion ) :
				( isQuestion ? firstActiveQuestionSpecification() : firstSpecificationButNotAQuestion() ) );
		}

	SpecificationItem *WordItem::firstSelectedSpecification( bool isIncludingAnsweredQuestions, bool isAssignment, bool isDeactiveAssignment, bool isArchivedAssignment, unsigned short questionParameter )
		{
		return ( isIncludingAnsweredQuestions && questionParameter > NO_QUESTION_PARAMETER ? firstAnsweredQuestion( isAssignment, isDeactiveAssignment, isArchivedAssignment, questionParameter ) :
				( isAssignment ? ( isArchivedAssignment ? firstArchivedAssignment( isIncludingAnsweredQuestions, questionParameter ) : ( isDeactiveAssignment ? firstDeactiveAssignment( isIncludingAnsweredQuestions, questionParameter ) : firstActiveAssignment( isIncludingAnsweredQuestions, questionParameter ) ) ) :
				( questionParameter == NO_QUESTION_PARAMETER ? firstSpecificationButNotAQuestion() : firstQuestionSpecification( isIncludingAnsweredQuestions, questionParameter ) ) ) );
		}

	SpecificationItem *WordItem::firstSpecification( bool isIncludingAnsweredQuestions, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		if( specificationList != NULL )
			return specificationList->firstSpecificationItem( true, isIncludingAnsweredQuestions, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

		return NULL;
		}

	SpecificationItem *WordItem::firstSpecificationButNotAQuestion()
		{
		if( specificationList != NULL )
			return specificationList->firstActiveSpecificationItem( false, false );

		return NULL;
		}

	SpecificationItem *WordItem::firstAssignmentOrSpecificationButNotAQuestion( bool isAllowingDifferentLanguage, bool isAllowingEmptyContextResult, bool includeActiveAssignments, bool includeDeactiveAssignments, bool includeArchivedAssignments, bool isNegative, bool isPossessive, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem )
		{
		SpecificationItem *foundSpecificationItem = NULL;

		if( assignmentList != NULL )
			foundSpecificationItem = assignmentList->firstSpecificationItem( isAllowingDifferentLanguage, isAllowingEmptyContextResult, false, includeActiveAssignments, includeDeactiveAssignments, includeArchivedAssignments, isNegative, isPossessive, NO_QUESTION_PARAMETER, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem );

		if( foundSpecificationItem == NULL &&
		specificationList != NULL )
			return specificationList->firstSpecificationItem( isAllowingDifferentLanguage, isAllowingEmptyContextResult, false, true, false, false, isNegative, isPossessive, NO_QUESTION_PARAMETER, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem );

		return foundSpecificationItem;
		}

	SpecificationItem *WordItem::firstUserSpecification( bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationItem *foundSpecificationItem = NULL;

		if( assignmentList != NULL )
			foundSpecificationItem = assignmentList->firstUserSpecificationItem( true, true, true, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

		if( foundSpecificationItem == NULL &&
		specificationList != NULL )
			return specificationList->firstUserSpecificationItem( true, false, false, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem, specificationString );

		return foundSpecificationItem;
		}

	SpecificationItem *WordItem::correctedSuggestiveQuestionAssumptionSpecificationItem()
		{
		if( wordSpecification_ != NULL )
			return wordSpecification_->correctedSuggestiveQuestionAssumptionSpecificationItem();

		return NULL;
		}


	// Protected word type functions

	void WordItem::clearWriteLevel( unsigned short currentWriteLevel )
		{
		if( wordTypeList != NULL )
			wordTypeList->clearWriteLevel( currentWriteLevel );
		}

	bool WordItem::isCorrectDefiniteArticle( unsigned short definiteArticleParameter, unsigned short wordTypeNr )
		{
		WordTypeItem *foundWordTypeItem;

		if( wordTypeList != NULL &&
		( foundWordTypeItem = wordTypeList->activeWordTypeItem( false, wordTypeNr ) ) != NULL )
			return foundWordTypeItem->isCorrectDefiniteArticle( definiteArticleParameter );

		return false;
		}

	bool WordItem::isCorrectIndefiniteArticle( unsigned short indefiniteArticleParameter, unsigned short wordTypeNr )
		{
		WordTypeItem *foundWordTypeItem;

		if( wordTypeList != NULL &&
		( foundWordTypeItem = wordTypeList->activeWordTypeItem( false, wordTypeNr ) ) != NULL )
			return foundWordTypeItem->isCorrectIndefiniteArticle( indefiniteArticleParameter );

		return false;
		}

	bool WordItem::isCorrectHiddenWordType( unsigned short wordTypeNr, char *compareString, void *hideKey )
		{
		if( wordTypeList != NULL )
			return wordTypeList->isCorrectHiddenWordType( wordTypeNr, compareString, hideKey );

		return false;
		}

	bool WordItem::isNumeralBoth()
		{
		return ( wordParameter_ == WORD_PARAMETER_NUMERAL_BOTH );
		}

	bool WordItem::isNumeralWordType()
		{
		if( wordTypeList != NULL )
			return ( wordTypeList->activeWordTypeItem( false, WORD_TYPE_NUMERAL ) != NULL );

		return false;
		}

	bool WordItem::isNoun()
		{
		return ( isSingularNoun() ||
				isPluralNoun() );
		}

	bool WordItem::isSingularNoun()
		{
		if( wordTypeList != NULL )
			return ( wordTypeList->activeWordTypeItem( false, WORD_TYPE_NOUN_SINGULAR ) != NULL );

		return false;
		}

	bool WordItem::isPluralNoun()
		{
		if( wordTypeList != NULL )
			return ( wordTypeList->activeWordTypeItem( false, WORD_TYPE_NOUN_PLURAL ) != NULL );

		return false;
		}

	bool WordItem::isPropername()
		{
		if( wordTypeList != NULL )
			return ( wordTypeList->activeWordTypeItem( false, WORD_TYPE_PROPER_NAME ) != NULL );

		return false;
		}

	bool WordItem::isPropernamePrecededByDefiniteArticle( unsigned short definiteArticleParameter )
		{
		WordTypeItem *foundWordTypeItem;

		if( wordTypeList != NULL &&
		( foundWordTypeItem = wordTypeList->activeWordTypeItem( false, WORD_TYPE_PROPER_NAME ) ) != NULL )
			return foundWordTypeItem->isPropernamePrecededByDefiniteArticle( definiteArticleParameter );

		return false;
		}

	ResultType WordItem::addWordType( bool isPropernamePrecededByDefiniteArticle, unsigned short definiteArticleParameter, unsigned short indefiniteArticleParameter, unsigned short wordTypeNr, size_t wordLength, char *wordTypeString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "addWordType";
		if( wordType_ == NULL &&
		// Create supporting module
		( wordType_ = new WordType( this, commonVariables_ ) ) == NULL )
			return startErrorInWord( functionNameString, NULL, "I failed to create my word type module" );

		return wordType_->addWordType( isPropernamePrecededByDefiniteArticle, definiteArticleParameter, indefiniteArticleParameter, wordTypeNr, wordLength, wordTypeString );
		}

	ResultType WordItem::hideWordType( unsigned short wordTypeNr, void *authorizationKey )
		{
		if( wordTypeList != NULL )
			return wordTypeList->hideWordTypeItem( wordTypeNr, authorizationKey );

		return commonVariables_->result;
		}

	ResultType WordItem::deleteWordType( unsigned short wordTypeNr )
		{
		if( wordTypeList != NULL )
			return wordTypeList->deleteWordType( wordTypeNr );

		return commonVariables_->result;
		}

	ResultType WordItem::markWordTypeAsWritten( unsigned short wordTypeNr )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "markWordTypeAsWritten";
		if( wordTypeList != NULL )
			return wordTypeList->markWordTypeAsWritten( wordTypeNr );

		return startErrorInWord( functionNameString, NULL, "The word type list isn't created yet" );
		}

	WordResultType WordItem::checkWordTypeForBeenWritten( unsigned short wordTypeNr )
		{
		WordResultType wordResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkWordTypeForBeenWritten";

		if( wordTypeList != NULL )
			return wordTypeList->checkWordTypeForBeenWritten( wordTypeNr );

		wordResult.result = startErrorInWord( functionNameString, NULL, "The word type list isn't created yet" );
		return wordResult;
		}

	WordResultType WordItem::findWordType( bool checkAllLanguages, unsigned short searchWordTypeNr, char *searchWordString )
		{
		WordResultType wordResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findWordType";

		if( wordType_ != NULL )
			return wordType_->findWordType( checkAllLanguages, searchWordTypeNr, searchWordString );

		wordResult.result = startErrorInWord( functionNameString, NULL, "The word type module isn't created yet" );
		return wordResult;
		}

	WordResultType WordItem::findWordTypeInAllWords( bool checkAllLanguages, unsigned short searchWordTypeNr, char *searchWordString, WordItem *previousWordItem )
		{
		WordResultType wordResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findWordTypeInAllWords";

		if( wordType_ == NULL &&
		// Create supporting module
		( wordType_ = new WordType( this, commonVariables_ ) ) == NULL )
			{
			wordResult.result = startErrorInWord( functionNameString, NULL, "I failed to create my word type module" );
			return wordResult;
			}

		return wordType_->findWordTypeInAllWords( checkAllLanguages, searchWordTypeNr, searchWordString, previousWordItem );
		}

	char *WordItem::anyWordTypeString()
		{
		if( wordType_ != NULL )
			return wordType_->wordTypeString( true, NO_ORDER_NR, WORD_TYPE_UNDEFINED );

		return NULL;
		}

	char *WordItem::wordTypeString( bool checkAllLanguages, unsigned short orderNr, unsigned short wordTypeNr )
		{
		if( wordType_ != NULL )
			return wordType_->wordTypeString( checkAllLanguages, orderNr, wordTypeNr );

		return NULL;
		}

	char *WordItem::activeSingularNounString()
		{
		return activeWordTypeString( WORD_TYPE_NOUN_SINGULAR );
		}

	char *WordItem::activeWordTypeString( unsigned short wordTypeNr )
		{
		if( wordTypeList != NULL )
			return wordTypeList->activeWordTypeString( false, wordTypeNr );

		return NULL;
		}

	WordTypeItem *WordItem::activeWordTypeItem( bool checkAllLanguages, unsigned short wordTypeNr )
		{
		if( wordTypeList != NULL )
			return wordTypeList->activeWordTypeItem( checkAllLanguages, wordTypeNr );

		return NULL;
		}


	// Protected write functions

	ResultType WordItem::writeJustificationSpecification( SpecificationItem *justificationSpecificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeJustificationSpecification";
		if( wordWrite_ != NULL ||
		// Create supporting module
		( wordWrite_ = new WordWrite( this, commonVariables_ ) ) != NULL )
			return wordWrite_->writeJustificationSpecification( justificationSpecificationItem );

		return startErrorInWord( functionNameString, NULL, "I failed to create my word write module" );
		}

	ResultType WordItem::writeSelectedSpecification( bool isWriteGivenSpecificationWordOnly, SpecificationItem *writeSpecificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeSpecification";
		if( wordWrite_ != NULL ||
		// Create supporting module
		( wordWrite_ = new WordWrite( this, commonVariables_ ) ) != NULL )
			return wordWrite_->writeSelectedSpecification( true, true, false, isWriteGivenSpecificationWordOnly, NO_ANSWER_PARAMETER, writeSpecificationItem );

		return startErrorInWord( functionNameString, NULL, "I failed to create my word write module" );
		}

	ResultType WordItem::writeSelectedSpecification( bool forceResponseNotBeingAssignment, bool forceResponseNotBeingFirstSpecification, bool writeCurrentSentenceOnly, bool isWriteGivenSpecificationWordOnly, unsigned short answerParameter, SpecificationItem *writeSpecificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeSelectedSpecification";
		if( wordWrite_ != NULL ||
		// Create supporting module
		( wordWrite_ = new WordWrite( this, commonVariables_ ) ) != NULL )
			return wordWrite_->writeSelectedSpecification( forceResponseNotBeingAssignment, forceResponseNotBeingFirstSpecification, writeCurrentSentenceOnly, isWriteGivenSpecificationWordOnly, answerParameter, writeSpecificationItem );

		return startErrorInWord( functionNameString, NULL, "I failed to create my word write module" );
		}

	ResultType WordItem::writeSelectedSpecificationInfo( bool isAssignment, bool isDeactiveAssignment, bool isArchivedAssignment, bool isQuestion, WordItem *writeWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeSentenceWithSpecificationInfoInWord";
		if( wordWrite_ != NULL ||
		// Create supporting module
		( wordWrite_ = new WordWrite( this, commonVariables_ ) ) != NULL )
			return wordWrite_->writeSelectedSpecificationInfo( isAssignment, isDeactiveAssignment, isArchivedAssignment, isQuestion, writeWordItem );

		return startErrorInWord( functionNameString, NULL, "I failed to create my word write module" );
		}

	ResultType WordItem::writeSelectedRelationInfo( bool isAssignment, bool isDeactiveAssignment, bool isArchivedAssignment, bool isQuestion, WordItem *writeWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeSentenceWithRelatedInfoInWord";
		if( wordWrite_ != NULL ||
		// Create supporting module
		( wordWrite_ = new WordWrite( this, commonVariables_ ) ) != NULL )
			return wordWrite_->writeSelectedRelationInfo( isAssignment, isDeactiveAssignment, isArchivedAssignment, isQuestion, writeWordItem );

		return startErrorInWord( functionNameString, NULL, "I failed to create my word write module" );
		}

	ResultType WordItem::writeSpecification( bool isAdjustedSpecification, bool isCorrectedAssumptionByKnowledge, bool isCorrectedAssumptionByOppositeQuestion, SpecificationItem *writeSpecificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeSpecification";
		if( wordWrite_ != NULL ||
		// Create supporting module
		( wordWrite_ = new WordWrite( this, commonVariables_ ) ) != NULL )
			return wordWrite_->writeSpecification( isAdjustedSpecification, isCorrectedAssumptionByKnowledge, isCorrectedAssumptionByOppositeQuestion, writeSpecificationItem );

		return startErrorInWord( functionNameString, NULL, "I failed to create my word write module" );
		}


	// Protected write sentence functions

	ResultType WordItem::selectGrammarToWriteSentence( bool isWriteGivenSpecificationWordOnly, unsigned short answerParameter, unsigned short grammarLevel, GrammarItem *selectedGrammarItem, SpecificationItem *writeSpecificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "selectGrammarToWriteSentence";
		if( wordWriteSentence_ != NULL ||
		// Create supporting module
		( wordWriteSentence_ = new WordWriteSentence( this, commonVariables_ ) ) != NULL )
			return wordWriteSentence_->selectGrammarToWriteSentence( isWriteGivenSpecificationWordOnly, answerParameter, grammarLevel, selectedGrammarItem, writeSpecificationItem );

		return startErrorInWord( functionNameString, NULL, "I failed to create my word write sentence module" );
		}


	// Protected write words functions

	void WordItem::initializeWordWriteWordsVariables()
		{
		if( wordWriteWords_ != NULL )
			wordWriteWords_->initializeWordWriteWordsVariables();
		}

	void WordItem::initializeWordWriteWordsSpecificationVariables( size_t startWordPosition )
		{
		if( wordWriteWords_ != NULL )
			wordWriteWords_->initializeWordWriteWordsSpecificationVariables( startWordPosition );
		}

	WriteResultType WordItem::writeWordsToSentence( bool isWriteGivenSpecificationWordOnly, unsigned short answerParameter, GrammarItem *definitionGrammarItem, SpecificationItem *writeSpecificationItem )
		{
		WriteResultType writeResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeWordsToSentence";

		if( wordWriteWords_ != NULL ||
		// Create supporting module
		( wordWriteWords_ = new WordWriteWords( this, commonVariables_ ) ) != NULL )
			return wordWriteWords_->writeWordsToSentence( isWriteGivenSpecificationWordOnly, answerParameter, definitionGrammarItem, writeSpecificationItem );

		writeResult.result = startErrorInWord( functionNameString, NULL, "I failed to create my word write words module" );
		return writeResult;
		}

/*************************************************************************
 *
 *	"Fear of the Lord is the foundation of true wisdom.
 *	All who obey his commandments will grow in wisdom." (Psalm 111:10)
 *
 *************************************************************************/
