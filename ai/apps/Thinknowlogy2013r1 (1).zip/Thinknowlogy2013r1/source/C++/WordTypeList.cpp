/*
 *	Class:			WordTypeList
 *	Parent class:	List
 *	Purpose:		To store word-type items
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "List.h"
#include "WordTypeItem.cpp"

class WordTypeList : private List
	{
	friend class WordType;

	// Private constructible variables

	WordTypeItem *foundWordTypeItem_;


	// Private deconstructor functions

	void deleteWordTypeList( WordTypeItem *searchItem )
		{
		WordTypeItem *deleteItem;

		while( searchItem != NULL )
			{
			deleteItem = searchItem;
			searchItem = searchItem->nextWordTypeItem();
			delete deleteItem;
			}
		}


	// Private functions

	void showWords( bool returnQueryToPosition, WordTypeItem *searchItem )
		{
		char *wordTypeString;
		char statusString[2] = SPACE_STRING;

		while( searchItem != NULL )
			{
			if( ( wordTypeString = searchItem->itemString() ) != NULL )
				{
				if( commonVariables()->hasFoundQuery ||
				strlen( commonVariables()->queryString ) > 0 )
					strcat( commonVariables()->queryString, ( returnQueryToPosition ? NEW_LINE_STRING : QUERY_SEPARATOR_SPACE_STRING ) );

				commonVariables()->hasFoundQuery = true;

				if( !searchItem->isActiveItem() )	// Don't show status with active items
					{
					statusString[0] = searchItem->statusChar();
					strcat( commonVariables()->queryString, statusString );
					}

				strcat( commonVariables()->queryString, wordTypeString );
				}

			searchItem = searchItem->nextWordTypeItem();
			}
		}

	char *wordTypeString( bool isCurrentLanguage, unsigned short orderNr, unsigned short wordTypeNr, WordTypeItem *searchItem )
		{
		unsigned short currentOrderNr = NO_ORDER_NR;

		while( searchItem != NULL )
			{
			if( searchItem->wordTypeNr() == wordTypeNr )
				{
				if( currentOrderNr == orderNr )
					return searchItem->itemString();
				else
					currentOrderNr++;
				}
			else
				{
				if( foundWordTypeItem_ == NULL )
					foundWordTypeItem_ = searchItem;
				}

			searchItem = ( isCurrentLanguage ? searchItem->nextCurrentLanguageWordTypeItem() : searchItem->nextWordTypeItem() );
			}

		return NULL;
		}

	WordTypeItem *firstActiveWordTypeItem()
		{
		return (WordTypeItem *)firstActiveItem();
		}

	WordTypeItem *firstArchivedWordTypeItem()
		{
		return (WordTypeItem *)firstArchivedItem();
		}

	WordTypeItem *firstDeletedWordTypeItem()
		{
		return (WordTypeItem *)firstDeletedItem();
		}


	public:
	// Constructor

	WordTypeList( WordItem *myWord, CommonVariables *commonVariables )
		{
		foundWordTypeItem_ = NULL;
		initializeListVariables( WORD_TYPE_LIST_SYMBOL, "WordTypeList", myWord, commonVariables );
		}

	// Deconstructor

	~WordTypeList()
		{
		deleteWordTypeList( firstActiveWordTypeItem() );
		deleteWordTypeList( (WordTypeItem *)firstDeactiveItem() );
		deleteWordTypeList( firstArchivedWordTypeItem() );
		deleteWordTypeList( firstDeletedWordTypeItem() );
		}


	// Protected functions

	void showWords( bool returnQueryToPosition )
		{
		showWords( returnQueryToPosition, firstActiveWordTypeItem() );
		showWords( returnQueryToPosition, firstArchivedWordTypeItem() );
		showWords( returnQueryToPosition, firstDeletedWordTypeItem() );
		}

	void clearWriteLevel( unsigned short currentWriteLevel )
		{
		WordTypeItem *searchItem = firstActiveWordTypeItem();

		while( searchItem != NULL )
			{
			searchItem->clearWriteLevel( currentWriteLevel );
			searchItem = searchItem->nextWordTypeItem();
			}
		}

	bool isCorrectHiddenWordType( unsigned short wordTypeNr, char *compareString, void *authorizationKey )
		{
		WordTypeItem *searchItem = firstActiveCurrentLanguageWordTypeItem();

		while( searchItem != NULL )
			{
			if( searchItem->wordTypeNr() == wordTypeNr &&
			searchItem->isCorrectHiddenWordType( compareString, authorizationKey ) )
				return true;

			searchItem = searchItem->nextCurrentLanguageWordTypeItem();
			}

		return false;
		}

	ResultType hideWordTypeItem( unsigned short wordTypeNr, void *authorizationKey )
		{
		bool hasFoundWordType = false;
		WordTypeItem *searchItem = firstActiveCurrentLanguageWordTypeItem();
		char functionNameString[FUNCTION_NAME_LENGTH] = "hideWordTypeItem";

		while( searchItem != NULL &&
		!hasFoundWordType )
			{
			if( searchItem->wordTypeNr() == wordTypeNr )
				{
				if( searchItem->hideWordType( authorizationKey ) == RESULT_OK )
					hasFoundWordType = true;
				else
					return addError( functionNameString, NULL, "I failed to hide a word type" );
				}
			else
				searchItem = searchItem->nextCurrentLanguageWordTypeItem();
			}

		if( !hasFoundWordType )
			return startError( functionNameString, NULL, "I coundn't find the given word type" );

		return commonVariables()->result;
		}

	ResultType deleteWordType( unsigned short wordTypeNr )
		{
		bool hasFoundWordType = false;
		WordTypeItem *searchItem = firstActiveWordTypeItem();
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteWordType";

		while( searchItem != NULL &&
		!hasFoundWordType )
			{
			if( searchItem->wordTypeNr() == wordTypeNr &&
			searchItem->wordTypeLanguageNr() == commonVariables()->currentGrammarLanguageNr )
				{
				if( deleteActiveItem( false, searchItem ) == RESULT_OK )
					hasFoundWordType = true;
				else
					return addError( functionNameString, NULL, "I failed to delete an active item" );
				}
			else
				searchItem = searchItem->nextWordTypeItem();
			}

		if( !hasFoundWordType )
			return startError( functionNameString, NULL, "I coundn't find the given word type" );

		return commonVariables()->result;
		}

	ResultType findMatchingWordReferenceString( char *searchString )
		{
		WordTypeItem *searchItem = firstActiveWordTypeItem();
		char functionNameString[FUNCTION_NAME_LENGTH] = "findMatchingWordReferenceString";

		commonVariables()->hasFoundMatchingStrings = false;

		while( !commonVariables()->hasFoundMatchingStrings &&
		searchItem != NULL )
			{
			if( searchItem->itemString() != NULL )
				{
				if( compareStrings( searchString, searchItem->itemString() ) == RESULT_OK )
					{
					if( commonVariables()->hasFoundMatchingStrings )
						commonVariables()->matchingWordTypeNr = searchItem->wordTypeNr();
					}
				else
					return addError( functionNameString, NULL, "I failed to compare an active word type string with the query string" );
				}

			searchItem = searchItem->nextWordTypeItem();
			}

		searchItem = firstArchivedWordTypeItem();

		while( !commonVariables()->hasFoundMatchingStrings &&
		searchItem != NULL )
			{
			if( searchItem->itemString() != NULL )
				{
				if( compareStrings( searchString, searchItem->itemString() ) == RESULT_OK )
					{
					if( commonVariables()->hasFoundMatchingStrings )
						commonVariables()->matchingWordTypeNr = searchItem->wordTypeNr();
					}
				else
					return addError( functionNameString, NULL, "I failed to compare a deleted word type string with the query string" );
				}

			searchItem = searchItem->nextWordTypeItem();
			}

		searchItem = firstDeletedWordTypeItem();

		while( !commonVariables()->hasFoundMatchingStrings &&
		searchItem != NULL )
			{
			if( searchItem->itemString() != NULL )
				{
				if( compareStrings( searchString, searchItem->itemString() ) == RESULT_OK )
					{
					if( commonVariables()->hasFoundMatchingStrings )
						commonVariables()->matchingWordTypeNr = searchItem->wordTypeNr();
					}
				else
					return addError( functionNameString, NULL, "I failed to compare a deleted word type string with the query string" );
				}

			searchItem = searchItem->nextWordTypeItem();
			}

		return commonVariables()->result;
		}

	ResultType markWordTypeAsWritten( unsigned short wordTypeNr )
		{
		bool hasFoundWordTypeNr = false;
		WordTypeItem *pluralNounWordTypeItem = NULL;
		WordTypeItem *singularNounWordTypeItem = NULL;
		WordTypeItem *searchItem = firstActiveWordTypeItem();
		char functionNameString[FUNCTION_NAME_LENGTH] = "markWordTypeAsWritten";

		if( wordTypeNr > WORD_TYPE_UNDEFINED &&
		wordTypeNr < NUMBER_OF_WORD_TYPES )
			{
			while( searchItem != NULL )
				{
				if( !searchItem->isWordAlreadyWritten() )
					{
					if( searchItem->isWordTypeSingularNoun() )
						singularNounWordTypeItem = searchItem;
					else
						{
						if( searchItem->isWordTypePluralNoun() )
							pluralNounWordTypeItem = searchItem;
						}

					if( searchItem->wordTypeNr() == wordTypeNr )
						{
						if( searchItem->markWordTypeAsWritten() == RESULT_OK )
							hasFoundWordTypeNr = true;
						else
							return addError( functionNameString, NULL, "I failed to mark a word as written" );
						}
					}

				searchItem = searchItem->nextWordTypeItem();
				}

			if( hasFoundWordTypeNr )
				{
				if( wordTypeNr == WORD_TYPE_NOUN_SINGULAR &&	// If singular noun - also set plural noun
				pluralNounWordTypeItem != NULL )
					{
					if( pluralNounWordTypeItem->markWordTypeAsWritten() != RESULT_OK )
						return addError( functionNameString, NULL, "I failed to mark a plural noun word as written" );
					}
				else
					{
					if( wordTypeNr == WORD_TYPE_NOUN_PLURAL &&	// If plural noun - also set singular noun
					singularNounWordTypeItem != NULL )
						{
						if( singularNounWordTypeItem->markWordTypeAsWritten() != RESULT_OK )
							return addError( functionNameString, NULL, "I failed to mark a singular noun word as written" );
						}
					}
				}
			else
				return startError( functionNameString, NULL, "I couldn't find the given word type number" );
			}
		else
			return startError( functionNameString, NULL, "The given word type number is undefined or out of bounds" );

		return commonVariables()->result;
		}

	ResultType createWordTypeItem( bool isPropernamePrecededByDefiniteArticle, unsigned short definiteArticleParameter, unsigned short indefiniteArticleParameter, unsigned short wordTypeNr, size_t wordLength, char *wordTypeString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "createWordTypeItem";
		if( wordTypeNr > WORD_TYPE_UNDEFINED &&
		wordTypeNr < NUMBER_OF_WORD_TYPES )
			{
			if( wordTypeString != NULL )
				{
				if( commonVariables()->currentItemNr < MAX_ITEM_NR )
					{
					if( addItemToActiveList( (Item *)( new WordTypeItem( isPropernamePrecededByDefiniteArticle, definiteArticleParameter, indefiniteArticleParameter, commonVariables()->currentGrammarLanguageNr, wordTypeNr, wordLength, wordTypeString, this, myWord(), commonVariables() ) ) ) != RESULT_OK )
						return addError( functionNameString, NULL, "I failed to add an active word type item" );
					}
				else
					return startError( functionNameString, NULL, "The current item number is undefined" );
				}
			else
				return startError( functionNameString, NULL, "The given wordTypeString is undefined" );
			}
		else
			return startError( functionNameString, NULL, "The given word type number is undefined or out of bounds" );

		return commonVariables()->result;
		}

	WordResultType checkWordTypeForBeenWritten( unsigned short wordTypeNr )
		{
		WordResultType wordResult;
		bool hasFound = false;
		WordTypeItem *searchItem = firstActiveWordTypeItem();
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkWordTypeForBeenWritten";

		if( wordTypeNr > WORD_TYPE_UNDEFINED &&
		wordTypeNr < NUMBER_OF_WORD_TYPES )
			{
			while( searchItem != NULL &&
			!hasFound )
				{
				if( searchItem->wordTypeNr() == wordTypeNr )
					{
					hasFound = true;
					wordResult.isWordAlreadyWritten = searchItem->isWordAlreadyWritten();
					}
				else
					searchItem = searchItem->nextWordTypeItem();
				}

			if( !hasFound )
				startError( functionNameString, NULL, "I couldn't find the given word type number" );
			}
		else
			startError( functionNameString, NULL, "The given word type number is undefined or out of bounds" );

		wordResult.result = commonVariables()->result;
		return wordResult;
		}

	char *wordTypeString( bool checkAllLanguages, unsigned short orderNr, unsigned short wordTypeNr )
		{
		char *foundWordTypeString;

		foundWordTypeItem_ = NULL;

		// Try to find word type from the current language
		if( ( foundWordTypeString = wordTypeString( true, orderNr, wordTypeNr, firstActiveCurrentLanguageWordTypeItem() ) ) == NULL )
			{
			if( ( foundWordTypeString = wordTypeString( true, orderNr, wordTypeNr, firstArchivedCurrentLanguageWordTypeItem() ) ) == NULL )
				{
				if( ( foundWordTypeString = wordTypeString( true, orderNr, wordTypeNr, firstDeletedCurrentLanguageWordTypeItem() ) ) == NULL )
					{
					// Not found in current language. Now, try all languages
					if( ( checkAllLanguages ||
					myWord()->isGrammarLanguage() ) &&

					( foundWordTypeString = wordTypeString( false, orderNr, wordTypeNr, firstActiveWordTypeItem() ) ) == NULL )
						{
						if( ( foundWordTypeString = wordTypeString( false, orderNr, wordTypeNr, firstArchivedWordTypeItem() ) ) == NULL )
							foundWordTypeString = wordTypeString( false, orderNr, wordTypeNr, firstDeletedWordTypeItem() );
						}
					}
				}
			}

		return ( foundWordTypeString == NULL ? ( foundWordTypeItem_ == NULL ? NULL : foundWordTypeItem_->itemString() ) : foundWordTypeString );
		}

	char *activeWordTypeString( bool checkAllLanguages, unsigned short wordTypeNr )
		{
		WordTypeItem *foundWordTypeItem;

		if( ( foundWordTypeItem = activeWordTypeItem( checkAllLanguages, wordTypeNr ) ) != NULL )
			return foundWordTypeItem->itemString();

		return NULL;
		}

	WordTypeItem *activeWordTypeItem( bool checkAllLanguages, unsigned short wordTypeNr )
		{
		WordTypeItem *searchItem = firstActiveCurrentLanguageWordTypeItem();

		// Check current language first
		while( searchItem != NULL )
			{
			if( wordTypeNr == WORD_TYPE_UNDEFINED ||
			searchItem->wordTypeNr() == wordTypeNr )
				return searchItem;

			searchItem = searchItem->nextCurrentLanguageWordTypeItem();
			}

		// Not found in current language, then try all languages
		if( checkAllLanguages ||
		myWord()->isGrammarLanguage() )
			{
			searchItem = firstActiveWordTypeItem();

			while( searchItem != NULL )
				{
				if( wordTypeNr == WORD_TYPE_UNDEFINED ||
				searchItem->wordTypeNr() == wordTypeNr )
					return searchItem;

				searchItem = searchItem->nextWordTypeItem();
				}
			}

		return NULL;
		}

	WordTypeItem *firstActiveCurrentLanguageWordTypeItem()
		{
		WordTypeItem *searchItem = firstActiveWordTypeItem();

		while( searchItem != NULL &&
		searchItem->wordTypeLanguageNr() < commonVariables()->currentGrammarLanguageNr )
			searchItem = searchItem->nextWordTypeItem();

		return searchItem;
		}

	WordTypeItem *firstArchivedCurrentLanguageWordTypeItem()
		{
		WordTypeItem *searchItem = firstArchivedWordTypeItem();

		while( searchItem != NULL &&
		searchItem->wordTypeLanguageNr() < commonVariables()->currentGrammarLanguageNr )
			searchItem = searchItem->nextWordTypeItem();

		return searchItem;
		}

	WordTypeItem *firstDeletedCurrentLanguageWordTypeItem()
		{
		WordTypeItem *searchItem = firstDeletedWordTypeItem();

		while( searchItem != NULL &&
		searchItem->wordTypeLanguageNr() < commonVariables()->currentGrammarLanguageNr )
			searchItem = searchItem->nextWordTypeItem();

		return searchItem;
		}
	};

/*************************************************************************
 *
 *	"He lifts the poor from the dust
 *	and needy from the garbage dump.
 *	He sets them among princes,
 *	even princes of his own people!" (Psalm 113:7-8)
 *
 *************************************************************************/
