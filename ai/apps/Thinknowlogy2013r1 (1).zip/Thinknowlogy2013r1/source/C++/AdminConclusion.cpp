/*
 *	Class:			AdminConclusion
 *	Supports class:	AdminItem
 *	Purpose:		To create conclusions and questions autonomously
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include "AdminItem.h"
#include "GeneralizationItem.cpp"
#include "SpecificationItem.cpp"

class AdminConclusion
	{
	// Private constructible variables

	JustificationItem *possessiveReversibleConclusionJustificationItem_;

	SpecificationItem *createdConclusionSpecificationItem_;
	SpecificationItem *foundConclusionSpecificationItem_;
	SpecificationItem *foundSpecificationGeneralizationDefinitionSpecificationItem_;
	SpecificationItem *lastCreatedSpecificationSubstitutionConclusionSpecificationItem_;

	CommonVariables *commonVariables_;
	AdminItem *admin_;
	WordItem *myWord_;
	char moduleNameString_[FUNCTION_NAME_LENGTH];


	// Private functions

	bool isConclusion( unsigned short justificationTypeNr )
		{
		return ( justificationTypeNr == JUSTIFICATION_TYPE_SPECIFICATION_GENERALIZATION_SUBSTITUTION_CONCLUSION ||
				justificationTypeNr == JUSTIFICATION_TYPE_SPECIFICATION_SUBSTITUTION_CONCLUSION ||
				justificationTypeNr == JUSTIFICATION_TYPE_POSSESSIVE_REVERSIBLE_CONCLUSION ||
				justificationTypeNr == JUSTIFICATION_TYPE_SPECIFICATION_SUBSTITUTION_QUESTION );
		}

	ResultType addSpecificationGeneralizationConclusion( SpecificationItem *definitionSpecificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "addSpecificationGeneralizationConclusion";
		if( definitionSpecificationItem != NULL )
			{
			if( definitionSpecificationItem->isGeneralizationNoun() &&
			definitionSpecificationItem->isSpecificationNoun() )
				{
				if( addConclusion( false, false, false, false, false, false, JUSTIFICATION_TYPE_SPECIFICATION_GENERALIZATION_SUBSTITUTION_CONCLUSION, NO_PREPOSITION_PARAMETER, NO_QUESTION_PARAMETER, WORD_TYPE_NOUN_PLURAL, definitionSpecificationItem->generalizationWordTypeNr(), WORD_TYPE_UNDEFINED, NO_COLLECTION_NR, definitionSpecificationItem->specificationCollectionNr(), definitionSpecificationItem->relationCollectionNr(), NO_CONTEXT_NR, NO_CONTEXT_NR, NO_CONTEXT_NR, definitionSpecificationItem, NULL, NULL, definitionSpecificationItem->specificationWordItem(), definitionSpecificationItem->generalizationWordItem(), NULL ) != RESULT_OK )
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a specification generalization substitution conclusion" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The generalization word and/or specification word of the given definition specification item isn't a noun" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given definition specification item is undefined" );

		return commonVariables_->result;
		}

	ResultType findSpecificationGeneralizationDefinition( unsigned short generalizationWordTypeNr, WordItem *generalizationWordItem, WordItem *specificationWordItem )
		{
		GeneralizationItem *currentGeneralizationItem;
		SpecificationItem *foundSpecificationItem;
		WordItem *currentGeneralizationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findSpecificationGeneralizationDefinition";

		foundSpecificationGeneralizationDefinitionSpecificationItem_ = NULL;

		if( generalizationWordItem != NULL )
			{
			if( specificationWordItem != NULL )
				{
				if( ( currentGeneralizationItem = specificationWordItem->firstActiveGeneralizationItemOfSpecification() ) != NULL )
					{
					do	{
						if( ( currentGeneralizationWordItem = currentGeneralizationItem->generalizationWordItem() ) != NULL )
							{
							if( currentGeneralizationWordItem != generalizationWordItem &&
							currentGeneralizationItem->generalizationWordTypeNr() == generalizationWordTypeNr &&
							( foundSpecificationItem = currentGeneralizationWordItem->firstAssignmentOrSpecification( false, false, false, NO_QUESTION_PARAMETER, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_CONTEXT_NR, specificationWordItem ) ) != NULL )
								{
								if( !foundSpecificationItem->isExclusive() &&
								!foundSpecificationItem->hasSpecificationCollection() )
									foundSpecificationGeneralizationDefinitionSpecificationItem_ = foundSpecificationItem;
								}
							}
						else
							return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found an undefined generalization word" );
						}
					while( foundSpecificationGeneralizationDefinitionSpecificationItem_ == NULL &&
					( currentGeneralizationItem = currentGeneralizationItem->nextGeneralizationItemOfSpecification() ) != NULL );
					}
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		return commonVariables_->result;
		}

	ResultType findSpecificationSubstitutionQuestion( bool isCorrectedAssumption, bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, SpecificationItem *currentSpecificationItem, SpecificationItem *definitionSpecificationItem, WordItem *generalizationWordItem, WordItem *currentGeneralizationWordItem, WordItem *specificationWordItem, WordItem *currentSpecificationWordItem )
		{
		SpecificationResultType specificationResult;
		bool blockCommonWordOfCompoundCollection = false;
		bool isAssignment = ( isDeactive || isArchived || isNegative );
		unsigned int noCompoundCommonWordCollectionNr;
		unsigned int nonCompoundSpecificationCollectionNr;
		SpecificationItem *adjustedQuestionSpecificationItem = NULL;
		WordItem *commonWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findSpecificationSubstitutionQuestion";

		if( currentSpecificationItem != NULL )
			{
			if( generalizationWordItem != NULL )
				{
				if( currentGeneralizationWordItem != NULL )
					{
					if( specificationWordItem != NULL )
						{
						if( currentSpecificationWordItem != NULL )
							{
							nonCompoundSpecificationCollectionNr = currentSpecificationWordItem->nonCompoundCollectionNr( specificationWordTypeNr );
							commonWordItem = currentSpecificationWordItem->commonWordItem( specificationCollectionNr, currentGeneralizationWordItem );

							if( nonCompoundSpecificationCollectionNr > NO_COLLECTION_NR &&
							currentSpecificationItem->hasSpecificationCompoundCollection() &&
							currentSpecificationWordItem->isCompoundCollection( specificationCollectionNr, specificationWordItem ) )
								{
								// Detect a conflict
								if( generalizationWordItem->checkForSpecificationConflict( true, isExclusive, isNegative, isPossessive, specificationWordTypeNr, nonCompoundSpecificationCollectionNr, currentSpecificationItem->relationCollectionNr(), currentSpecificationItem->generalizationContextNr(), currentSpecificationItem->specificationContextNr(), currentSpecificationItem->relationContextNr(), currentSpecificationWordItem, currentSpecificationItem->relationWordItem(), currentSpecificationItem->specificationString() ) == RESULT_OK )
									{
									if( ( specificationResult = generalizationWordItem->findQuestionToAdjustedByCompoundCollection( isNegative, isPossessive, questionParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, currentSpecificationItem->relationContextNr(), specificationWordItem ) ).result == RESULT_OK )
										{
										if( ( adjustedQuestionSpecificationItem = specificationResult.adjustedQuestionSpecificationItem ) == NULL )
											{
											if( currentSpecificationWordItem->commonWordItem( specificationCollectionNr, currentGeneralizationWordItem ) != NULL )
												blockCommonWordOfCompoundCollection = true;
											}
										}
									else
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to inf a question to be adjusted by a compound collection in generalization word \"", generalizationWordItem->anyWordTypeString(), "\" by compound collection" );
									}
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check for a specification conflict in generalization word \"", generalizationWordItem->anyWordTypeString(), "\"" );
								}
							else
								{
								if( !isCorrectedAssumption )
									{
									if( nonCompoundSpecificationCollectionNr == NO_COLLECTION_NR )
										nonCompoundSpecificationCollectionNr = myWord_->nonCompoundCollectionNrInAllWords( specificationCollectionNr );

									if( ( specificationResult = generalizationWordItem->findRelatedSpecification( false, false, false, isPossessive, NO_QUESTION_PARAMETER, nonCompoundSpecificationCollectionNr, currentSpecificationItem->relationCollectionNr(), generalizationContextNr, specificationContextNr, currentSpecificationItem->relationContextNr(), specificationWordItem, currentSpecificationItem->relationWordItem(), currentSpecificationItem->specificationString() ) ).result == RESULT_OK )
										{
										if( specificationResult.relatedSpecificationItem != NULL )
											blockCommonWordOfCompoundCollection = true;
										}
									else
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a related specification" );
									}
								}

							if( !commonVariables_->hasShownWarning &&
							!blockCommonWordOfCompoundCollection )
								{
								if( commonWordItem != NULL &&
								( noCompoundCommonWordCollectionNr = commonWordItem->nonCompoundCollectionNr( specificationWordTypeNr ) ) > NO_COLLECTION_NR )
									{
									if( generalizationWordItem->firstAssignmentOrSpecificationButNotAQuestion( false, true, true, true, true, isNegative, isPossessive, noCompoundCommonWordCollectionNr, generalizationContextNr, specificationContextNr, NO_CONTEXT_NR, commonWordItem ) != NULL )
										{
										if( generalizationWordItem->firstAssignmentOrSpecificationButNotAQuestion( false, true, true, true, true, isNegative, isPossessive, specificationCollectionNr, generalizationContextNr, specificationContextNr, NO_CONTEXT_NR, commonWordItem ) == NULL )
											blockCommonWordOfCompoundCollection = true;
										}
									}

								if( !blockCommonWordOfCompoundCollection &&
								!generalizationWordItem->isCorrectedAssumptionByKnowledge() )
									{
									// Create a question
									if( addConclusion( isAssignment, isDeactive, isArchived, true, isNegative, isPossessive, JUSTIFICATION_TYPE_SPECIFICATION_SUBSTITUTION_QUESTION, NO_PREPOSITION_PARAMETER, questionParameter, generalizationWordTypeNr, specificationWordTypeNr, WORD_TYPE_UNDEFINED, currentSpecificationItem->generalizationCollectionNr(), specificationCollectionNr, currentSpecificationItem->relationCollectionNr(), currentSpecificationItem->generalizationContextNr(), currentSpecificationItem->specificationContextNr(), NO_CONTEXT_NR, ( isCorrectedAssumption ? NULL : definitionSpecificationItem ), ( generalizationWordItem->isCorrectedAssumption() ? definitionSpecificationItem : NULL ), currentSpecificationItem, generalizationWordItem, currentSpecificationWordItem, NULL ) == RESULT_OK )
										{
										if( adjustedQuestionSpecificationItem != NULL )
											{
											// Write adjusted question
											if( generalizationWordItem->writeSpecification( true, false, false, adjustedQuestionSpecificationItem ) != RESULT_OK )
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write an adjusted question" );
											}
										}
									else
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a specification substitution question about generalization word \"", generalizationWordItem->anyWordTypeString(), "\" with specification word \"", currentSpecificationWordItem->anyWordTypeString(), "\"" );
									}
								}
							}
						else
							return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given current specfication word item is undefined" );
						}
					else
						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specfication word item is undefined" );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given current generalization word item is undefined" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given current specfication item is undefined" );

		return commonVariables_->result;
		}

	ResultType addConclusion( bool isAssignment, bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, unsigned short justificationTypeNr, unsigned short prepositionParamater, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, SpecificationItem *definitionSpecificationItem, SpecificationItem *anotherDefinitionSpecificationItem, SpecificationItem *specificSpecificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem )
		{
		JustificationResultType justificationResult;
		SpecificationResultType specificationResult;
		bool hasCreatedJustification = false;
		bool isQuestion = ( questionParameter > NO_QUESTION_PARAMETER );
		unsigned int createdRelationContextNr;
		JustificationItem *specificationJustificationItem = NULL;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addConclusion";

		possessiveReversibleConclusionJustificationItem_ = NULL;
		createdConclusionSpecificationItem_ = NULL;
		foundConclusionSpecificationItem_ = NULL;

		if( generalizationWordItem != NULL )
			{
			if( specificationWordItem != NULL )
				{
				if( isConclusion( justificationTypeNr ) )
					{
					if( isQuestion ||

					( ( definitionSpecificationItem == NULL ||

					( !definitionSpecificationItem->isQuestion() &&
					!definitionSpecificationItem->isSelfGeneratedAssumption() ) ) &&

					( specificSpecificationItem == NULL ||

					( !specificSpecificationItem->isQuestion() &&
					!specificSpecificationItem->isSelfGeneratedAssumption() ) ) ) )
						{
						if( ( justificationResult = generalizationWordItem->addJustification( false, justificationTypeNr, 1, commonVariables_->currentSentenceNr, NULL, definitionSpecificationItem, anotherDefinitionSpecificationItem, specificSpecificationItem ) ).result == RESULT_OK )
							{
							if( ( specificationJustificationItem = justificationResult.foundJustificationItem ) == NULL )
								{
								hasCreatedJustification = true;
								specificationJustificationItem = justificationResult.createdJustificationItem;
								}

							if( specificationJustificationItem != NULL )
								{
								if( ( specificationResult = admin_->addSpecification( isAssignment, isDeactive, isArchived, isExclusive, isNegative, isPossessive, true, ( justificationTypeNr == JUSTIFICATION_TYPE_SPECIFICATION_GENERALIZATION_SUBSTITUTION_CONCLUSION ), false, prepositionParamater, questionParameter, generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, generalizationCollectionNr, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, 0, specificationJustificationItem, generalizationWordItem, specificationWordItem, relationWordItem, NULL ) ).result == RESULT_OK )
									{
									if( !commonVariables_->hasShownWarning )
										{
										createdConclusionSpecificationItem_ = specificationResult.createdSpecificationItem;
										foundConclusionSpecificationItem_ = specificationResult.foundSpecificationItem;

										if( createdConclusionSpecificationItem_ == NULL )
											{
											// A justification has been created, but the conclusion specification already exists.
											// So, the justification needs to be added separately
											if( hasCreatedJustification )
												{
												if( foundConclusionSpecificationItem_ != NULL )
													{
													if( !isPossessive &&
													relationContextNr > NO_CONTEXT_NR &&
													relationContextNr != foundConclusionSpecificationItem_->relationContextNr() )
														possessiveReversibleConclusionJustificationItem_ = specificationJustificationItem;
													else
														{
														// Add (attach) new created justification to the found specification
														if( generalizationWordItem->attachJustification( specificationJustificationItem, foundConclusionSpecificationItem_ ) != RESULT_OK )
															return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to attach a justification to a conclusion in generalization word \"", generalizationWordItem->anyWordTypeString(), "\"" );
														}
													}
												else
													// Check conclusion for existence before calling this function - rather than deleting the just created justification
													return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I have created a justification, but it isn't used. Please check if the conclusion already exists, before calling this function" );
												}
											}
										else
											{
											// Check conclusion for integrity
											if( generalizationWordItem->writeSelectedSpecification( true, true, false, false, NO_ANSWER_PARAMETER, createdConclusionSpecificationItem_ ) == RESULT_OK )
												{
												if( strlen( commonVariables_->writeSentenceString ) > 0 )
													{
													if( ( createdRelationContextNr = createdConclusionSpecificationItem_->relationContextNr() ) > NO_CONTEXT_NR )
														{
														if( admin_->collectGeneralizationWordWithPreviousOne( isExclusive, createdConclusionSpecificationItem_->hasExclusiveGeneralizationCollection(), isPossessive, generalizationWordTypeNr, specificationWordTypeNr, questionParameter, createdRelationContextNr, generalizationWordItem, specificationWordItem ) != RESULT_OK )
															return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to collect a generalization word with a previous one" );
														}
													}
												else
													return myWord_->startErrorInItem( functionNameString, moduleNameString_, "Integrity error! I couldn't write the created conclusion with generalization word \"", generalizationWordItem->anyWordTypeString(), "\" and specification word \"", specificationWordItem->anyWordTypeString(), "\". I guess, the implementation of my writing modules is insufficient to write this particular sentence structure" );
												}
											else
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to write the created conclusion in generalization word \"", generalizationWordItem->anyWordTypeString(), "\" to check the writing integrity" );
											}

										if( myWord_->isNounWordType( specificationWordTypeNr ) &&

										( hasCreatedJustification ||
										createdConclusionSpecificationItem_ != NULL ) )
											{
											if( findSpecificationSubstitutionConclusionOrQuestion( false, isDeactive, isArchived, isExclusive, isNegative, isPossessive, false, questionParameter, generalizationWordTypeNr, specificationWordTypeNr, generalizationContextNr, specificationContextNr, generalizationWordItem, specificationWordItem ) != RESULT_OK )
												return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a specification substitution conclusion or question for generalization word \"", generalizationWordItem->anyWordTypeString(), "\"" );
											}
										}
									}
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a concluded specification" );
								}
							else
								return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I couldn't find or create a specification justification" );
							}
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a justification" );
						}
					else
						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The definition specification item or specific specification item is a question or an assumption, which can't be a justification for a conclusion" );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given justification type number isn't a conclusion" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		return commonVariables_->result;
		}


	public:
	// Constructor

	AdminConclusion( AdminItem *admin, WordItem *myWord, CommonVariables *commonVariables )
		{
		char errorString[MAX_ERROR_STRING_LENGTH] = EMPTY_STRING;

		possessiveReversibleConclusionJustificationItem_ = NULL;
		createdConclusionSpecificationItem_ = NULL;
		foundConclusionSpecificationItem_ = NULL;
		foundSpecificationGeneralizationDefinitionSpecificationItem_ = NULL;
		lastCreatedSpecificationSubstitutionConclusionSpecificationItem_ = NULL;

		admin_ = admin;
		myWord_ = myWord;
		commonVariables_ = commonVariables;
		strcpy( moduleNameString_, "AdminConclusion" );

		if( commonVariables_ != NULL )
			{
		if( admin_ != NULL )
			{
			if( myWord_ == NULL )
				strcpy( errorString, "The given my word is undefined" );
			}
		else
			strcpy( errorString, "The given admin is undefined" );
			}
		else
			strcpy( errorString, "The given common variables is undefined" );

		if( strlen( errorString ) > 0 )
			{
			if( myWord_ != NULL )
				myWord_->startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, moduleNameString_, errorString );
			else
				{
			if( commonVariables_ != NULL )
				commonVariables_->result = RESULT_SYSTEM_ERROR;
				fprintf( stderr, "\nClass:%s\nFunction:\t%s\nError:\t\t%s.\n", moduleNameString_, PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, errorString );
				}
			}
		}


	// Protected functions

	void initializeAdminConclusionVariables()
		{
		lastCreatedSpecificationSubstitutionConclusionSpecificationItem_ = NULL;
		}

	ResultType addSpecificationGeneralizationConclusion( unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, SpecificationItem *definitionSpecificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "addSpecificationGeneralizationConclusion";
		if( generalizationWordItem != NULL )
			{
			if( !generalizationWordItem->hasCollection( specificationWordItem ) )
				{
				if( findSpecificationGeneralizationDefinition( generalizationWordTypeNr, generalizationWordItem, specificationWordItem ) == RESULT_OK )
					{
					if( foundSpecificationGeneralizationDefinitionSpecificationItem_ != NULL )
						{
						if( admin_->collectGeneralizationWordWithPreviousOne( false, false, false, generalizationWordTypeNr, specificationWordTypeNr, NO_QUESTION_PARAMETER, NO_CONTEXT_NR, generalizationWordItem, specificationWordItem ) == RESULT_OK )
							{
							if( generalizationWordItem->hasCollection( specificationWordItem ) )
								{
								if( addSpecificationGeneralizationConclusion( foundSpecificationGeneralizationDefinitionSpecificationItem_ ) == RESULT_OK )
									{
									if( addSpecificationGeneralizationConclusion( definitionSpecificationItem ) != RESULT_OK )
										return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a specification generalization conclusion about the given sentence" );
									}
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a specification generalization conclusion about an earlier sentence" );
								}
							}
						else
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to collect a generalization word with a previous one" );
						}
					}
				else
					return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a specification generalization" );
				}
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );

		return commonVariables_->result;
		}

	ResultType findPossessiveReversibleConclusion( bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int specificationContextNr, unsigned int relationPronounContextNr, unsigned int relationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem )
		{
		ContextResultType contextResult;
		bool isAssignment;
		bool hasFoundSpecificDeactiveAssignment = false;
		bool hasFoundSpecificArchivedAssignment = false;
		unsigned int nContextRelations;
		unsigned int relationCollectionNr;
		unsigned int tempGeneralizationContextNr;
		unsigned int generalizationContextNr = NO_CONTEXT_NR;
		SpecificationItem *assumptionSpecificationItem;
		SpecificationItem *specificSpecificationItem;
		SpecificationItem *tempSpecificationItem;
		SpecificationItem *userSpecificationItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findPossessiveReversibleConclusion";

		if( relationContextNr > NO_CONTEXT_NR )
			{
			if( generalizationWordItem != NULL )
				{
				if( specificationWordItem != NULL )
					{
					if( relationWordItem != NULL )
						{
						if( myWord_->isNounWordType( specificationWordTypeNr ) &&
						admin_->isGeneralizationReasoningWordType( false, generalizationWordTypeNr ) )
							{
							tempGeneralizationContextNr = generalizationWordItem->contextNrInWord( !isPossessive, generalizationWordTypeNr, specificationWordItem );

							if( tempGeneralizationContextNr > NO_COLLECTION_NR &&
							( nContextRelations = myWord_->nContextWords( !isPossessive, tempGeneralizationContextNr, specificationWordItem ) ) > 1 )
								{
								// Find correct generalization context, which will become the relation context
								if( ( contextResult = admin_->getRelationContextNr( isExclusive, isNegative, !isPossessive, false, NO_QUESTION_PARAMETER, relationPronounContextNr, specificationContextNr, nContextRelations, relationWordItem, specificationWordItem, generalizationWordItem, NULL ) ).result == RESULT_OK )
									generalizationContextNr = contextResult.contextNr;
								else
									return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to get the relation context number" );
								}

							// Check if already exists
							if( generalizationContextNr == NO_CONTEXT_NR ||
							relationWordItem->firstActiveAssignment( false, !isPossessive, NO_QUESTION_PARAMETER, relationPronounContextNr, specificationContextNr, generalizationContextNr, specificationWordItem, NULL ) == NULL )
								{
								// Find the non-reversible specification
								specificSpecificationItem = generalizationWordItem->firstAssignmentOrSpecificationButNotAQuestion( false, true, true, false, false, isNegative, isPossessive, NO_COLLECTION_NR, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem );

								if( ( tempSpecificationItem = generalizationWordItem->firstAssignmentOrSpecificationButNotAQuestion( false, true, false, true, false, isNegative, isPossessive, NO_COLLECTION_NR, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem ) ) != NULL )
									{
									hasFoundSpecificDeactiveAssignment = true;

									if( specificSpecificationItem == NULL )
										specificSpecificationItem = tempSpecificationItem;
									}

								if( ( tempSpecificationItem = generalizationWordItem->firstAssignmentOrSpecificationButNotAQuestion( false, true, false, false, true, isNegative, isPossessive, NO_COLLECTION_NR, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem ) ) != NULL )
									{
									hasFoundSpecificArchivedAssignment = true;

									if( specificSpecificationItem == NULL )
										specificSpecificationItem = tempSpecificationItem;
									}

								if( specificSpecificationItem != NULL )
									{
									// Check if user entered specification already exists
									userSpecificationItem = relationWordItem->firstUserSpecification( isNegative, !isPossessive, NO_QUESTION_PARAMETER, relationPronounContextNr, specificationContextNr, generalizationContextNr, specificationWordItem, NULL );

									if( userSpecificationItem == NULL ||
									userSpecificationItem->isDeactiveAssignment() != hasFoundSpecificDeactiveAssignment ||		// Ambiguous when has different tense (time)
									userSpecificationItem->isArchivedAssignment() != hasFoundSpecificArchivedAssignment )		// (active, deactive or archive)
										{
										isAssignment = ( ( ( isDeactive ||
														isArchived ) &&

														userSpecificationItem == NULL ) ||

														specificSpecificationItem->hasExclusiveGeneralizationCollection() );

										if( ( relationCollectionNr = relationWordItem->collectionNr( relationWordTypeNr, specificationWordItem ) ) > NO_COLLECTION_NR )
											{
											if( relationWordItem->isExclusiveCollection( relationCollectionNr ) )
												isExclusive = true;
											}

										if( addConclusion( isAssignment, isDeactive, isArchived, isExclusive, isNegative, !isPossessive, JUSTIFICATION_TYPE_POSSESSIVE_REVERSIBLE_CONCLUSION, NO_PREPOSITION_PARAMETER, NO_QUESTION_PARAMETER, relationWordTypeNr, WORD_TYPE_NOUN_SINGULAR, generalizationWordTypeNr, relationCollectionNr, NO_COLLECTION_NR, NO_COLLECTION_NR, relationPronounContextNr, specificationContextNr, generalizationContextNr, NULL, NULL, specificSpecificationItem, relationWordItem, specificationWordItem, generalizationWordItem ) == RESULT_OK )
											{
											if( contextResult.replaceContextNr > NO_CONTEXT_NR )
												{
												if( foundConclusionSpecificationItem_ != NULL )
													{
													if( possessiveReversibleConclusionJustificationItem_ == NULL )
														{
														if( relationWordItem->replaceOlderSpecifications( contextResult.replaceContextNr, foundConclusionSpecificationItem_->updatedSpecificationItem() ) != RESULT_OK )
															return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to replace older conclusion specifications in relation word \"", relationWordItem->anyWordTypeString(), "\" to specification word \"", specificationWordItem->anyWordTypeString(), "\"" );
														}
													else
														{
														if( ( assumptionSpecificationItem = relationWordItem->firstAssumptionSpecification( true, isNegative, !isPossessive, NO_QUESTION_PARAMETER, relationPronounContextNr, specificationContextNr, specificationWordItem ) ) != NULL )
															{
															if( relationWordItem->attachJustification( possessiveReversibleConclusionJustificationItem_, assumptionSpecificationItem ) == RESULT_OK )
																{
																if( relationWordItem->attachJustification( foundConclusionSpecificationItem_->specificationJustificationItem(), assumptionSpecificationItem->updatedSpecificationItem() ) == RESULT_OK )
																	{
																	if( relationWordItem->archiveOrDeletedSpecification( foundConclusionSpecificationItem_, assumptionSpecificationItem->updatedSpecificationItem() ) == RESULT_OK )
																		{
																		if( relationWordItem->recalculateAssumptionsInWord() != RESULT_OK )
																			return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to recalculate the assumptions in relation word \"", relationWordItem->anyWordTypeString(), "\"" );
																		}
																	else
																		return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to archive the found conclusion specification in relation word \"", relationWordItem->anyWordTypeString(), "\"" );
																	}
																else
																	return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to attach the justification specification of the found conclusion specification to the assumption conclusion specification in relation word \"", relationWordItem->anyWordTypeString(), "\"" );
																}
															else
																return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to attach the possessive reversible conclusion justification to the assumption conclusion specification in relation word \"", relationWordItem->anyWordTypeString(), "\"" );
															}
														else
															return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I couldn't find an assumption specification" );
														}
													}
												else
													return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I couldn't find an older conclusion" );
												}
											}
										else
											return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a possessive reversible conclusion from relation word \"", relationWordItem->anyWordTypeString(), "\" to specification word \"", specificationWordItem->anyWordTypeString(), "\"" );
										}
									}
								else
									return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I couldn't find the non-reversible specification" );
								}
							}
						}
					else
						return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given relation word item is undefined" );
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specfication word item is undefined" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given relation context number is undefined" );

		return commonVariables_->result;
		}

	ResultType findSpecificationSubstitutionConclusionOrQuestion( bool isAssumption, bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, bool isUserSentence, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem )
		{
		SpecificationResultType specificationResult;
		bool includeAssignments;
		bool isCorrectedAssumption;
		bool skipCreatingQuestions = false;
		bool isAssignment = ( isDeactive || isArchived );
		unsigned short newQuestionParameter;
		unsigned int specificationCollectionNr;
		SpecificationItem *currentSpecificationItem;
		SpecificationItem *definitionSpecificationItem;
		SpecificationItem *foundRelatedSpecificationItem;
		SpecificationItem *foundSpecificationItem;
		WordItem *currentGeneralizationWordItem;
		WordItem *currentSpecificationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findSpecificationSubstitutionConclusionOrQuestion";

		if( myWord_->isNounWordType( specificationWordTypeNr ) )
			{
			if( generalizationWordItem != NULL )
				{
				if( specificationWordItem != NULL )
					{
					if( admin_->isGeneralizationReasoningWordType( false, generalizationWordTypeNr ) )
						{
						if( admin_->findGeneralizationAssumptionBySpecification( isDeactive, isArchived, isNegative, isPossessive, generalizationWordTypeNr, specificationWordTypeNr, generalizationContextNr, generalizationWordItem, specificationWordItem ) != RESULT_OK )
							return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a generalization assumption by specification word \"", specificationWordItem->anyWordTypeString(), "\" in generalization word \"", generalizationWordItem->anyWordTypeString(), "\"" );
						}

//					if( !commonVariables_->hasShownWarning &&	// Don't check to find deeper conflicts as well
					if( ( currentSpecificationItem = specificationWordItem->firstSpecificationButNotAQuestion() ) != NULL )
						{
						do	{
							if( currentSpecificationItem->isSpecificationNoun() &&
							currentSpecificationItem->isNegative() == isNegative &&
							currentSpecificationItem->isPossessive() == isPossessive &&
							!currentSpecificationItem->isSpecificationGeneralization() )
								{
								if( ( currentSpecificationWordItem = currentSpecificationItem->specificationWordItem() ) != NULL )
									{
									specificationCollectionNr = currentSpecificationItem->specificationCollectionNr();

									foundSpecificationItem = generalizationWordItem->firstAssignmentOrSpecification( true, true, true, true, true, isNegative, isPossessive, questionParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, NO_CONTEXT_NR, currentSpecificationWordItem, NULL );

									if( foundSpecificationItem == NULL ||

									( !currentSpecificationItem->isExclusive() &&

									( !foundSpecificationItem->isOlderSentence() ||

									( !isAssumption &&
									!isUserSentence &&
									foundSpecificationItem->isSelfGeneratedAssumption() ) ) ) )
										{
										newQuestionParameter = NO_QUESTION_PARAMETER;

										if( ( specificationResult = generalizationWordItem->findRelatedSpecification( false, false, false, isPossessive, questionParameter, specificationCollectionNr, currentSpecificationItem->relationCollectionNr(), currentSpecificationItem->generalizationContextNr(), currentSpecificationItem->specificationContextNr(), currentSpecificationItem->relationContextNr(), currentSpecificationWordItem, currentSpecificationItem->relationWordItem(), currentSpecificationItem->specificationString() ) ).result == RESULT_OK )
											{
											foundRelatedSpecificationItem = specificationResult.relatedSpecificationItem;

											if( foundRelatedSpecificationItem == NULL &&

											( currentSpecificationItem->hasSpecificationCollection() ||
											admin_->isGeneralizationReasoningWordType( false, generalizationWordTypeNr ) ) )
												{
												if( ( currentGeneralizationWordItem = currentSpecificationItem->generalizationWordItem() ) != NULL )
													{
													isCorrectedAssumption = generalizationWordItem->isCorrectedAssumption();

													if( ( foundSpecificationItem = generalizationWordItem->firstAssignmentOrSpecification( true, true, true, true, true, isNegative, isPossessive, questionParameter, generalizationContextNr, specificationContextNr, NO_CONTEXT_NR, currentGeneralizationWordItem, NULL ) ) != NULL &&

													( ( !isExclusive &&
													currentSpecificationItem->isExclusive() ) ||

													( isExclusive &&
													generalizationWordTypeNr == WORD_TYPE_PROPER_NAME ) ) )
														{
														// Question
														if( !skipCreatingQuestions &&
														foundSpecificationItem->hasSpecificationCollection() &&

														( ( isExclusive &&
														!currentSpecificationItem->isExclusive() ) ||

														( !isExclusive &&
														currentSpecificationItem->isExclusive() ) ) &&

														// Skip premature questions on possessive user sentences
														( isPossessive == admin_->isUserSentencePossessive() ||
														generalizationWordItem == admin_->userSentenceGeneralizationWordItem() ||
														currentSpecificationWordItem->isCompoundCollection( specificationCollectionNr, specificationWordItem ) ) )
															{
															if( ( specificationResult = generalizationWordItem->findRelatedSpecification( false, false, true, isPossessive, questionParameter, specificationCollectionNr, currentSpecificationItem->relationCollectionNr(), generalizationContextNr, specificationContextNr, currentSpecificationItem->relationContextNr(), currentSpecificationWordItem, currentSpecificationItem->relationWordItem(), currentSpecificationItem->specificationString() ) ).result == RESULT_OK )
																{
																foundRelatedSpecificationItem = specificationResult.relatedSpecificationItem;

																if( isCorrectedAssumption ||
																foundRelatedSpecificationItem == NULL )
																	{
																	newQuestionParameter = WORD_PARAMETER_SINGULAR_VERB_IS;

																	if( findSpecificationSubstitutionQuestion( isCorrectedAssumption, isDeactive, isArchived, isExclusive, isNegative, isPossessive, newQuestionParameter, generalizationWordTypeNr, specificationWordTypeNr, specificationCollectionNr, generalizationContextNr, specificationContextNr, currentSpecificationItem, foundSpecificationItem, generalizationWordItem, currentGeneralizationWordItem, specificationWordItem, currentSpecificationWordItem ) == RESULT_OK )
																		{
																		if( !isCorrectedAssumption &&
																		foundRelatedSpecificationItem != NULL )
																			{
																			if( generalizationWordItem->archiveOrDeletedSpecification( foundRelatedSpecificationItem, createdConclusionSpecificationItem_ ) != RESULT_OK )
																				return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to archive a related specification in generalization word \"", generalizationWordItem->anyWordTypeString(), "\"" );
																			}
																		}
																	else
																		return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a specification substitution question in generalization word \"", generalizationWordItem->anyWordTypeString(), "\" with specification word \"", currentSpecificationWordItem->anyWordTypeString(), "\"" );
																	}
																}
															else
																return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find out if generalization word \"", generalizationWordItem->anyWordTypeString(), "\" is related to the found specification" );
															}
														}
													else	// Assumption / conclusion
														{
														if( !isExclusive &&
														currentSpecificationItem->hasSpecificationCollection() &&
														admin_->isGeneralizationReasoningWordType( false, generalizationWordTypeNr ) )
															{
															// Detect a conflict
															if( generalizationWordItem->checkForSpecificationConflict( false, isExclusive, isNegative, isPossessive, specificationWordTypeNr, specificationCollectionNr, currentSpecificationItem->relationCollectionNr(), currentSpecificationItem->generalizationContextNr(), currentSpecificationItem->specificationContextNr(), currentSpecificationItem->relationContextNr(), currentSpecificationWordItem, currentSpecificationItem->relationWordItem(), currentSpecificationItem->specificationString() ) != RESULT_OK )
																return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check for a specification conflict in generalization word \"", generalizationWordItem->anyWordTypeString(), "\"" );
															}

														if( !commonVariables_->hasShownWarning &&
														!isCorrectedAssumption )
															{
															if( isAssumption ||
															currentSpecificationItem->isSelfGeneratedAssumption() )
																{
																// Create an assumption
																if( admin_->addAssumption( isDeactive, isArchived, isExclusive, isNegative, isPossessive, JUSTIFICATION_TYPE_SPECIFICATION_SUBSTITUTION_ASSUMPTION, NO_PREPOSITION_PARAMETER, generalizationWordTypeNr, specificationWordTypeNr, WORD_TYPE_UNDEFINED, currentSpecificationItem->generalizationCollectionNr(), specificationCollectionNr, currentSpecificationItem->relationCollectionNr(), generalizationContextNr, specificationContextNr, foundSpecificationItem, currentSpecificationItem, generalizationWordItem, currentSpecificationWordItem, NULL ) != RESULT_OK )
																	return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a suggestive question assumption about generalization word \"", generalizationWordItem->anyWordTypeString(), "\" with specification word \"", currentSpecificationWordItem->anyWordTypeString(), "\"" );
																}
															else
																{
																if( currentSpecificationItem->isSpecificationNoun() )
																	{
																	includeAssignments = ( generalizationContextNr > NO_CONTEXT_NR ||
																							specificationContextNr > NO_CONTEXT_NR );

																	if( ( definitionSpecificationItem = generalizationWordItem->firstAssignmentOrSpecification( includeAssignments, isNegative, isPossessive, NO_QUESTION_PARAMETER, generalizationContextNr, specificationContextNr, NO_CONTEXT_NR, currentGeneralizationWordItem ) ) != NULL )
																		{
																		if( lastCreatedSpecificationSubstitutionConclusionSpecificationItem_ != NULL &&
																		lastCreatedSpecificationSubstitutionConclusionSpecificationItem_->generalizationWordItem() == generalizationWordItem )
																			specificationCollectionNr = lastCreatedSpecificationSubstitutionConclusionSpecificationItem_->specificationCollectionNr();

																		// Create a conclusion
																		if( addConclusion( isAssignment, isDeactive, isArchived, isExclusive, isNegative, isPossessive, JUSTIFICATION_TYPE_SPECIFICATION_SUBSTITUTION_CONCLUSION, NO_PREPOSITION_PARAMETER, questionParameter, generalizationWordTypeNr, currentSpecificationItem->specificationWordTypeNr(), WORD_TYPE_UNDEFINED, currentSpecificationItem->generalizationCollectionNr(), specificationCollectionNr, currentSpecificationItem->relationCollectionNr(), currentSpecificationItem->generalizationContextNr(), currentSpecificationItem->specificationContextNr(), NO_CONTEXT_NR, definitionSpecificationItem, NULL, currentSpecificationItem, generalizationWordItem, currentSpecificationWordItem, NULL ) == RESULT_OK )
																			lastCreatedSpecificationSubstitutionConclusionSpecificationItem_ = createdConclusionSpecificationItem_;
																		else
																			return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to add a specification substitution conclusion about generalization word \"", generalizationWordItem->anyWordTypeString(), "\" with specification word \"", currentSpecificationWordItem->anyWordTypeString(), "\"" );
																		}
																	else
																		return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I couldn't find a definition specification item of a conclusion or question" );
																	}
																}
															}
														}

													if( !commonVariables_->hasShownWarning &&
													currentSpecificationItem->hasSpecificationCollection() &&

													( !currentSpecificationItem->isExclusive() ||

													( isExclusive &&
													myWord_->isNounWordType( generalizationWordTypeNr ) ) ) )
														{
														if( admin_->findGeneralizationAssumptionByGeneralization( isDeactive, isArchived, isNegative, isPossessive, newQuestionParameter, generalizationWordTypeNr, specificationWordTypeNr, generalizationContextNr, currentSpecificationItem->relationContextNr(), generalizationWordItem, currentSpecificationItem->specificationWordItem() ) != RESULT_OK )
															return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a generalization assumption by generalization word \"", generalizationWordItem->anyWordTypeString(), "\" and with specification word \"", currentSpecificationWordItem->anyWordTypeString(), "\"" );
														}
													}
												else
													return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found an undefined generalization word" );
												}
											else
												{
												if( !currentSpecificationItem->isExclusive() &&
												currentSpecificationItem->isUserSpecification() )
													{
													if( generalizationWordItem->checkForSpecificationConflict( false, isExclusive, isNegative, isPossessive, specificationWordTypeNr, specificationCollectionNr, currentSpecificationItem->relationCollectionNr(), currentSpecificationItem->generalizationContextNr(), currentSpecificationItem->specificationContextNr(), currentSpecificationItem->relationContextNr(), currentSpecificationWordItem, currentSpecificationItem->relationWordItem(), currentSpecificationItem->specificationString() ) != RESULT_OK )
														return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to check for a specification conflict in generalization word \"", generalizationWordItem->anyWordTypeString(), "\"" );
													}
												}
											}
										else
											return myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find out if generalization word \"", generalizationWordItem->anyWordTypeString(), "\" is related to the found specification" );
										}
									else
										skipCreatingQuestions = true;
									}
								else
									return myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found an undefined specification word" );
								}
							}
						while( !commonVariables_->hasShownWarning &&
						( currentSpecificationItem = currentSpecificationItem->nextSpecificationItemButNotAQuestion() ) != NULL );
						}
					}
				else
					return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specfication word item is undefined" );
				}
			else
				return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given generalization word item is undefined" );
			}
		else
			return myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word type isn't a noun" );

		return commonVariables_->result;
		}

	SpecificationResultType findCompoundSpecificationSubstitutionConclusion( bool isNegative, bool isPossessive, unsigned short specificationWordTypeNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem )
		{
		SpecificationResultType specificationResult;
		GeneralizationItem *currentGeneralizationItem;
		SpecificationItem *foundSpecificationItem;
		SpecificationItem *previousSpecificationItem = NULL;
		SpecificationItem *lastCreatedSpecificationItem = NULL;
		WordItem *currentGeneralizationWordItem;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findCompoundSpecificationSubstitutionConclusion";

		if( myWord_->isNounWordType( specificationWordTypeNr ) )
			{
			if( specificationWordItem != NULL )
				{
				do	{
					if( ( currentGeneralizationItem = specificationWordItem->firstActiveGeneralizationItemOfSpecification() ) != NULL )
						{
						previousSpecificationItem = lastCreatedSpecificationItem;

						do	{
							if( ( currentGeneralizationWordItem = currentGeneralizationItem->generalizationWordItem() ) != NULL )
								{
								if( ( foundSpecificationItem = currentGeneralizationWordItem->firstAssignmentOrSpecificationButNotAQuestion( false, true, true, true, true, isNegative, isPossessive, NO_COLLECTION_NR, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem ) ) != NULL )
									{
									if( findSpecificationSubstitutionConclusionOrQuestion( foundSpecificationItem->isSelfGeneratedAssumption(), foundSpecificationItem->isDeactiveItem(), foundSpecificationItem->isArchivedItem(), foundSpecificationItem->isExclusive(), isNegative, isPossessive, false, NO_QUESTION_PARAMETER, foundSpecificationItem->generalizationWordTypeNr(), specificationWordTypeNr, generalizationContextNr, specificationContextNr, currentGeneralizationWordItem, foundSpecificationItem->specificationWordItem() ) == RESULT_OK )
										{
										if( !commonVariables_->hasShownWarning )
											{
											if( ( specificationResult = currentGeneralizationWordItem->findRelatedSpecification( false, foundSpecificationItem ) ).result == RESULT_OK )
												{
												if( ( foundSpecificationItem = specificationResult.relatedSpecificationItem ) != NULL )
													{
													if( findSpecificationSubstitutionConclusionOrQuestion( foundSpecificationItem->isSelfGeneratedAssumption(), foundSpecificationItem->isDeactiveItem(), foundSpecificationItem->isArchivedItem(), foundSpecificationItem->isExclusive(), isNegative, isPossessive, false, foundSpecificationItem->questionParameter(), foundSpecificationItem->generalizationWordTypeNr(), specificationWordTypeNr, generalizationContextNr, specificationContextNr, currentGeneralizationWordItem, foundSpecificationItem->specificationWordItem() ) == RESULT_OK )
														specificationResult.compoundGeneralizationWordItem = currentGeneralizationWordItem;
													else
														myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a specification substitution conclusion or question for generalization word \"", currentGeneralizationWordItem->anyWordTypeString(), "\" and specification word \"", specificationWordItem->anyWordTypeString(), "\"" );
													}
												}
											else
												myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a related specification in word \"", currentGeneralizationWordItem->anyWordTypeString(), "\" is related to the found specification" );
											}
										}
									else
										myWord_->addErrorInItem( functionNameString, moduleNameString_, "I failed to find a specification substitution conclusion or question for generalization word \"", currentGeneralizationWordItem->anyWordTypeString(), "\" and specification word \"", specificationWordItem->anyWordTypeString(), "\"" );
									}
								}
							else
								myWord_->startErrorInItem( functionNameString, moduleNameString_, "I found an undefined generalization word" );
							}
						while( commonVariables_->result == RESULT_OK &&
						!commonVariables_->hasShownWarning &&
						( currentGeneralizationItem = currentGeneralizationItem->nextGeneralizationItemOfSpecification() ) != NULL );
						}
					}
				while( commonVariables_->result == RESULT_OK &&
				!commonVariables_->hasShownWarning &&
				// Do until no more conclusions or questions are created
				previousSpecificationItem != NULL &&	// Skip when no generalizations are available
				previousSpecificationItem != lastCreatedSpecificationItem );
				}
			else
				myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word item is undefined" );
			}
		else
			myWord_->startErrorInItem( functionNameString, moduleNameString_, "The given specification word type isn't a noun" );

		specificationResult.result = commonVariables_->result;
		return specificationResult;
		}
	};

/*************************************************************************
 *
 *	"He forgives all my sins and heals all my diseases.
 *	He redeems me from death and crowns me with love and
 *	tender mercies. He fills my life with good things.
 *	My youth is renewed like the eagle's!" (Psalm 103:3-5)
 *
 *************************************************************************/
