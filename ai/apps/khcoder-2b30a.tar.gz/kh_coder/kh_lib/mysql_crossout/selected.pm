package mysql_crossout::selected;

use base qw(mysql_crossout);
use strict;

use mysql_crossout::selected::r_com;

1;