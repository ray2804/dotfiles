<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<?php 
	$page = "add";
	include 'head.php'; 
	include 'objects.php';
	
	echo $header_html;
?>
<body>
<?php 
	
	$linkGen = new LinkGenerator();
	$pgGen = new PageGenerator();
	
	echo $linkGen->t_link().' | '.$linkGen->i_link() ;
	echo "<center><a href=\"$main_page\">$logo_html</a></center>";
	$pgGen->addFilePage();
	echo $foot_html; 

?>