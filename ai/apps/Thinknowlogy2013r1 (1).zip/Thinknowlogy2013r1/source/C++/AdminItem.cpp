/*
 *	Class:			AdminItem
 *	Parent class:	WordItem
 *	Grand parent:	Item
 *	Purpose:		To process tasks at administration level
 *	Version:		Thinknowlogy 2013 (release 1)
 *
 *************************************************************************/
/*
 *	Thinknowlogy is grammar-based software,
 *	designed to utilize rules of intelligence contained within grammar,
 *	in order to create intelligence through natural language in software,
 *	which is demonstrated by:
 *	- Programming in natural language;
 *	- Reasoning in natural language:
 *		- drawing conclusions,
 *		- making assumptions (with self-adjusting level of uncertainty),
 *		- asking questions about gaps in the knowledge,
 *		- detecting conflicts in the knowledge;
 *	- Building semantics autonomously (no vocabularies):
 *		- detecting some cases of semantic ambiguity;
 *	- Intelligent answering of "is" questions (by providing alternatives).
 *
 *************************************************************************/
/*
 *	Copyright (C) 2009-2013, Menno Mafait
 *
 *	Your additions, modifications, suggestions and bug reports
 *	are welcome at http://mafait.org
 *
 *************************************************************************/
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 *************************************************************************/

#include <time.h>
#include "AdminAssumption.cpp"
#include "AdminAuthorization.cpp"
#include "AdminCleanup.cpp"
#include "AdminCollection.cpp"
#include "AdminConclusion.cpp"
#include "AdminContext.cpp"
#include "AdminGrammar.cpp"
#include "AdminImperative.cpp"
#include "AdminJustification.cpp"
#include "AdminLanguage.cpp"
#include "AdminQuery.cpp"
#include "AdminRead.cpp"
#include "AdminReadCreateWords.cpp"
#include "AdminReadSentence.cpp"
#include "AdminSelection.cpp"
#include "AdminSolve.cpp"
#include "AdminSpecification.cpp"
#include "AdminWrite.cpp"

	// Private functions

	ResultType AdminItem::startup()
		{
		char titleString[MAX_READ_WRITE_STRING_LENGTH];
		char functionNameString[FUNCTION_NAME_LENGTH] = "startup";

		srand( (unsigned int)time( NULL ) );		// Initialize the random number generator with the time
		sprintf( titleString, "\n%s %s\n", PRODUCT_NAME, VERSION_NAME );

		if( commonVariables()->presentation->writeDiacriticalText( PRESENTATION_PROMPT_NOTIFICATION, titleString ) == RESULT_OK )
			{
			if( readStartupFile() == RESULT_OK )
				{
				if( commonVariables()->presentation->writeInterfaceText( false, PRESENTATION_PROMPT_NOTIFICATION, INTERFACE_CONSOLE_START_MESSAGE ) == RESULT_OK )
					isSystemStartingUp_ = false;
				else
					return addErrorInItem( functionNameString, NULL, NULL, "I failed to write the start interface text" );
				}
			else
				return startSystemErrorInItem( functionNameString, NULL, NULL, "I failed to read the startup file" );
			}
		else
			return startSystemErrorInItem( functionNameString, NULL, NULL, "I failed to write the title text" );

		return commonVariables()->result;
		}


	// Private read functions

	ResultType AdminItem::readStartupFile()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "readStartupFile";
		if( adminRead_ != NULL ||
		// Create supporting module
		( adminRead_ = new AdminRead( this, this, commonVariables() ) ) != NULL )
			return adminRead_->readStartupFile();

		return startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin read module" );
		}


	// Constructor

	AdminItem::AdminItem()
		{
		// Private constructible variables

		isSystemStartingUp_ = true;

		adminAssumption_ = NULL;
		adminAuthorization_ = NULL;
		adminCleanup_ = NULL;
		adminCollection_ = NULL;
		adminConclusion_ = NULL;
		adminContext_ = NULL;
		adminGrammar_ = NULL;
		adminImperative_ = NULL;
		adminJustification_ = NULL;
		adminLanguage_ = NULL;
		adminQuery_ = NULL;
		adminRead_ = NULL;
		adminReadCreateWords_ = NULL;
		adminReadSentence_ = NULL;
		adminSelection_ = NULL;
		adminSolve_ = NULL;
		adminSpecification_ = NULL;
		adminWrite_ = NULL;

		// Protected constructible variables

		fileList = NULL;
		readList = NULL;
		scoreList = NULL;
		wordList = NULL;
		conditionList = NULL;
		actionList = NULL;
		alternativeList = NULL;

		for( unsigned short adminListNr = 0; adminListNr < NUMBER_OF_ADMIN_LISTS; adminListNr++ )
			adminList[adminListNr] = NULL;

		// Initialization

		initializeItemVariables( "AdminItem", this, new CommonVariables() );

		if( ( commonVariables()->presentation = new Presentation( commonVariables() ) ) != NULL )
			{
		if( startup() != RESULT_OK )
			addErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, NULL, "I failed to start the administrator" );
			}
		else
			startSystemErrorInItem( PRESENTATION_ERROR_CONSTRUCTOR_FUNCTION_NAME, NULL, NULL, "I failed to create the presentation module" );
		}

	AdminItem::~AdminItem()
		{
		if( commonVariables() != NULL )
			{
			if( commonVariables()->presentation != NULL )
				delete commonVariables()->presentation;

			delete commonVariables();
			}

		if( adminAssumption_ != NULL )
			delete adminAssumption_;
		if( adminAuthorization_ != NULL )
			delete adminAuthorization_;
		if( adminCleanup_ != NULL )
			delete adminCleanup_;
		if( adminCollection_ != NULL )
			delete adminCollection_;
		if( adminConclusion_ != NULL )
			delete adminConclusion_;
		if( adminContext_ != NULL )
			delete adminContext_;
		if( adminGrammar_ != NULL )
			delete adminGrammar_;
		if( adminImperative_ != NULL )
			delete adminImperative_;
		if( adminJustification_ != NULL )
			delete adminJustification_;
		if( adminLanguage_ != NULL )
			delete adminLanguage_;
		if( adminQuery_ != NULL )
			delete adminQuery_;
		if( adminRead_ != NULL )
			delete adminRead_;
		if( adminReadCreateWords_ != NULL )
			delete adminReadCreateWords_;
		if( adminReadSentence_ != NULL )
			delete adminReadSentence_;
		if( adminSelection_ != NULL )
			delete adminSelection_;
		if( adminSolve_ != NULL )
			delete adminSolve_;
		if( adminSpecification_ != NULL )
			delete adminSpecification_;
		if( adminWrite_ != NULL )
			delete adminWrite_;

		if( fileList != NULL )
			delete fileList;
		if( readList != NULL )
			delete readList;
		if( scoreList != NULL )
			delete scoreList;
		if( wordList != NULL )
			delete wordList;
		if( conditionList != NULL )
			delete conditionList;
		if( actionList != NULL )
			delete actionList;
		if( alternativeList != NULL )
			delete alternativeList;
		}


	// Protected common functions

	bool AdminItem::isSystemStartingUp()
		{
		return isSystemStartingUp_;
		}

	bool AdminItem::isGeneralizationReasoningWordType( bool includeNoun, unsigned short generalizationWordTypeNr )
		{
		return ( generalizationWordTypeNr == WORD_TYPE_SYMBOL ||
				generalizationWordTypeNr == WORD_TYPE_NUMERAL ||
				generalizationWordTypeNr == WORD_TYPE_LETTER_SMALL ||
				generalizationWordTypeNr == WORD_TYPE_LETTER_CAPITAL ||
				generalizationWordTypeNr == WORD_TYPE_PROPER_NAME ||

				( includeNoun &&

				( generalizationWordTypeNr == WORD_TYPE_NOUN_SINGULAR ||
				generalizationWordTypeNr == WORD_TYPE_NOUN_PLURAL ) ) );
		}

	char AdminItem::adminListChar( unsigned short adminListNr )
		{
		switch( adminListNr )
			{
			case ADMIN_FILE_LIST:
				return ADMIN_FILE_LIST_SYMBOL;

			case ADMIN_READ_LIST:
				return ADMIN_READ_LIST_SYMBOL;

			case ADMIN_SCORE_LIST:
				return ADMIN_SCORE_LIST_SYMBOL;

			case ADMIN_WORD_LIST:
				return ADMIN_WORD_LIST_SYMBOL;

			case ADMIN_CONDITION_LIST:
				return ADMIN_CONDITION_LIST_SYMBOL;

			case ADMIN_ACTION_LIST:
				return ADMIN_ACTION_LIST_SYMBOL;

			case ADMIN_ALTERNATIVE_LIST:
				return ADMIN_ALTERNATIVE_LIST_SYMBOL;
			}

		return SYMBOL_QUESTION_MARK;
		}


	// Protected assignment functions

	ResultType AdminItem::assignSelectionSpecification( SelectionItem *assignmentSelectionItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "assignSelectionSpecification";
		if( adminSpecification_ != NULL )
			return adminSpecification_->assignSelectionSpecification( assignmentSelectionItem );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin specification module isn't created yet" );
		}

	ResultType AdminItem::assignSpecification( WordItem *generalizationWordItem, WordItem *specificationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "assignSpecification";
		if( adminSpecification_ != NULL )
			return adminSpecification_->assignSpecification( false, false, false, false, false, false, false, NO_PREPOSITION_PARAMETER, NO_QUESTION_PARAMETER, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, NO_SENTENCE_NR, 0, NULL, generalizationWordItem, specificationWordItem, NULL ).result;

		return startErrorInItem( functionNameString, NULL, NULL, "The admin specification module isn't created yet" );
		}

	SpecificationResultType AdminItem::assignSpecificationWithAuthorization( bool isAmbiguousRelationContext, bool isAssignedOrClear, bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, bool isSelfGenerated, unsigned short prepositionParameter, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int originalSentenceNr, unsigned int activeSentenceNr, unsigned int deactiveSentenceNr, unsigned int archiveSentenceNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem, char *specificationString )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addSpecificationWithAuthorization";

		if( specificationWordItem == commonVariables()->predefinedNounGrammarLanguageWordItem ||
		specificationWordItem == predefinedNounInterfaceLanguageWordItem() )
			{
			if( adminLanguage_ != NULL )
				return adminLanguage_->assignSpecificationWithAuthorization( isAmbiguousRelationContext, isAssignedOrClear, isDeactive, isArchived, isNegative, isPossessive, isSelfGenerated, prepositionParameter, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, originalSentenceNr, activeSentenceNr, deactiveSentenceNr, archiveSentenceNr, nContextRelations, specificationJustificationItem, generalizationWordItem, specificationWordItem, specificationString );
			else
				startErrorInItem( functionNameString, NULL, NULL, "The admin language module isn't created yet" );
			}
		else
			{
			if( adminAuthorization_ != NULL )
				return adminAuthorization_->assignSpecificationWithAuthorization( isAmbiguousRelationContext, isAssignedOrClear, isDeactive, isArchived, isNegative, isPossessive, isSelfGenerated, prepositionParameter, questionParameter, generalizationContextNr, specificationContextNr, relationContextNr, originalSentenceNr, activeSentenceNr, deactiveSentenceNr, archiveSentenceNr, nContextRelations, specificationJustificationItem, generalizationWordItem, specificationWordItem, specificationString );
			else
				startErrorInItem( functionNameString, NULL, NULL, "The admin authorization module isn't created yet" );
			}

		specificationResult.result = commonVariables()->result;
		return specificationResult;
		}


	// Protected assumption functions

	void AdminItem::initializeAdminAssumptionVariables()
		{
		if( adminAssumption_ != NULL )
			adminAssumption_->initializeAdminAssumptionVariables();
		}

	ResultType AdminItem::addSuggestiveQuestionAssumption( bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, SpecificationItem *specificSpecificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "addSuggestiveQuestionAssumption";
		if( adminAssumption_ != NULL )
			return adminAssumption_->addSuggestiveQuestionAssumption( isDeactive, isArchived, isExclusive, isNegative, isPossessive, generalizationWordTypeNr, specificationWordTypeNr, generalizationContextNr, specificationContextNr, relationContextNr, specificSpecificationItem, generalizationWordItem, specificationWordItem, relationWordItem );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin assumption module isn't created yet" );
		}

	ResultType AdminItem::findGeneralizationAssumptionBySpecification( bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int generalizationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "findGeneralizationAssumptionBySpecification";
		if( adminAssumption_ != NULL ||
		// Create supporting module
		( adminAssumption_ = new AdminAssumption( this, this, commonVariables() ) ) != NULL )
			return adminAssumption_->findGeneralizationAssumptionBySpecification( isDeactive, isArchived, isNegative, isPossessive, generalizationWordTypeNr, specificationWordTypeNr, generalizationContextNr, generalizationWordItem, specificationWordItem );

		return startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin assumption module" );
		}

	ResultType AdminItem::findGeneralizationAssumptionByGeneralization( bool isDeactive, bool isArchived, bool isNegative, bool isPossessive, unsigned short specificQuestionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int generalizationContextNr, unsigned int relationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "findGeneralizationAssumptionByGeneralization";
		if( adminAssumption_ != NULL )
			return adminAssumption_->findGeneralizationAssumptionByGeneralization( isDeactive, isArchived, isNegative, isPossessive, specificQuestionParameter, generalizationWordTypeNr, specificationWordTypeNr, generalizationContextNr, relationContextNr, generalizationWordItem, specificationWordItem );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin assumption module isn't created yet" );
		}

	ResultType AdminItem::findExclusiveSpecificationSubstitutionAssumption( bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "findExclusiveSpecificationSubstitutionAssumption";
		if( adminAssumption_ != NULL )
			return adminAssumption_->findExclusiveSpecificationSubstitutionAssumption( isDeactive, isArchived, isExclusive, isNegative, isPossessive, generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, generalizationContextNr, specificationContextNr, generalizationWordItem, specificationWordItem, relationWordItem );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin assumption module isn't created yet" );
		}

	ResultType AdminItem::addAssumption( bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, unsigned short justificationTypeNr, unsigned short prepositionParamater, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, SpecificationItem *definitionSpecificationItem, SpecificationItem *specificSpecificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "addAssumption";
		if( adminAssumption_ != NULL )
			return adminAssumption_->addAssumption( isDeactive, isArchived, isExclusive, isNegative, isPossessive, justificationTypeNr, prepositionParamater, generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, generalizationCollectionNr, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, definitionSpecificationItem, NULL, specificSpecificationItem, generalizationWordItem, specificationWordItem, relationWordItem );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin assumption module isn't created yet" );
		}


	// Protected authorization functions

	unsigned int AdminItem::myFirstSentenceNr()
		{
		if( adminAuthorization_ != NULL )
			return adminAuthorization_->myFirstSentenceNr();

		return NO_SENTENCE_NR;
		}

	ResultType AdminItem::login( WordItem *specificationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "login";
		if( adminAuthorization_ != NULL )
			return adminAuthorization_->login( specificationWordItem );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin authorization module isn't created yet" );
		}

	ResultType AdminItem::authorizeWord( WordItem *authorizationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "authorizeWord";
		if( adminAuthorization_ != NULL ||
		// Create supporting module
		( adminAuthorization_ = new AdminAuthorization( this, this, commonVariables() ) ) != NULL )
			return adminAuthorization_->authorizeWord( authorizationWordItem );

		return startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin authorization module" );
		}

	char *AdminItem::currentUserName()
		{
		if( adminAuthorization_ != NULL )
			return adminAuthorization_->currentUserName();

		return NULL;	// During startup - before login
		}


	// Protected cleanup functions

	void AdminItem::clearDontIncrementCurrentSentenceNr()
		{
		if( adminCleanup_ != NULL )
			adminCleanup_->clearDontIncrementCurrentSentenceNr();
		}

	bool AdminItem::dontIncrementCurrentSentenceNr()
		{
		if( adminCleanup_ != NULL )
			return adminCleanup_->dontIncrementCurrentSentenceNr();

		return false;
		}

	bool AdminItem::hasFoundChange()
		{
		if( adminCleanup_ != NULL )
			return adminCleanup_->hasFoundChange();

		return true;	// Default when admin cleanup module isn't created yet
		}

	bool AdminItem::wasUndoOrRedo()
		{
		if( adminCleanup_ != NULL )
			return adminCleanup_->wasUndoOrRedo();

		return true;	// Default when admin cleanup module isn't created yet
		}

	unsigned int AdminItem::highestSentenceNr()
		{
		if( adminCleanup_ != NULL )
			return adminCleanup_->highestSentenceNr();

		return NO_SENTENCE_NR;
		}

	ResultType AdminItem::checkForChanges()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkForChanges";
		if( adminCleanup_ != NULL )
			return adminCleanup_->checkForChanges();

		return startErrorInItem( functionNameString, NULL, NULL, "The admin cleanup module isn't created yet" );
		}

	ResultType AdminItem::cleanupDeletedItems()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "cleanupDeletedItems";
		if( adminCleanup_ != NULL ||
		// Create supporting module
		( adminCleanup_ = new AdminCleanup( this, this, commonVariables() ) ) != NULL )
			return adminCleanup_->cleanupDeletedItems();

		return startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin cleanup module" );
		}

	ResultType AdminItem::currentItemNr()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "currentItemNr";
		if( adminCleanup_ != NULL )
			return adminCleanup_->currentItemNr();

		return startErrorInItem( functionNameString, NULL, NULL, "The admin cleanup module isn't created yet" );
		}

	ResultType AdminItem::deleteRollbackInfo()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteRollbackInfo";
		if( adminCleanup_ != NULL )
			return adminCleanup_->deleteRollbackInfo();

		return startErrorInItem( functionNameString, NULL, NULL, "The admin cleanup module isn't created yet" );
		}

	ResultType AdminItem::deleteAllTemporaryLists()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteAllTemporaryLists";
		if( adminCleanup_ != NULL )
			return adminCleanup_->deleteAllTemporaryLists();

		return startErrorInItem( functionNameString, NULL, NULL, "The admin cleanup module isn't created yet" );
		}

	ResultType AdminItem::deleteUnusedInterpretations( bool deleteAllActiveWordTypes )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteUnusedInterpretations";
		if( adminCleanup_ != NULL )
			return adminCleanup_->deleteUnusedInterpretations( deleteAllActiveWordTypes );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin cleanup module isn't created yet" );
		}

	ResultType AdminItem::deleteSentences( bool isAvailableForRollback, unsigned int lowestSentenceNr )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "deleteSentences";
		if( adminCleanup_ != NULL )
			return adminCleanup_->deleteSentences( isAvailableForRollback, lowestSentenceNr );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin cleanup module isn't created yet" );
		}

	ResultType AdminItem::undoLastSentence()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "undoLastSentence";
		if( adminCleanup_ != NULL )
			return adminCleanup_->undoLastSentence();

		return startErrorInItem( functionNameString, NULL, NULL, "The admin cleanup module isn't created yet" );
		}

	ResultType AdminItem::redoLastUndoneSentence()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "redoLastUndoneSentence";
		if( adminCleanup_ != NULL )
			return adminCleanup_->redoLastUndoneSentence();

		return startErrorInItem( functionNameString, NULL, NULL, "The admin cleanup module isn't created yet" );
		}


	// Protected collection functions

	CollectionResultType AdminItem::collectSpecificationStrings( bool isExclusive, bool isExclusiveGeneralization, bool isQuestion, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, WordItem *generalizationWordItem, char *previousSpecificationString, char *currentSpecificationString )
		{
		CollectionResultType collectionResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "collectSpecificationWords";

		if( adminCollection_ != NULL )
			return adminCollection_->collectSpecificationStrings( isExclusive, isExclusiveGeneralization, isQuestion, generalizationWordTypeNr, specificationWordTypeNr, generalizationWordItem, previousSpecificationString, currentSpecificationString );

		collectionResult.result = startErrorInItem( functionNameString, NULL, NULL, "The admin collection module isn't created yet" );
		return collectionResult;
		}

	CollectionResultType AdminItem::collectSpecificationWords( bool isExclusive, bool isExclusiveGeneralization, bool isQuestion, bool isSpecificationGeneralization, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, WordItem *compoundGeneralizationWordItem, WordItem *generalizationWordItem, WordItem *previousSpecificationWordItem, WordItem *currentSpecificationWordItem )
		{
		CollectionResultType collectionResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "collectSpecificationWords";

		if( adminCollection_ != NULL )
			return adminCollection_->collectSpecificationWords( isExclusive, isExclusiveGeneralization, isQuestion, isSpecificationGeneralization, generalizationWordTypeNr, specificationWordTypeNr, compoundGeneralizationWordItem, generalizationWordItem, previousSpecificationWordItem, currentSpecificationWordItem );

		collectionResult.result = startErrorInItem( functionNameString, NULL, NULL, "The admin collection module isn't created yet" );
		return collectionResult;
		}

	ResultType AdminItem::collectGeneralizationWordWithPreviousOne( bool isExclusive, bool isExclusiveGeneralization, bool isPossessive, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short questionParameter, unsigned int relationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "collectGeneralizationWordWithPreviousOne";
		if( adminCollection_ != NULL ||
		// Create supporting module
		( adminCollection_ = new AdminCollection( this, this, commonVariables() ) ) != NULL )
			return adminCollection_->collectGeneralizationWordWithPreviousOne( isExclusive, isExclusiveGeneralization, isPossessive, generalizationWordTypeNr, specificationWordTypeNr, questionParameter, relationContextNr, generalizationWordItem, specificationWordItem );

		return startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin collection module" );
		}

	ResultType AdminItem::collectRelationWords( bool isExclusive, unsigned short relationWordTypeNr, unsigned short specificationWordTypeNr, WordItem *previousRelationWordItem, WordItem *currentRelationWordItem, WordItem *specificationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "collectRelationWords";
		if( adminCollection_ != NULL )
			return adminCollection_->collectRelationWords( isExclusive, relationWordTypeNr, specificationWordTypeNr, previousRelationWordItem, currentRelationWordItem, specificationWordItem );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin collection module isn't created yet" );
		}


	// Protected conclusion functions

	void AdminItem::initializeAdminConclusionVariables()
		{
		if( adminConclusion_ != NULL )
			adminConclusion_->initializeAdminConclusionVariables();
		}

	ResultType AdminItem::addSpecificationGeneralizationConclusion( unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, SpecificationItem *definitionSpecificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "addSpecificationGeneralizationConclusion";
		if( adminConclusion_ != NULL )
			return adminConclusion_->addSpecificationGeneralizationConclusion( generalizationWordTypeNr, specificationWordTypeNr, definitionSpecificationItem, generalizationWordItem, specificationWordItem );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin conclusion module isn't created yet" );
		}

	ResultType AdminItem::findPossessiveReversibleConclusion( bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int specificationContextNr, unsigned int relationPronounContextNr, unsigned int relationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "findPossessiveReversibleConclusion";
		if( adminConclusion_ != NULL )
			return adminConclusion_->findPossessiveReversibleConclusion( isDeactive, isArchived, isExclusive, isNegative, isPossessive, generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, specificationContextNr, relationPronounContextNr, relationContextNr, generalizationWordItem, specificationWordItem, relationWordItem );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin conclusion module isn't created yet" );
		}

	ResultType AdminItem::findSpecificationSubstitutionConclusionOrQuestion( bool isAssumption, bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, bool isUserSentence, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, WordItem *generalizationWordItem, WordItem *specificationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "findSpecificationSubstitutionConclusion";
		if( adminConclusion_ != NULL ||
		// Create supporting module
		( adminConclusion_ = new AdminConclusion( this, this, commonVariables() ) ) != NULL )
			return adminConclusion_->findSpecificationSubstitutionConclusionOrQuestion( isAssumption, isDeactive, isArchived, isExclusive, isNegative, isPossessive, isUserSentence, questionParameter, generalizationWordTypeNr, specificationWordTypeNr, generalizationContextNr, specificationContextNr, generalizationWordItem, specificationWordItem );

		return startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin conclusion module" );
		}

	SpecificationResultType AdminItem::findCompoundSpecificationSubstitutionConclusion( bool isNegative, bool isPossessive, unsigned short specificationWordTypeNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, WordItem *specificationWordItem )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "findCompoundSpecificationSubstitutionConclusion";

		if( adminConclusion_ != NULL )
			return adminConclusion_->findCompoundSpecificationSubstitutionConclusion( isNegative, isPossessive, specificationWordTypeNr, generalizationContextNr, specificationContextNr, relationContextNr, specificationWordItem );

		specificationResult.result = startErrorInItem( functionNameString, NULL, NULL, "The admin conclusion module isn't created yet" );
		return specificationResult;
		}


	// Protected context functions

	unsigned int AdminItem::highestContextNr()
		{
		if( adminContext_ != NULL )
			return adminContext_->highestContextNr();

		return NO_CONTEXT_NR;
		}

	ContextResultType AdminItem::addPronounContext( unsigned short contextWordTypeNr, WordItem *contextWordItem )
		{
		ContextResultType contextResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "getRelationContextNr";
		if( adminContext_ != NULL ||
		// Create supporting module
		( adminContext_ = new AdminContext( this, this, commonVariables() ) ) != NULL )
			return adminContext_->addPronounContext( contextWordTypeNr, contextWordItem );

		contextResult.result = startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin grammar module" );
		return contextResult;
		}

	ContextResultType AdminItem::getRelationContextNr( bool isExclusive, bool isNegative, bool isPossessive, bool isUserSentence, unsigned short questionParameter, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int nContextRelations, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem, ReadItem *startRelationReadItem )
		{
		ContextResultType contextResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "getRelationContextNr";
		if( adminContext_ != NULL ||
		// Create supporting module
		( adminContext_ = new AdminContext( this, this, commonVariables() ) ) != NULL )
			return adminContext_->getRelationContextNr( isExclusive, isNegative, isPossessive, isUserSentence, questionParameter, generalizationContextNr, specificationContextNr, nContextRelations, generalizationWordItem, specificationWordItem, relationWordItem, startRelationReadItem );

		contextResult.result = startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin grammar module" );
		return contextResult;
		}


	// Protected grammar functions

	ResultType AdminItem::addGrammar( char *grammarString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "addGrammar";
		if( adminGrammar_ != NULL ||
		// Create supporting module
		( adminGrammar_ = new AdminGrammar( this, this, commonVariables() ) ) != NULL )
			return adminGrammar_->addGrammar( grammarString );

		return startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin grammar module" );
		}

	WordItem *AdminItem::predefinedAdjectiveBusyWordItem()
		{
		if( adminGrammar_ != NULL )
			return adminGrammar_->predefinedAdjectiveBusyWordItem();

		return NULL;
		}

	WordItem *AdminItem::predefinedAdjectiveDoneWordItem()
		{
		if( adminGrammar_ != NULL )
			return adminGrammar_->predefinedAdjectiveDoneWordItem();

		return NULL;
		}

	WordItem *AdminItem::predefinedAdjectiveInvertedWordItem()
		{
		if( adminGrammar_ != NULL )
			return adminGrammar_->predefinedAdjectiveInvertedWordItem();

		return NULL;
		}

	WordItem *AdminItem::predefinedNounInterfaceLanguageWordItem()
		{
		if( adminGrammar_ != NULL )
			return adminGrammar_->predefinedNounInterfaceLanguageWordItem();

		return NULL;
		}

	WordItem *AdminItem::predefinedNounPasswordWordItem()
		{
		if( adminGrammar_ != NULL )
			return adminGrammar_->predefinedNounPasswordWordItem();

		return NULL;
		}

	WordItem *AdminItem::predefinedNounSolveLevelWordItem()
		{
		if( adminGrammar_ != NULL )
			return adminGrammar_->predefinedNounSolveLevelWordItem();

		return NULL;
		}

	WordItem *AdminItem::predefinedNounSolveMethodWordItem()
		{
		if( adminGrammar_ != NULL )
			return adminGrammar_->predefinedNounSolveMethodWordItem();

		return NULL;
		}

	WordItem *AdminItem::predefinedNounSolveStrategyWordItem()
		{
		if( adminGrammar_ != NULL )
			return adminGrammar_->predefinedNounSolveStrategyWordItem();

		return NULL;
		}

	WordItem *AdminItem::predefinedVerbLoginWordItem()
		{
		if( adminGrammar_ != NULL )
			return adminGrammar_->predefinedVerbLoginWordItem();

		return NULL;
		}


	// Protected imperative functions

	ResultType AdminItem::executeImperative( bool initializeVariables, unsigned short executionListNr, unsigned short imperativeParameter, unsigned short specificationWordParameter, unsigned short specificationWordTypeNr, unsigned long endSolveProgress, char *executionString, WordItem *generalizationWordItem, WordItem *specificationWordItem, ReadItem *startRelationWordReadItem, ReadItem *endRelationWordReadItem, SelectionItem *executionSelectionItem, SelectionItem *actionSelectionItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "executeImperative";
		if( adminImperative_ != NULL ||
		// Create supporting module
		( adminImperative_ = new AdminImperative( this, this, commonVariables() ) ) != NULL )
			return adminImperative_->executeImperative( initializeVariables, executionListNr, imperativeParameter, specificationWordParameter, specificationWordTypeNr, endSolveProgress, executionString, generalizationWordItem, specificationWordItem, startRelationWordReadItem, endRelationWordReadItem, executionSelectionItem, actionSelectionItem );

		return startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin imperative module" );
		}


	// Protected justification functions

	ResultType AdminItem::writeJustificationSpecification( char *justificationSentenceString, SpecificationItem *justificationSpecificationItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeJustificationSpecification";
		if( adminJustification_ != NULL ||
		// Create supporting module
		( adminJustification_ = new AdminJustification( this, commonVariables() ) ) != NULL )
			return adminJustification_->writeJustificationSpecification( justificationSentenceString, justificationSpecificationItem );

		return startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin justification module" );
		}


	// Protected language functions

	ResultType AdminItem::authorizeLanguageWord( WordItem *authorizationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "authorizeLanguageWord";
		if( adminLanguage_ != NULL )
			return adminLanguage_->authorizeLanguageWord( authorizationWordItem );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin language module isn't created yet" );
		}

	ResultType AdminItem::createGrammarLanguage( char *languageNameString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "createGrammarLanguage";
		if( adminLanguage_ != NULL ||
		// Create supporting module
		( adminLanguage_ = new AdminLanguage( this, this, commonVariables() ) ) != NULL )
			return adminLanguage_->createGrammarLanguage( languageNameString );

		return startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin language module" );
		}

	ResultType AdminItem::createInterfaceLanguage( char *languageNameString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "createInterfaceLanguage";
		if( adminLanguage_ != NULL ||
		// Create supporting module
		( adminLanguage_ = new AdminLanguage( this, this, commonVariables() ) ) != NULL )
			return adminLanguage_->createInterfaceLanguage( languageNameString );

		return startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin language module" );
		}

	ResultType AdminItem::createLanguageSpecification( WordItem *languageWordItem, WordItem *languageNounWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "createLanguageSpecification";
		if( adminLanguage_ != NULL )
			return adminLanguage_->createLanguageSpecification( languageWordItem, languageNounWordItem );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin language module isn't created yet" );
		}

	ResultType AdminItem::assignGrammarAndInterfaceLanguage( unsigned short newLanguageNr )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "assignGrammarAndInterfaceLanguage";
		if( adminLanguage_ != NULL )
			return adminLanguage_->assignGrammarAndInterfaceLanguage( newLanguageNr );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin language module isn't created yet" );
		}

	ResultType AdminItem::assignGrammarAndInterfaceLanguage( char *languageNameString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "assignInterfaceLanguage";
		if( adminLanguage_ != NULL )
			return adminLanguage_->assignGrammarAndInterfaceLanguage( languageNameString );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin language module isn't created yet" );
		}


	// Protected query functions

	void AdminItem::initializeQueryStringPosition()
		{
		if( adminQuery_ != NULL )
			adminQuery_->initializeQueryStringPosition();
		}

	ResultType AdminItem::writeTextWithPossibleQueryCommands( unsigned short promptTypeNr, char *textString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeTextWithPossibleQueryCommands";
		if( adminQuery_ != NULL ||
		// Create supporting module
		( adminQuery_ = new AdminQuery( this, this, commonVariables() ) ) != NULL )
			return adminQuery_->writeTextWithPossibleQueryCommands( promptTypeNr, textString );

		return startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin query module" );
		}

	ResultType AdminItem::executeQuery( bool suppressMessage, bool returnToPosition, bool writeQueryResult, unsigned short promptTypeNr, char *queryString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "executeQuery";
		if( adminQuery_ != NULL ||
		// Create supporting module
		( adminQuery_ = new AdminQuery( this, this, commonVariables() ) ) != NULL )
			return adminQuery_->executeQuery( suppressMessage, returnToPosition, writeQueryResult, promptTypeNr, queryString );

		return startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin query module" );
		}


	// Protected read functions

	ResultType AdminItem::readExamplesFile( char *examplesFileNameString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "readFile";
		if( adminRead_ != NULL )
			return adminRead_->readExamplesFile( examplesFileNameString );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin read module isn't created yet" );
		}

	ResultType AdminItem::readAndExecute()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "interact";
		if( adminRead_ != NULL )
			return adminRead_->readAndExecute();

		return startErrorInItem( functionNameString, NULL, NULL, "The admin read module isn't created yet" );
		}

	ResultType AdminItem::getUserInput( bool isPassword, bool isQuestion, bool isText, char *promptInputString, char *readString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "getUserInput";
		if( adminRead_ != NULL )
			return adminRead_->readLine( isPassword, isQuestion, isText, NO_SENTENCE_NR, promptInputString, readString );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin read module isn't created yet" );
		}

	FileResultType AdminItem::readInfoFile( bool reportErrorIfFileDoesNotExist, char *infoFileNameString )
		{
		FileResultType fileResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "readInfoFile";

		if( adminRead_ != NULL )
			return adminRead_->readInfoFile( reportErrorIfFileDoesNotExist, infoFileNameString );

		fileResult.result = startErrorInItem( functionNameString, NULL, NULL, "The admin read module isn't created yet" );
		return fileResult;
		}


	// Protected read create words functions

	void AdminItem::deleteReadList()
		{
		if( readList != NULL )
			readList->deleteList();
		}

	bool AdminItem::createImperativeSentence()
		{
		if( readList != NULL )
			return readList->createImperativeSentence();

		return false;
		}

	bool AdminItem::hasPassedGrammarIntegrityCheck()
		{
		if( readList != NULL )
			return readList->hasPassedGrammarIntegrityCheck();

		return false;
		}

	ReadResultType AdminItem::createReadWord( unsigned short wordOrderNr, unsigned short wordTypeNr, char *textString, WordItem *readWordItem )
		{
		ReadResultType readResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "createReadWord";
		if( adminReadCreateWords_ != NULL )
			return adminReadCreateWords_->createReadWord( wordOrderNr, wordTypeNr, 0, textString, readWordItem );

		readResult.result = startErrorInItem( functionNameString, NULL, NULL, "The admin read words module isn't created yet" );
		return readResult;
		}

	ReadResultType AdminItem::createReadWords( char *grammarString )
		{
		ReadResultType readResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "createReadWords";

		if( adminReadCreateWords_ != NULL )
			return adminReadCreateWords_->createReadWords( grammarString );

		readResult.result = startErrorInItem( functionNameString, NULL, NULL, "The admin read words module isn't created yet" );
		return readResult;
		}

	ReadResultType AdminItem::getWordInfo( bool skipDoubleQuotes, size_t startWordPosition, char *wordString )
		{
		ReadResultType readResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "getWordInfo";

		if( adminReadCreateWords_ != NULL )
			return adminReadCreateWords_->getWordInfo( skipDoubleQuotes, startWordPosition, wordString );

		readResult.result = startErrorInItem( functionNameString, NULL, NULL, "The admin read words module isn't created yet" );
		return readResult;
		}

	WordResultType AdminItem::createWord( unsigned short previousWordDefiniteArticleParameter, unsigned short previousWordIndefiniteArticleParameter, unsigned short wordTypeNr, unsigned short wordParameter, size_t wordLength, char *wordString )
		{
		WordResultType wordResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "createWord";

		if( adminReadCreateWords_ != NULL ||
		// Create supporting module
		( adminReadCreateWords_ = new AdminReadCreateWords( this, this, commonVariables() ) ) != NULL )
			return adminReadCreateWords_->createWord( previousWordDefiniteArticleParameter, previousWordIndefiniteArticleParameter, wordTypeNr, wordParameter, wordLength, wordString );

		wordResult.result = startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin read words module" );
		return wordResult;
		}

	ReadItem *AdminItem::firstActiveReadItem()
		{
		if( readList != NULL )
			return readList->firstActiveReadItem();

		return NULL;
		}

	ReadItem *AdminItem::firstDeactiveReadItem()
		{
		if( readList != NULL )
			return readList->firstDeactiveReadItem();

		return NULL;
		}


	// Protected read sentence functions

	void AdminItem::dontShowConclusions()
		{
		if( adminReadSentence_ != NULL )
			adminReadSentence_->dontShowConclusions();
		}

	void AdminItem::dontDeletedRollbackInfo()
		{
		if( adminReadSentence_ != NULL )
			adminReadSentence_->dontDeletedRollbackInfo();
		}

	bool AdminItem::areReadItemsStillValid()
		{
		if( adminReadSentence_ != NULL )
			return adminReadSentence_->areReadItemsStillValid();

		return false;
		}

	bool AdminItem::isPossessivePronounStructure()
		{
		if( adminReadSentence_ != NULL )
			return adminReadSentence_->isPossessivePronounStructure();

		return false;
		}

	ResultType AdminItem::processReadSentence( char *readString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "processReadSentence";
		if( adminReadSentence_ != NULL ||
		// Create supporting module
		( adminReadSentence_ = new AdminReadSentence( this, this, commonVariables() ) ) != NULL )
			return adminReadSentence_->processReadSentence( readString );

		return startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin read sentence module" );
		}


	// Protected selection functions

	ResultType AdminItem::checkForDuplicateSelection()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkForDuplicateSelection";
		if( adminSelection_ != NULL )
			return adminSelection_->checkForDuplicateSelection();

		return startErrorInItem( functionNameString, NULL, NULL, "The admin selection module isn't created yet" );
		}

	ResultType AdminItem::createSelectionTextPart( bool isAction, bool isNewStart, unsigned short selectionLevel, unsigned short selectionListNr, unsigned short imperativeParameter, char *specificationString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "createSelectionTextPart";
		if( adminSelection_ != NULL ||
		// Create supporting module
		( adminSelection_ = new AdminSelection( this, this, commonVariables() ) ) != NULL )
			return adminSelection_->createSelectionPart( isAction, false, false, false, false, isNewStart, false, false, false, selectionLevel, selectionListNr, imperativeParameter, NO_PREPOSITION_PARAMETER, NO_WORD_PARAMETER, WORD_TYPE_TEXT, WORD_TYPE_TEXT, WORD_TYPE_UNDEFINED, NO_CONTEXT_NR, NO_CONTEXT_NR, NO_CONTEXT_NR, 0, NULL, NULL, NULL, specificationString );

		return startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin selection module" );
		}

	ResultType AdminItem::createSelectionPart( bool isAction, bool isAssignedOrClear, bool isDeactive, bool isArchived, bool isFirstComparisonPart, bool isNewStart, bool isNegative, bool isPossessive, bool isValueSpecification, unsigned short selectionLevel, unsigned short selectionListNr, unsigned short imperativeParameter, unsigned short prepositionParameter, unsigned short specificationWordParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int nContextRelations, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "createSelectionPart";
		if( adminSelection_ != NULL ||
		// Create supporting module
		( adminSelection_ = new AdminSelection( this, this, commonVariables() ) ) != NULL )
			return adminSelection_->createSelectionPart( isAction, isAssignedOrClear, isDeactive, isArchived, isFirstComparisonPart, isNewStart, isNegative, isPossessive, isValueSpecification, selectionLevel, selectionListNr, imperativeParameter, prepositionParameter, specificationWordParameter, generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, generalizationContextNr, specificationContextNr, relationContextNr, nContextRelations, generalizationWordItem, specificationWordItem, relationWordItem, specificationString );

		return startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin selection module" );
		}

	ResultType AdminItem::executeSelections()
		{
		if( adminSelection_ != NULL )
			return adminSelection_->executeSelection( MAX_PROGRESS, NULL );

		return commonVariables()->result;
		}

	ResultType AdminItem::executeSelection( unsigned long endSolveProgress, SelectionItem *actionSelectionItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "executeSelection";
		if( adminSelection_ != NULL )
			return adminSelection_->executeSelection( endSolveProgress, actionSelectionItem );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin selection module isn't created yet" );
		}


	// Protected solve functions

	void AdminItem::clearCurrentSolveProgress()
		{
		if( adminSolve_ != NULL )
			adminSolve_->clearCurrentSolveProgress();
		}

	void AdminItem::deleteScoreList()
		{
		if( scoreList != NULL )
			scoreList->deleteList();
		}

	ResultType AdminItem::canWordBeSolved( WordItem *solveWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "canWordBeSolved";
		if( adminSolve_ != NULL )
			return adminSolve_->canWordBeSolved( solveWordItem );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin solve module isn't created yet" );
		}

	ResultType AdminItem::solveWord( unsigned long endSolveProgress, WordItem *solveWordItem, SelectionItem *actionSelectionItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "solveWord";
		if( adminSolve_ != NULL ||
		// Create supporting module
		( adminSolve_ = new AdminSolve( this, this, commonVariables() ) ) != NULL )
			return adminSolve_->solveWord( endSolveProgress, solveWordItem, actionSelectionItem );

		return startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin solve module" );
		}

	ResultType AdminItem::findPossibilityToSolveWord( bool isAddScores, bool isInverted, bool duplicatesAllowed, bool prepareSort, unsigned short solveStrategyParameter, WordItem *solveWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "findPossibilityToSolveWord";
		if( adminSolve_ != NULL )
			return adminSolve_->findPossibilityToSolveWord( isAddScores, isInverted, duplicatesAllowed, prepareSort, solveStrategyParameter, solveWordItem );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin solve module isn't created yet" );
		}

	SelectionResultType AdminItem::checkCondition( SelectionItem *conditionSelectionItem )
		{
		SelectionResultType selectionResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "checkCondition";

		if( adminSolve_ != NULL ||
		// Create supporting module
		( adminSolve_ = new AdminSolve( this, this, commonVariables() ) ) != NULL )
			return adminSolve_->checkCondition( conditionSelectionItem );

		selectionResult.result = startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin solve module" );
		return selectionResult;
		}


	// Protected specification functions

	void AdminItem::initializeLinkedWord()
		{
		if( adminSpecification_ != NULL )
			adminSpecification_->initializeLinkedWord();
		}

	void AdminItem::initializeAdminSpecificationVariables()
		{
		if( adminSpecification_ != NULL )
			adminSpecification_->initializeAdminSpecificationVariables();
		}

	bool AdminItem::isUserSentencePossessive()
		{
		if( adminReadSentence_ != NULL )
			return adminReadSentence_->isUserSentencePossessive();

		return false;
		}

	CollectionResultType AdminItem::addUserSpecifications( bool initializeVariables, bool isAction, bool isAssignment, bool isConditional, bool isDeactive, bool isArchived, bool isExclusive, bool isNewStart, bool isPossessive, bool isSpecificationGeneralization, unsigned short prepositionParameter, unsigned short questionParameter, unsigned short selectionLevel, unsigned short selectionListNr, unsigned short imperativeParameter, unsigned short specificationWordParameter, unsigned int specificationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationPronounContextNr, ReadItem *generalizationWordItem, ReadItem *startSpecificationReadItem, ReadItem *endSpecificationReadItem, ReadItem *startRelationReadItem, ReadItem *endRelationWordReadItem )
		{
		CollectionResultType collectionResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addUserSpecifications";

		if( adminSpecification_ != NULL ||
		// Create supporting module
		( adminSpecification_ = new AdminSpecification( this, this, commonVariables() ) ) != NULL )
			return adminSpecification_->addUserSpecifications( initializeVariables, isAction, isAssignment, isConditional, isDeactive, isArchived, isExclusive, isNewStart, isPossessive, isSpecificationGeneralization, prepositionParameter, questionParameter, selectionLevel, selectionListNr, imperativeParameter, specificationWordParameter, specificationCollectionNr, generalizationContextNr, specificationContextNr, relationPronounContextNr, generalizationWordItem, startSpecificationReadItem, endSpecificationReadItem, startRelationReadItem, endRelationWordReadItem );

		collectionResult.result = startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin specification module" );
		return collectionResult;
		}

	SpecificationResultType AdminItem::addSpecification( bool isAssignment, bool isDeactive, bool isArchived, bool isExclusive, bool isNegative, bool isPossessive, bool isSelfGenerated, bool isSpecificationGeneralization, bool isValueSpecification, unsigned short prepositionParameter, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addSpecification";

		if( adminSpecification_ != NULL ||
		// Create supporting module
		( adminSpecification_ = new AdminSpecification( this, this, commonVariables() ) ) != NULL )
			return adminSpecification_->addSpecification( isAssignment, false, isDeactive, isArchived, isExclusive, isNegative, isPossessive, false, isSelfGenerated, isSpecificationGeneralization, isValueSpecification, prepositionParameter, questionParameter, generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, generalizationCollectionNr, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, nContextRelations, specificationJustificationItem, generalizationWordItem, specificationWordItem, relationWordItem, specificationString );

		specificationResult.result = startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin specification module" );
		return specificationResult;
		}

	SpecificationResultType AdminItem::addSpecificationWithAuthorization( bool isAssignment, bool isConditional, bool isDeactiveAssignment, bool isArchivedAssignment, bool isExclusive, bool isNegative, bool isPossessive, bool isSelection, bool isSpecificationGeneralization, bool isValueSpecification, unsigned short prepositionParameter, unsigned short questionParameter, unsigned short generalizationWordTypeNr, unsigned short specificationWordTypeNr, unsigned short relationWordTypeNr, unsigned int generalizationCollectionNr, unsigned int specificationCollectionNr, unsigned int relationCollectionNr, unsigned int generalizationContextNr, unsigned int specificationContextNr, unsigned int relationContextNr, unsigned int nContextRelations, JustificationItem *specificationJustificationItem, WordItem *generalizationWordItem, WordItem *specificationWordItem, WordItem *relationWordItem, char *specificationString )
		{
		SpecificationResultType specificationResult;
		char functionNameString[FUNCTION_NAME_LENGTH] = "addSpecificationWithAuthorization";

		if( specificationWordItem == commonVariables()->predefinedNounGrammarLanguageWordItem ||
		specificationWordItem == predefinedNounInterfaceLanguageWordItem() )
			{
			if( adminLanguage_ != NULL )
				return adminLanguage_->addSpecificationWithAuthorization( isAssignment, isConditional, isDeactiveAssignment, isArchivedAssignment, isExclusive, isNegative, isPossessive, isSelection, isSpecificationGeneralization, isValueSpecification, prepositionParameter, questionParameter, generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, generalizationCollectionNr, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, nContextRelations, specificationJustificationItem, generalizationWordItem, specificationWordItem, relationWordItem, specificationString );
			else
				startErrorInItem( functionNameString, NULL, NULL, "The admin language module isn't created yet" );
			}
		else
			{
			if( adminAuthorization_ != NULL )
				return adminAuthorization_->addSpecificationWithAuthorization( isAssignment, isConditional, isDeactiveAssignment, isArchivedAssignment, isExclusive, isNegative, isPossessive, isSelection, isSpecificationGeneralization, isValueSpecification, prepositionParameter, questionParameter, generalizationWordTypeNr, specificationWordTypeNr, relationWordTypeNr, generalizationCollectionNr, specificationCollectionNr, relationCollectionNr, generalizationContextNr, specificationContextNr, relationContextNr, nContextRelations, specificationJustificationItem, generalizationWordItem, specificationWordItem, relationWordItem, specificationString );
			else
				startErrorInItem( functionNameString, NULL, NULL, "The admin authorization module isn't created yet" );
			}

		specificationResult.result = commonVariables()->result;
		return specificationResult;
		}

	WordItem *AdminItem::userSentenceGeneralizationWordItem()
		{
		if( adminSpecification_ != NULL )
			return adminSpecification_->userSentenceGeneralizationWordItem();

		return NULL;
		}


	// Protected write functions

	void AdminItem::initializeAdminWriteVariables()
		{
		if( adminWrite_ != NULL )
			adminWrite_->initializeAdminWriteVariables();
		}

	ResultType AdminItem::answerQuestions()
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "answerQuestions";
		if( adminWrite_ != NULL )
			return adminWrite_->answerQuestions();

		return startErrorInItem( functionNameString, NULL, NULL, "The admin write module isn't created yet" );
		}

	ResultType AdminItem::integrityCheck( bool isQuestion, char *integrityCheckSentenceString )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeWordsFailedForGrammarIntegrityCheck";
		if( adminWrite_ != NULL ||
		// Create supporting module
		( adminWrite_ = new AdminWrite( this, this, commonVariables() ) ) != NULL )
			return adminWrite_->integrityCheck( isQuestion, integrityCheckSentenceString );

		return startErrorInItem( functionNameString, NULL, NULL, "I failed to create the admin write module" );
		}

	ResultType AdminItem::writeJustificationReport( WordItem *justificationWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeJustificationReport";
		if( adminWrite_ != NULL )
			return adminWrite_->writeSelfGeneratedInfo( false, true, true, true, true, NULL, justificationWordItem );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin write module isn't created yet" );
		}

	ResultType AdminItem::writeSelfGeneratedInfo( bool writeSelfGeneratedConclusions, bool writeSelfGeneratedAssumptions, bool writeSelfGeneratedQuestions )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeSelfGeneratedInfo";
		if( adminWrite_ != NULL )
			return adminWrite_->writeSelfGeneratedInfo( writeSelfGeneratedConclusions, writeSelfGeneratedAssumptions, writeSelfGeneratedQuestions );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin write module isn't created yet" );
		}

	ResultType AdminItem::writeInfoAboutWord( bool writeCurrentSentenceOnly, bool writeUserSpecifications, bool writeSelfGeneratedConclusions, bool writeSelfGeneratedAssumptions, bool writeUserQuestions, bool writeSelfGeneratedQuestions, bool writeSpecificationInfo, bool writeRelatedInfo, char *integrityCheckSentenceString, WordItem *writeWordItem )
		{
		char functionNameString[FUNCTION_NAME_LENGTH] = "writeInfoAboutWord";
		if( adminWrite_ != NULL )
			return adminWrite_->writeInfoAboutWord( writeCurrentSentenceOnly, false, writeUserSpecifications, writeSelfGeneratedConclusions, writeSelfGeneratedAssumptions, writeUserQuestions, writeSelfGeneratedQuestions, writeSpecificationInfo, writeRelatedInfo, integrityCheckSentenceString, writeWordItem );

		return startErrorInItem( functionNameString, NULL, NULL, "The admin write module isn't created yet" );
		}


	// Public functions

	bool AdminItem::hasRequestedRestart()
		{
		if( adminImperative_ != NULL )
			return adminImperative_->hasRequestedRestart();

		return false;
		}

	ResultType AdminItem::interact()
		{
		if( commonVariables() != NULL &&
		commonVariables()->result != RESULT_SYSTEM_ERROR )
			{
			readAndExecute();
			commonVariables()->result = RESULT_OK;	// Ignore RESULT_ERROR. Application will only exit on system error
			return RESULT_OK;						// Application will not exit on a normal error
			}

		return RESULT_SYSTEM_ERROR;
		}

/*************************************************************************
 *
 *	"Listen to me, all you in the distant lands!
 *	Pay attentation, you who are far away!
 *	The Lord called me before my birth;
 *	from within the womb he called me by name." (Psalm 49:1)
 *
 *************************************************************************/
